# v7.11 tidy table + original dealer size

- The Dealer is back at his original size/position (the v7.5 push-back is gone: GHOST_BACK = 0); the cinematic table view keeps the camera about as far from him as normal play.
- Tidy table: item slots re-spaced (136 px, player row y596, dealer row y412), every item squared up (long items point along the depth axis), items drawn 14% smaller, shells laid in ONE straight row (y452) clear of the gun and both item rows, no random rotation.
- Table lines: plank seams widen with distance and the fine grain fades, so thin lines no longer alias/swim when the camera moves.
- Checked only on early frames of the round-start cinematic (4 shells, handcuffs, magnifier); a full 12-item table and the dealer's own item row were not reviewed.

# v7.10 fixes from play-testing

- Cinematic (round start): the camera now glides to ONE fixed pose and holds perfectly still (no orbit, no handheld drift, no item-landing shake); the Dealer holds still (no per-item gesture, cloth springs frozen); the bump-mapping fades with distance so the table lines can't shimmer. Verified: camera eye identical [0, 1.33, 1.16] at every frame while the drop plays.
- The grey 'light from the lens' beam was the magnifier's glass: a 1-unit-long glass cylinder. It is now a thin disc. The lamp's light cones and the god-ray post pass are off during the cinematic (god rays removed), lens aberration off.
- Achievement unlock: small card, top-right under the help/pause buttons (~210 px wide), hidden during cinematics. Not captured on a screenshot (no unlock was triggered).

# v7.9 graphics + hand bones

- Hands: 9 extra half-angle 'blend' bones per hand (proximal + middle joint of every finger, thumb MCP): 20 -> 29 joints (limit 32). Vertices around a joint hand part of their parent/child weight to the helper, which bends half as much, so knuckles roll instead of creasing. Built in tools/build-fps-arms.py, palette in `Rig.skinFull` (hands.js); the grip solver does not see them. hands.test 210/212, hand-physics 8/8.
- Materials: procedural bump mapping on the table wood (grain + plank relief) and wall plaster, lacquer fresnel + tight candle glints, hemisphere ambient, 9-tap rotated soft shadows.
- Post: depth of field (peripheral blur always, focus band tightens during the cinematics) and light shafts from the lamp, on top of the existing bloom/FXAA/grade (postQ >= 2 only; auto-quality still drops it on slow devices).
- Honest limits: judged only on software-rendered stills; not measured on a phone (shadow taps went 5 -> 9, two extra quarter-res blur passes); no SSAO, no real reflections, no new textures.

# v7.7 physics pass

- Items on the table (renderer.js / stage3d.js): each item now drops with a tumble (tilt + angular velocity), bounces with a restitution per material (glass .2, can .3, metal .3-.5, soft .1), skids a little and settles onto its slot through damped springs; every bounce reports its impact speed so sound and camera thud scale with it. Slots/positions are unchanged.
- Rage slam: the shock now travels outwards from the fists (nearer items jump first), each item tumbles and lands with its own sound; shells (Physics bodies) still get kicked.
- The Ghost's robe and hood are spring-damper chains driven by how his body moves (head-pin velocity, lean change) plus a faint draught: they lag, overshoot and settle on their own instead of a canned sway.
- Not done: gun / hand-item physics, item-item collision on the table, cloth on the player's side, a performance pass on a real phone. Only still frames of the new item landing were checked (no motion review).

# v7.6 cinematic + voice + rage (partial overhaul)

- Round start: the camera glides from the player's view down to the table, the Dealer puts the items down one by one (reach gesture, then drop), each item lands with its own material sound + a small camera thud + dust, then the camera glides back. HUD and the player's hands step aside during the glide. Repeats every round. (`Show.reload`, `Sc.cine`, camera blend in `stage3d.js`; skipped when reduced-motion is on.)
- Dealer voice: still SYNTHESISED (no recorded voice and no speech engine in this build) but rebuilt: deeper, hoarse (vocal fry, jitter, rasp), slap-back echo, and a different performance per mood (boom / excited / whisper / murmur / laugh / rage roar). Each line category has a default mood.
- New dialogue (EN + AR, `data/dealer-lines.js`), no immediate repeats; the dialogue box is small, sits beside his head, fades in/out.
- Dealer's loss: new rage sequence (stare + red eye glow, hands rise, pause, slam, shake, items hop, roar, recover) replaces the old collapse. Captured frame by frame in the real game (screenshots/dealer-rage-*.png) using the slow-motion test hook `window.__timeScale` (tests/rage-shots.js); fixes made from those captures: red wash too strong, raise too high (dealer vanished), slam lean too deep (camera inside the cloth).
- Not done: texture/lighting/DOF overhaul, footsteps/doors/drawers/wind audio, spatial audio, facial expressions (the ghost has no face), per-drop physical item collisions beyond the existing drop.
- Tests: `tests/cine-shots.js`, `tests/cine-video.js`; `screenshots/` holds real captures of the round-start cinematic.

# v7.5 Ghost motion

- The Ghost's body now sits 0.5 model units behind the head pin (`GHOST_BACK` in `stage3d.js`) so the gun and items are held out in front of it instead of inside the robe.
- Smoothing: the head pin is low-passed every frame, and the torso lean starts from the previous frame's value (leans in at once when a hand needs to reach, eases back slowly).
- New tests: `tests/ghost-view.js` (close-up screenshots), `tests/ghost-items.js` (dealer-only item flow, 2 items: pickup > hold > release, no console errors).
- Not verified: finger-level grip on the gun at screenshot resolution, reach to far table items, phone performance.

# v7.4 the Ghost is the only dealer

- The dealer is now the supplied `ghost-scary.zip` model. It arrived as ONE static mesh (228k vertices, no skeleton, no animation), so `tools/build-ghost-dealer.py` builds everything from scratch: decimated to ~40k vertices with baked vertex colours, scaled to the dealer's height, and given a NEW 22-bone skeleton authored for this body (trunk + head + jaw lip + hood tip, two 3-bone arms for the gun IK, four hanging robe chains). Skin weights are computed from the shape (height bands, arm-chain distance, robe sectors). Output goes straight into `data/models.js`.
- Motion: the existing dealer animation (breathing, lean, head tracking, IK arms, gun handling, speech jaw) drives the new bones; on top, the robe chains and the hood tip sway continuously with follow-through (`stage3d.js`, "the Ghost's own secondary motion").
- Removed: the old Hooded Skull model and the other 17 dealers (catalogue, tints, gear), plus the 5 achievements that needed several dealers. Weapon looks are untouched. `Selected dealer` in old saves falls back to the Ghost.
- Limits: the ghost has no hands of its own, so the supplied gloved hands still appear at its wrists when it holds the gun; its jaw is a soft lip movement of the hood (no real mouth); eye glow positions were set by measurement, not by eye, and I only looked at software-rendered screenshots.

# v7.3 first-person arms (fpsarms.fbx)

- Both player and dealer hands are now the supplied `first-person-arms` model (gloved hands, real 24-bone skeleton per arm, the file's own skin weights, colour x AO texture at 1024 px). Generated by `tools/build-fps-arms.py` -> `data/fps-arms.js` (loaded right after `data/br-assets.js`; remove that one `<script>` line in `index.html` to get the previous hands back).
- The new rig is mapped onto the existing 20-role hand rig (arm/elbow/wrist/palm -> wrist; point/middle/ring/pink 1-3 -> index..pinky 1-3, tip bone merged; thumb1-3), baked into the old grip pose and aligned to the old gun sockets, so the existing grip solver, 8 hand states, hand physics, emotes and slap keep working unchanged.
- Tests: `hands.test.js` 210/212 (2 fail: R/medicine and R/spray at the smallest hand scale 0.24, ~1 cm capsule overlap vs the 0.8 cm limit; the in-game scale 0.26 passes), `hand-physics.test.js` 8/8, `grip-3d.js` and `br-shot.js` ran in a real (software WebGL) browser with no console errors.
- Not done / limits: the game has a shotgun (no pistol) so no pistol grip was made; the file's normal and roughness maps are not used (the renderer has no normal mapping); the fingers' bend axes are one hinge axis per finger (thumb has no full opposition); hand look was checked only on software-rendered screenshots, not on a phone; forearm is cut short behind the wrist and capped.

# v7.1 hands & physics

- The player's forearms/sleeves are gone: only the hands are drawn (set `Stage3D.playerArms = true` to bring the arms back).
- Hand dynamics: free hands follow their animation through a lightly under-damped spring (weight, tiny overshoot). Tests: `tests/hand-physics.test.js` (8 checks).
- Hands are moving colliders: a moving hand shoves loose shells, coins, bottles and cans on the table (momentum transfer, wakes settled objects, soft knock sound). Shells and cans now roll (spin follows speed, lower rolling friction).
- Not tested on a phone. The hand-vs-object push was verified in the unit test and the game ran without errors, but I did not capture a screenshot of a hand visibly pushing an object.

# v7 graphics pass

- New post-processing pipeline in `scripts/gl3d.js`: offscreen scene buffer, bright-pass + two-level gaussian bloom (candles, eyes, light shafts glow), FXAA anti-aliasing (the old renderer had none), chromatic aberration at the corners, filmic grade (cold shadows / warm candle light, S-curve, soft highlight roll-off), vignette and film grain. Applies to the menu and the room.
- Adaptive: if the device averages under ~37 fps for a while it drops 2 -> 1 (no 2nd bloom level / FXAA / aberration) -> 0 (off) by itself. Tunable at runtime via `GL3D.fx` (bloom, thr, vig, grain, ca, grade); disable with `GL3D.autoQ=false; GL3D.postQ=0`.
- Tested only in a software-rendered desktop browser (real phone GPUs not tested), so the cost on your phone is unmeasured. This is a self-written WebGL1 engine: no PBR/SSAO/real-time global illumination yet.

# Phase B ("ULTIMATE DEVELOPMENT PROMPT") — honest status

**Done and tested in a real browser (screenshots taken) / node tests:**
- New table: your supplied Old_Table model, textured, fitted to the room (`tools/build-table.js` -> `data/table-assets.js`).
- Animated menu: slow drifting camera, dust, candle flicker, grin/sphere faces as MENU-ONLY art (never in the play room).
- ONE emote button -> compact translucent menu (all old emotes kept + clap, victory, mock, laugh, point, refuse, wave, welcome, anger, surrender, thumbs, challenge, wonder, ok, knock). 16 real hand-skeleton clips, no GIFs. Online the gesture shows to every player as a bubble on the match screen (the online screen is 2D).
- SLAP: after the Dealer survives a LIVE self-shot, a "SLAP" button appears for 3.5 s (never after a blank, a blocked or a fatal shot). Hand swing with a contact frame, camera shake, slap sound, and six personality-based Dealer reactions (shock, anger, laugh, holding his face, threat, shout) chosen from each dealer's demeanour, each with its own dialogue lines (EN/AR).
- SLAP BACK: after YOUR survived LIVE self-shot the Dealer may slap you (chance follows his temper): arm sweep, small camera nudge + shake, sound, line of dialogue. Purely cosmetic - no HP change.
- Online: the slap is server-validated (`M.slap` in `scripts/mp-engine.js`, `slap` handler in `server/rooms.js`): only another living seat, only once, only right after a survived live self-shot, inside a 6 s window. `tests/slap.test.js` = 10 checks. Tests: logic 281, v6 318, hands 212, mp-server 183, slap 10.

**NOT done / limits (no pretending):**
- **ZOKS emote: not found anywhere in the project files you gave me, so it was neither changed nor recreated. Tell me where it is defined and I will wire it in.**
- The Dealer model in the RAR ("The Dealer Showcase.rar") could not be opened here (no unrar/7z), so the menu background is procedural, not that model.
- Dealers still share one skeleton (different masks/gear/tint/personality/dialogue, but not fully different bodies/faces); per-dealer full animation sets are not done (only the shared set + the slap reactions).
- Items are not all redone to one PBR quality bar; no designated visual slot markers on the table yet; item placement still uses the old table-clamp logic.
- Slap/emote in multiplayer are shown on the 2D match screen (bubble + shake), not as 3D animation. Not tested over a real network or on phones.
- No separate LOD/memory pass was done.

# v6 "ULTIMATE MEGA UPDATE" — honest status

**Done and tested** (npm test = 280 + 318 + 182 checks, plus real-browser runs):
- Engine rewrite: 50 items (10 free / 40 buyable) with real effects, 11 weapons (10 locked, buyable) with real rule hooks, LIVE SHELL / BLANK SHELL terminology everywhere, shell-count under the HUD (counts only, never the order).
- Economy + saved ownership (no double-buy), 84 achievements, daily/special challenges, save v2 with checksum + backup (detects corruption; it is NOT anti-cheat).
- New main menu (9 buttons) over the live 3D room; Characters / Weapons / Items / Shop screens with rarity, buy, select.
- Dealer AI scores all 50 items; knows fake information from Black Mirror / Whisper Box.
- All 50 item icons and in-3D item models (shape-recipe based), generic use feedback for every item.
- Forced landscape: no "rotate phone" screen; orientation lock is requested, otherwise the UI is rotated with CSS and touches are mapped.
- Settings sliders are direction-fixed for Arabic (RTL).
- **Real multiplayer** (2-4 players, free-for-all): zero-dependency Node WebSocket server (`server/`), server-authoritative engine (`scripts/mp-engine.js`), rooms/codes, reconnect, turn timer, rate limits, hidden-info masking. Verified with 3 real browsers against a real local server and 182 automated checks. Deploy: Dockerfile / render.yaml / fly.toml / `server/README.md`.

**Not finished yet / limits (no pretending):**
- Multiplayer was NOT tested on real phones or over the internet; it needs you to host the server. Online mode uses 18 items and the standard weapon, in a 2D match screen (not the 3D room).
- Dealers: 18 distinct looks (different masks/hats/armour/tint on one shared skinned body, so the SKELETON/animations are shared) with a drag-to-rotate 3D preview. Weapons: 10 attachment-based 3D variants on the shared gun model (no separate rigs/animations per weapon).
- Still pending: the 10 hand-emote animations in single player (emotes exist as a chat feature online), cinematic round/event intros, per-dealer voice synthesis tuning and dialogue packs, weapon preview in the Weapons screen, item hold/use animations beyond the generic feedback, settings screen rebuild.

# THE TALLOW ROOM — mobile horror table game (HTML5 / Canvas / Web Audio)

A turn-based, tension-driven duel against **the Dealer**, a wax-masked host who has loaded a stylized fictional
"Caster" with secret shells (Embers = damage, Ash = blank). Original characters, art, UI, text and sound — nothing is
copied from any other game. Inspired only by the *genre* of tense turn-based table duels.

## Run it
- **Desktop / phone browser:** open `index.html` (works from `file://`, no server, no build step, no external assets).
- **Local server (optional):** `python3 -m http.server 8080` then open `http://localhost:8080`.
- Best in **landscape**. In portrait the game auto-pauses and shows a rotate prompt.
- Audio starts after the first tap (browser autoplay rule).

## How to play
Each round the Caster is loaded; the counts of Embers/Ash are shown, the order is secret.
On your turn: **Aim at Dealer** or **Aim at Self**, then **Fire**; or use an item (**Items**), inspect the Caster (🔍).
Shooting yourself with Ash gives you an extra turn; with an Ember you lose a pulse. Reduce the Dealer's pulses to 0 in each of
3 rounds. Items (13): Magnifier, Handcuffs, Cigarette, Battery, Medicine, Drink can, Lighter, Scrambler, Coin, Rusted Blade (1 damage, cannot kill), Dead Casing (next shell becomes Ash), Pest Spray (wipes opponent charge/knowledge), Coarse Rope (steal an item).
Difficulties: Easy / Normal / Hard / Nightmare (unlocked after a win). Tap items on the table or use the Items panel.

## Features (all implemented and exercised by the tests below)
- **Real 3D (v2):** a self-written WebGL engine (`scripts/gl3d.js`, `scripts/stage3d.js`; no external libraries) draws a 3D room, table, the Caster, 13 item models, the skull-masked Dealer and 3D hands/arms, with point lights, a shadow-mapped lamp, fog, procedural wood/concrete/cloth/skin/wax surfaces, light shafts and glow sprites. The existing animation clips drive the 3D objects (screen coordinates are ray-cast into the world). If WebGL is unavailable or '3D view' is off, the original 2D renderer is used automatically.
- 13 items: magnifier, handcuffs, cigarette, battery, medicine, drink can, lighter, scrambler, coin + new knife, blank, insect spray, rope (each with use animation, sound, 3D model, Dealer AI use).
- Shop (menu): earn Wax by winning rounds, buy items; up to two owned items join your side at the start of a new game.
- Settings sheet with 7 tabs (General / Audio / Video / Controls / Weapon / Interface / Access) — see **v4** below; drag the room to look around.
- Dealer subtitles appear directly under the Dealer's chin and follow the 3D head; subtitle language can differ from the UI language.
- 28 first-person hand states, 51 Dealer clips (idle/face/speech/interaction/special), 19 Caster clips — keyframe clips with
  priorities, interruptibility, events, SFX hooks, pause, fallbacks, manifest validation at boot.
- Dealer item use with full animations; Dealer AI with 4 difficulties.
- Lightweight physics (shells, coin, can, cigarette butt, pill, bottle, cell).
- Fully synthesized audio: SFX (54), ambience, generative music, formant-synth Dealer voice (+ subtitles); independent master/music/ambience/effects volume.
- Menu, HUD, inventory, pause, settings (quality low/medium/high, 30/60 fps, reduced motion, shake, text size, touch size, subtitles, language EN/Arabic with RTL), item archive, 28 tiered achievements + statistics page (v4), endings, save & resume, progression.

## Project layout
```
index.html            all screens
styles/               main, menu, menu-art, gameplay, settings, ui2 (v4 design system) CSS
scripts/              util, game-state (rules engine), dealer-ai, save-manager, progress (stats + achievements), icons (SVG set), hands (v5 skeletal hand system),
                      audio-manager, animation-controller, physics, art (procedural drawing), gl3d/stage3d/rig (3D),
                      renderer, gameplay (presentation director), turn-system, input-manager, accessibility,
                      ui-controller (HUD/menus), ui-extra (settings sheet, achievements, statistics, visual prefs), menu-art, main
data/                 game-data.js, ui-data.js (achievement definitions + v4 strings), animations.js (source of truth), models.js, br-assets.js (v5: the supplied shotgun + hands, baked) + generated *.json manifests
tools/export-manifests.js   regenerates and validates data/*.json
tools/build-br-assets.py    v5: converts the supplied shotgun/hands FBX (tools/br/) into data/br-assets.js
tests/                logic.test.js + hands.test.js (node); Playwright: play-browser, features-browser, ui-features, hud-layout, ui-shots, aim-probe, menu-art, grip-3d, perf-3d,
                      v5: br-states (every weapon state, 100k-case clearance sweep), br-items (every item through the real game flow), br-shot, hands-lab (close-up viewer)
assets/, audio/       placeholders only (README.txt): art and audio are generated procedurally at runtime
```
Rules engine (`Engine`) is deterministic/seeded and independent from the presentation (`Show`), which only narrates events.

## Android (Samsung) packaging
1. **Quickest:** host the folder on any static HTTPS host and "Add to Home screen" in Chrome (fullscreen via the menu button).
2. **WebView app:** Android Studio → Empty Activity. Copy this folder into `app/src/main/assets/tallow/`. In the Activity:
   `webView.settings.javaScriptEnabled = true; domStorageEnabled = true; mediaPlaybackRequiresUserGesture = false;`
   then `webView.loadUrl("file:///android_asset/tallow/index.html")`. Set `android:screenOrientation="sensorLandscape"`,
   use immersive fullscreen flags, and keep `android:hardwareAccelerated="true"`.
   (A WebView/Capacitor build was **not** produced or tested here — instructions only.)
3. **Capacitor:** `npm i @capacitor/core @capacitor/cli @capacitor/android`, `npx cap init`, set `webDir` to this folder, `npx cap add android`, `npx cap sync`.

## Storage notes
Settings, progress and the in-progress run use `localStorage` (key prefix `tallow.`), falling back to memory if blocked. Clearing
site data or private mode loses saves. Corrupt saves are detected and reset with a notice.

## v3 — your GLB assets, real skeleton, physics (this update)
The three supplied files are **the actual game assets** now (converted by `tools/build-models.js` into `data/models.js`, base64, so the game still runs from `file://`; re-run `node tools/build-models.js <folder-with-the-glbs>` to rebuild).
- **`old_rustic_game_table_3d.glb`** → the table (50 parts, vertex-colour wood/iron look kept; a subtle procedural grain is added on top). Scaled uniformly so its top surface is exactly the game's table height; the old slab/legs are gone. Loose bodies (shells, coin, can…) are clamped to this table's measured top rectangle.
- **`decorative_shotgun_3d_animated.glb`** → the Caster. Split into body + fore-end (the fore-end slides when racked). Measured sockets: pistol-grip rear face, fore-end underside, muzzle, ejection port. It lies on its side on the table (resting on its flat side, no floating) and turns upright when held.
- **`hooded_skull_character_3d.glb`** → the Dealer. **The file contains no skeleton, no skin and no usable animation** (80 rigid mesh parts, vertex colours, one turntable rotation). So I authored a real 29-joint skeleton (root, pelvis, spine, chest, neck, head, jaw, 2×[upper arm, forearm, hand, 4 fingers, thumb, upper leg, lower leg, foot]) with joint positions measured from the model's own parts, and computed 4-joint skin weights per vertex (8,628 vertices; blends at shoulders, elbows, wrists, neck, jaw, trunk, knees). Skinning runs on the GPU (3×vec4 joint matrices).
- **Weapon holding:** right hand wraps the grip (palm on the grip's rear face, fingers curled), left hand cups the fore-end from below. Wrist targets come from the gun's measured sockets every frame (not from hand positions copied onto the gun). Arms use two-bone IK with an elbow pole (Dealer: real skeleton IK; player: first-person arm chain). If the Dealer cannot reach, his torso leans over the table (head stays put); if still out of reach the gun is brought to the hand, so the hand never leaves the grip.
- **Dealer animation:** head look/tilt, jaw (talking), breathing, finger curl, lean-in, arm IK – all driven by the existing animation channels. Glowing eyes are additive sprites in the sockets.
- **Physics:** fixed 120 Hz timestep with render interpolation, adaptive sub-stepping (no body moves more than half its radius per sub-step → no tunnelling), per-kind mass/restitution/friction, mass-weighted contacts, rest/sleep state, table-top clamp in world space.
- **Also:** smoothed camera (critically-damped look, smooth-noise shake instead of per-frame random), smaller HUD/menu/banner typography, GL resource-leak check.
- New tests: `tests/logic.test.js` (163 assertions: physics determinism across 30/60/144 fps, no tunnelling, rest pose = original mesh, IK reach/bone-length/clamp, weights normalised), `tests/grip-3d.js` (renders both holders), `tests/perf-3d.js` (no GL object growth, no console errors).

## v3.1 — smoothness (lag + choppy sound)
- **Sound:** all 59 sound effects are rendered once (offline, in the background after the first tap) into small cached buffers; playing one is a single node instead of dozens of live oscillators/filters. The Dealer's voice is rendered off the main thread the first time a line is spoken, then cached. Audio buffer hint is `balanced` (no under-runs when a frame runs long), reverb tail shortened (cheaper convolution), polyphony cap 24.
- **Frame rate:** automatic resolution governor (drops render scale smoothly when frames exceed ~22 ms, recovers when there is headroom), lower pixel budgets per quality tier, shadow map refreshed every 2nd frame, 5-tap instead of 9-tap shadow filter, cheaper wood shader, light shafts and film grain only when there is headroom/High quality.
- Measured: JS+submit cost per frame is ~3.6 ms; GL objects stop growing after start-up; 163 logic tests and 32 browser checks pass. **Not measured on a real phone GPU** (the sandbox only has software WebGL), so the governor thresholds are untuned guesses until you try it on the Samsung.

## v3.2 — image main menu + menu song
- The main menu is now your artwork (`assets/menu-art.jpg`) with invisible, keyboard-focusable hot-spots over its six buttons (Continue / Settings / Shop / Item archive / Achievements / Leave). Because the labels are part of the picture they are Arabic only; screen-reader labels follow the selected language. A small row at the bottom keeps **New Game** (difficulty choice), Credits, Fullscreen and a music on/off button, since the artwork has no buttons for them.
- Animation: a canvas layer draws ~22 shotgun shells that fall (three depth layers, motion-blurred foreground ones), bounce once on the wet floor with sparks and a reflection, then fade; plus drifting fog, rising embers, a slow "breathing" zoom of the artwork and pulsing red glow on the buttons. (The shells already printed in the picture stay still; the new ones are drawn on top.) Reduced-motion setting → fewer shells, no breathing.
- Music: the audio track of your video was extracted to `assets/menu-music.mp3` (2.4 MB, 2:52, loops). It plays on the menu only; **pressing Continue fades it out (0.45 s) and starts the game** (the in-game generative music is silent while the song plays and returns afterwards). Continue resumes your saved run; with no save it starts a new game on the last-used difficulty (first time: the short tutorial first). Returning to the menu restarts the song.
- Browsers/WebViews block sound until the first touch, so a "tap anywhere for sound" hint shows and the first tap starts the song. In an Android WebView app call `settings.setMediaPlaybackRequiresUserGesture(false)` to let it start by itself.
- Fixed a real bug found on the way: four menu buttons shared ids with their modals (`mShop`, `mArchive`, `mAch`, `mCredits`, `mLeave`), so those dialogs could be addressed through the wrong element and the old test passed vacuously. Buttons are now `bShop`/`bArchive`/`bAch`/`bCredits`/`bLeave`, and a test asserts all ids in `index.html` are unique.
- While the image menu is showing, the 3D scene is not rendered (saves battery).

## v4 — UI & gameplay overhaul (this update)
Brief: modernise the whole UI, redesign Settings and every control button, make the weapon hold steady and always point at the crosshair, fill the main menu without empty space or scrolling, add achievements and genuinely useful tools — without removing or breaking anything.

### Weapon: why it drifted, and the fix
- **Root cause (measured, not guessed):** after you aimed the Caster at the Dealer, its generic idle clip kept interpolating the barrel angle from the aimed value (−1.5 rad) towards the carry pose (−0.51 rad) — **about 295 px of muzzle drift on the 1280×720 stage** — and the recoil clip flicked the same angle and back. So the barrel slid whenever nothing else was playing.
- **Fix:** every pose now has its own static idle clip (carry / aimed at Dealer / aimed at self / Dealer takes the gun) with an optional, tiny motion amplitude; recoil is a separate "kick" channel that no longer changes the pose angle; and the player's Caster is **steered in 3D every frame** so that its barrel line passes through one fixed world point on the Dealer's chest (`Stage3D.aimTarget`, muzzle height and your weapon-position setting included). Camera look-around, camera sway and the weapon offset therefore cannot pull the barrel off the target. Raise / fire / reload / hand-over animations are kept.
- **Crosshair:** drawn at the projected aim point (off / dot / cross / ring, size, opacity). Its on-screen size is fixed in CSS pixels, so it looks the same on every phone and render scale.
- **Measured** (headless Chromium, 915×412, software WebGL; 2D overlay compared with the projected barrel line): *Locked* — muzzle jitter σ = 0.01 px, aim error 0.1 px · *Natural* — σ = 0.56 px · with a weapon offset set — 0.1 px · while dragging the camera — 0.1 px (`tests/aim-probe.js`). I also looked at the in-game screenshots (`tests/aim-shot.js`): with the default dot, and with ring + shifted + enlarged gun, the barrel points at the marker.
- Note: the game is turn-based with a fixed camera, so "the crosshair" is a fixed world point on the Dealer rather than a free-aim reticle.

### Settings (one sheet, 7 tabs, every control is wired and saved)
General (language, subtitles, subtitle language, replay tutorial, shortcuts to Statistics / Achievements) · Audio (master, music, ambience, effects, voice) · Video (3D on/off, quality, render scale, 30/60 fps, brightness, vignette, effects, shake, fullscreen) · Controls (touch-target size, look sensitivity, invert Y, haptics) · Weapon (hold steadiness Locked/Subtle/Natural, camera sway, crosshair style/size/opacity, weapon X/Y/scale with a live preview) · Interface (UI scale, HUD opacity, button labels on/off, action-cluster side left/right, FPS meter, accent colour) · Access (text size, high contrast, reduced motion, shake, camera sway).
Sliders show their value and apply live; each tab has a *Reset this page* button that restores only that tab's defaults; changes are coalesced to one apply per frame and saved 400 ms after the last move; anything still pending is written immediately when the app is backgrounded or closed (`visibilitychange` / `pagehide`). Every key is validated by `SaveMgr.sanitizeSettings` (range-clamped numbers, strict booleans, enum whitelist), so an old or corrupt save falls back to defaults instead of breaking the game. The whole sheet is data-driven (`TABS` in `scripts/ui-extra.js`), so a new option is one row.

### Buttons and HUD
- All in-game controls were redrawn as compact icon buttons (51 inline-SVG icons in `scripts/icons.js`; no emoji, no external files) with short captions that can be switched off. Visual size is small, the touch area is expanded to at least 40 px, with press feedback (scale + brightness), clear disabled / active / selected states and no overlaps. Layout test (`tests/hud-layout.js`): 0 overlapping, off-screen or undersized controls at 915×412, 740×360, 1280×720 and 2400×1080 in three setting variants (defaults; left-handed + UI scale 1.2 + captions off; Arabic/RTL + UI scale 0.85 + HUD opacity 0.6).
- The action cluster can sit on the left or right; UI scale (0.85–1.2) and HUD opacity (0.45–1) apply to the whole HUD.
- **Main menu:** the artwork's empty side bars are filled with a blurred copy of the art, and a small icon rail (New game, Statistics, Credits, Fullscreen, Music) replaces the text row. No scrolling at any tested size.
- New CSS design system in `styles/ui2.css` (tokens, tiers, accent colour via `data-accent`, high-contrast mode via `data-contrast`, RTL-aware, compositor-only animations).

### Achievements and statistics
- **28 achievements in 4 tiers** — 6 Beginner, 8 Intermediate, 8 Advanced, 6 Legendary. Each has an icon, goal, progress bar and Wax reward; the page shows overall completion %, filters by tier, and highlights new unlocks; unlock pop-ups are queued, animated and have a sound. Five accent colours (ember by default; gold, ice, verdant and violet unlocked by specific achievements) recolour the UI.
- Progress is a pure function of the saved lifetime statistics (games, wins, rounds, shots, self-shots, Ash self-shots, hits, damage dealt/taken, items used, best streak, play time, Wax earned/spent, perfect rounds, Nightmare wins …) plus the item archive, fed by the same event stream that drives the narration — so the page can only show what really happened in play. Unlocks and rewards are idempotent (never paid twice). A Statistics page lists the counters.
- Saves from v3 keep their unlocked achievements; the new lifetime counters start at 0.

### Performance work in this update
- Menu animations use compositor-only properties; dragging a slider no longer re-creates the render surfaces (resize only when quality or resolution actually changed); the brightness overlay is not composited when it is 1.0; the FPS meter only runs when enabled; play time is saved every 20 s, not every frame.
- Checked with an A/B run against the previous build in the same software-WebGL sandbox (`tests/frame-probe.js`): script time per frame 1.6 ms vs 3.0 ms (Medium) and the same or better frame pace. The first seconds after the first tap are slower because all 59 sound effects are rendered once in the background (7 s of CPU in the sandbox); after that the pace is steady. **These are sandbox numbers, not phone numbers.**

## Replacing placeholder art/audio
All art lives in `scripts/art.js` and all sound in the `SFX` table of `scripts/audio-manager.js`. To use file assets, load images/audio
in those modules and keep the same names; run `node tools/export-manifests.js` to revalidate.

## Test report (what was actually run)
- `node tests/logic.test.js` — 206 assertions pass (rules engine, items, 600 simulated games, save sanitising, manifests, physics, IK, and the v4 statistics / achievement / settings-sanitising logic) (determinism, every item, rule validation, 600 simulated games, save sanitizing, manifests).
- `node tests/play-browser.js` (headless Chromium, 915x412 touch) — a full game played through UI to an ending, no console errors; avg draw ≈1.5 ms/frame in headless software rendering.
- `node tests/features-browser.js` — 20 checks pass: pause, settings, save→leave→reload→continue state restore, archive/achievements/credits/settings screens, portrait auto-pause + resume, low quality + 30 fps cap (min frame interval 33 ms) + reduced motion + Arabic/RTL, and an offline render of all 54 SFX (audible, finite, non-clipping).

- v2 browser tests: `tests/features-browser.js` also checks the shop (13 cards, buy, stock consumed at game start), settings tabs, sensitivity, the 3D scene rendering under software WebGL (307 draw calls / 22k triangles on Low), exact camera ray/project round-trip, subtitle placement under the Dealer, and 59 SFX renders. `tests/play-browser.js` completed full games in both 2D mode and (once, before the new items) 3D mode.

## Honest limitations
- **GLB assets are stylised low-poly trimesh exports** (vertex colours only, no textures/PBR, no normals — normals are generated with a crease angle). The character's hands are big blocky parts: each finger is ONE rigid bone (curls as a unit, no knuckle bending), so the grip is a convincing wrap but not a anatomically exact one. The supplied files' only animation is a turntable spin and is intentionally unused; the character has no authored clips, so idle/lean/grip poses are procedural on the authored skeleton. The Dealer's brows are not animated (the model's brow ridge is a fixed part); expression comes from head tilt, jaw and eye glow. Dealer legs/feet are skinned but hidden behind the table. No LOD system. Remaining props (13 items, room) are still primitive-built and **3D is low-poly procedural art, not AAA/PBR.** Models are built from primitives (boxes, spheres, lathes); hands and Dealer arms are blocky, textures are generated in shaders, there is no skeletal mocap, no LOD system, no real PBR materials. Frame rate on real Android GPUs is **unmeasured** (only headless software WebGL was used, which is far slower); use Quality Low / Resolution scale / 2D fallback if needed.
- The Dealer and logo are **original** designs, deliberately not copies of Buckshot Roulette's characters or branding.
- Not done / partial vs. the overhaul brief: no wall blood splatter (table decals only), cinematic scene transitions are fades/flashes, spatial audio is stereo panning only, achievement unlocks are an animated, queued pop-up with a sound (no full-screen cinematic), the 'Resolution' option is a render-scale slider, and 3D item/hand poses were tuned by eye on a handful of screenshots, so odd poses may remain in rarely seen animations.
- **Not tested on a real Android device** or real speakers/headphones; performance numbers are from headless desktop Chromium. Audio was verified numerically (offline render), **not by ear**; voice quality is a stylized formant synth, not speech.
- The Dealer's arms are simple stylized shapes; art is procedural vector drawing, not hand-painted AAA assets. Animation is keyframed procedural rigs, not skeletal/mocap.
- Not every item/ending path was visually inspected frame-by-frame; unattended bot play covered ordinary flows, and logic simulations covered rules.
- Arabic text is machine-written and not reviewed by a native speaker.
- Achievements/endings beyond those reached in tests were verified by logic only.

### v4 test report (what was actually run)
- `node tests/logic.test.js` — **206** assertions pass.
- `node tests/ui-features.js` (Playwright, 2D renderer) — **43** checks pass: every setting changes what it claims to (HUD scale/opacity/side/labels, accent, contrast, brightness, vignette, crosshair, weapon offset, hold, FPS meter…), values persist across a reload, "reset" restores only the open page, the FPS counter appears only when enabled, achievement progress / reward / pop-up / tier filter, one-time payout, accent unlocks, the statistics page, and play time that counts only while a game runs (not while paused).
- `node tests/features-browser.js` — **32** checks pass (3D scene renders under software WebGL, pause/resume, save/continue, portrait pause, Arabic/RTL, 59 SFX render audible and finite, …); `node tests/menu-art.js` — 8 pass.
- `node tests/hud-layout.js` — 0 layout problems at 915×412, 740×360, 1280×720, 2400×1080 (portrait shows the rotate prompt by design).
- `node tests/ui-shots.js` — 16 screens × 4 landscape sizes in English and 16 screens × 3 sizes in Arabic/RTL, 0 layout problems, no console errors (menu with its tool rail, the 7 settings tabs, achievements, statistics, difficulty, shop, archive, credits, leave dialog and tutorial). I looked at a sample of the screenshots by eye; I did not review every image.
- Test-harness note: `tests/ui-features.js` seeds its start-up settings with a `window.name` marker. An earlier version used a localStorage flag and failed once ("settings survive a reload"): headless Chromium can show an init script an *empty* localStorage right after a reload — I reproduced it on a blank page with no game code (12 of 40 reloads) — so the flag re-seeded and wiped the saved values. The game itself was not the cause.
- `node tests/aim-probe.js` / `tests/aim-shot.js` — weapon numbers above. `node tests/play-browser.js` — a full game played through the UI.
- `node tests/perf-3d.js` / `tests/frame-probe.js` — no GL object growth, no console errors; frame pace A/B (software WebGL only).

### v4 — additional honest limitations
- **Not tested on a real Android phone/GPU.** All numbers come from headless desktop Chromium with software WebGL; touch behaviour was exercised with Playwright's touch emulation, not with fingers. Frame rates on your Samsung are unknown until you try it.
- Because the game is turn-based with a fixed camera, the crosshair marks a fixed world point on the Dealer's chest; it is not a free-aim reticle. In the 2D fallback renderer (3D off) there is no steered gun and no crosshair.
- Brightness is a simple overlay, not true gamma. Accent colours recolour the UI only (not the 3D scene). The weapon-position preview is a schematic, not a live render.
- The main-menu labels are part of your Arabic image, so they are Arabic in every language; the new tool rail and everything else follows the selected language.
- The new Arabic strings are machine-written and not reviewed by a native speaker.
- New lifetime statistics start at 0 for existing saves, so statistic-based achievements cannot be unlocked retroactively.

## v5 — the supplied shotgun and hands + the Smart Hands system (this update)
Brief: replace the Caster **and the hands** with the models you supplied (`buckshot-roulette-shotgun_1.zip`), keep them exactly as made, hold the gun like a real shotgun (grip hand + fore-end hand, one unit), never let the gun swing back into the camera when you aim at yourself or when the Dealer aims at you, and give the hands their own skeleton-driven system (release, pick up, hold, use, reload, interact) with eight explicit states.

### What is used, and how (nothing was re-modelled)
- `tools/build-br-assets.py` (sources in `tools/br/`) reads the FBX and bakes `data/br-assets.js` (≈6 MB, a plain `<script>`, so it still runs from `file://`): the gun meshes with their **original UVs and normals**, both hand meshes, and the **original textures byte-identical** (embedded as data URIs). Colours, proportions and the small parts are untouched; the gun is only scaled to the length of the old gun (3.81 units) so every other system keeps working.
- **The hands needed one thing the file does not contain: skin weights.** The FBX only has an empty armature (null nodes), so the 20-bone skeleton (the file's own bone names, hierarchy and proportions) is fitted to each hand mesh and the weights are computed (finger segmentation by geodesic distance, smoothed Gaussian weights). The rest pose of the skeleton is the exact grip pose in the file.
- Both the player's hands and the Dealer's hands are these meshes now (the Dealer's old glove triangles are hidden and his arms use IK to reach the supplied hands).

### The weapon hold
- **Right hand on the grip, left hand on the fore-end, one unit.** The wrist of each hand sits exactly where the file puts it on the gun (measured wrist-to-socket distance in the game: player ≤ 0.06 cm, Dealer grip hand 0.00 cm, Dealer support hand ≤ 0.27 cm). The pump hand rides the slide when the gun is cocked or reloaded. Hands blend on/off the gun with an eased "attach" weight, so pick-up and release never pop.
- **Weapon direction = aim direction.** The barrel is steered at the real target (Dealer's chest / your own face / the Dealer's head) and the crosshair is the projection of that line: aim error 0.00–0.01 px.
- **Why the gun came back into your face (measured):** the gun was placed on a plane that, for the "aim at yourself" and "Dealer aims at you" poses, ended up *above the eye height* (1.56 m vs. eye 1.5 m), so the camera ray hit it at a negative distance, i.e. behind the camera plane. Fix: the placement plane is capped below the eye, the gun is placed along the ray through the logical screen position, and every key point of the gun **and both hands** (bounding-box corners) is pushed out horizontally until it is at least **0.45 m in front of the eye along the view axis**. The push rises instantly (no frame where the gun is inside the camera) and relaxes smoothly (7 /s), plus a final hard guarantee and a table-top floor.
- **Second cause found in this update (Dealer):** after the Dealer's aim animation ended nothing held that pose, so the gun drifted back to the lying-on-the-table pose (the same thing happened to your gun after each shot). New hold poses (`gun_idle_dplayer_*`, `gun_idle_dself_*`) exist, and the gun actor's idle clip is now always the *currently held* pose, so no animation can end in a drift.
- **Dealer arms:** both of his wrists have to sit on the gun. When the target is out of his reach the gun is moved (the larger shortfall leads, up to 14 iterations) until both wrists reach their sockets, so the hands never leave the gun.

### Smart Hands (File 2) — `scripts/hands.js`
- One independent system, driven by the file's own skeleton: per-bone angles, independent fingers (index / middle / ring / pinky / thumb), per-finger critically-damped follow with a different time constant for each finger (fingers close one after another, never snap), GPU skinning.
- **Eight explicit states, exactly one at a time:** 1 Idle Hands · 2 Weapon Holding · 3 Item Pickup · 4 Item Holding · 5 Item Release · 6 Interaction (pointing / tapping) · 7 Reloading (support hand works the pump) · 8 Transition (wrist moving between free pose and gun socket).
- **Grip per item (size / shape):** power grip for can, medicine, battery, blank shell, spray, magnifier handle, knife, scrambler, rope; precision grip for lighter and handcuffs; pinch for cigarette and coin. A solver closes each finger segment (capsules) against the item's proxy shape (cylinder / box / sphere) until it touches, so thick items open the hand wider than thin ones and fingers do not go through the item. The free hand lies palm-down on the table and rolls thumb-up when it holds an item; hands never go through the table top.
- Penetration of the solved grips: worst 6.5 mm (left hand, handcuffs, hand scale −8 %), typically 2–5 mm; there is no case above 8 mm in the 78 checked combinations (13 items × 2 hands × 3 hand scales).

### v5 test report (what was actually run)
- `node tests/logic.test.js` — **206** pass (unchanged rules/animation data; the manifest now has 116 clips).
- `node tests/hands.test.js` — **212** pass: asset integrity (meshes, UVs, indices, skin arrays), the 20-bone skeleton, bind pose = the file's grip pose, independent fingers, grip solver for all items / both hands / 3 scales, the 8-state controller (idle → pickup → transition → weapon → reload → release → item hold → release → interact), no joint jump larger than 0.25 rad per 16 ms frame over 600 rapid state flips.
- `node tests/br-states.js` (headless Chromium, real game code, nothing mocked) — **all checks pass**: normal hold, look left/right/up/down + 8 look extremes, sudden camera flips, aim at the Dealer, aim at yourself, fire, recoil, reload, lower, inspect, the Dealer takes / aims at you / aims at himself / fires / reloads / puts the gun down, 14 back-to-back transitions. Over ~1200 held frames the **nearest point of gun or hands to the eye never fell below 0.45 m**; a separate sweep of **99,900 camera-pose × gun-state cases** (`Stage3D.brProbe`) found 0 violations and 0 NaN. Gun position spread in steady phases 0.05–0.26 mm (no jitter). No console errors.
- `node tests/br-items.js` — every item through the real `Show.item()` flow for the player (13) and the Dealer (4): picked up, held, used, released; only the eight defined states appear; no weapon state while handling an item.
- Close-up viewer `tests/hands-lab.js` (standalone WebGL page) was used to compare the file's grip pose with the game's pose by eye.
- Earlier suites re-run on this build: `ui-features` **43/43**, `features-browser` **32/32**, `play-browser` (full play-through to the ending, items used, no console errors) **pass**, `logic.test.js` **206/206**.

### v5 — honest limitations
- **The models are yours, not mine.** They closely resemble assets of the game *Buckshot Roulette* and the zip contains no licence file. Please make sure you have the right to use and ship them; the project's "everything is original" statement at the top of this README does **not** cover these two files.
- **Skin weights are computed, not authored.** The original file has none, so extreme finger angles can show linear-blend-skinning artefacts; to avoid them the fingers cannot be stretched completely flat (open range limited to about 30 % curl), and the original hands are long and thin, so an "open" hand still looks like a relaxed one.
- **Normal maps are not shipped** (the ones in the file measured flat) and a fixed exposure factor is applied because the lamp light is warm; the hands look more orange in the low-quality render than in the lab viewer.
- **Dealer geometry is a compromise.** A ~1 m shotgun cannot be held with its muzzle at your own face using human-length arms, so when the Dealer aims at himself the barrel line passes within ≈12 cm of his head but the muzzle ends *behind* it (hidden by his head from your side). When he aims at you the barrel line passes within ≈20 cm (≈6°) of your face because the gun is placed where both his hands can hold it. The gun is never closer than 0.45 m to your camera in either case.
- **Aiming at yourself:** both of your arms cross in an X in front of the camera (two hands on a gun pointing at your face); this is geometry, not a bug.
- **Grips are solved against simple proxy shapes** (cylinder / box / sphere), not against the real item meshes, and the free hands are still *positioned* by the game's existing 2D hand animation clips; only their 3D rendering, fingers and states are new.
- Not measured: frame time on a phone (the headless run only shows the CPU draw cost ≈ 0.56 ms/frame; the Dealer's gun-reach solver adds a few small iterations per frame while he holds the gun).
- A hand resting next to the gun that lies on the table reports "Item Pickup" (open, ready hand) instead of "Idle" – a state-naming simplification, no visual pop.
- The 2D fallback renderer (3D off) keeps the old drawn gun and hands.
- **Not tested on a real Android device.** All numbers are from headless Chromium with software WebGL at 915×412 / Low quality (which is pixelated); frame rate on your phone is unknown. The in-game screenshots are low-resolution, so fine details (finger placement) were judged in the lab viewer, not in the game view.
