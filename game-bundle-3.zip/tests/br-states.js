/* In-game state test for the supplied shotgun + hands (software WebGL, real game code: Show / Anim / Stage3D, nothing mocked).
   It forces every weapon state the player or the dealer can be in, records every rendered frame (camera, gun placement, hand states, wrist-to-socket distance,
   aim error) and checks:
     A  nothing of the gun / hands ever comes closer to the eye than the clearance limit (all states, look sweeps, sudden flips)
     B  the hands stay on their sockets on the gun while they hold it (player: glued; dealer: arm reach)
     C  the barrel points at the intended target (dealer / own face / player's face / dealer's head) in the steady aim phases
     D  hand-state sequences are the expected ones (no conflicting states while the gun is held)
     E  the gun does not jitter in steady phases
     F  a grid sweep of camera poses x gun states (Stage3D.brProbe) never breaks the clearance
   usage: node tests/br-states.js [settingsJSON] [tag]      (exit code 1 when a check fails) */
const { chromium } = require('playwright');
const fs = require('fs');
const ZMIN = 0.45, TOL = 0.002;
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const ctx = await b.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 1, hasTouch: true, isMobile: true });
  const p = await ctx.newPage(); const logs = [];
  const extra = process.argv[2] && process.argv[2] !== '-' ? JSON.parse(process.argv[2]) : {}, tag = process.argv[3] || 's';
  fs.mkdirSync('/tmp/claude-0/shots', { recursive: true });
  await p.addInitScript((x) => { try { localStorage.setItem('tallow.settings.v1', JSON.stringify(Object.assign({ quality: 'low' }, x))); } catch (e) {} }, extra);
  p.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') logs.push(m.type() + ': ' + m.text()); }); p.on('pageerror', (e) => logs.push('PAGEERROR: ' + e.message));
  await p.goto('file://' + process.cwd() + '/index.html'); await p.waitForTimeout(2500);
  await p.evaluate(() => document.getElementById('mNew').click()); await p.waitForTimeout(300);
  await p.evaluate(() => document.querySelector('#diffList button').click()); await p.waitForTimeout(1500);
  await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find((x) => /skip/i.test(x.textContent) && x.offsetParent); if (b) b.click(); });
  await p.waitForFunction(() => window.Turns && window.Turns.canAct && window.Turns.canAct(), null, { timeout: 180000 });
  await p.waitForTimeout(1500);

  // ---- in-page recorder + helpers
  await p.evaluate(() => {
    const R = window.Renderer, S = window.Stage3D, Sh = window.Show, An = window.Anim;
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    const T = window.__T = { frames: [], phase: '', sleep, R, S, Sh, An };
    const orig = S.render;
    S.render = function (r) {
      const out = orig.apply(this, arguments);
      try {
        const d = S.brDebug() || {}, gs = R.gunState(), hs = S.handStates(), sk = d.sock || {}, gi = S.gunInfo, E = S.Cam.eye, hold = r.scene.gunHolder;
        let tp = null; const aim = Sh.aimed, who = Sh.aimWho;
        if (aim === 'opp') tp = who === 'p' ? S.aimTarget() : [E[0], E[1] - 0.07, E[2]];
        else if (aim === 'self') tp = who === 'p' ? [E[0], E[1] - 0.07, E[2]] : (S.dealerHead ? [S.dealerHead.p[0], S.dealerHead.p[1] - S.dealerHead.r * 0.2, S.dealerHead.p[2]] : null);
        const st = (w, s) => (hs[w][s] ? hs[w][s].state : null), at = (w, s) => (hs[w][s] ? hs[w][s].attach : null), er = (w, s) => (sk[w] && sk[w][s] ? sk[w][s].err : null);
        T.frames.push({ t: r.t, ph: T.phase, hold, aim, who, md: d.minDepth, push: d.push, roll: d.roll, pos: d.pos, gs: { x: gs.x, y: gs.y, ang: gs.ang, sc: gs.sc, fore: gs.fore, brk: gs.brk, kick: gs.kick },
          eye: E.slice(), tgt: S.Cam.tgt.slice(), f: S.Cam.f.slice(), mz: gi ? gi.muzzle : null, dir: gi ? [gi.M[0], gi.M[1], gi.M[2]] : null, tp,
          st: { pl: st('p', 'l'), pr: st('p', 'r'), dl: st('d', 'l'), dr: st('d', 'r') }, at: { pl: at('p', 'l'), pr: at('p', 'r'), dl: at('d', 'l'), dr: at('d', 'r') },
          dd: d.dealer ? JSON.parse(JSON.stringify(d.dealer)) : null, sk: { pl: er('p', 'l'), pr: er('p', 'r'), dl: er('d', 'l'), dr: er('d', 'r') }, ae: S.aimErrorPx ? S.aimErrorPx() : null });
      } catch (e) { T.err = String(e && e.stack || e); }
      return out;
    };
    T.look = async (x, y, ms) => { R.lookHold = true; R.lookX = x; R.lookY = y; await sleep(ms); };
    T.lookOff = async (ms) => { R.lookHold = false; R.lookX = 0; R.lookY = 0; await sleep(ms); };
    T.looks = async (list, ms) => { for (const [x, y] of list) { T.phase = T.phase.split('@')[0] + '@look' + x + ',' + y; await T.look(x, y, ms); } T.phase = T.phase.split('@')[0]; await T.lookOff(ms); };
  });
  const ev = (code) => p.evaluate('(async()=>{const T=window.__T,Sh=T.Sh,An=T.An,R=T.R,S=T.S,sleep=T.sleep;' + code + '})()');
  const shot = async (n) => { await p.screenshot({ path: '/tmp/claude-0/shots/st_' + tag + '_' + n + '.png', timeout: 120000 }); };
  const phase = (n) => ev("T.phase='" + n + "';");
  const LOOKS = '[[0.35,0],[-0.35,0],[0,0.3],[0,-0.3],[0.35,0.3],[-0.35,-0.3],[0.35,-0.3],[-0.35,0.3]]';
  const FLIPS = '[[-0.35,-0.3],[0.35,0.3],[-0.35,0.3],[0.35,-0.3],[0,0]]';
  const t0 = Date.now(), lap = (s) => console.log('[' + ((Date.now() - t0) / 1000).toFixed(0) + 's] ' + s);

  // ================= 1) player: take, hold, look around
  await phase('take'); await ev("await Sh.takeGun('p');"); await phase('held'); await ev('await sleep(2500);'); lap('player holds the gun'); await shot('hold');
  await phase('held'); await ev('await T.looks(' + LOOKS + ', 900);'); lap('look sweep (held)');
  await phase('flip'); await ev('for (const [x,y] of ' + FLIPS + ') { T.phase="flip@"+x+","+y; R.lookHold=true; R.lookX=x; R.lookY=y; await sleep(260); } T.phase="flip"; await T.lookOff(900);'); lap('sudden flips (held)');
  // ================= 2) aim at the dealer
  await phase('aimD'); await ev("await Sh.aimGun('p','opp');"); await ev('await sleep(2500);'); await shot('aimD'); lap('aim at the dealer');
  await phase('aimD'); await ev('await T.looks(' + LOOKS + ', 800);'); lap('look sweep (aim dealer)');
  await phase('fireD'); await ev("An.gun.play('gun_fire',{force:true}); An.player.play('hand_fire',{force:true}); await sleep(220);"); await shot('fireD'); await ev('await sleep(1200); An.gun.play("gun_recoil",{force:true}); await sleep(1500);'); lap('fire at the dealer');
  await phase('lower'); await ev('await Sh.lowerGun(); await sleep(1500);'); lap('lower + put on the table'); await shot('lowered');
  // ================= 3) aim at yourself
  await phase('take'); await ev("await Sh.takeGun('p');"); await phase('aimS'); await ev("await Sh.aimGun('p','self');"); await ev('await sleep(2500);'); await shot('aimS'); lap('aim at yourself');
  await phase('aimS'); await ev('await T.looks(' + LOOKS + ', 800);'); lap('look sweep (aim self)');
  await phase('flipS'); await ev('for (const [x,y] of ' + FLIPS + ') { T.phase="flipS@"+x+","+y; R.lookHold=true; R.lookX=x; R.lookY=y; await sleep(260); } T.phase="flipS"; await T.lookOff(900);'); lap('sudden flips (aim self)');
  await phase('fireS'); await ev("An.gun.play('gun_fire',{force:true}); An.player.play('hand_fire',{force:true}); await sleep(220);"); await shot('fireS'); await ev('await sleep(1200); An.gun.play("gun_recoil",{force:true}); await sleep(1500);'); lap('fire at yourself');
  await phase('lower'); await ev('await Sh.lowerGun(); await sleep(1500);');
  // ================= 4) the dealer aims at the player (and himself), fires, reloads
  await phase('dtake'); await ev("await Sh.takeGun('d');"); await phase('dheld'); await ev('await sleep(2000);'); await shot('dealerHold'); lap('dealer holds the gun');
  await phase('daimP'); await ev("await Sh.aimGun('d','opp');"); await ev('await sleep(2500);'); await shot('dealerAimsPlayer'); lap('dealer aims at the player');
  await phase('daimP'); await ev('await T.looks(' + LOOKS + ', 800);'); lap('look sweep (dealer aims at player)');
  await phase('flipDP'); await ev('for (const [x,y] of ' + FLIPS + ') { T.phase="flipDP@"+x+","+y; R.lookHold=true; R.lookX=x; R.lookY=y; await sleep(260); } T.phase="flipDP"; await T.lookOff(900);');
  await phase('dfireP'); await ev("An.gun.play('gun_fire',{force:true}); await sleep(220);"); await shot('dealerFire'); await ev('await sleep(1200); An.gun.play("gun_recoil",{force:true}); await sleep(1500);'); lap('dealer fires at the player');
  await phase('daimS'); await ev("await Sh.aimGun('d','self');"); await ev('await sleep(2200);'); await shot('dealerAimsSelf'); lap('dealer aims at himself');
  await phase('dput'); await ev("await Sh.putGun('d'); await sleep(1500);"); lap('dealer puts the gun down');
  await phase('dtake2'); await ev("await Sh.takeGun('d');"); await phase('reload'); await ev("An.gun.play('gun_reload',{force:true}); await sleep(1200);"); await shot('reload'); await ev('await sleep(2800);'); lap('reload');
  await phase('dput'); await ev("await Sh.putGun('d'); await sleep(1500);");
  // ================= 5) transitions between all states, back to back
  for (const step of [["take","await Sh.takeGun('p');"], ["aimD","await Sh.aimGun('p','opp');"], ["aimS","await Sh.aimGun('p','self');"], ["aimD","await Sh.aimGun('p','opp');"], ["lower","await Sh.lowerGun();"], ["inspect","await Sh.inspectGun();"], ["take","await Sh.takeGun('p');"], ["aimS","await Sh.aimGun('p','self');"], ["lower","await Sh.lowerGun();"], ["dtake","await Sh.takeGun('d');"], ["daimP","await Sh.aimGun('d','opp');"], ["daimS","await Sh.aimGun('d','self');"], ["daimP","await Sh.aimGun('d','opp');"], ["dput","await Sh.putGun('d');"]]) {
    await phase('tr_' + step[0]); await ev(step[1] + ' await sleep(500);');
  }
  lap('transitions done');
  await ev('await sleep(1500);');

  // ================= 6) grid sweep of camera poses x gun states (no drawing)
  const sweep = await p.evaluate(() => {
    const T = window.__T, S = T.S, seen = new Set(), gss = [];
    for (const f of T.frames) { if (f.hold !== 'p' && f.hold !== 'd') continue; const k = [f.gs.x, f.gs.y, f.gs.ang, f.gs.sc].map((v) => Math.round(v * 20)).join(','); if (!seen.has(k)) { seen.add(k); gss.push({ gs: f.gs, holder: f.hold }); } }
    // extreme / synthetic states on top of the recorded ones
    for (const holder of ['p', 'd']) for (const ang of [-1.7, -1.2, -0.9, -0.5, 0, 0.5, 0.9, 1.2, 1.7]) for (const sc of [0.8, 1, 1.3, 1.7]) for (const x of [-300, 0, 300]) for (const y of [-60, 0, 90, 220]) gss.push({ gs: { x: 640 + x, y: 520 + y - 150, ang, sc, kick: 0.5, fore: 0.5, brk: 0.5 }, holder });
    const cases = [];
    for (const lx of [-0.35, -0.17, 0, 0.17, 0.35]) for (const ly of [-0.3, 0, 0.3]) for (const punch of [0, 1.2]) for (const sh of [[0, 0], [0.04, 0.03], [-0.04, -0.03]]) {
      const eye = [lx * 0.55 + sh[0], 1.5 + ly * 0.25 + sh[1], 1.78 - punch * 0.05], tgt = [eye[0] * 0.2 - lx * 0.4, 0.86 + ly * 0.1, -0.75];
      for (const g of gss) cases.push({ eye, tgt, gs: g.gs, holder: g.holder });
    }
    const res = S.brProbe(cases); let min = 1e9, bad = 0, nan = 0, worst = null;
    res.forEach((r, i) => { if (!r.ok) nan++; if (r.minDepth < min) { min = r.minDepth; worst = { eye: cases[i].eye, gs: cases[i].gs, holder: cases[i].holder, r }; } if (r.minDepth < 0.449) bad++; });
    return { n: res.length, min, bad, nan, worst, gs: gss.length };
  });
  lap('grid sweep: ' + sweep.n + ' cases');

  const frames = await p.evaluate(() => ({ frames: window.__T.frames, err: window.__T.err || null }));
  fs.writeFileSync('/tmp/claude-0/shots/st_' + tag + '_frames.json', JSON.stringify(frames.frames));
  const F = frames.frames; const fails = [];
  const check = (ok, msg) => { console.log((ok ? '  PASS ' : '  FAIL ') + msg); if (!ok) fails.push(msg); };
  console.log('\nframes recorded: ' + F.length + (frames.err ? '   recorder error: ' + frames.err : ''));

  // ---- A) clearance (all frames while somebody holds the gun, or the gun is in transit)
  const held = F.filter((f) => (f.hold === 'p' || f.hold === 'd') && f.md !== undefined && f.md !== null);
  const minAll = Math.min(...held.map((f) => f.md));
  check(held.length > 40 && minAll >= ZMIN - TOL, 'A  nearest point of gun/hands to the eye over ' + held.length + ' held frames = ' + minAll.toFixed(4) + ' m (limit ' + ZMIN + ')');
  const byPh = {}; for (const f of held) { const k = f.ph.split('@')[0]; (byPh[k] = byPh[k] || []).push(f); }
  console.log('     per phase (frames, min clearance, max push):');
  for (const k of Object.keys(byPh)) { const a = byPh[k]; console.log('       ' + k.padEnd(10) + String(a.length).padStart(4) + '  ' + Math.min(...a.map((f) => f.md)).toFixed(3) + '  ' + Math.max(...a.map((f) => f.push)).toFixed(3)); }
  const lk = held.filter((f) => /@look|@|flip/.test(f.ph));
  check(lk.length > 20 && Math.min(...lk.map((f) => f.md)) >= ZMIN - TOL, 'A2 during look sweeps / sudden flips (' + lk.length + ' frames) min = ' + (lk.length ? Math.min(...lk.map((f) => f.md)).toFixed(4) : 'n/a'));
  const behind = held.filter((f) => { const d = [f.pos[0] - f.eye[0], f.pos[1] - f.eye[1], f.pos[2] - f.eye[2]]; return d[0] * f.f[0] + d[1] * f.f[1] + d[2] * f.f[2] <= 0; });
  check(behind.length === 0, 'A3 gun origin is never behind the camera plane (' + behind.length + ' frames)');

  // ---- B) hands on their sockets
  const sockFrames = (who, side) => F.filter((f) => f.hold === who && f.at[who + side] >= 0.95 && f.sk[who + side] !== null && /held|aim|fire|look|flip|dheld|reload|daim|dfire/.test(f.ph));
  for (const [who, side, lim, nm] of [['p', 'l', 0.004, 'player support hand'], ['p', 'r', 0.004, 'player grip hand'], ['d', 'l', 0.004, 'dealer grip hand'], ['d', 'r', 0.02, 'dealer support hand']]) {
    const a = sockFrames(who, side); const mx = a.length ? Math.max(...a.map((f) => f.sk[who + side])) : NaN;
    check(a.length > 10 && mx <= lim, 'B  ' + nm + ': max wrist-to-socket distance ' + (mx * 100).toFixed(2) + ' cm over ' + a.length + ' frames (limit ' + (lim * 100).toFixed(1) + ' cm)');
  }
  // hands attached the whole time the gun is held (steady phases)
  const steadyP = F.filter((f) => f.hold === 'p' && /^(held|aimD|aimS|fireD|fireS|flip|flipS)/.test(f.ph));
  const steadyD = F.filter((f) => f.hold === 'd' && /^(dheld|daimP|daimS|dfireP|flipDP|reload)/.test(f.ph));
  const minAtP = Math.min(...steadyP.map((f) => Math.min(f.at.pl, f.at.pr))), minAtD = Math.min(...steadyD.map((f) => Math.min(f.at.dl, f.at.dr)));
  check(steadyP.length > 30 && minAtP >= 0.9, 'B2 player: hand attach weight never drops while holding (min ' + minAtP.toFixed(3) + ' over ' + steadyP.length + ' frames)');
  check(steadyD.length > 30 && minAtD >= 0.9, 'B3 dealer: hand attach weight never drops while holding (min ' + minAtD.toFixed(3) + ' over ' + steadyD.length + ' frames)');

  // frames of a phase before its first look sweep / flip starts (the camera is at rest, the pose has settled)
  const steady = (ph, who) => { const o = []; let cut = false; for (const f of F) { if (f.ph.indexOf(ph + '@') === 0) cut = true; if (!cut && f.ph === ph && f.hold === who) o.push(f); } return o; };

  // ---- C) aim direction
  const miss = (f, line) => { if (!f.tp || !f.mz || !f.dir) return null; const d = f.dir, l = Math.hypot(d[0], d[1], d[2]) || 1, u = [d[0] / l, d[1] / l, d[2] / l], v = [f.tp[0] - f.mz[0], f.tp[1] - f.mz[1], f.tp[2] - f.mz[2]], t = v[0] * u[0] + v[1] * u[1] + v[2] * u[2]; if (t <= 0 && !line) return { dist: 9, ang: 3.14 };
    const c = [v[0] - u[0] * t, v[1] - u[1] * t, v[2] - u[2] * t], vl = Math.hypot(v[0], v[1], v[2]) || 1; return { dist: Math.hypot(c[0], c[1], c[2]), ang: Math.acos(Math.min(1, t / vl)) }; };
  for (const [ph, who, aim, lim, nm] of [['aimD', 'p', 'opp', 0.06, 'player -> dealer'], ['aimS', 'p', 'self', 0.08, 'player -> own face'], ['daimP', 'd', 'opp', 0.3, 'dealer -> player'], ['daimS', 'd', 'self', 0.12, 'dealer -> himself']]) {
    const a = steady(ph, who).filter((f) => f.aim === aim); const tail = a.slice(Math.floor(a.length * 0.5)).map((f) => miss(f, ph === 'daimS')).filter(Boolean);     // aiming at his own head the muzzle may already be past the head: use the barrel LINE
    const ms = tail.length ? Math.max(...tail.map((m) => m.dist)) : NaN, as = tail.length ? Math.max(...tail.map((m) => m.ang)) : NaN;
    check(tail.length > 3 && ms <= lim, 'C  ' + nm + ': barrel line misses the target by <= ' + (ms * 100).toFixed(1) + ' cm (' + (as * 57.2958).toFixed(1) + ' deg) in the second half of the phase, ' + tail.length + ' frames');
  }
  const ae = F.filter((f) => f.ph === 'aimD' && f.ae !== null).map((f) => f.ae).slice(-8); if (ae.length) console.log('     aim error (px) at the dealer plane, last frames: ' + ae.map((v) => v.toFixed(2)).join(' '));

  // ---- D) hand state sequences
  const seq = (key, test) => { const o = []; for (const f of F) { if (!test(f)) continue; const s = f.st[key]; if (s && o[o.length - 1] !== s) o.push(s); } return o; };
  const sP = seq('pr', () => true), sPl = seq('pl', () => true), sD = seq('dl', () => true), sDr = seq('dr', () => true);
  console.log('     player grip hand : ' + sP.join(' > ')); console.log('     player support   : ' + sPl.join(' > ')); console.log('     dealer grip hand : ' + sD.join(' > ')); console.log('     dealer support   : ' + sDr.join(' > '));
  const known = ['idle', 'weapon', 'pickup', 'hold', 'release', 'interact', 'reload', 'transition'];     // 1 Idle Hands, 2 Weapon Holding, 3 Item Pickup, 4 Item Holding, 5 Item Release, 6 Interaction, 7 Reloading, 8 Transition
  const allSt = new Set([...sP, ...sPl, ...sD, ...sDr]);
  check([...allSt].every((s) => known.indexOf(s) >= 0), 'D  only the 8 defined states appear (' + [...allSt].join(', ') + ')');
  const bad = F.filter((f) => f.hold === 'p' && /^(aimD|aimS|fireD|fireS)/.test(f.ph) && !(f.st.pr === 'weapon' || f.st.pr === 'transition' || f.st.pr === 'reload'));
  check(bad.length === 0, 'D2 no conflicting state on the player grip hand while aiming/firing (' + bad.length + ' frames)');
  check(F.some((f) => f.st.pl === 'reload' || f.st.dr === 'reload'), 'D3 the Reloading state occurs on the support hand when the pump works');

  // ---- E) jitter in steady phases (camera at rest = frames where look is off): position spread of the gun origin
  const still = (ph, who) => steady(ph, who).slice(-8);
  for (const [ph, who] of [['held', 'p'], ['aimD', 'p'], ['aimS', 'p'], ['dheld', 'd'], ['daimP', 'd']]) {
    const b2 = still(ph, who);
    if (b2.length < 4) { console.log('     (jitter ' + ph + ': too few frames)'); continue; }
    const mean = [0, 1, 2].map((i) => b2.reduce((s, f) => s + f.pos[i], 0) / b2.length), sd = Math.sqrt(b2.reduce((s, f) => s + [0, 1, 2].reduce((q, i) => q + (f.pos[i] - mean[i]) ** 2, 0), 0) / b2.length);
    check(sd < 0.01, 'E  gun position spread in the last frames of "' + ph + '": ' + (sd * 1000).toFixed(2) + ' mm (limit 10 mm; includes the designed hand tremble)');
  }

  // ---- F) sweep
  check(sweep.nan === 0 && sweep.bad === 0 && sweep.min >= ZMIN - TOL, 'F  grid sweep (' + sweep.n + ' camera x gun-state cases, ' + sweep.gs + ' gun states): min clearance ' + sweep.min.toFixed(4) + ' m, violations ' + sweep.bad + ', NaN ' + sweep.nan);
  if (sweep.bad) console.log('     worst: ' + JSON.stringify(sweep.worst));

  console.log('\nconsole: ' + (logs.length ? '\n' + logs.slice(0, 8).join('\n') : 'no errors or warnings'));
  check(logs.filter((l) => /error/i.test(l)).length === 0, 'G  no console errors / page errors');
  console.log(fails.length ? '\nFAILED: ' + fails.length + ' check(s)' : '\nALL CHECKS PASSED');
  await b.close(); process.exit(fails.length ? 1 : 0);
})();
