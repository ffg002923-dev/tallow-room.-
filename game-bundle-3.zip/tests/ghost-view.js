/* close-up screenshots of the Ghost dealer holding the gun (software WebGL). usage: node tests/ghost-view.js [tag] */
const { chromium } = require('playwright');
(async () => {
  const tag = process.argv[2] || 'a';
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const ctx = await b.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 1, hasTouch: true, isMobile: true });
  const p = await ctx.newPage(); const logs = []; await p.addInitScript(() => { try { localStorage.setItem('tallow.settings.v1', JSON.stringify({ quality: 'medium' })); } catch (e) {} });
  p.on('console', m => { if (m.type() === 'error') logs.push(m.text()); }); p.on('pageerror', e => logs.push('PAGEERROR: ' + e.message));
  await p.goto('file://' + process.cwd() + '/index.html', { waitUntil: 'domcontentloaded', timeout: 120000 }); await p.waitForTimeout(2500);
  await p.evaluate(() => document.getElementById('mNew').click()); await p.waitForTimeout(300);
  await p.evaluate(() => document.querySelector('#diffList button').click()); await p.waitForTimeout(2500);
  await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find(x => /skip/i.test(x.textContent) && x.offsetParent); if (b) b.click(); }); await p.waitForFunction(() => window.Turns && window.Turns.canAct && window.Turns.canAct(), null, { timeout: 170000 }); await p.waitForTimeout(1500);
  const clip = { x: 300, y: 40, width: 330, height: 250 };
  await p.screenshot({ path: `/tmp/claude-0/shots/gh_${tag}_idle.png`, clip, timeout: 120000 });
  await p.evaluate(() => { clearInterval(window.__gh); window.__gh = setInterval(() => { window.Renderer.scene.gunHolder = 'd'; }, 8); }); await p.waitForTimeout(2200);
  await p.screenshot({ path: `/tmp/claude-0/shots/gh_${tag}_gun1.png`, clip, timeout: 120000 }); await p.waitForTimeout(700);
  await p.screenshot({ path: `/tmp/claude-0/shots/gh_${tag}_gun2.png`, clip, timeout: 120000 });
  console.log(await p.evaluate(() => JSON.stringify({ d: window.Stage3D.brDebug().dealer, hs: window.Stage3D.handStates().d })));
  console.log(logs.slice(0, 6).join('\n') || 'no console errors'); await b.close();
})();
