/* browser tests for the v4 interface: settings sheet, every new setting is stored + applied, achievements page, unlock pop-up,
   statistics page, accent locking, HUD layout switches. 2D renderer (fast); run: node tests/ui-features.js */
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const out = []; const ok = (n, c, x) => out.push((c ? 'PASS ' : 'FAIL ') + n + (x ? ' ' + x : ''));
  const ctx = await b.newContext({ viewport: { width: 915, height: 412 }, hasTouch: true, isMobile: true }); const p = await ctx.newPage(); const errs = [];
  p.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()); }); p.on('pageerror', (e) => errs.push('PAGEERROR ' + e.message));
  /* seed once per tab. A window.name marker is used instead of a localStorage flag: right after a reload headless Chromium can show an init script an EMPTY localStorage (reproduced with a blank page and no game code), which made the old flag re-seed and wipe the saved settings. */
  await p.addInitScript(() => { try { if (window.name !== 'tallow-test-seeded') { window.name = 'tallow-test-seeded'; localStorage.setItem('tallow.settings.v1', JSON.stringify({ three: false, quality: 'low' })); } } catch (e) {} });
  await p.goto('file://' + process.cwd() + '/index.html'); await p.waitForTimeout(1200);
  const ev = (f, a) => p.evaluate(f, a), click = (id) => ev((i) => document.getElementById(i).click(), id), vis = (id) => ev((i) => { const e = document.getElementById(i); return !!e && !e.classList.contains('hidden') && e.offsetParent !== null; }, id);
  const tab = async (i) => { await ev((i) => document.querySelectorAll('#setTabs button')[i].click(), i); await p.waitForTimeout(150); };
  const stored = () => ev(() => JSON.parse(localStorage.getItem('tallow.settings.v1')));
  const setRange = async (key, v) => { await ev(([k, v]) => { const r = document.getElementById('set_' + k) || document.getElementById('set_' + k + '_a'); r.value = v; r.dispatchEvent(new Event('input', { bubbles: true })); r.dispatchEvent(new Event('change', { bubbles: true })); }, [key, v]); await p.waitForTimeout(120); };

  // --- settings sheet
  await click('mSettings'); await p.waitForTimeout(300); ok('settings sheet opens', await vis('mSet'));
  ok('7 tabs with icons + labels', await ev(() => [...document.querySelectorAll('#setTabs button')].every((t) => t.querySelector('svg') && t.textContent.trim().length > 2)) && await ev(() => document.querySelectorAll('#setTabs button').length === 7));
  const kinds = {}; for (let i = 0; i < 7; i++) { await tab(i); const k = await ev(() => ({ range: document.querySelectorAll('#setBody input[type=range]').length, tog: document.querySelectorAll('#setBody .tog').length, seg: document.querySelectorAll('#setBody .seg').length, sel: document.querySelectorAll('#setBody select').length })); for (const q in k) kinds[q] = (kinds[q] || 0) + k[q]; }
  ok('sheet uses sliders, toggles, segmented buttons and dropdowns', kinds.range >= 14 && kinds.tog >= 8 && kinds.seg >= 5 && kinds.sel >= 2, JSON.stringify(kinds));
  ok('every row has a visible label', await ev(() => { let bad = 0; document.querySelectorAll('#setBody .srow:not(.note):not(.full) > label').forEach((l) => { if (!l.textContent.trim()) bad++; }); return bad === 0; }));

  // --- every slider writes its value to storage and takes effect
  await tab(0); await tab(4);       // weapon tab
  await setRange('gunX', 17); await setRange('gunY', -9); await setRange('gunScale', 1.1); await setRange('xhairSize', 1.5); await setRange('xhairAlpha', 0.5); await setRange('camSway', 0.9);
  await p.waitForTimeout(600); let st = await stored();
  ok('weapon sliders are saved', st.gunX === 17 && st.gunY === -9 && Math.abs(st.gunScale - 1.1) < 1e-6 && st.xhairSize === 1.5 && st.xhairAlpha === 0.5 && st.camSway === 0.9, JSON.stringify(st));
  ok('weapon offset reaches the renderer', await ev(() => window.Renderer.gunOff.x === 17 && window.Renderer.gunOff.y === -9 && window.Renderer.camSway === 0.9 && window.Renderer.xhair.size === 1.5));
  ok('weapon preview redraws', await ev(() => document.querySelector('.wprevbox svg') && document.querySelector('.wprevbox svg g[transform]').getAttribute('transform').includes('scale(1.1)')));
  await ev(() => { const s = document.querySelector('#setBody select'); s.value = '2'; s.dispatchEvent(new Event('change', { bubbles: true })); });
  ok('crosshair dropdown stores the style', (await stored()).crosshair === 'cross' && await ev(() => window.Renderer.xhair.style === 'cross'));
  await ev(() => document.querySelectorAll('#setBody .seg')[0].querySelectorAll('button')[2].click()); await p.waitForTimeout(100);
  ok('weapon stability mode is stored', (await stored()).gunHold === 'natural' && await ev(() => window.Show.gunIdle('dealer') === 'gun_idle_dealer_natural'));
  await ev(() => document.querySelectorAll('#setBody .seg')[0].querySelectorAll('button')[0].click());
  ok('locked stability picks the locked idle clip', await ev(() => window.Show.gunIdle('held') === 'gun_idle_held_locked' && !!window.AnimData && true));
  await tab(5);   // interface
  await setRange('uiScale', 1.15); await setRange('hudAlpha', 0.7); await p.waitForTimeout(500);
  ok('UI scale + HUD opacity apply to the page', await ev(() => document.documentElement.style.getPropertyValue('--ui') === '1.15' && document.documentElement.style.getPropertyValue('--hudA') === '0.7'));
  const togs = await ev(() => [...document.querySelectorAll('#setBody .tog')].map((t) => t.getAttribute('aria-label')));
  await ev(() => document.querySelectorAll('#setBody .tog')[0].click()); await p.waitForTimeout(100);
  ok('button captions toggle applies', (await stored()).hudLabels === false && await ev(() => document.documentElement.dataset.labels === '0'), togs.join(','));
  await ev(() => document.querySelectorAll('#setBody .seg')[0].querySelectorAll('button')[0].click()); await p.waitForTimeout(100);
  ok('left-handed layout applies', (await stored()).hudSide === 'left' && await ev(() => document.documentElement.dataset.side === 'left'));
  await ev(() => document.querySelectorAll('#setBody .tog')[1].click()); await p.waitForTimeout(150);
  ok('FPS counter shows', await ev(() => !document.getElementById('fps').classList.contains('hidden')));
  // accent swatches: locked until the matching achievement is earned
  ok('four accent colours are locked at the start', await ev(() => document.querySelectorAll('.sw.locked').length === 4 && document.querySelectorAll('.sw').length === 5));
  await ev(() => document.querySelectorAll('.sw.locked')[0].click()); await p.waitForTimeout(100); ok('clicking a locked accent does not select it', (await stored()).accent === 'ember');
  await tab(2);   // video
  await setRange('brightness', 0.8); await p.waitForTimeout(300);
  ok('brightness overlay applies', await ev(() => parseFloat(document.getElementById('bright').style.opacity) > 0.15));
  await ev(() => document.querySelectorAll('#setBody .tog')[1].click()); await p.waitForTimeout(100); ok('vignette toggle reaches the renderer', await ev(() => window.Renderer.vignette === false));
  await tab(3); await ev(() => document.querySelectorAll('#setBody .tog')[0].click()); await p.waitForTimeout(100); ok('invert-look setting stored', (await stored()).invertY === true);
  await tab(6); await ev(() => [...document.querySelectorAll('#setBody .tog')].find((t) => /contrast/i.test(t.getAttribute('aria-label'))).click()); await p.waitForTimeout(100);
  ok('high-contrast HUD applies', await ev(() => document.documentElement.dataset.contrast === '1'));
  // reset this page only
  await tab(5); await click('setReset'); await p.waitForTimeout(200); st = await stored();
  ok('reset restores only the open page', st.uiScale === 1 && st.hudSide === 'right' && st.brightness !== 1 && st.contrast === true, JSON.stringify({ ui: st.uiScale, side: st.hudSide, br: st.brightness, c: st.contrast }));
  await click('setBack'); await p.waitForTimeout(200);

  // --- persistence across reload
  await p.reload(); await p.waitForFunction(() => window.Turns && window.Turns.settings && window.Renderer && window.Renderer.gunOff, null, { timeout: 30000 }); await p.waitForTimeout(500);
  { const v = await ev(() => ({ gunX: window.Turns.settings.gunX, inv: window.Turns.settings.invertY, off: window.Renderer.gunOff && window.Renderer.gunOff.x, c: document.documentElement.dataset.contrast, raw: localStorage.getItem('tallow.settings.v1').slice(0, 80) })); ok('settings survive a reload', v.gunX === 17 && v.inv === true && v.off === 17 && v.c === '1', JSON.stringify(v)); }

  // --- achievements
  const meta0 = await ev(() => ({ n: window.GameData.achDefs.length, ids: window.GameData.achievements.length }));
  ok('28 achievements in four tiers', meta0.n === 28 && meta0.ids === 28 && await ev(() => ['b', 'c', 'a', 'l'].every((t) => window.GameData.achDefs.some((a) => a.tier === t))));
  await click('bAch'); await p.waitForTimeout(400); ok('achievements page opens', await vis('mAch'));
  ok('every card has an icon, a progress bar and a reward', await ev(() => [...document.querySelectorAll('#achList .ach')].length === 28 && [...document.querySelectorAll('#achList .ach')].every((c) => c.querySelector('.ai svg') && c.querySelector('.bar > i') && c.querySelector('.rw'))));
  ok('completion text shows 0 of 28', await ev(() => /0 of 28/.test(document.getElementById('achSum').textContent) && document.getElementById('achPct').textContent === '0%'));
  await ev(() => document.querySelectorAll('#achTabs button')[4].click()); await p.waitForTimeout(200);
  ok('tier filter shows only legendary', await ev(() => document.querySelectorAll('#achList .ach').length === 6 && [...document.querySelectorAll('#achList .ach')].every((c) => c.classList.contains('t-l'))));
  await ev(() => document.querySelector('#mAch [data-close]').click());
  // real gameplay stats drive unlocks: simulate the event stream the game produces
  const r1 = await ev(() => {
    const T = window.Turns, P = window.Progress, m = T.meta; const before = m.coins || 0;
    P.track([{ t: 'shot', who: 'p', target: 'opp', victim: 'd', type: 'e', dmg: 1, charged: false }], null, m);
    return { spark: !!m.ach.spark, coins: m.coins - before, hits: m.stats.hits, shots: m.stats.shots };
  });
  ok('hitting the dealer unlocks "Spark" and pays its Wax reward', r1.spark && r1.coins === 10 && r1.hits === 1 && r1.shots === 1, JSON.stringify(r1));
  await p.waitForTimeout(500); ok('unlock pop-up appears with name + reward', await ev(() => { const a = document.querySelector('#achPop .apop'); return !!a && /Spark/.test(a.textContent) && /\+10 Wax/.test(a.textContent) && a.classList.contains('t-b'); }));
  await p.screenshot({ path: '/tmp/claude-0/shots/ach_pop.png', timeout: 120000 });
  const r2 = await ev(() => { const P = window.Progress, m = window.Turns.meta, ev = []; for (let i = 0; i < 5; i++) ev.push({ t: 'shot', who: 'p', target: 'self', victim: 'p', type: 'a', dmg: 0, charged: false }); P.track(ev, null, m); return { nerves: !!m.ach.nerves, self: m.stats.selfShots, ash: m.stats.ashSelf, shots: m.stats.shots }; });
  ok('self shots and ash survived are counted; "Nerves of Tallow" unlocks at 5', r2.nerves && r2.self === 5 && r2.ash === 5 && r2.shots === 6, JSON.stringify(r2));
  const r3 = await ev(() => { const m = window.Turns.meta, c = m.coins; window.Progress.check(m); window.Progress.check(m); return m.coins === c; });
  ok('an achievement pays out exactly once', r3);
  await click('bAch'); await p.waitForTimeout(400);
  { const v = await ev(() => ({ d: document.querySelectorAll('#achList .ach.done').length, w: [...document.querySelectorAll('#achList .ach:not(.done) .bar > i')].some((i) => parseFloat(i.style.width) > 0 && parseFloat(i.style.width) < 100), f: document.querySelectorAll('#achList .ach.fresh').length, ach: Object.keys(window.Turns.meta.ach).join(',') })); ok('page shows the earned ones as done and partial progress as a percentage', v.d === 2 && v.w, JSON.stringify(v)); ok('newly unlocked cards are highlighted', v.f === 2, JSON.stringify(v)); }
  await ev(() => document.querySelector('#mAch [data-close]').click());
  // reward: an accent colour unlocks with its achievement
  await ev(() => { const m = window.Turns.meta; m.stats.wins = 1; window.Progress.check(m); });
  await p.waitForTimeout(300); ok('winning a game unlocks the Gold accent', await ev(() => window.Progress.accentUnlocked('gold') && !!window.Turns.meta.ach.out_of_room));
  await click('mSettings'); await p.waitForTimeout(250); await tab(5); await p.waitForTimeout(150);
  await ev(() => [...document.querySelectorAll('.sw')][1].click()); await p.waitForTimeout(150);
  ok('unlocked accent can be selected and recolours the UI', (await stored()).accent === 'gold' && await ev(() => getComputedStyle(document.documentElement).getPropertyValue('--ember').trim() === '#ffb43a'));
  await click('setBack'); await p.waitForTimeout(200);

  // --- statistics page
  await click('hStats'); await p.waitForTimeout(400); ok('statistics page opens from the menu', await vis('mStats'));
  ok('statistics show real numbers', await ev(() => { const t = document.getElementById('statsBody').textContent; return /Shots fired/.test(t) && /Time played/.test(t) && document.querySelectorAll('#statsBody .stitem').length >= 20 && document.querySelectorAll('#statsBody .tile').length === 4; }));
  ok('statistics reflect the tracked shots', await ev(() => { const items = [...document.querySelectorAll('#statsBody .stitem')]; const f = (l) => { const e = items.find((x) => x.textContent.startsWith(l)); return e ? e.querySelector('b').textContent : null; }; return f('Shots fired') === '6' && f('Dealer hit') === '1' && f('Shots at yourself') === '5'; }));
  await ev(() => document.querySelector('#mStats [data-close]').click());
  // saved to storage
  ok('meta (stats + achievements) is saved', await ev(() => { const m = JSON.parse(localStorage.getItem('tallow.meta.v1')); return m.ach.spark === 1 && m.stats.shots === 6 && m.coins >= 10; }));

  // --- in-game: play time counts, HUD icon buttons are visible and unique
  await click('mNew'); await p.waitForTimeout(250); await ev(() => document.querySelector('#diffList button').click()); await p.waitForTimeout(500);
  for (let i = 0; i < 8 && await vis('mTut'); i++) { await click('tutNext'); await p.waitForTimeout(200); }
  await p.waitForFunction(() => window.Turns.canAct && window.Turns.canAct(), null, { timeout: 60000 }); const t0 = await ev(() => window.Turns.meta.stats.playSec); await p.waitForTimeout(3200);
  ok('play time only counts while a game runs', await ev((t0) => window.Turns.meta.stats.playSec >= t0 + 2, t0));
  ok('HUD action buttons are icon buttons with captions', await ev(() => ['btnInv', 'btnAimS', 'btnAimD'].every((id) => { const e = document.getElementById(id); return e.querySelector('svg') && e.querySelector('.cap'); })));
  await click('btnPause'); await p.waitForTimeout(300); const t1 = await ev(() => window.Turns.meta.stats.playSec); await p.waitForTimeout(2500);
  ok('paused time is not counted', await ev((t1) => window.Turns.meta.stats.playSec <= t1 + 1, t1));
  ok('no console errors', errs.length === 0, errs.slice(0, 3).join(' | '));
  console.log(out.join('\n')); console.log('\n' + out.filter((l) => l.startsWith('PASS')).length + ' passed, ' + out.filter((l) => l.startsWith('FAIL')).length + ' failed');
  await b.close();
})();
