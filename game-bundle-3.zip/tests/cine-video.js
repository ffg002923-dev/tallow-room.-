/* records the real game (software WebGL) while the Dealer's rage scene plays, so frames can be pulled out with ffmpeg. usage: node tests/cine-video.js [outdir] */
const { chromium } = require('playwright');
(async () => {
  const dir = process.argv[2] || '/tmp/vid';
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const ctx = await b.newContext({ viewport: { width: 915, height: 412 }, hasTouch: true, isMobile: true, recordVideo: { dir, size: { width: 915, height: 412 } } });
  const p = await ctx.newPage(); const logs = [];
  await p.addInitScript(() => { try { localStorage.setItem('tallow.settings.v1', JSON.stringify({ quality: 'medium', subtitles: true })); } catch (e) {} });
  p.on('console', m => { if (m.type() === 'error') logs.push(m.text()); }); p.on('pageerror', e => logs.push('PAGEERROR: ' + e.message));
  await p.goto('file://' + process.cwd() + '/index.html', { waitUntil: 'domcontentloaded', timeout: 120000 }); await p.waitForTimeout(2500);
  await p.evaluate(() => document.getElementById('mNew').click()); await p.waitForTimeout(300);
  await p.evaluate(() => document.querySelector('#diffList button').click()); await p.waitForTimeout(2500);
  await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find(x => /skip/i.test(x.textContent) && x.offsetParent); if (b) b.click(); });
  // the round-start cinematic plays by itself right now: keep recording through it, then trigger the rage scene
  await p.waitForFunction(() => window.Turns && window.Turns.canAct && window.Turns.canAct(), null, { timeout: 170000 }); await p.waitForTimeout(1500);
  const t = Date.now(); await p.evaluate(() => { window.__t0 = performance.now(); window.Show.death('d', null).then(() => { window.__done = true; }).catch(e => { window.__err = String(e); }); });
  await p.waitForFunction(() => window.__done || window.__err, null, { timeout: 60000 }).catch(() => {}); await p.waitForTimeout(1000);
  console.log('rage scene ms', Date.now() - t, await p.evaluate(() => window.__err || 'ok')); console.log(logs.slice(0, 6).join('\n') || 'no console errors'); await ctx.close(); await b.close();
})();
