/* Node tests for the supplied-hands system (no browser): asset integrity, skeleton, poses, the grip solver for every item and both hands, the 8-state controller.
   usage: node tests/hands.test.js */
'use strict';
const path = require('path'), root = path.join(__dirname, '..');
require(path.join(root, 'scripts/util.js')); require(path.join(root, 'data/game-data.js'));
require(path.join(root, 'data/br-assets.js')); require(path.join(root, 'data/fps-arms.js'));
const H = require(path.join(root, 'scripts/hands.js')); const BR = globalThis.BR, D = globalThis.GameData || globalThis.D;
let pass = 0, fail = 0; const ok = (c, m) => { if (c) pass++; else { fail++; console.log('  FAIL:', m); } };
const fin = (a) => { for (let i = 0; i < a.length; i++) if (!isFinite(a[i])) return false; return true; };

// ---- 1) baked assets
ok(!!BR && !!BR.body && !!BR.pump && !!BR.hands && !!BR.meta, 'BR assets present (body, pump, hands, meta)');
const meshOk = (m, skin) => { const n = m.p.length / 3; return m.p.length % 3 === 0 && m.n.length === m.p.length && m.t.length === n * 2 && m.i.length % 3 === 0 && Math.max(...m.i) < n && fin(m.p) && fin(m.n) && (!skin || (m.j.length === n * 4 && m.w.length === n * 4)); };
const parts = []; for (const k of ['body', 'pump']) { const b = BR[k]; for (const g of Object.keys(b)) if (b[g] && b[g].p) parts.push([k + '.' + g, b[g]]); if (b.p) parts.push([k, b]); }
ok(parts.length >= 2, 'gun meshes found (' + parts.map((x) => x[0]).join(', ') + ')');
for (const [n, m] of parts) ok(meshOk(m, false), 'gun mesh "' + n + '" has consistent positions / normals / UVs / indices (' + (m.p.length / 3) + ' verts)');
for (const k of ['R', 'L']) ok(meshOk(BR.hands[k], true), 'hand mesh ' + k + ' is consistent and skinned (' + BR.hands[k].p.length / 3 + ' verts)');
ok(Math.abs(BR.meta.muzzle[0] - 1.905) < 0.01, 'gun length matches the original scale (muzzle x = ' + BR.meta.muzzle[0] + ')');

// ---- 2) skeleton
ok(H.init() === true, 'Hands.init()');
for (const k of ['R', 'L']) {
  const r = H.rig[k]; ok(r.n === 20, k + ': 20 bones (' + r.n + ')'); ok(new Set(r.names).size === r.n, k + ': bone names are unique');
  ok(r.par.every((p, i) => p === -1 || (p >= 0 && p < i)), k + ': parents precede children (hierarchy is a tree)');
  ok([0, 1, 2, 3, 4].every((f) => r.fing.indexOf(f) >= 0), k + ': five independent fingers present (the file\'s own bone names are kept: ' + r.names.slice(0, 3).join(', ') + '...)');
  const S = r.skin(r.bindPose(), 0); let dev = 0; for (let j = 0; j < r.n; j++) { const I = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0]; for (let q = 0; q < 12; q++) dev = Math.max(dev, Math.abs(S[j * 12 + q] - I[q])); }
  ok(dev < 1e-3, k + ': the bind pose reproduces the file\'s grip pose exactly (max palette deviation ' + dev.toExponential(1) + ')');
  for (const c of [0.3, 0.5, 0.8, 1]) ok(fin(r.skin(r.curlPose([c, c, c, c, c]), 0.1)), k + ': curl ' + c + ' gives a finite skin palette');
  // fingers are independent: curling only the index must not move the pinky chain
  const a = r.curlPose([1, 1, 1, 1, 1]), b = r.curlPose([0.3, 1, 1, 1, 1]); let diffI = 0, diffP = 0; for (let i = 0; i < r.n; i++) { const f = r.fing[i], d = Math.abs(a[i] - b[i]); if (f === 0) diffI += d; else if (f >= 0) diffP += d; }
  ok(diffI > 0.3 && diffP < 1e-9, k + ': fingers are independent (index changes by ' + diffI.toFixed(2) + ' rad, the other fingers by ' + diffP.toExponential(0) + ')');
}

// ---- 3) grip solver: every item, both hands, three hand scales
const ids = (D && D.itemOrder) || Object.keys(H.ITEM_GRIPS); let worst = 0, worstId = '', cnt = 0;
for (const id of ids) ok(!!H.ITEM_GRIPS[id], 'item "' + id + '" has a grip entry (size / shape / grip type)');
for (const key of ['R', 'L']) for (const id of Object.keys(H.ITEM_GRIPS)) for (const hs of [0.24, 0.26, 0.28]) {   // 0.26 = the hand scale used in the game, +-8%
  const g = H.itemGrip(key, id, hs); cnt++; ok(fin(g.th) && isFinite(g.pen), key + '/' + id + '@' + hs + ': solved pose is finite');
  if (g.pen < worst) { worst = g.pen; worstId = key + '/' + id + '@' + hs; }
  ok(g.pen > -0.03, key + '/' + id + '@' + hs + ': finger penetration ' + (g.pen * hs * 100).toFixed(2) + ' cm (limit 0.8 cm)');
}
console.log('  grip solver: ' + cnt + ' item/hand/scale combinations, worst penetration ' + worst.toFixed(4) + ' units at ' + worstId);

// ---- 4) the 8-state controller
const st = (c) => c.state, run = (c, n, inp, dt) => { const seq = []; for (let i = 0; i < n; i++) { c.update(dt || 0.016, inp); if (seq[seq.length - 1] !== c.state) seq.push(c.state); } return seq; };
const mk = () => H.newCtl('R', 'p', 'r');
ok(H.STATES.join() === 'idle,weapon,pickup,hold,release,interact,reload,transition', 'the 8 states exist in the specified order');
{
  const c = mk(); let all = [];
  all = all.concat(run(c, 30, {}));                                         ok(st(c) === 'idle', 'state 1 idle: relaxed hands with no input');
  all = all.concat(run(c, 20, { near: 1 }));                                ok(st(c) === 'pickup', 'state 3 pickup: reaching for something');
  const seqG = run(c, 80, { gun: true });                                    ok(seqG.join() === 'transition,weapon' && c.attach === 1, 'gun grab: ' + seqG.join(' > ') + ' (attach ' + c.attach.toFixed(3) + ')');
  ok(run(c, 40, { gun: true, reload: 0.6 }).join() === 'reload', 'state 7 reloading: the support hand works the pump');
  ok(run(c, 5, { gun: true, reload: 0 }).join() === 'weapon', 'back to weapon holding after the pump');
  const seqR = run(c, 120, { gun: false });                                  ok(seqR.join() === 'release,idle' && c.attach === 0, 'gun release: ' + seqR.join(' > '));
  const g = H.itemGrip('R', 'can', 0.26);
  const seqI = run(c, 60, { item: { id: 'can', th: g.th }, grab: 1 });       ok(seqI.join() === 'pickup,hold', 'item: ' + seqI.join(' > ') + ' (state 3 -> 4)');
  const seqL = run(c, 80, {});                                                ok(seqL.join() === 'release,idle', 'item let go: ' + seqL.join(' > ') + ' (state 5)');
  ok(run(c, 30, { point: 1 }).join() === 'interact', 'state 6 interaction: pointing / pressing buttons');
  { // a use animation may relax the fingers while the item is still in the hand: still "hold"; only a real opening is a release
    const g2 = H.itemGrip('R', 'battery', 0.26), c3 = mk(); run(c3, 60, { item: { id: 'battery', th: g2.th }, grab: 1 });
    ok(run(c3, 40, { item: { id: 'battery', th: g2.th }, grab: 0.55 }).join() === 'hold', 'item stays in state 4 (hold) while the fingers only relax (grab 0.55)');
    const sq = run(c3, 60, { item: { id: 'battery', th: g2.th }, grab: 0.05 }); ok(sq[sq.length - 1] === 'release', 'fingers opening around the item = state 5 (release): ' + sq.join(' > '));
    ok(run(c3, 80, {}).join() === 'idle' && !c3.gripped, 'then the hand is idle again and ready for the next item');
  }
  ok(fin(c.th), 'joint angles stay finite through the whole sequence');
  // fast flips must not produce a state outside the 8, nor a pose that jumps: track the largest per-frame change of any joint angle
  let jump = 0, prev = Float32Array.from(c.th); const c2 = mk();
  for (let i = 0; i < 600; i++) { const ph = (i / 40) | 0, inp = ph % 4 === 0 ? { gun: true } : ph % 4 === 1 ? { gun: true, reload: 0.7 } : ph % 4 === 2 ? {} : { item: { id: 'coin', th: H.itemGrip('R', 'coin', 0.26).th }, grab: 1 };
    c2.update(0.016, inp); if (H.STATES.indexOf(c2.state) < 0) ok(false, 'unknown state ' + c2.state); for (let j = 0; j < c2.th.length; j++) { if (i > 0) jump = Math.max(jump, Math.abs(c2.th[j] - prev[j])); prev[j] = c2.th[j]; } }
  ok(jump < 0.25, 'no bone jitter: largest joint change in one 16 ms frame over 600 rapid state flips = ' + jump.toFixed(3) + ' rad (limit 0.25)');
}
console.log('\nhands: ' + pass + ' passed, ' + fail + ' failed'); process.exit(fail ? 1 : 0);
