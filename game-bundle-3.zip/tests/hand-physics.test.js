'use strict';
/* a moving hand shoves loose objects; a still / disabled hand does not; shells roll; everything stays finite */
global.window = global; require('../scripts/util.js'); const P = require('../scripts/physics.js');
let pass = 0, fail = 0; const ok = (c, n) => { if (c) pass++; else { fail++; console.log('FAIL', n); } };
function run(sec) { for (let i = 0; i < sec * 60; i++) P.step(1 / 60); }
P.clear(); P.pushers = [{ x: -60, y: 560, vx: 600, vy: 0, r: 34, on: true }];
const s = P.spawn('shell_e', -20, 560, 0, 0, 0, 0, 0, 0); s.settled = true;
for (let i = 0; i < 20; i++) { const h = P.pushers[0]; h.x += 10; P.step(1 / 60); }
ok(s.x > 0 && !s.settled || s.x > -20, 'moving hand pushes a settled shell'); ok(Math.abs(s.vx) > 20 || s.x > 30, 'shell gained momentum');
run(3); ok(isFinite(s.x) && isFinite(s.y) && isFinite(s.rot), 'finite state'); ok(s.x < 430 && s.y >= 405 && s.y <= 700, 'stays on the table');
ok(s.settled, 'shell comes to rest again');
P.clear(); P.pushers = [{ x: -60, y: 560, vx: 600, vy: 0, r: 34, on: false }];
const t = P.spawn('shell_e', -20, 560, 0, 0, 0, 0, 0, 0); t.settled = true; for (let i = 0; i < 20; i++) { P.pushers[0].x += 10; P.step(1 / 60); } ok(t.x === -20, 'a disabled hand does not push');
P.clear(); P.pushers = []; const r = P.spawn('shell_e', -100, 560, 0, 300, 0, 0, 0, 0); run(0.15); ok(Math.abs(r.vr) > 2, 'moving shell rolls (spin follows speed)');
P.clear(); P.pushers = [{ x: 0, y: 560, vx: 900, vy: 0, r: 34, on: true }]; for (let i = 0; i < 6; i++) P.spawn('coin', i * 12 - 30, 560, 0, 0, 0, 0, i, 0); for (let i = 0; i < 120; i++) { P.pushers[0].x += 8; P.step(1 / 60); } ok(P.bodies.every((b) => isFinite(b.x) && isFinite(b.y)), 'cluster of coins stays finite under a sweeping hand');
console.log('hand-physics: ' + pass + ' passed, ' + fail + ' failed'); process.exit(fail ? 1 : 0);
