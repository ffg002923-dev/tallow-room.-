/* dealer-only variant of br-items.js: the Ghost picks up, holds, uses and releases the first 6 items through the real Show.item() flow.
   usage: node tests/ghost-items.js [settingsJSON] [tag] */
const { chromium } = require('playwright');
const fs = require('fs');
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const ctx = await b.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 1, hasTouch: true, isMobile: true });
  const p = await ctx.newPage(); const logs = [];
  const extra = process.argv[2] && process.argv[2] !== '-' ? JSON.parse(process.argv[2]) : {}, tag = process.argv[3] || 'i';
  fs.mkdirSync('/tmp/claude-0/shots', { recursive: true });
  await p.addInitScript((x) => { try { localStorage.setItem('tallow.settings.v1', JSON.stringify(Object.assign({ quality: 'low' }, x))); } catch (e) {} }, extra);
  p.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') logs.push(m.type() + ': ' + m.text()); }); p.on('pageerror', (e) => logs.push('PAGEERROR: ' + e.message));
  await p.goto('file://' + process.cwd() + '/index.html'); await p.waitForTimeout(2500);
  await p.evaluate(() => document.getElementById('mNew').click()); await p.waitForTimeout(300);
  await p.evaluate(() => document.querySelector('#diffList button').click()); await p.waitForTimeout(1500);
  await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find((x) => /skip/i.test(x.textContent) && x.offsetParent); if (b) b.click(); });
  await p.waitForFunction(() => window.Turns && window.Turns.canAct && window.Turns.canAct(), null, { timeout: 180000 });
  await p.waitForTimeout(1500);
  const ids = await p.evaluate(() => window.GameData.itemOrder);
  await p.evaluate(() => {
    const S = window.Stage3D, Sh = window.Show, R = window.Renderer; const T = window.__T = { frames: [], ids: [] };
    const orig = S.render;
    S.render = function (r) {
      const out = orig.apply(this, arguments);
      try { const hs = S.handStates(), held = r.scene.held; T.frames.push({ t: r.t, who: T.who || '', id: T.id || '', hp: held.p ? held.p.id : null, hd: held.d ? held.d.id : null, st: { pl: hs.p.l && hs.p.l.state, pr: hs.p.r && hs.p.r.state, dl: hs.d.l && hs.d.l.state, dr: hs.d.r && hs.d.r.state }, gr: hs.grip || null }); } catch (e) { T.err = String(e && e.stack || e); }
      return out;
    };
  });
  const results = [];
  const shots = { p: [], d: [] };
  for (const who of ['d']) {
    for (const id of (who === 'p' ? ids : ids.slice(0, 2))) {
      await p.evaluate(([w, i]) => { const T = window.__T; T.who = w; T.id = i; }, [who, id]);
      // run the real flow; poll for the "hold" moment to take a screenshot
      const run = p.evaluate(async ([w, i]) => { await window.Show.item({ who: w, id: i, idx: 0, consumed: false, fx: { k: 'none' } }); await new Promise((r) => setTimeout(r, 900)); return true; }, [who, id]);
      if (shots[who].indexOf(id) >= 0) {
        try { await p.waitForFunction(([w, i]) => { const h = window.Renderer.scene.held; return h[w] && h[w].id === i; }, [who, id], { timeout: 20000, polling: 100 }); await p.waitForTimeout(700); await p.screenshot({ path: '/tmp/claude-0/shots/gi_' + tag + '_' + who + '_' + id + '.png', timeout: 120000 }); } catch (e) { logs.push('screenshot ' + who + id + ': ' + e.message); }
      }
      await run;
      await p.evaluate(() => window.Show.sleep ? window.Show.sleep(0.2) : 0);
    }
    console.log(who === 'p' ? 'player items done' : 'dealer items done');
  }
  const frames = await p.evaluate(() => ({ f: window.__T.frames, err: window.__T.err || null }));
  fs.writeFileSync('/tmp/claude-0/shots/gi_' + tag + '_frames.json', JSON.stringify(frames.f));
  const F = frames.f; let pass = 0, fail = 0; const ok = (c, m) => { if (c) { pass++; console.log('  PASS ' + m); } else { fail++; console.log('  FAIL ' + m); } };
  const compress = (a) => a.filter((s, i) => s && s !== a[i - 1]);
  for (const who of ['d']) for (const id of (who === 'p' ? ids : ids.slice(0, 2))) {
    const a = F.filter((f) => f.who === who && f.id === id); const hk = who === 'p' ? 'pr' : 'dl';       // the hand that carries the item: the animation's "r" hand (screen right for the player, the Dealer's mirrored side)
    const seqR = compress(a.map((f) => f.st[who + 'r'])), seqL = compress(a.map((f) => f.st[who + 'l']));
    const heldFrames = a.filter((f) => (who === 'p' ? f.hp : f.hd) === id);
    const holdR = heldFrames.filter((f) => f.st[who + 'r'] === 'hold' || f.st[who + 'l'] === 'hold');
    console.log('    ' + who + ' ' + id.padEnd(10) + ' frames ' + String(a.length).padStart(4) + '  held ' + String(heldFrames.length).padStart(3) + '  right: ' + seqR.join('>') + '   left: ' + seqL.join('>'));
    ok(heldFrames.length > 3, who + '/' + id + ': the item is held in the scene (' + heldFrames.length + ' frames)');
    ok(holdR.length > 0 && seqR.indexOf('pickup') >= 0 && seqR.indexOf('release') >= 0, who + '/' + id + ': a hand goes through pickup > hold > release (' + seqR.join('>') + ')');
    const known = ['idle', 'weapon', 'pickup', 'hold', 'release', 'interact', 'reload', 'transition'];
    ok(a.every((f) => ['pl', 'pr', 'dl', 'dr'].every((k) => !f.st[k] || known.indexOf(f.st[k]) >= 0)), who + '/' + id + ': only the 8 defined states appear');
    ok(a.every((f) => ['pl', 'pr', 'dl', 'dr'].every((k) => f.st[k] !== 'weapon' && f.st[k] !== 'reload')), who + '/' + id + ': no weapon states while handling an item');
  }
  console.log('\nconsole: ' + (logs.length ? '\n' + logs.slice(0, 8).join('\n') : 'no errors or warnings'));
  ok(logs.filter((l) => /error/i.test(l)).length === 0, 'no console errors / page errors');
  console.log('\nitems: ' + pass + ' passed, ' + fail + ' failed'); await b.close(); process.exit(fail ? 1 : 0);
})();
