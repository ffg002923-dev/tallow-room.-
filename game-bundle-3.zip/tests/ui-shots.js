/* renders the redesigned screens at several viewport sizes (software WebGL) and reports layout problems:
   horizontal overflow, controls that overflow their container, overlapping HUD buttons, tiny touch targets. Screenshots go to $SHOTS (default /tmp/claude-0/shots). */
const { chromium } = require('playwright');
const OUT = process.env.SHOTS || '/tmp/claude-0/shots';
const SIZES = (process.env.SIZES || '915x412,740x360,1280x720,2400x1080').split(',').map((s) => s.split('x').map(Number));
const ONLY = process.env.ONLY ? process.env.ONLY.split(',') : null;
(async () => {
  const b = await chromium.launch();   // UI screens do not need WebGL: the 2D renderer keeps this fast
  let problems = 0; const say = (...a) => console.log(...a);
  for (const [w, h] of SIZES) {
    const ctx = await b.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: 1, hasTouch: true, isMobile: w < 1000 });
    const p = await ctx.newPage(); const logs = [];
    p.on('console', (m) => { if (m.type() === 'error') logs.push(m.text()); }); p.on('pageerror', (e) => logs.push('PAGEERROR: ' + e.message));
    await p.addInitScript(() => { try { localStorage.setItem('tallow.settings.v1', JSON.stringify({ quality: 'low', three: false, lang: new URLSearchParams(location.search).get('ar') ? 'ar' : 'en' })); } catch (e) {} });
    await p.goto('file://' + process.cwd() + '/index.html' + (process.env.AR ? '?ar=1' : '')); await p.waitForTimeout(2500);
    const shot = async (name) => { if (ONLY && !ONLY.includes(name)) return; await p.screenshot({ path: OUT + '/ui_' + w + 'x' + h + '_' + name + '.png', timeout: 120000 }); };
    const check = async (name, sel) => {
      const r = await p.evaluate((sel) => {
        const out = [], root = document.querySelector(sel); if (!root) return ['missing ' + sel];
        const vw = innerWidth, vh = innerHeight, rr = root.getBoundingClientRect();
        if (rr.right > vw + 1 || rr.bottom > vh + 1 || rr.left < -1 || rr.top < -1) out.push('container outside viewport ' + [rr.left, rr.top, rr.right, rr.bottom].map(Math.round).join(','));
        if (document.documentElement.scrollWidth > vw + 1) out.push('page scrolls horizontally');
        root.querySelectorAll('button, select, input').forEach((e) => {
          if (!e.offsetParent && getComputedStyle(e).position !== 'fixed') return; const b = e.getBoundingClientRect(); if (b.width === 0) return;
          if (!e.classList.contains('tog') && (b.width < 30 || b.height < 28) || e.classList.contains('tog') && (b.width < 44 || b.height < 24)) out.push('small control ' + (e.id || e.className || e.tagName) + ' ' + Math.round(b.width) + 'x' + Math.round(b.height));
        });
        root.querySelectorAll('*').forEach((e) => { if (e.scrollWidth > e.clientWidth + 2 && ['visible'].includes(getComputedStyle(e).overflowX) && e.clientWidth > 0 && e.children.length === 0 && (e.textContent || '').trim() && getComputedStyle(e).display !== 'inline') out.push('text overflow: ' + (e.textContent || '').trim().slice(0, 30)); });
        return out;
      }, sel);
      if (r.length) { problems += r.length; say('  [' + w + 'x' + h + '] ' + name + ': ' + r.slice(0, 6).join(' | ')); } else say('  [' + w + 'x' + h + '] ' + name + ': ok');
    };
    await shot('menu'); await check('menu tools', '.mart-tools');
    await p.evaluate(() => document.getElementById('mSettings').click()); await p.waitForTimeout(500);
    for (const tab of ['general', 'audio', 'video', 'controls', 'weapon', 'interface', 'access']) {
      await p.evaluate((t) => { const i = ['general', 'audio', 'video', 'controls', 'weapon', 'interface', 'access'].indexOf(t); document.querySelectorAll('#setTabs button')[i].click(); }, tab); await p.waitForTimeout(+(process.env.WAIT || 350));
      await shot('set_' + tab); await check('settings/' + tab, '#mSet .sheet');
    }
    await p.evaluate(() => document.getElementById('setBack').click()); await p.waitForTimeout(250);
    await p.evaluate(() => document.getElementById('bAch').click()); await p.waitForTimeout(500); await shot('ach'); await check('achievements', '#mAch .card');
    await p.evaluate(() => document.querySelectorAll('#achTabs button')[4].click()); await p.waitForTimeout(300); await shot('ach_legendary');
    await p.evaluate(() => document.querySelector('#mAch [data-close]').click()); await p.waitForTimeout(250);
    await p.evaluate(() => document.getElementById('hStats').click()); await p.waitForTimeout(500); await shot('stats'); await check('statistics', '#mStats .card');
    await p.evaluate(() => document.querySelector('#mStats [data-close]').click()); await p.waitForTimeout(250);
    if (process.env.DIALOGS) {
      const dlg = [['mNew', 'mDiff', 'difficulty'], ['bShop', 'mShop', 'shop'], ['bArchive', 'mArchive', 'archive'], ['bCredits', 'mCredits', 'credits'], ['bLeave', 'mLeave', 'leave']];
      for (const [btn, mod, nm] of dlg) { await p.evaluate((b) => document.getElementById(b).click(), btn); await p.waitForTimeout(400); await shot('dlg_' + nm); await check(nm, '#' + mod + ' .card'); await p.evaluate((m) => document.querySelector('#' + m + ' [data-close]').click(), mod); await p.waitForTimeout(200); }
      await p.evaluate(() => window.UI.showTutorial(() => {})); await p.waitForTimeout(500); await shot('dlg_tutorial'); await check('tutorial', '#mTut .card');
      await p.evaluate(() => document.getElementById('tutSkip').click()); await p.waitForTimeout(200);
    }
    say('  [' + w + 'x' + h + '] console errors: ' + (logs.length ? logs.slice(0, 4).join(' | ') : 'none'));
    await ctx.close();
  }
  say('layout problems: ' + problems); await b.close();
})();
