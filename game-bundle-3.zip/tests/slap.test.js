'use strict';
/* SLAP rule (server engine): only after a survived LIVE self-shot, only by another living seat, once, and never for a blank. */
const { load } = (() => { try { return require('../server/engine-loader.js'); } catch (e) { return {}; } })();
const loader = require('../server/engine-loader.js');
const E = (typeof loader === 'function' ? loader : (loader.loadEngine || loader.load || loader))();
const M = E.MP || E;
let pass = 0, fail = 0; const ok = (c, n) => { if (c) pass++; else { fail++; console.log('FAIL', n); } };
function fresh() { const st = M.newMatch(['a', 'b', 'c'], { seed: 7 }); M.startRound(st); return st; }
function force(st, shells) { st.chamber = shells.slice(); st.pub = { e: shells.filter((x) => x === 'e').length, a: shells.filter((x) => x === 'a').length }; }
{ const st = fresh(); st.turn = 'a'; force(st, ['e', 'a', 'a', 'e']); st[st.turn].hp = 3;
  const r = M.apply(st, 'a', { type: 'shoot', target: 'a' }); ok(r.ok && st.slap && st.slap.victim === 'a', 'live self-shot opens slap');
  ok(!M.slap(st, 'a', 1).ok, 'victim cannot slap himself');
  const s1 = M.slap(st, 'b', 1); ok(s1.ok && s1.ev[0].t === 'slap' && s1.ev[0].to === 'a', 'other seat may slap');
  ok(!M.slap(st, 'c', 2).ok, 'second slap refused (once only)'); }
{ const st = fresh(); st.turn = 'a'; force(st, ['a', 'e', 'e']); M.apply(st, 'a', { type: 'shoot', target: 'a' }); ok(!st.slap, 'blank self-shot never opens a slap'); ok(!M.slap(st, 'b', 1).ok, 'no slap on a blank'); }
{ const st = fresh(); st.turn = 'a'; force(st, ['e', 'a', 'e']); M.apply(st, 'a', { type: 'shoot', target: 'b' }); ok(!st.slap, 'shooting someone else opens no slap'); }
{ const st = fresh(); st.turn = 'a'; force(st, ['e', 'a', 'a', 'e']); M.apply(st, 'a', { type: 'shoot', target: 'a' }); st.slap.at = 1000; ok(!M.slap(st, 'b', 1000 + M.SLAP_MS + 1).ok, 'too-late slap refused'); }
{ const st = fresh(); st.turn = 'a'; force(st, ['e', 'a', 'a', 'e']); M.apply(st, 'a', { type: 'shoot', target: 'a' }); st[st.turn].alive; M.apply(st, st.turn, { type: 'shoot', target: st.turn === 'a' ? 'b' : 'a' }); ok(!M.slap(st, 'c', 1).ok, 'slap expires when play moves on'); }
{ const st = fresh(); st.turn = 'a'; force(st, ['e', 'a', 'a', 'e']); M.apply(st, 'a', { type: 'shoot', target: 'a' }); st.b.alive = false; ok(!M.slap(st, 'b', 1).ok, 'dead seat cannot slap'); }
console.log('slap: ' + pass + ' passed, ' + fail + ' failed'); process.exit(fail ? 1 : 0);
