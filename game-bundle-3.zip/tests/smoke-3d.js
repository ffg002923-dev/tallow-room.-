const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const ctx = await b.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 1, hasTouch: true, isMobile: true });
  const p = await ctx.newPage(); const logs = []; await p.addInitScript(() => { try { localStorage.setItem('tallow.settings.v1', JSON.stringify({ quality: 'medium' })); } catch (e) {} });
  p.on('console', m => logs.push(m.type() + ': ' + m.text())); p.on('pageerror', e => logs.push('PAGEERROR: ' + e.message));
  await p.goto('file://' + process.cwd() + '/index.html'); await p.waitForTimeout(3000);
  console.log(await p.evaluate(() => JSON.stringify({ gl: window.GL3D && window.GL3D.ok, use3d: window.Renderer.use3d, ready: window.Stage3D.ready, draws: window.GL3D.stats })));
  await p.screenshot({ path: '/tmp/claude-0/shots/menu3d.png' });
  if (process.argv[2] === 'game') { await p.evaluate(() => document.getElementById('mNew').click()); await p.waitForTimeout(300); await p.evaluate(() => document.querySelector('#diffList button').click()); await p.waitForTimeout(800); for (let i = 0; i < 8; i++) { await p.evaluate(() => { const e = document.getElementById('tutNext'); if (e && e.offsetParent) e.click(); }); await p.waitForTimeout(200); } await p.waitForTimeout(5000); await p.screenshot({ path: '/tmp/claude-0/shots/game3d.png', timeout: 90000 }); }
  console.log(logs.slice(0, 12).join('\n') || 'no console output');
  await b.close();
})();
