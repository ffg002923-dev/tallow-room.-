/* takes in-game 3D screenshots while the player aims the Caster at the Dealer, to eyeball crosshair/gun alignment */
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const ctx = await b.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 1, hasTouch: true, isMobile: true });
  const p = await ctx.newPage(); const logs = [];
  const extra = process.argv[2] ? JSON.parse(process.argv[2]) : {};
  const tag = process.argv[3] || 'a';
  await p.addInitScript((x) => { try { localStorage.setItem('tallow.settings.v1', JSON.stringify(Object.assign({ quality: 'low' }, x))); } catch (e) {} }, extra);
  p.on('console', m => { if (m.type() === 'error') logs.push(m.text()); }); p.on('pageerror', e => logs.push('PAGEERROR: ' + e.message));
  await p.goto('file://' + process.cwd() + '/index.html'); await p.waitForTimeout(2500);
  await p.evaluate(() => document.getElementById('mNew').click()); await p.waitForTimeout(300);
  await p.evaluate(() => document.querySelector('#diffList button').click()); await p.waitForTimeout(1500);
  await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find(x => /skip/i.test(x.textContent) && x.offsetParent); if (b) b.click(); });
  await p.waitForFunction(() => window.Turns && window.Turns.canAct && window.Turns.canAct(), null, { timeout: 90000 });
  await p.screenshot({ path: '/tmp/claude-0/shots/g3_' + tag + '_idle.png' });
  await p.evaluate(() => document.getElementById('btnAimD').click());
  await p.waitForFunction(() => window.Turns && window.Turns.aim === 'opp', null, { timeout: 60000 }); await p.waitForTimeout(1800);
  await p.screenshot({ path: '/tmp/claude-0/shots/g3_' + tag + '_aim.png' });
  const info = await p.evaluate(() => ({ err: window.Stage3D.aimErrorPx(), cross: window.Stage3D.cross, dbg: window.Stage3D.aimDbg }));
  console.log(JSON.stringify(info));
  console.log(logs.slice(0, 5).join('\n') || 'no console errors');
  await b.close();
})();
