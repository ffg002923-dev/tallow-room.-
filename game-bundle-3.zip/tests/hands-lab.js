/* close-up screenshots of the supplied gun + hands (no game): node tests/hands-lab.js <preset> <out.png> [optionsJSON]
   presets: grip | free | item:<id> */
const { chromium } = require('playwright');
(async () => {
  const preset = process.argv[2] || 'grip', out = process.argv[3] || '/tmp/claude-0/shots/lab.png', opt = process.argv[4] ? JSON.parse(process.argv[4]) : {};
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const p = await b.newPage({ viewport: { width: 900, height: 600 } }); const logs = [];
  p.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') logs.push(m.text()); }); p.on('pageerror', (e) => logs.push('PAGEERROR ' + e.message));
  await p.goto('file://' + __dirname + '/hands-lab.html'); await p.waitForFunction(() => window.__ok !== undefined);
  if (!(await p.evaluate(() => window.__ok))) { console.log('no webgl'); await b.close(); return; }
  await p.waitForFunction(() => window.__ready && window.__ready(), null, { timeout: 60000 });
  await p.evaluate(([n, o]) => window.__draw(window.__scene(n, o)), [preset, opt]); await p.waitForTimeout(300);
  const pen = await p.evaluate(() => window.__pen); await p.screenshot({ path: out });
  console.log('saved', out, pen === undefined ? '' : 'pen ' + pen, logs.join(' | ') || 'no errors');
  await b.close();
})();
