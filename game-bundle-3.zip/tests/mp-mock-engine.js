'use strict';
/* mp-mock-engine.js — minimal implementation of the multiplayer Engine contract, for server tests.
 * Rules: 2-4 seats, hp 2, 6-shell seeded chamber, shoot/peek item, first to 2 round wins takes the match. */
const HP = 2, SLOTS = 6, WINS = 2;

function rnd(st) { // mulberry32, state kept in the match so it is deterministic per seed
  st.rng = (st.rng + 0x6D2B79F5) | 0;
  let t = Math.imul(st.rng ^ (st.rng >>> 15), 1 | st.rng);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}
const alive = (st) => st.order.slice();
const nextAlive = (st, seat) => {
  const o = st.order; if (!o.length) return null;
  const i = o.indexOf(seat);
  if (i < 0) { // seat just died: continue with the first alive seat after it in seat order
    const k = st.seats.indexOf(seat);
    for (let j = 1; j <= st.seats.length; j++) { const s = st.seats[(k + j) % st.seats.length]; if (o.includes(s)) return s; }
    return o[0];
  }
  return o[(i + 1) % o.length];
};

function reload(st, ev) {
  const n = 4 + Math.floor(rnd(st) * 3); // 4..6 shells
  const live = 1 + Math.floor(rnd(st) * (n - 1));
  st.chamber = [];
  for (let i = 0; i < n; i++) st.chamber.push(i < live ? 'live' : 'blank');
  for (let i = n - 1; i > 0; i--) { const j = Math.floor(rnd(st) * (i + 1)); [st.chamber[i], st.chamber[j]] = [st.chamber[j], st.chamber[i]]; }
  st.pos = 0; st.pub = { live, blank: n - live };
  ev.push({ t: 'reload', live, blank: n - live });
}

function endRoundIfNeeded(st, ev) {
  if (st.order.length > 1) return;
  const w = st.order[0] || null;
  if (w) st.roundWins[w]++;
  ev.push({ t: 'roundEnd', winner: w, roundWins: Object.assign({}, st.roundWins) });
  const live = st.seats.filter((s) => !st.out.has(s));
  if ((w && st.roundWins[w] >= WINS) || live.length <= 1) {
    st.phase = 'over'; st.winner = w || live[0] || null;
    ev.push({ t: 'matchOver', winner: st.winner });
  } else st.phase = 'between';
}

const E = {
  newMatch(seatIds, opts = {}) {
    if (!Array.isArray(seatIds) || seatIds.length < 2 || seatIds.length > 4) throw new Error('2-4 seats');
    const st = { seats: seatIds.slice(), order: [], phase: 'between', turn: seatIds[0], round: 0, roundWins: {}, winner: null,
      rng: opts.seed | 0, chamber: [], pos: 0, pub: { live: 0, blank: 0 }, out: new Set(), known: {} };
    for (const s of seatIds) { st[s] = { hp: HP, max: HP, items: new Array(SLOTS).fill(null), alive: true, fx: {}, weapon: (opts.weapons && opts.weapons[s]) || 'default' }; st.roundWins[s] = 0; }
    return st;
  },
  startRound(st) {
    st.round++; st.known = {};
    st.order = st.seats.filter((s) => !st.out.has(s));
    for (const s of st.order) { const p = st[s]; p.hp = p.max = HP; p.alive = true; p.items = new Array(SLOTS).fill(null); p.items[0] = { id: 'peek', uses: 1 }; }
    st.phase = 'play'; st.turn = st.order[(st.round - 1) % st.order.length];
    const ev = [{ t: 'roundStart', round: st.round, order: st.order.slice(), hp: HP }];
    reload(st, ev);
    ev.push({ t: 'turn', seat: st.turn });
    return ev;
  },
  apply(st, seat, a) {
    if (st.phase !== 'play') return { ok: false, reason: 'not_playing', ev: [] };
    if (st.turn !== seat) return { ok: false, reason: 'not_your_turn', ev: [] };
    if (!a || typeof a !== 'object') return { ok: false, reason: 'bad_action', ev: [] };
    const ev = [];
    if (a.type === 'item') {
      const it = Number.isInteger(a.idx) ? st[seat].items[a.idx] : null;
      if (!it) return { ok: false, reason: 'no_item', ev: [] };
      st[seat].items[a.idx] = null;
      st.known[seat] = { pos: st.pos, shell: st.chamber[st.pos] };
      ev.push({ t: 'peek', seat, shell: st.chamber[st.pos] }); // secret: masked for everyone but `seat`
      return { ok: true, ev };
    }
    if (a.type !== 'shoot') return { ok: false, reason: 'bad_action', ev: [] };
    if (typeof a.target !== 'string' || !st.seats.includes(a.target)) return { ok: false, reason: 'bad_target', ev: [] };
    if (!st[a.target].alive) return { ok: false, reason: 'target_dead', ev: [] };
    const shell = st.chamber[st.pos++];
    st.pub[shell]--;
    ev.push({ t: 'shot', seat, target: a.target, shell });
    if (shell === 'live') {
      st[a.target].hp--;
      if (st[a.target].hp <= 0) { st[a.target].alive = false; st.order = st.order.filter((s) => s !== a.target); ev.push({ t: 'down', seat: a.target }); }
    }
    endRoundIfNeeded(st, ev);
    if (st.phase === 'play') {
      if (st.pos >= st.chamber.length) reload(st, ev);
      if (!(a.target === seat && shell === 'blank' && st[seat].alive)) st.turn = nextAlive(st, seat);
      ev.push({ t: 'turn', seat: st.turn });
    }
    return { ok: true, ev };
  },
  forfeit(st, seat) {
    if (!st[seat] || st.out.has(seat) || st.phase === 'over') return [];
    st.out.add(seat); const p = st[seat]; p.hp = 0; p.alive = false;
    const ev = [{ t: 'forfeit', seat }];
    const wasTurn = st.turn === seat, was = st.order.includes(seat);
    if (st.phase === 'play' && was) {
      const nxt = wasTurn ? nextAlive(st, seat) : st.turn;
      st.order = st.order.filter((s) => s !== seat);
      endRoundIfNeeded(st, ev);
      if (st.phase === 'play') { st.turn = wasTurn ? (st.order.includes(nxt) ? nxt : st.order[0]) : st.turn; ev.push({ t: 'turn', seat: st.turn }); }
    } else {
      st.order = st.order.filter((s) => s !== seat);
      if (st.seats.filter((s) => !st.out.has(s)).length <= 1) { st.phase = 'over'; st.winner = st.seats.find((s) => !st.out.has(s)) || null; ev.push({ t: 'matchOver', winner: st.winner }); }
    }
    return ev;
  },
  viewFor(st, seat) {
    const players = {};
    for (const s of st.seats) { const p = st[s]; players[s] = { hp: p.hp, max: p.max, alive: p.alive, weapon: p.weapon, out: st.out.has(s), items: p.items.map((i) => (i ? { id: i.id } : null)) }; }
    const k = st.known[seat];
    return { seats: st.seats.slice(), order: st.order.slice(), players, phase: st.phase, turn: st.turn, round: st.round, roundWins: Object.assign({}, st.roundWins),
      winner: st.winner, left: st.chamber.length - st.pos, pub: Object.assign({}, st.pub), peek: k && k.pos === st.pos ? k.shell : null, me: seat };
  },
  maskEvent(ev, seat) {
    if (ev.t === 'peek' && ev.seat !== seat) return { t: 'peek', seat: ev.seat }; // hide the shell
    return ev;
  },
  autoAction(st, seat) { return { type: 'shoot', target: st.order.find((s) => s !== seat) }; },
};
module.exports = E;
