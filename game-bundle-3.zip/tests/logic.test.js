/* Node test-suite for the pure-logic layer (rules engine, AI, save validation, animation manifest, audio manifest).
   Run:  node tests/logic.test.js */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');
const root = path.join(__dirname, '..');
const ctx = { console, setTimeout, clearTimeout, Date, Math, JSON, Buffer };
ctx.window = ctx; vm.createContext(ctx);
function load(rel) { vm.runInContext(fs.readFileSync(path.join(root, rel), 'utf8'), ctx, { filename: rel }); }
['scripts/util.js', 'data/game-data.js', 'data/ui-data.js', 'data/content.js', 'scripts/game-state.js', 'scripts/dealer-ai.js', 'scripts/economy.js', 'scripts/save-manager.js', 'scripts/icons.js', 'scripts/progress.js'].forEach(load);
const optional = ['data/animations.js', 'scripts/audio-manager.js'];
optional.forEach((f) => { if (fs.existsSync(path.join(root, f))) { try { load(f); } catch (e) { console.log('LOAD FAIL', f, e.message); process.exitCode = 1; } } });

const { Engine: E, DealerAI: AI, GameData: D, U } = ctx;
let pass = 0, fail = 0;
function ok(c, m) { if (c) { pass++; } else { fail++; console.log('  FAIL:', m); } }
function section(n) { console.log('\n# ' + n); }

section('Engine: determinism');
{
  const a = E.newGame('normal', 1234), b = E.newGame('normal', 1234);
  E.startRound(a); E.startRound(b);
  ok(JSON.stringify(a) === JSON.stringify(b), 'same seed gives identical round setup');
  const c = E.newGame('normal', 99); E.startRound(c);
  ok(JSON.stringify(a.chamber) !== JSON.stringify(c.chamber) || a.p.items.map(x => x && x.id).join() !== c.p.items.map(x => x && x.id).join(), 'different seed differs');
}

section('Engine: rules');
{
  const st = E.newGame('normal', 5); E.startRound(st);
  ok(st.phase === 'play' && st.turn === 'p', 'round starts on player turn');
  ok(st.chamber.length >= 3 && st.loaded.e >= 1 && st.loaded.a >= 1, 'chamber has both shell types');
  ok(st.p.items.filter(Boolean).length === 2, 'round 1 deals 2 items');
  // not your turn
  ok(!E.apply(st, 'd', { type: 'shoot', target: 'opp' }).ok, 'dealer cannot act on player turn');
  // fake chamber to test shot rules
  st.chamber = ['a', 'e', 'e']; st.pub = { e: 2, a: 1 };
  let r = E.apply(st, 'p', { type: 'shoot', target: 'self' });
  ok(r.ok && st.turn === 'p', 'self-shot with ash keeps the turn');
  r = E.apply(st, 'p', { type: 'shoot', target: 'self' });
  ok(r.ok && st.p.hp === st.p.max - 1 && st.turn === 'd', 'self-shot with ember hurts and passes turn');
  st.chamber = ['e', 'a']; st.pub = { e: 1, a: 1 };
  r = E.apply(st, 'd', { type: 'shoot', target: 'opp' });
  ok(st.p.hp === st.p.max - 2 && st.turn === 'p', 'dealer hits player and passes turn');
  // cuffs
  st.d.cuffed = true; st.chamber = ['a', 'e']; st.pub = { e: 1, a: 1 };
  r = E.apply(st, 'p', { type: 'shoot', target: 'opp' });
  ok(r.ev.some(e => e.t === 'skip') && st.turn === 'p' && !st.d.cuffed, 'cuffed dealer loses exactly one turn');
  // charge doubles
  st.p.hp = st.p.max; st.d.hp = st.d.max; st.p.charged = true; st.chamber = ['e', 'a']; st.pub = { e: 1, a: 1 };
  E.apply(st, 'p', { type: 'shoot', target: 'opp' });
  ok(st.d.hp === st.d.max - 2 && !st.p.charged, 'charged ember deals 2 and charge is consumed');
  // reload when empty
  st.turn = 'p'; st.chamber = ['a']; st.pub = { e: 0, a: 1 };
  r = E.apply(st, 'p', { type: 'shoot', target: 'opp' });
  ok(r.ev.some(e => e.t === 'reload') && st.chamber.length > 0, 'empty chamber triggers reload');
  // kill
  const k = E.newGame('normal', 7); E.startRound(k); k.d.hp = 1; k.chamber = ['e', 'a']; k.pub = { e: 1, a: 1 };
  r = E.apply(k, 'p', { type: 'shoot', target: 'opp' });
  ok(k.phase === 'between' && r.ev.some(e => e.t === 'roundEnd' && e.winner === 'p'), 'killing dealer ends round (between)');
  ok(!E.apply(k, 'p', { type: 'shoot', target: 'opp' }).ok, 'no actions after round end');
}

section('Engine: items');
{
  const mk = (id, mut) => { const s = E.newGame('normal', 11); E.startRound(s); s.p.items = new Array(6).fill(null); s.d.items = new Array(6).fill(null); s.p.items[0] = { id, uses: D.items[id].uses }; if (mut) mut(s); return s; };
  let s = mk('magnifier', s => { s.chamber = ['e', 'a']; s.pub = { e: 1, a: 1 }; });
  let r = E.apply(s, 'p', { type: 'item', idx: 0 });
  ok(r.ok && s.peek.who === 'p' && s.peek.type === 'e' && !s.p.items[0], 'magnifier peeks and is consumed');
  ok(E.infoFor(s, 'p').peek === 'e' && E.infoFor(s, 'd').peek === null, 'peek knowledge is private');
  s = mk('cigarette'); ok(!E.apply(s, 'p', { type: 'item', idx: 0 }).ok, 'cigarette refused at full pulse');
  s = mk('cigarette', s => { s.p.hp = 1; }); r = E.apply(s, 'p', { type: 'item', idx: 0 }); ok(r.ok && s.p.hp === 2, 'cigarette heals 1');
  s = mk('handcuffs'); r = E.apply(s, 'p', { type: 'item', idx: 0 }); ok(r.ok && s.d.cuffed, 'handcuffs bind dealer');
  s = mk('handcuffs', s => { s.d.cuffed = true; }); ok(!E.apply(s, 'p', { type: 'item', idx: 0 }).ok, 'cannot cuff twice');
  s = mk('battery'); r = E.apply(s, 'p', { type: 'item', idx: 0 }); ok(r.ok && s.p.charged, 'battery charges');
  s = mk('can', s => { s.chamber = ['a', 'e']; s.pub = { e: 1, a: 1 }; }); r = E.apply(s, 'p', { type: 'item', idx: 0 });
  ok(r.ok && s.chamber.length === 1 && s.pub.a === 0 && r.ev[0].fx.type === 'a', 'can ejects and reveals current shell');
  s = mk('can', s => { s.chamber = ['a']; s.pub = { e: 0, a: 1 }; }); r = E.apply(s, 'p', { type: 'item', idx: 0 });
  ok(r.ev.some(e => e.t === 'reload'), 'can that empties the chamber reloads');
  s = mk('lighter'); ok(!E.apply(s, 'p', { type: 'item', idx: 0 }).ok, 'lighter needs a target');
  s = mk('lighter', s => { s.d.items[2] = { id: 'coin', uses: 1 }; s.d.items[4] = { id: 'can', uses: 1 }; });
  r = E.apply(s, 'p', { type: 'item', idx: 0 });
  ok(r.ok && s.d.items.filter(Boolean).length === 1 && s.p.items[0] && s.p.items[0].uses === 1, 'lighter burns one item and keeps 1 charge');
  r = E.apply(s, 'p', { type: 'item', idx: 0 });
  ok(r.ok && s.d.items.filter(Boolean).length === 0 && !s.p.items[0], 'lighter consumed after second use');
  s = mk('medicine', s => { s.p.hp = 1; });
  for (let i = 0; i < 20; i++) { const t = mk('medicine', s => { s.p.hp = 1; s.r = i * 77; }); E.apply(t, 'p', { type: 'item', idx: 0 }); if (t.p.hp < 1) ok(false, 'medicine killed player'); }
  ok(true, 'medicine never fatal (20 seeds)');
  s = mk('scrambler', s => { s.chamber = ['e', 'a', 'e', 'a', 'e']; s.pub = { e: 3, a: 2 }; s.peek = { who: 'p', type: 'e' }; });
  r = E.apply(s, 'p', { type: 'item', idx: 0 }); ok(r.ok && s.peek.who === null && s.chamber.filter(c => c === 'e').length === 3, 'scrambler keeps counts, clears peek');
  s = mk('coin'); r = E.apply(s, 'p', { type: 'item', idx: 0 }); ok(r.ok && r.ev[0].fx.k === 'coin' && r.ev[0].fx.inner, 'coin produces an inner effect');
}

section('Engine: validate / serialisation');
{
  const st = E.newGame('hard', 3); E.startRound(st);
  ok(E.validate(JSON.parse(JSON.stringify(st))), 'valid state survives JSON round-trip');
  const bad = JSON.parse(JSON.stringify(st)); bad.p.hp = 99; ok(!E.validate(bad), 'rejects hp > max');
  const bad2 = JSON.parse(JSON.stringify(st)); bad2.p.items[0] = { id: 'nope', uses: 1 }; ok(!E.validate(bad2), 'rejects unknown item');
  ok(!E.validate(null) && !E.validate({}) && !E.validate('x'), 'rejects junk');
  const bad3 = JSON.parse(JSON.stringify(st)); bad3.chamber = ['x']; ok(!E.validate(bad3), 'rejects bad chamber');
}

section('Simulation: full games Dealer-AI vs scripted player (all difficulties)');
{
  const playerPolicy = (st) => {
    const i = st.p.items.findIndex((x, k) => x && E.canUse(st, 'p', k).ok);
    if (i >= 0 && U.Rand.next(st) < 0.6) return { type: 'item', idx: i };
    const info = E.infoFor(st, 'p'); const pe = info.ember / Math.max(1, info.total);
    return { type: 'shoot', target: st.p.fx.forcedOn ? 'self' : (pe >= 0.5 ? 'opp' : 'self') };
  };
  const results = {};
  let stuck = 0, actions = 0;
  for (const diff of ['easy', 'normal', 'hard', 'nightmare']) {
    results[diff] = { w: 0, l: 0 };
    for (let seed = 1; seed <= 150; seed++) {
      const st = E.newGame(diff, seed);
      let guard = 0;
      while (st.phase !== 'won' && st.phase !== 'lost' && guard < 5000) {
        if (st.phase === 'between') { E.startRound(st); continue; }
        guard++;
        const who = st.turn;
        const act = who === 'p' ? playerPolicy(st) : AI.decide(st);
        const r = E.apply(st, who, act);
        actions++;
        if (!r.ok) { ok(false, `illegal action by ${who}: ${JSON.stringify(act)} -> ${r.reason}`); break; }
        if (!E.validate(st) && st.phase === 'play') { ok(false, 'state invalid mid-game'); break; }
      }
      if (guard >= 5000) { stuck++; }
      results[diff][st.phase === 'won' ? 'w' : 'l']++;
    }
  }
  ok(stuck === 0, 'no game failed to terminate (' + actions + ' actions simulated)');
  console.log('  player win/loss vs dealer (150 seeds each):', JSON.stringify(results));
  ok(results.easy.w >= results.nightmare.w, 'easy is not harder than nightmare for the player');
  // Fairness: identical AI on both seats, single round, normal difficulty (no bonuses). Player moves first.
  let pw = 0, N = 600;
  for (let seed = 1; seed <= N; seed++) {
    const st = E.newGame('normal', 1000 + seed); E.startRound(st); let g = 0;
    while (st.phase === 'play' && g < 3000) { g++; const who = st.turn; const r = E.apply(st, who, AI.decide(st, who)); if (!r.ok) { ok(false, 'mirror illegal ' + r.reason); break; } }
    if (st.phase === 'between') pw++;
  }
  console.log('  mirror single round (normal): first seat wins', pw, '/', N);
  ok(pw > N * 0.4 && pw < N * 0.65, 'round-1 mirror match within 40-65% (no crippling seat bias)');
}

section('Engine: new items (knife, blank, spray, rope)');
{
  const mk = (id, mut) => { const s = E.newGame('normal', 11); E.startRound(s); s.p.items = new Array(6).fill(null); s.d.items = new Array(6).fill(null); s.p.items[0] = { id, uses: D.items[id].uses }; if (mut) mut(s); return s; };
  let s = mk('knife'); let hp = s.d.hp; let r = E.apply(s, 'p', { type: 'item', idx: 0 });
  ok(r.ok && s.d.hp === hp - 1 && !s.p.items[0], 'knife wounds the dealer by 1 and is consumed');
  s = mk('knife', (x) => { x.d.hp = 1; }); ok(!E.apply(s, 'p', { type: 'item', idx: 0 }).ok && s.d.hp === 1, 'knife cannot kill (refused at 1 pulse)');
  s = mk('blank', (x) => { x.chamber = ['e', 'a', 'e']; x.pub = { e: 2, a: 1 }; }); r = E.apply(s, 'p', { type: 'item', idx: 0 });
  ok(r.ok && s.chamber[0] === 'a' && s.pub.e === 1 && s.pub.a === 2, 'blank turns the next shell to ash and fixes public counts');
  s = mk('blank', (x) => { x.chamber = ['a', 'e']; x.pub = { e: 1, a: 1 }; }); ok(!E.apply(s, 'p', { type: 'item', idx: 0 }).ok, 'blank refused when next shell is already ash');
  s = mk('spray', (x) => { x.d.charged = true; }); r = E.apply(s, 'p', { type: 'item', idx: 0 }); ok(r.ok && !s.d.charged, 'spray wipes the opponent charge');
  s = mk('spray'); ok(!E.apply(s, 'p', { type: 'item', idx: 0 }).ok, 'spray refused with nothing to wipe');
  s = mk('rope', (x) => { x.d.items[3] = { id: 'coin', uses: 1 }; }); r = E.apply(s, 'p', { type: 'item', idx: 0 });
  ok(r.ok && !s.d.items[3] && s.p.items.some((i) => i && i.id === 'coin'), 'rope moves a dealer item to the player');
  s = mk('rope'); ok(!E.apply(s, 'p', { type: 'item', idx: 0 }).ok, 'rope refused when the dealer has nothing');
  const v = E.validate(s); ok(!v || v === true || (Array.isArray(v) ? v.length === 0 : true), 'state still validates');
}

section('Save-manager sanitising');
{
  const S = ctx.Save;
  const s = S.sanitizeSettings({ master: 5, quality: 'ultra', fps: 144, textSize: 9, lang: 'xx', shake: 'a' });
  ok(s.master === 1 && s.quality !== 'ultra' && s.fps === 60 && s.textSize === 1 && s.lang === 'en', 'settings clamped/defaulted');
  ok(S.sanitizeMeta('garbage').stats.games === 0, 'meta tolerates garbage');
  S.write('tallow.run.v1', 'not json{'); ctx.Save.mem['tallow.run.v1'] = 'not json{';
  ok(S.loadRun() === null && S.corruptFlag, 'corrupt run save is discarded and flagged');
  const st = E.newGame('normal', 2); E.startRound(st); S.queueRun(st); S.flushRun();
  ok(E.validate(S.loadRun()), 'valid run saved and loaded');
}

section('Animation manifest');
if (ctx.AnimData) {
  const rep = ctx.AnimData.validate();
  rep.errors.forEach(e => console.log('  ERR', e));
  ok(rep.errors.length === 0, 'manifest validates (' + rep.clips + ' clips, ' + rep.sfx + ' sfx refs, ' + rep.events + ' events)');
  const need = ['hand_idle','hand_breathe','hand_fingers','hand_tap','hand_look_table','hand_reach','hand_grab','hand_hold','hand_inspect','hand_rotate','hand_use','hand_putdown','hand_drop','hand_reach_weapon','hand_hold_weapon','hand_raise_weapon','hand_lower_weapon','hand_inspect_weapon','hand_fire','hand_recoil','hand_recover','hand_tremble','hand_hesitate','hand_startle','hand_frustrate','hand_victory','hand_defeat','hand_rest'];
  ok(need.every(n => ctx.AnimData.clips[n]), 'all 28 required player-hand states exist');
  for (const id of D.itemOrder) for (const who of ['p', 'd']) ok(!!ctx.AnimData.itemUse(id, who), `item clip builds for ${id}/${who}`);
} else console.log('  (animations.js not present yet)');

section('Audio manifest');
if (ctx.AudioMgr && ctx.AudioMgr.SFX && ctx.AnimData) {
  const names = ctx.AnimData.allSfxRefs();
  const missing = names.filter(n => !ctx.AudioMgr.SFX[n]);
  ok(missing.length === 0, 'every sfx referenced by animations exists in synth table' + (missing.length ? ' — missing: ' + missing.join(',') : ''));
  const used = new Set(names);
  ctx.AudioMgr.requiredSfx.forEach(n => ok(!!ctx.AudioMgr.SFX[n], 'required sfx ' + n));
}

section('Physics: fixed timestep, CCD, interpolation');
{
  load('scripts/physics.js'); const P = ctx.Physics;
  const run = (dtFrame, T) => { P.clear(); P.spawn('coin', 0, 520, 200, 150, 90, 0, 0, 5); P.spawn('can', 60, 560, 80, -120, 30, 0, 0, 2); let t = 0; while (t < T) { P.step(dtFrame); t += dtFrame; } return P.bodies.map(b => [b.x, b.y, b.z]); };
  const a = run(1 / 30, 4), b = run(1 / 60, 4), c = run(1 / 144, 4);
  const near = (u, v, tol) => u.every((r, i) => r.every((x, k) => Math.abs(x - v[i][k]) <= tol));
  ok(near(a, b, 40) && near(b, c, 40), 'outcome is (nearly) independent of the frame rate: ' + JSON.stringify(a.map(r => r.map(Math.round))) + ' vs ' + JSON.stringify(c.map(r => r.map(Math.round))));
  // no tunnelling: very fast bodies fired at every wall stay inside the bounds
  P.clear(); const B = P.bounds; const sp = [[4000, 0], [-4000, 0], [0, 4000], [0, -4000], [3000, 3000]];
  for (const [vx, vy] of sp) P.spawn('pill', 0, 550, 0, vx, vy, 0, 0, 0);
  for (let i = 0; i < 600; i++) P.step(1 / 60);
  ok(P.bodies.every(b => b.x >= B.x0 - 1 && b.x <= B.x1 + 1 && b.y >= B.y0 - 1 && b.y <= B.y1 + 1), 'fast bodies never tunnel through the table edges');
  ok(P.bodies.every(b => b.z >= 0), 'nothing sinks below the table surface');
  ok(P.stats.maxSub > 1, 'sub-stepping is used for fast bodies (max ' + P.stats.maxSub + ')');
  P.clear(); const bb = P.spawn('shell_e', 0, 500, 120, 80, 40, 0, 0, 3); for (let i = 0; i < 2000; i++) P.step(1 / 60);
  ok(bb.settled && P.bodies.length === 1, 'bodies come to rest (no endless jitter)');
  P.clear(); const q = P.spawn('coin', 0, 500, 100, 100, 0, 0, 0, 0); P.step(1 / 100); const l = P.lerped(q); ok(l.x >= Math.min(q.px, q.x) - 1e-6 && l.x <= Math.max(q.px, q.x) + 1e-6, 'render interpolation stays between the previous and current state');
}

section('GLB models: embedded data, skeleton, skinning');
{
  load('data/models.js'); load('scripts/rig.js'); const MO = ctx.MODELS, Rg = ctx.Rg;
  ok(MO && MO.table && MO.gun && MO.dealer, 'models.js holds table, gun and dealer');
  for (const k of ['table', 'gun', 'dealer']) { const g = Rg.decode(MO[k]); ok(g.p.length / 3 === MO[k].nv && g.i.reduce((a, b) => (b > a ? b : a), 0) < MO[k].nv, k + ' geometry decodes and indices are valid (' + MO[k].nv + ' vertices)'); ok(g.c.length === g.p.length, k + ' keeps its per-vertex colours'); }
  const ch = Rg.decode(MO.dealer), rig = new Rg.Rig(MO.dealer.meta.rig, 32);
  ok(rig.n === 22 && rig.par[0] === -1 && rig.par.filter(q => q < 0).length === 1, 'the Ghost skeleton has 22 joints with a single root');
  let badW = 0, maxJ = 0; for (let v = 0; v < ch.p.length / 3; v++) { let s = 0; for (let k = 0; k < 4; k++) { s += ch.w[v * 4 + k]; maxJ = Math.max(maxJ, ch.j[v * 4 + k]); } if (Math.abs(s - 255) > 4) badW++; }
  ok(badW === 0 && maxJ < rig.n, 'every vertex has normalised skin weights over valid joints');
  const used = new Set(); for (let v = 0; v < ch.p.length / 3; v++) for (let k = 0; k < 4; k++) if (ch.w[v * 4 + k] > 8) used.add(ch.j[v * 4 + k]); ok(used.size >= 20, 'at least 20 of the 22 joints actually influence vertices (' + used.size + ')');
  // rest pose = identity skinning
  rig.reset(); rig.fk(); const sk = rig.skin(); let err = 0; for (let v = 0; v < ch.p.length / 3; v += 37) { const p = [ch.p[v * 3], ch.p[v * 3 + 1], ch.p[v * 3 + 2]]; let o = [0, 0, 0]; for (let k = 0; k < 4; k++) { const w = ch.w[v * 4 + k] / 255, b = ch.j[v * 4 + k] * 12; for (let r = 0; r < 3; r++) o[r] += w * (sk[b + r * 4] * p[0] + sk[b + r * 4 + 1] * p[1] + sk[b + r * 4 + 2] * p[2] + sk[b + r * 4 + 3]); } err = Math.max(err, Math.hypot(o[0] - p[0], o[1] - p[1], o[2] - p[2])); }
  ok(err < 1e-3, 'rest pose reproduces the original mesh (max error ' + err.toExponential(1) + ')');
  // IK reaches reachable targets exactly and keeps bone lengths
  for (const side of ['L', 'R']) {
    rig.reset(); rig.fk(); const S = rig.pos('upperarm_' + side), L = rig.len['arm_' + side], T = [S[0] + (side === 'L' ? 0.2 : -0.2), S[1] - 0.45, S[2] + 0.55];
    const r = rig.ikArm(side, T, [S[0] + (side === 'L' ? 1 : -1), S[1] - 1, S[2] - 0.5]); rig.fk(); const h = rig.pos('hand_' + side), e = rig.pos('forearm_' + side);
    ok(r.reached && Math.hypot(h[0] - T[0], h[1] - T[1], h[2] - T[2]) < 1e-6, side + ' arm IK reaches its target');
    ok(Math.abs(Math.hypot(e[0] - S[0], e[1] - S[1], e[2] - S[2]) - L[0]) < 1e-6 && Math.abs(Math.hypot(h[0] - e[0], h[1] - e[1], h[2] - e[2]) - L[1]) < 1e-6, side + ' arm keeps its bone lengths');
    const far = [S[0], S[1], S[2] + 5]; const r2 = rig.ikArm(side, far, [S[0], S[1] - 1, S[2]]); ok(!r2.reached && Math.hypot(...r2.wrist.map((x, i) => x - S[i])) <= L[0] + L[1] + 1e-6, side + ' unreachable target is clamped to the arm length');
  }
  // gun sockets lie on the gun's grip / fore-end surfaces
  const gm = MO.gun.meta; ok(gm.grip[0] < gm.fore[0] && gm.muzzle[0] > gm.fore[0] && gm.butt[0] < gm.grip[0], 'gun sockets are ordered butt < grip < fore-end < muzzle along the barrel');
  const tm = MO.table.meta; ok(Math.abs(tm.top.y - 1.66) < 0.01 && tm.legs.length === 4, 'table top height and 4 legs measured from the model');
}


section('v4: achievements, statistics, new settings');
{
  const P = ctx.Progress, Save = ctx.Save, I = ctx.Icons, defs = D.achDefs, mk = () => Save.sanitizeMeta({});
  ok(defs.length >= 65 && new Set(defs.map(d => d.id)).size === defs.length, defs.length + ' (>=65) achievements with unique ids');
  ok(JSON.stringify(D.achievements) === JSON.stringify(defs.map(d => d.id)), 'D.achievements is derived from the definitions (save files keep working)');
  for (const old of ['first_light', 'out_of_room', 'untouched', 'thread', 'ash_walker', 'pack_rat', 'bare_hands', 'nightmare']) ok(!!P.def(old), 'original achievement kept: ' + old);
  const cnt = { b: 0, c: 0, a: 0, l: 0 }; for (const d of defs) cnt[d.tier]++;
  ok(cnt.b >= 5 && cnt.c >= 5 && cnt.a >= 5 && cnt.l >= 5, 'every tier (beginner/intermediate/advanced/legendary) has at least 5: ' + JSON.stringify(cnt));
  ok(defs.every(d => d.goal > 0 && d.coins > 0 && I.has(d.icon)), 'every achievement has a goal, a Wax reward and a real icon');
  ok(defs.every(d => (d.stat === 'discovered' || d.stat === 'achCount' || Save.DERIVED.includes(d.stat) || Save.STAT_KEYS.includes(d.stat))), 'every achievement reads a stat that is really recorded');
  const ord = { b: 0, c: 1, a: 2, l: 3 }, avg = (t) => defs.filter(d => d.tier === t).reduce((a, d) => a + d.coins, 0) / cnt[t];
  ok(avg('b') < avg('c') && avg('c') < avg('a') && avg('a') < avg('l'), 'rewards grow with the tier');
  ok(P.def('wax_saint').goal === defs.length - 1 && P.def('pack_rat').goal === 13, 'completion goals match the real totals (all others; 13 original items)');
  for (const lang of ['en', 'ar']) ok(defs.every(d => D.strings[lang]['ach.' + d.id] && D.strings[lang]['ach.' + d.id + '.d']) && D.accents.every(a => D.strings[lang]['accent.' + a]), lang + ': every achievement and accent is named');
  // i18n: every literal key used by the markup and the v4 scripts exists in both languages
  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8'); const keys = new Set([...html.matchAll(/data-(?:i18n|aria)="([^"]+)"/g)].map(m => m[1]));
  for (const f of ['scripts/ui-extra.js', 'scripts/ui-controller.js']) for (const m of fs.readFileSync(path.join(root, f), 'utf8').matchAll(/U\.t\('([A-Za-z0-9_.]+)'/g)) keys.add(m[1]);
  for (const m of fs.readFileSync(path.join(root, 'scripts/ui-extra.js'), 'utf8').matchAll(/(?:label|desc|k): '([a-zA-Z0-9]+\.[A-Za-z0-9_.]+)'|\['[a-zA-Z0-9]+', '(set\.[A-Za-z0-9_.]+)'\]/g)) keys.add(m[1] || m[2]);
  for (const k of [...keys]) if (k.endsWith('.')) keys.delete(k);
  const miss = {}; for (const lang of ['en', 'ar']) miss[lang] = [...keys].filter(k => !(k in D.strings[lang]) && !k.startsWith('logo'));
  ok(miss.en.length === 0 && miss.ar.length === 0, 'all ' + keys.size + ' referenced text keys exist in English and Arabic' + (miss.en.length || miss.ar.length ? ' — missing en:' + miss.en.join(',') + ' ar:' + miss.ar.join(',') : ''));
  // progress is a pure function of the statistics
  let m = mk(); ok(P.summary(m).done === 0 && P.summary(m).total === defs.length, 'fresh profile: 0 of ' + defs.length);
  ok(P.progress(P.def('warming_up'), m).pct === 0, 'progress starts at 0 %');
  m.stats.shots = 10; ok(P.progress(P.def('warming_up'), m).pct === 50 && P.progress(P.def('warming_up'), m).v === 10, 'half-way is 50 %');
  m.stats.shots = 19; ok(P.progress(P.def('warming_up'), m).pct === 95, '19/20 shows 95 % (never rounds up to 100 before it is earned)');
  m = mk(); const c0 = m.coins; P.track([{ t: 'shot', who: 'p', target: 'opp', victim: 'd', type: 'e', dmg: 2, charged: true }], { stats: { bestStreak: 2 } }, m);
  ok(m.stats.shots === 1 && m.stats.hits === 1 && m.stats.dmgDealt === 2 && m.stats.charged === 1 && m.stats.bestStreak === 2 && m.ach.spark && m.coins === c0 + 10, 'a charged hit counts as shot, hit, damage and charged hit; Spark pays 10 Wax');
  P.track([{ t: 'shot', who: 'd', target: 'opp', victim: 'p', type: 'e', dmg: 1, charged: false }, { t: 'item', who: 'p', id: 'handcuffs' }, { t: 'item', who: 'd', id: 'handcuffs' }], null, m);
  ok(m.stats.shots === 1 && m.stats.dmgTaken === 1 && m.stats.itemsUsed === 1 && m.stats.cuffs === 1, "the dealer's shots do not count as yours, but damage you take does");
  P.track([{ t: 'shot', who: 'p', target: 'self', victim: 'p', type: 'e', dmg: 1, charged: false }], null, m); ok(m.stats.selfShots === 1 && m.stats.ashSelf === 0 && m.stats.dmgTaken === 2 && m.stats.hits === 1, 'shooting yourself with an ember is a self shot, not a dealer hit');
  const before = JSON.stringify(m); P.check(m); P.check(m); ok(JSON.stringify(m) === before, 'check() is idempotent: rewards are paid exactly once');
  // game-flow counters
  m = mk(); P.newGame(); const st = { phase: 'between', diff: 'normal', stats: { bestStreak: 3, dmgTaken: 0 } };
  P.onRoundEnd(st, { winner: 'p', hpLeft: 1, items: 0 }, m); ok(m.stats.thread === 1 && m.stats.bare === 1 && m.stats.ash3 === 1 && m.ach.thread && m.ach.bare_hands && m.ach.ash_walker, 'close call, item-free round and an ash streak are counted and unlock their achievements');
  P.onRoundEnd(st, { winner: 'p', hpLeft: 3, items: 2 }, m); ok(m.stats.ash3 === 1, 'an ash streak is counted once per game');
  P.onWin({ stats: { dmgTaken: 0 }, diff: 'nightmare' }, m); ok(m.stats.perfect === 1 && m.stats.nightmareWins === 1 && m.ach.untouched === 1 && m.ach.nightmare === 1 && !!D.accentUnlock.violet, 'an untouched Nightmare win unlocks Untouched and Nightmare Survivor');
  P.onRoundEnd({ phase: 'lost', diff: 'normal', stats: { bestStreak: 0 } }, { winner: 'd', hpLeft: 0, items: 0 }, m); ok(m.stats.losses === 1, 'a lost game is counted');
  // reward chains
  m = mk(); for (const d of defs) if (d.id !== 'wax_saint') m.ach[d.id] = 1; P.check(m); ok(!!m.ach.wax_saint, 'Wax Saint unlocks once all 27 others are done');
  m = mk(); ctx.Turns = { meta: m }; m.stats.playSec = 3599; P.acc = 1.2; P.tick(0); delete ctx.Turns; ok(m.stats.playSec === 3600 && m.ach.dark_hour === 1, 'play time accumulates and unlocks "An Hour in the Dark"');
  m = mk(); for (const k of ['curious']) { for (const id of D.itemOrder.slice(0, 5)) m.discovered[id] = 1; } P.check(m); ok(m.ach.curious === 1 && !m.ach.pack_rat, 'discovering 5 item kinds unlocks Curious Hands only');
  // accents
  m = mk(); ok(P.accentUnlocked('ember', m) && !P.accentUnlocked('gold', m), 'gold accent is locked at the start'); m.ach.out_of_room = 1; ok(P.accentUnlocked('gold', m) && !P.accentUnlocked('ice', m), 'winning a game unlocks Gold only');
  ok(P.fmtTime(3725) === '1h 2m' && P.fmtTime(75) === '1m 15s', 'play time formatting');
  // save sanitising of the new fields
  const bad = Save.sanitizeSettings({ gunHold: 'x', camSway: 9, crosshair: 'laser', xhairSize: -1, xhairAlpha: 5, gunX: 1e9, gunY: -1e9, gunScale: 0, uiScale: 3, hudAlpha: 0, hudLabels: 'yes', hudSide: 'up', invertY: 1, showFps: 'y', brightness: 9, vignette: 3, contrast: 'x', accent: 'rainbow' });
  ok(bad.gunHold === 'locked' && bad.camSway === 1 && bad.crosshair === 'dot' && bad.xhairSize === 0.6 && bad.xhairAlpha === 1 && bad.gunX === 40 && bad.gunY === -40 && bad.gunScale === 0.9 && bad.uiScale === 1.2 && bad.hudAlpha === 0.45 && bad.hudSide === 'right' && bad.brightness === 1.3 && bad.accent === 'ember', 'out-of-range / invalid new settings are clamped or replaced by defaults');
  ok(bad.hudLabels === true && bad.vignette === true && bad.invertY === false && bad.showFps === false && bad.contrast === false, 'flags that are not real booleans fall back to their default');
  const dflt = Save.defaultSettings(); ok(dflt.gunHold === 'locked' && dflt.crosshair === 'dot' && dflt.gunX === 0 && dflt.gunY === 0 && dflt.gunScale === 1 && dflt.uiScale === 1 && dflt.hudSide === 'right' && dflt.accent === 'ember', 'defaults: locked weapon, dot crosshair, centred weapon, 100 % UI, ember accent');
  const canon = (o) => JSON.stringify(Object.keys(o).sort().map(k => [k, o[k]])); ok(canon(Save.sanitizeSettings(dflt)) === canon(dflt), 'sanitising the defaults changes nothing');
  const mm = Save.sanitizeMeta({ ach: { spark: 1, bogus: 1 }, stats: { shots: 12, playSec: -5, hits: 'x', evil: 9 } }); ok(mm.ach.spark === 1 && !('bogus' in mm.ach) && mm.stats.shots === 12 && mm.stats.playSec === 0 && mm.stats.hits === 0 && !('evil' in mm.stats), 'meta sanitising keeps real stats, drops unknown/invalid ones');
  const old = Save.sanitizeMeta({ ach: { first_light: 1, nightmare: 1 }, stats: { games: 3, wins: 1, rounds: 4 }, coins: 77 }); ok(old.ach.first_light && old.ach.nightmare && old.stats.games === 3 && old.coins === 77 && old.stats.shots === 0, 'saves from v3 load unchanged (new stats start at 0)');
}

section('index.html: unique element ids');
{
  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8'), ids = [...html.matchAll(/\sid="([^"]+)"/g)].map(m => m[1]), dup = ids.filter((x, i) => ids.indexOf(x) !== i);
  ok(dup.length === 0, 'no duplicate ids' + (dup.length ? ': ' + dup.join(',') : ''));
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
