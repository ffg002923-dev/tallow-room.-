/* image menu: renders, shells fall (canvas changes between frames), music plays on the menu, Continue stops it and starts the game */
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] });
  const ctx = await b.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 1, hasTouch: true, isMobile: true });
  const p = await ctx.newPage(); const logs = []; p.on('console', m => { if (['error', 'warning'].includes(m.type())) logs.push(m.text()); }); p.on('pageerror', e => logs.push('PAGEERROR ' + e.message));
  let ok = 0, bad = 0; const t = (c, m) => { c ? ok++ : bad++; console.log((c ? 'PASS ' : 'FAIL ') + m); };
  await p.goto('file://' + process.cwd() + '/index.html'); await p.waitForTimeout(2500);
  await p.screenshot({ path: '/tmp/claude-0/shots/menuart1.png', timeout: 60000 }); await p.waitForTimeout(700); await p.screenshot({ path: '/tmp/claude-0/shots/menuart2.png', timeout: 60000 });
  const m1 = await p.evaluate(() => { const a = MenuArt.music; return { exists: !!a, paused: a && a.paused, t: a && a.currentTime, vol: a && a.volume, dur: a && a.duration, loop: a && a.loop, err: a && a.error && a.error.code }; });
  t(m1.exists && !m1.paused && m1.t > 0.5, 'menu song plays on the menu ' + JSON.stringify(m1));
  const px = await p.evaluate(async () => { const c = document.getElementById('martFx'), x = c.getContext('2d'); const a = x.getImageData(0, 0, c.width, c.height).data; let n = 0; for (let i = 3; i < a.length; i += 4) if (a[i] > 20) n++; await new Promise(r => setTimeout(r, 400)); const b2 = x.getImageData(0, 0, c.width, c.height).data; let d = 0; for (let i = 3; i < a.length; i += 4 * 7) if (Math.abs(a[i] - b2[i]) > 20) d++; return { n, d }; });
  t(px.n > 500 && px.d > 100, 'falling shells are drawn and change between frames ' + JSON.stringify(px));
  const hs = await p.evaluate(() => [...document.querySelectorAll('.hot')].map(h => { const r = h.getBoundingClientRect(); return [Math.round(r.x), Math.round(r.y), Math.round(r.width), Math.round(r.height)]; }));
  t(hs.length === 6 && hs.every(r => r[2] > 100 && r[3] > 20), 'six hot-spots over the buttons ' + JSON.stringify(hs[0]));
  await p.mouse.click(hs[1][0] + hs[1][2] / 2, hs[1][1] + hs[1][3] / 2); await p.waitForTimeout(500);
  t(await p.evaluate(() => !document.getElementById('mSet').classList.contains('hidden')), 'Settings hot-spot opens settings'); await p.evaluate(() => document.getElementById('setBack').click()); await p.waitForTimeout(300);
  await p.mouse.click(hs[0][0] + hs[0][2] / 2, hs[0][1] + hs[0][3] / 2); await p.waitForTimeout(1200);
  const g = await p.evaluate(() => ({ menuHidden: document.getElementById('menu').classList.contains('hidden'), tut: !document.getElementById('mTut') ? null : !document.getElementById('mTut').classList.contains('hidden'), paused: MenuArt.music.paused, vol: MenuArt.music.volume, flag: AudioMgr.menuMusic }));
  console.log(JSON.stringify(g)); t(g.menuHidden || g.tut, 'Continue leaves the menu (game / tutorial starts)'); t(g.paused || g.vol < 0.6, 'menu song fades/stops'); t(!g.flag, 'generative game music is released');
  await p.waitForTimeout(800); const g2 = await p.evaluate(() => ({ paused: MenuArt.music.paused, state: window.__tallow && window.__tallow.state && window.__tallow.state.round })); console.log(JSON.stringify(g2)); t(g2.paused, 'song fully stopped');
  console.log(logs.length ? 'LOGS ' + logs.slice(0, 5).join(' | ') : 'no console errors'); console.log(ok + ' ok, ' + bad + ' failed'); await b.close(); process.exit(bad ? 1 : 0);
})();
