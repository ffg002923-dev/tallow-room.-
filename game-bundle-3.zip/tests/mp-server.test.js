'use strict';
/* mp-server.test.js — end-to-end tests for the multiplayer backend (no framework). Run: node tests/mp-server.test.js
 * Uses the mock engine, Node's global WebSocket, NetClient, raw TCP for protocol-level checks. */
const http = require('http');
const net = require('net');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { createServer } = require('../server/server');
const NetClient = require('../scripts/net-client');
const mock = require('./mp-mock-engine');

let passed = 0, failed = 0, finished = false, current = '';
const ok = (cond, name) => { if (cond) passed++; else { failed++; console.log('  FAIL [' + current + '] ' + name); } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function waitFor(fn, ms = 4000, what = 'condition') {
  const t0 = Date.now();
  for (;;) { const v = fn(); if (v) return v; if (Date.now() - t0 > ms) throw new Error('timeout waiting for ' + what); await sleep(8); }
}
const rejects = async (p, code) => { try { await p; return false; } catch (e) { return e.code === code || e.reason === code; } };

const servers = [], clients = [];
const FAST = { turnMs: 3000, graceMs: 600, intermissionMs: 30, resultsMs: 150, statusMs: 100, idleMs: 60000 };
async function srv(o = {}) { const s = createServer({ engine: mock, port: 0, ...FAST, ...o }); await s.listen(0, '127.0.0.1'); servers.push(s); return s; }

function mk(s, o = {}) {
  const c = new NetClient({ url: s.wsUrl, storage: null, backoffMin: 50, backoffMax: 200, pingMs: 300, WebSocket: o.WS, ...(o.opts || {}) });
  Object.assign(c, { log: [], lobby: null, states: [], errors: [], emotes: [], results: null, statuses: [] });
  c.on('matchEvents', (m) => c.log.push(m)); c.on('lobby', (l) => { c.lobby = l; }); c.on('state', (x) => c.states.push(x));
  c.on('error', (e) => c.errors.push(e)); c.on('emote', (e) => c.emotes.push(e)); c.on('results', (r) => { c.results = r; });
  c.on('status', (x) => c.statuses.push(x));
  clients.push(c); return c;
}
/** n clients in one lobby (host first). All ready. */
async function lobby(s, n, o = {}) {
  const cs = []; const host = mk(s, o.hostOpts); await host.connect(); const me = await host.createRoom(o.names ? o.names[0] : 'Host', o.settings); cs.push(host);
  for (let i = 1; i < n; i++) { const c = mk(s, o.opts && o.opts[i]); await c.connect(); await c.joinRoom(me.room, o.names ? o.names[i] : 'Guest' + i); await c.setReady(true); cs.push(c); }
  return { code: me.room, cs, host, room: () => s.rooms.rooms.get(me.room) };
}
/** plays automatically: peek item once per round, then shoot a random foe */
function bot(c) {
  let alive = [], used = false;
  c.on('matchEvents', ({ events }) => {
    let mine = false;
    for (const e of events) {
      if (e.t === 'roundStart') { alive = e.order.slice(); used = false; }
      else if (e.t === 'down' || e.t === 'forfeit') alive = alive.filter((s) => s !== e.seat);
      if (e.t === 'turn') mine = e.seat === c.you.seat;
    }
    if (mine) setImmediate(async () => {
      try {
        if (!used) { used = true; await c.act({ type: 'item', idx: 0 }); }
        const foes = alive.filter((s) => s !== c.you.seat);
        await c.act({ type: 'shoot', target: foes[Math.floor(Math.random() * foes.length)] });
      } catch (e) { c.botErr = e; }
    });
  });
}
const over = (c) => c.log.some((m) => m.events.some((e) => e.t === 'matchOver'));
const norm = (e) => (e.t === 'peek' ? { t: 'peek', seat: e.seat } : e);

// ---- raw TCP websocket client (protocol-level tests) ----
function rawWS(port, { headers = {}, path: p = '/ws', origin } = {}) {
  return new Promise((resolve, reject) => {
    const sock = net.connect(port, '127.0.0.1');
    const key = crypto.randomBytes(16).toString('base64');
    let buf = Buffer.alloc(0), upgraded = false; const frames = []; let head = '';
    const r = { sock, frames, closed: false, head: () => head,
      send(op, payload, o = {}) { // masked client frame
        payload = Buffer.from(payload); const fin = o.fin === false ? 0 : 0x80; const masked = o.unmasked ? 0 : 0x80;
        let h; const L = payload.length;
        if (L < 126) h = Buffer.from([fin | op, masked | L]); else if (L < 65536) { h = Buffer.alloc(4); h[0] = fin | op; h[1] = masked | 126; h.writeUInt16BE(L, 2); } else { h = Buffer.alloc(10); h[0] = fin | op; h[1] = masked | 127; h.writeUInt32BE(L, 6); }
        const mask = crypto.randomBytes(4); const body = Buffer.from(payload);
        if (masked) for (let i = 0; i < L; i++) body[i] ^= mask[i & 3];
        sock.write(masked ? Buffer.concat([h, mask, body]) : Buffer.concat([h, body]));
      },
      text(s, o) { r.send(1, s, o); },
      json(o) { r.text(JSON.stringify(Object.assign({ v: 1 }, o))); },
      msgs() { return frames.filter((f) => f.op === 1).map((f) => JSON.parse(f.payload.toString())); },
      closeCode() { const f = frames.find((x) => x.op === 8); return f ? (f.payload.length >= 2 ? f.payload.readUInt16BE(0) : 1005) : null; } };
    sock.on('data', (d) => {
      buf = Buffer.concat([buf, d]);
      if (!upgraded) {
        const i = buf.indexOf('\r\n\r\n'); if (i < 0) return;
        head = buf.subarray(0, i).toString(); buf = buf.subarray(i + 4); upgraded = true;
        const accept = /sec-websocket-accept: (.+)/i.exec(head);
        r.status = +head.split(' ')[1]; r.acceptOk = !!accept && accept[1].trim() === crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
        resolve(r);
      }
      while (buf.length >= 2) { // server frames are unmasked
        let len = buf[1] & 0x7f, off = 2;
        if (len === 126) { if (buf.length < 4) break; len = buf.readUInt16BE(2); off = 4; } else if (len === 127) { if (buf.length < 10) break; len = buf.readUInt32BE(6); off = 10; }
        if (buf.length < off + len) break;
        frames.push({ op: buf[0] & 0xf, payload: buf.subarray(off, off + len) }); buf = buf.subarray(off + len);
      }
    });
    sock.on('error', () => {}); sock.on('close', () => { r.closed = true; if (!upgraded) resolve(r); });
    const h = Object.assign({ Host: '127.0.0.1:' + port, Upgrade: 'websocket', Connection: 'Upgrade', 'Sec-WebSocket-Key': key, 'Sec-WebSocket-Version': '13' }, headers);
    if (origin) h.Origin = origin;
    sock.write(`GET ${p} HTTP/1.1\r\n` + Object.entries(h).map(([k, v]) => k + ': ' + v).join('\r\n') + '\r\n\r\n');
    setTimeout(() => reject(new Error('raw handshake timeout')), 3000).unref();
  });
}
const httpGet = (port, p, headers = {}, method = 'GET') => new Promise((resolve, reject) => {
  const req = http.request({ host: '127.0.0.1', port, path: p, method, headers, agent: false }, (res) => {
    const chunks = []; res.on('data', (c) => chunks.push(c)); res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
  }); req.on('error', reject); req.end();
});

const TESTS = [];
const T = (name, fn) => TESTS.push([name, fn]);

// ============================== tests ==============================
T('http: health, static files, traversal, MIME', async () => {
  const s = await srv();
  const h = await httpGet(s.port, '/health'); const j = JSON.parse(h.body);
  ok(h.status === 200 && j.ok === true && typeof j.rooms === 'number' && typeof j.players === 'number' && typeof j.uptime === 'number', '/health JSON');
  const idx = await httpGet(s.port, '/');
  ok(idx.status === 200 && /text\/html/.test(idx.headers['content-type']) && /<html|<!doctype/i.test(idx.body.toString()), 'index.html served at /');
  ok(idx.headers['cache-control'] === 'no-cache', 'html no-cache');
  const js = await httpGet(s.port, '/scripts/net-client.js');
  ok(js.status === 200 && /javascript/.test(js.headers['content-type']) && js.headers['cache-control'] === 'no-cache', 'js MIME + no-cache');
  const gz = await httpGet(s.port, '/scripts/net-client.js', { 'Accept-Encoding': 'gzip' });
  ok(gz.headers['content-encoding'] === 'gzip', 'gzip for js');
  ok((await httpGet(s.port, '/styles/')).status === 404 || (await httpGet(s.port, '/styles/')).status === 200 && false, 'no directory listing');
  ok([403, 404].includes((await httpGet(s.port, '/../package.json')).status), 'raw ../ blocked');
  ok((await httpGet(s.port, '/../package.json')).status === 403, 'raw ../ is 403');
  ok([403, 404].includes((await httpGet(s.port, '/%2e%2e/%2e%2e/etc/passwd')).status), 'encoded ../ blocked');
  ok([403, 404].includes((await httpGet(s.port, '/scripts/..%2f..%2f..%2fetc/passwd')).status), 'encoded slash traversal blocked');
  ok((await httpGet(s.port, '/%00')).status >= 400, 'NUL rejected');
  ok((await httpGet(s.port, '/server/server.js')).status === 404, 'server dir not served');
  ok((await httpGet(s.port, '/nope.txt')).status === 404, '404');
  ok((await httpGet(s.port, '/', {}, 'POST')).status === 405, 'POST 405');
  const head = await httpGet(s.port, '/', {}, 'HEAD'); ok(head.status === 200 && head.body.length === 0, 'HEAD');
  // MIME for assets that exist in the game
  const find = (dir, ext) => { try { for (const f of fs.readdirSync(dir, { withFileTypes: true })) { if (['node_modules', 'tools', 'tests', 'server'].includes(f.name)) continue; const p = path.join(dir, f.name); if (f.isDirectory()) { const r = find(p, ext); if (r) return r; } else if (p.endsWith(ext)) return p; } } catch (e) { /* */ } return null; };
  const root = path.join(__dirname, '..');
  for (const [ext, mime] of [['.mp3', 'audio/mpeg'], ['.jpg', 'image/jpeg'], ['.png', 'image/png'], ['.svg', 'image/svg+xml'], ['.json', 'application/json']]) {
    const f = find(root, ext); if (!f || /node_modules|[\\/](tools|tests|server)[\\/]/.test(f)) continue;
    const r = await httpGet(s.port, '/' + path.relative(root, f).split(path.sep).map(encodeURIComponent).join('/'));
    ok(r.status === 200 && r.headers['content-type'].startsWith(mime), 'MIME ' + ext + (r.status === 200 ? '' : ' status ' + r.status));
    if (ext === '.mp3') { const rg = await httpGet(s.port, '/' + path.relative(root, f).split(path.sep).map(encodeURIComponent).join('/'), { Range: 'bytes=0-9' }); ok(rg.status === 206 && rg.body.length === 10, 'Range request'); }
  }
  // custom static dir + symlink escape
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'tw-')); fs.writeFileSync(path.join(tmp, 'index.html'), '<html>x</html>'); fs.writeFileSync(path.join(tmp, 'a.webmanifest'), '{}');
  fs.symlinkSync('/etc/hostname', path.join(tmp, 'link.txt'));
  const s2 = await srv({ staticDir: tmp });
  ok((await httpGet(s2.port, '/')).body.toString() === '<html>x</html>', 'custom staticDir');
  ok((await httpGet(s2.port, '/a.webmanifest')).headers['content-type'].startsWith('application/manifest+json'), 'webmanifest MIME');
  ok((await httpGet(s2.port, '/link.txt')).status === 403, 'symlink escape blocked');
  fs.rmSync(tmp, { recursive: true, force: true });
});

T('rooms: create/join/errors/full/names', async () => {
  const s = await srv();
  const codes = new Set(); const RE = /^[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{5}$/;
  const a = mk(s); await a.connect();
  const me = await a.createRoom('  <b>Ann</b>\u0007 Longer-than-sixteen-chars  ', { dealer: 'warden', weaponMode: 'caster', difficulty: 'hard' });
  ok(RE.test(me.room), 'room code format ' + me.room);
  ok(me.you.token && /^[0-9a-f]{48}$/.test(me.you.token), 'token is 24 random bytes hex');
  const name = me.you.name; ok(!/[<>\u0007]/.test(name) && name.length <= 16 && name === name.trim() && name.startsWith('bAnn/b'), 'name sanitised: "' + name + '"');
  for (let i = 0; i < 40; i++) { const x = mk(s); await x.connect(); const r = await x.createRoom('x'); codes.add(r.room); ok(RE.test(r.room), 'code ok'); x.close(); }
  ok(codes.size === 40, '40 unique codes');
  await waitFor(() => a.lobby && a.lobby.players.length === 1, 1000, 'lobby');
  ok(a.lobby.settings.weaponMode === 'caster' && a.lobby.settings.dealer === 'warden', 'settings kept');
  const b = mk(s); await b.connect();
  ok(await rejects(b.joinRoom('ZZZZZ', 'B'), 'room_not_found'), 'wrong code rejected');
  ok(await rejects(b.joinRoom('', 'B'), 'room_not_found'), 'empty code rejected');
  ok(await rejects(b.joinRoom(12345, 'B'), 'room_not_found'), 'numeric code rejected');
  const jb = await b.joinRoom(me.room.toLowerCase(), ''); ok(jb.you.name === 'Player 2', 'default name Player 2: ' + jb.you.name);
  const c = mk(s); await c.connect(); const jc = await c.joinRoom(me.room, 'Cee\u0000\u001fX'); ok(jc.you.name === 'CeeX', 'control chars stripped');
  const d = mk(s); await d.connect(); await d.joinRoom(me.room, 'D');
  ok(new Set([me.you.seat, jb.you.seat, jc.you.seat]).size === 3, 'distinct seats');
  const e = mk(s); await e.connect();
  ok(await rejects(e.joinRoom(me.room, 'E'), 'room_full'), '5th player rejected (room_full)');
  await waitFor(() => a.lobby.players.length === 4, 1000, '4 in lobby');
  ok(a.lobby.players.filter((p) => p.host).length === 1 && a.lobby.players[0].host, 'first player is host');
  ok(await rejects(a.setSettings({ weaponMode: 'bogus' }), 'bad_settings'), 'bad weaponMode rejected');
  ok(await rejects(a.setSettings({ x: 'y'.repeat(1000) }), 'bad_settings'), 'oversize settings rejected');
  ok(await rejects(b.setSettings({ dealer: 'x' }), 'not_host'), 'settings host-only');
  await a.setSettings({ dealer: 'ghoul', weaponMode: 'own', difficulty: 5 });
  await waitFor(() => b.lobby && b.lobby.settings.dealer === 'ghoul', 1000, 'settings broadcast');
  // session persistence (fake sessionStorage): "page reload" resumes the seat
  const store = {}; const fake = { getItem: (k) => store[k] || null, setItem: (k, v) => { store[k] = v; }, removeItem: (k) => { delete store[k]; } };
  const p1 = mk(s, { opts: { storage: fake } }); await p1.connect(); const r1 = await p1.createRoom('Persist'); p1.close();
  ok(!!store['tallow.session.v1'], 'session stored');
  const p2 = mk(s, { opts: { storage: fake } }); await p2.connect();
  ok(p2.you && p2.you.seat === r1.you.seat && p2.room === r1.room, 'new NetClient resumed from storage');
  ok(await rejects(p2.leave().then(() => { throw Object.assign(new Error('x'), { code: 'x' }); }), 'x') && !store['tallow.session.v1'], 'leave clears session');
});

T('lobby: ready/start rules', async () => {
  const s = await srv();
  const h = mk(s); await h.connect(); const me = await h.createRoom('H');
  ok(await rejects(h.startMatch(), 'need_players'), 'start alone rejected');
  const g = mk(s); await g.connect(); await g.joinRoom(me.room, 'G');
  ok(await rejects(g.startMatch(), 'not_host'), 'guest cannot start');
  ok(await rejects(h.startMatch(), 'not_ready'), 'host cannot start until guest ready');
  await g.setReady(true);
  const g2 = mk(s); await g2.connect(); await g2.joinRoom(me.room, 'G2');
  ok(await rejects(h.startMatch(), 'not_ready'), 'new unready player blocks start');
  await g2.setReady(true);
  const matchMsgs = []; g.on('match', (m) => matchMsgs.push(m));
  await h.startMatch();
  await waitFor(() => matchMsgs.length === 1 && g.log.length >= 1, 1500, 'match start');
  ok(matchMsgs[0].state && matchMsgs[0].state.chamber === undefined && matchMsgs[0].seats.length === 3, 'match start carries masked state, 3 seats');
  ok(JSON.stringify(matchMsgs[0]).indexOf('"chamber"') < 0, 'chamber order never sent');
  const j = mk(s); await j.connect();
  ok(await rejects(j.joinRoom(me.room, 'late'), 'match_in_progress'), 'join after start rejected');
  ok(await rejects(g.setReady(false), 'match_in_progress'), 'ready locked during match');
  ok(await rejects(h.startMatch(), 'match_in_progress'), 'double start rejected');
});

async function playFull(s, { delayed = [], n = 4 } = {}) {
  const WS = (idx) => (delayed.includes(idx) ? delayWS(80, 250) : undefined);
  const opts = {}; for (let i = 0; i < n; i++) opts[i] = { WS: WS(i) };
  const L = await lobby(s, n, { hostOpts: opts[0], opts });
  L.cs.forEach(bot);
  await L.host.startMatch();
  await waitFor(() => L.cs.every(over), 25000, 'match over for all');
  await waitFor(() => L.cs.every((c) => c.lobby && c.lobby.phase === 'lobby' && c.lobby.last), 5000, 'back to lobby with scores');
  return L;
}
function checkLogs(L, label) {
  const ref = L.cs[0].log;
  ok(ref.length > 3, label + ': has events (' + ref.length + ' batches)');
  ok(L.cs.every((c) => c.log.every((m, i) => m.ver === i + 1)), label + ': every seat got ver 1..N with no gaps/dupes');
  ok(L.cs.every((c) => c.log.length === ref.length), label + ': same batch count per seat');
  const flat = (c) => JSON.stringify(c.log.map((m) => ({ ver: m.ver, ev: m.events.map(norm) })));
  ok(L.cs.every((c) => flat(c) === flat(L.cs[0])), label + ': identical ordered logs after unmasking secrets');
  let leaked = 0, seen = 0;
  for (const c of L.cs) for (const m of c.log) for (const e of m.events) if (e.t === 'peek') { if (e.seat === c.you.seat) { seen++; if (!e.shell) leaked = -1e9; } else if (e.shell) leaked++; }
  ok(seen > 0 && leaked === 0, label + ': peek secret shown only to owner (' + seen + ' own peeks)');
  ok(L.cs.every((c) => c.botErr === undefined || /not_your_turn|no_match/.test(c.botErr.reason || '')), label + ': no unexpected bot errors');
  const w = L.cs[0].results; ok(w && w.winner && L.cs.every((c) => c.results && c.results.winner === w.winner), label + ': same winner everywhere');
  ok(L.cs.every((c) => c.lobby.last.winner === w.winner && c.lobby.last.roundWins), label + ': lobby carries scores');
  ok(L.cs.every((c) => c.lastVer === ref.length), label + ': client lastVer matches');
}
T('match: 4 clients play to the end, identical ordered logs', async () => {
  const s = await srv(); const L = await playFull(s); checkLogs(L, 'plain');
  ok(L.room() && L.room().phase === 'lobby' && L.room().st === null, 'room back in lobby');
  // a second match in the same room works (lobby reset, ready cleared)
  ok(L.cs.slice(1).every((c) => c.lobby.players.find((p) => p.id === c.you.id).ready === false), 'ready cleared after match');
});

function delayWS(min, max) { // ordered artificial latency in both directions
  return class DelayWS {
    constructor(url) {
      const ws = this.ws = new WebSocket(url); let inAt = 0, outAt = 0; const rnd = () => min + Math.random() * (max - min);
      const later = (state, fn) => { const at = Math.max(state.v, Date.now() + rnd()); state.v = at; setTimeout(fn, at - Date.now()); };
      const inS = { get v() { return inAt; }, set v(x) { inAt = x; } }, outS = { get v() { return outAt; }, set v(x) { outAt = x; } };
      this._later = (fn) => later(outS, fn);
      ws.onopen = () => later(inS, () => this.onopen && this.onopen());
      ws.onmessage = (e) => later(inS, () => this.onmessage && this.onmessage(e));
      ws.onclose = (e) => later(inS, () => this.onclose && this.onclose(e));
      ws.onerror = () => {};
    }
    send(d) { this._later(() => { try { this.ws.send(d); } catch (e) { /* closed */ } }); }
    close(c) { this.ws.close(c); }
  };
}
T('latency: 80-250ms jittery clients still see identical order', async () => {
  const s = await srv({ turnMs: 8000 }); const L = await playFull(s, { delayed: [1, 3] }); checkLogs(L, 'latency');
});

T('actions: illegal intents rejected, one winner per race', async () => {
  const s = await srv(); const L = await lobby(s, 2); await L.host.startMatch();
  await waitFor(() => L.cs.every((c) => c.log.length >= 1), 1500, 'round start');
  const room = L.room(); const turn = L.cs.find((c) => c.you.seat === room.st.turn), other = L.cs.find((c) => c !== turn);
  const ver0 = room.ver;
  ok(await rejects(other.act({ type: 'shoot', target: turn.you.seat }), 'not_your_turn'), 'not your turn rejected');
  ok(await rejects(turn.act({ type: 'shoot', target: 'nobody' }), 'bad_target'), 'bad target rejected');
  ok(await rejects(turn.act({ type: 'shoot' }), 'bad_target'), 'missing target rejected');
  ok(await rejects(turn.act({ type: 'dance' }), 'bad_action'), 'unknown action type rejected');
  ok(await rejects(turn.act({ type: 'item', idx: 5 }), 'no_item'), 'empty item slot rejected');
  ok(await rejects(turn.act({ type: 'item', idx: -1 }), 'bad_action'), 'negative idx rejected');
  ok(await rejects(turn.act(null), 'bad_action'), 'null action rejected');
  ok(room.ver === ver0, 'rejections do not bump ver');
  // race: two packets in the same tick from the turn holder -> exactly one accepted
  const rs = await Promise.allSettled([turn.act({ type: 'shoot', target: other.you.seat }), turn.act({ type: 'shoot', target: other.you.seat })]);
  ok(rs.filter((r) => r.status === 'fulfilled').length === 1, 'double-send: exactly one accepted');
  ok(room.ver === ver0 + 1 || room.ver === ver0 + 2 || room.ver > ver0, 'ver advanced');
  ok(await rejects(mk(s).act({ type: 'shoot', target: 'x' }), 'offline'), 'act while offline rejected');
  const raw = await rawWS(s.port); raw.json({ t: 'act', seq: 'x', action: {} }); raw.json({ t: 'act', seq: 1, action: { type: 'shoot', target: 's0' } });
  await waitFor(() => raw.msgs().length >= 2, 1000, 'raw replies');
  ok(raw.msgs()[0].code === 'bad_seq' && raw.msgs()[1].t === 'rej' && raw.msgs()[1].reason === 'not_in_room', 'act outside a room: bad_seq / not_in_room');
  raw.sock.destroy();
});

T('resume: token restores seat + state; bad token refused', async () => {
  const s = await srv({ graceMs: 3000 }); const L = await lobby(s, 3, { opts: { 1: { opts: { backoffMin: 400, backoffMax: 400 } } } });
  await L.host.startMatch(); await waitFor(() => L.cs.every((c) => c.log.length >= 1), 1500, 'start');
  const room = L.room(); const victim = L.cs[1], seat = victim.you.seat, token = victim.you.token;
  const st0 = victim.states.length;
  victim.ws.close(); // simulate lost connection (client auto-reconnects after ~400ms)
  await waitFor(() => victim.status === 'reconnecting', 1000, 'reconnecting');
  await waitFor(() => room.players.find((p) => p.seat === seat && !p.connected), 1000, 'server noticed');
  ok(L.cs[0].lobby && true, 'others still online');
  await waitFor(() => L.cs[0].lobby.players.find((p) => p.seat === seat && !p.connected), 1000, 'lobby shows disconnected');
  // progress the game while the victim is offline
  const actor = L.cs.find((c) => c.you.seat === room.st.turn && c !== victim);
  if (actor) await actor.act({ type: 'shoot', target: L.cs.find((c) => c !== actor && c !== victim).you.seat });
  await waitFor(() => victim.status === 'online' && victim.states.length > st0, 3000, 'victim resumed with state');
  ok(victim.you.seat === seat && victim.you.token === token, 'same seat and token after resume');
  await sleep(60);
  ok(victim.lastVer === room.ver, 'resynced to current ver (' + victim.lastVer + '/' + room.ver + ')');
  const last = victim.states[victim.states.length - 1].state; ok(last.me === seat && last.chamber === undefined, 'resync is masked, for own seat');
  ok(room.players.find((p) => p.seat === seat).connected, 'server marks reconnected');
  const bad = mk(s); await bad.connect();
  const r = await bad._request({ t: 'resume', room: L.code, token: 'f'.repeat(48) }).then(() => 'ok', (e) => e.code);
  ok(r === 'resume_failed', 'wrong token refused');
  ok((await bad._request({ t: 'resume', room: 'ZZZZZ', token: token }).then(() => 'ok', (e) => e.code)) === 'resume_failed', 'unknown room refused');
  // second connection with the token steals the seat and kicks the old socket
  const thief = mk(s, { opts: { reconnect: false } }); await thief.connect();
  const rr = await thief._request({ t: 'resume', room: L.code, token });
  ok(rr.resumed && rr.you.seat === seat, 'resume from a second socket works');
  await waitFor(() => victim.status !== 'online', 1500, 'old socket replaced');
});

T('forfeit: grace expiry in lobby removes, in match forfeits and game continues', async () => {
  const s = await srv({ graceMs: 300, turnMs: 5000 });
  // lobby: removal after grace
  const A = await lobby(s, 3); const gone = A.cs[2]; gone.close();
  await waitFor(() => A.cs[0].lobby.players.length === 3 && !A.cs[0].lobby.players[2].connected, 1000, 'shown disconnected');
  await waitFor(() => A.cs[0].lobby.players.length === 2, 1500, 'removed after grace');
  // match: the current-turn holder drops
  const L = await lobby(s, 3); L.cs.forEach(bot);
  const room = L.room(); const tick = () => 0;
  // freeze bots from acting first: drop whoever holds the turn right after start
  await L.host.startMatch();
  await waitFor(() => room.st && room.st.round === 1, 1000, 'started');
  const holder = L.cs.find((c) => c.you.seat === room.st.turn); const seat = holder.you.seat; holder.opts.reconnect = false; holder.close();
  await waitFor(() => room.st.turn !== seat || room.st.out.has(seat), 2000, 'turn advanced after forfeit');
  ok(room.st.out.has(seat) && room.st[seat].alive === false, 'engine.forfeit called for ' + seat);
  const rest = L.cs.filter((c) => c !== holder);
  await waitFor(() => rest.every((c) => c.log.some((m) => m.events.some((e) => e.t === 'forfeit' && e.seat === seat))), 2000, 'forfeit event broadcast');
  await waitFor(() => rest.every(over), 20000, 'remaining players finish the match');
  ok(rest.every((c) => c.results && c.results.winner !== seat), 'winner is a remaining player');
  await waitFor(() => rest.every((c) => c.lobby.phase === 'lobby' && c.lobby.players.length === 2), 3000, 'lobby after match without the forfeited player');
  void tick;
});

T('turn timeout: server auto-acts through the engine', async () => {
  const s = await srv({ turnMs: 150 }); const L = await lobby(s, 2); await L.host.startMatch();
  const room = L.room(); await waitFor(() => L.cs.every((c) => c.log.length >= 1), 1000, 'start');
  const t0 = room.st.turn; await waitFor(() => L.cs[0].log.some((m) => m.auto), 1500, 'auto action broadcast');
  const m = L.cs[0].log.find((x) => x.auto); ok(m.auto === t0, 'auto-acted for the player on turn (' + t0 + ')');
  ok(m.events.some((e) => e.t === 'shot' && e.seat === t0), 'auto action is a legal shot via engine.apply');
  ok(L.cs[1].log.some((x) => x.auto === t0), 'both seats saw it');
  await waitFor(() => over(L.cs[0]) && over(L.cs[1]), 15000, 'unattended match completes by timeouts alone');
  ok(L.cs[0].log.every((x, i) => x.ver === i + 1), 'versions contiguous');
});

T('host migration', async () => {
  const s = await srv({ graceMs: 1500 }); const L = await lobby(s, 3, { names: ['H', 'B', 'C'] });
  const [h, b, c] = L.cs; ok(L.room().hostId === h.you.id, 'initial host');
  h.close();
  await waitFor(() => c.lobby.host === b.you.id, 1500, 'host moved to next player');
  ok(c.lobby.players.find((p) => p.id === h.you.id).connected === false && c.lobby.players.find((p) => p.id === b.you.id).host, 'old host shown offline; new host flagged');
  ok(await rejects(c.startMatch(), 'not_host'), 'non-host still cannot start');
  await b.startMatch(); await waitFor(() => c.log.length >= 1, 1500, 'new host started the match (disconnected player dropped)');
  ok(L.room().st.seats.length === 2, 'disconnected player excluded from match');
  // explicit leave by host in lobby
  const s2 = await srv(); const M = await lobby(s2, 2); await M.cs[0].leave();
  await waitFor(() => M.cs[1].lobby.host === M.cs[1].you.id && M.cs[1].lobby.players.length === 1, 1500, 'leave -> migrate');
  await M.cs[1].leave(); await waitFor(() => s2.rooms.rooms.size === 0, 1000, 'empty room destroyed');
  ok(s2.rooms.rooms.size === 0, 'room destroyed when empty');
});

T('room idle expiry', async () => {
  const s = await srv({ graceMs: 5000, idleMs: 200 }); const L = await lobby(s, 2); L.cs.forEach((c) => c.close());
  await waitFor(() => s.rooms.rooms.size === 0, 2000, 'idle room destroyed'); ok(true, 'destroyed after idle');
});

T('emotes: validated + rate limited; pings/RTT', async () => {
  const s = await srv(); const L = await lobby(s, 3); const [a, b, c] = L.cs;
  for (let i = 0; i < 6; i++) a.emote('skull');
  await sleep(300);
  ok(b.emotes.length === 1 && c.emotes.length === 1 && a.emotes.length === 1, 'burst of 6 -> exactly 1 delivered (to all incl. sender)');
  ok(b.emotes[0].seat === a.you.seat && b.emotes[0].id === 'skull', 'emote carries sender seat');
  b.emote('Bad Id!'); await waitFor(() => b.errors.some((e) => e.code === 'bad_emote'), 1000, 'bad emote error'); ok(true, 'invalid emote id rejected');
  b.emote('wave'); await sleep(200); ok(a.emotes.length === 2, 'other player not limited by a');
  await sleep(1400); a.emote('skull'); await waitFor(() => b.emotes.length === 3, 1000, 'after 1.5s'); ok(true, 'emote allowed again after 1.5s');
  // time sync
  await waitFor(() => a.rtt !== null, 2000, 'rtt'); ok(a.rtt >= 0 && a.rtt < 500 && Math.abs(a.clockOffset) < 1000, 'rtt/offset estimate sane (' + a.rtt + 'ms, off ' + Math.round(a.clockOffset) + ')');
  ok(Math.abs(a.serverNow() - Date.now()) < 1000, 'serverNow() close to local on loopback');
  await waitFor(() => a.lobby.players.every((p) => typeof p.ping === 'number'), 3000, 'RTT of every player in lobby msgs'); ok(true, 'lobby reports per-player RTT');
  const raw = await rawWS(s.port); raw.json({ t: 'ping', c: 123 }); await waitFor(() => raw.msgs().length, 1000, 'pong');
  ok(raw.msgs()[0].t === 'pong' && raw.msgs()[0].c === 123 && typeof raw.msgs()[0].s === 'number', 'pong echoes c, adds s'); raw.sock.destroy();
});

T('hardening: malformed JSON, unknown types, oversize, flood, bad frames', async () => {
  const s = await srv({ rate: { perSec: 30, burst: 60 } });
  const good = await lobby(s, 2);
  const r = await rawWS(s.port);
  ok(r.status === 101 && r.acceptOk, 'handshake 101 with valid Sec-WebSocket-Accept');
  for (const bad of ['not json', '[]', '"str"', 'null', '{}', '{"t":5}', '{"t":"zzz"}', '{"t":"__proto__"}', '{"t":"constructor"}', '{"v":9,"t":"ping"}', '{"t":"act"}', '{"t":"create","name":{"a":1},"settings":"x"}', '{"t":"join","room":{"a":1}}', '{"t":"emote"}'])
    r.text(bad);
  r.json({ t: 'ping', c: 1 });
  await waitFor(() => r.msgs().some((m) => m.t === 'pong'), 1500, 'still serving after garbage');
  ok(r.msgs().filter((m) => m.t === 'err').length >= 10 && !r.closed, 'errors returned, socket alive');
  ok(JSON.parse((await httpGet(s.port, '/health')).body).ok, 'server alive');
  // fragmentation + ping/pong at frame level
  r.send(1, '{"v":1,"t":"pi', { fin: false }); r.send(0, 'ng","c":77}'); r.send(9, 'hb');
  await waitFor(() => r.frames.some((f) => f.op === 10 && f.payload.toString() === 'hb') && r.msgs().some((m) => m.t === 'pong' && m.c === 77), 1500, 'fragmented msg + ping');
  ok(true, 'fragmented text message reassembled; ping answered with pong');
  r.send(0x8, Buffer.from([0x03, 0xe8]));
  await waitFor(() => r.closed, 1500, 'close handshake'); ok(r.closeCode() === 1000, 'close frame echoed');
  // oversize frame (64KB limit)
  const big = await rawWS(s.port); big.text('x'.repeat(70000)); await waitFor(() => big.closeCode() !== null, 1500, 'oversize close'); ok(big.closeCode() === 1009, 'oversize -> 1009');
  const jbig = new WebSocket(s.wsUrl); const code = await new Promise((res) => { jbig.onopen = () => jbig.send('y'.repeat(100000)); jbig.onclose = (e) => res(e.code); });
  ok(code === 1009, 'global WebSocket oversize -> 1009 (got ' + code + ')');
  const unm = await rawWS(s.port); unm.text('{"t":"ping"}', { unmasked: true }); await waitFor(() => unm.closeCode() !== null, 1500, 'unmasked'); ok(unm.closeCode() === 1002, 'unmasked client frame -> 1002');
  const bin = await rawWS(s.port); bin.send(2, 'bin'); await waitFor(() => bin.closeCode() !== null, 1500, 'binary'); ok(bin.closeCode() === 1003, 'binary -> 1003');
  const u8 = await rawWS(s.port); u8.send(1, Buffer.from([0xff, 0xfe, 0xfd])); await waitFor(() => u8.closeCode() !== null, 1500, 'utf8'); ok(u8.closeCode() === 1007, 'invalid UTF-8 -> 1007');
  const ctl = await rawWS(s.port); ctl.send(9, Buffer.alloc(200)); await waitFor(() => ctl.closeCode() !== null, 1500, 'ctl'); ok(ctl.closeCode() === 1002, 'oversize control frame -> 1002');
  const flood = await rawWS(s.port); for (let i = 0; i < 300; i++) flood.json({ t: 'ping', c: i });
  await waitFor(() => flood.closeCode() !== null, 2000, 'flood'); ok(flood.closeCode() === 1008, 'message flood -> 1008');
  const spam = await rawWS(s.port); for (let i = 0; i < 40; i++) { spam.text('junk'); if (i % 10 === 9) await sleep(400); }
  await waitFor(() => spam.closeCode() !== null, 3000, 'abusive'); ok(spam.closeCode() === 1008, 'persistent garbage -> 1008');
  const guess = await rawWS(s.port); for (let i = 0; i < 14; i++) { guess.json({ t: 'join', room: 'AAAA' + i }); if (i % 6 === 5) await sleep(250); }
  await waitFor(() => guess.closeCode() !== null, 3000, 'guessing'); ok(guess.closeCode() === 1008, 'code guessing -> 1008');
  // wrong path / non-upgrade
  const wrong = await rawWS(s.port, { path: '/nope' }); ok(wrong.status === 404, 'upgrade on wrong path -> 404');
  const nov = await rawWS(s.port, { headers: { 'Sec-WebSocket-Version': '8' } }); ok(nov.status === 426, 'bad WS version -> 426');
  const nokey = await rawWS(s.port, { headers: { 'Sec-WebSocket-Key': 'abc' } }); ok(nokey.status === 400, 'bad key -> 400');
  // the well-behaved room kept working through all this
  await good.host.startMatch(); await waitFor(() => good.cs.every((c) => c.log.length >= 1), 2000, 'unaffected match');
  ok(true, 'other rooms unaffected');
  ok(JSON.parse((await httpGet(s.port, '/health')).body).ok, 'server alive at end');
});

T('heartbeat: silent peer dropped after 2 missed pongs; origin allow-list', async () => {
  const s = await srv({ pingMs: 100 });
  const r = await rawWS(s.port); // raw socket never answers pings
  await waitFor(() => r.frames.some((f) => f.op === 9), 1000, 'server ping'); ok(true, 'server pings');
  await waitFor(() => r.closed, 1500, 'dropped'); ok(r.closed, 'unresponsive socket dropped');
  const c = mk(s, { opts: { pingMs: 5000 } }); await c.connect(); await sleep(450); ok(c.status === 'online', 'node WebSocket auto-pongs and stays connected');
  const s2 = await srv({ allowedOrigins: ['https://good.example'] });
  ok((await rawWS(s2.port, { origin: 'https://evil.example' })).status === 403, 'bad Origin -> 403');
  const g = await rawWS(s2.port, { origin: 'https://good.example' }); ok(g.status === 101, 'allowed Origin -> 101'); g.sock.destroy();
});

T('client: gap detection triggers sync; duplicates dropped; backoff + status', async () => {
  const s = await srv(); const c = mk(s);
  const seen = []; c.on('matchEvents', (m) => seen.push(m.ver));
  await c.connect(); await c.createRoom('x');
  let syncs = 0; c.sync = function () { syncs++; this.syncing = true; return true; };
  c._onMessage(JSON.stringify({ t: 'match', ver: 0, state: {}, seats: [] }));
  const ev = (ver) => c._onMessage(JSON.stringify({ t: 'ev', ver, ev: [{ t: 'x', ver }] }));
  ev(1); ev(1); ev(3); ev(4);
  ok(JSON.stringify(seen) === '[1]' && syncs === 1, 'gap held back + one sync requested');
  c._onMessage(JSON.stringify({ t: 'state', ver: 2, state: { me: 's0' } }));
  ok(JSON.stringify(seen) === '[1,3,4]', 'after state(ver2) held events 3,4 flushed in order: ' + JSON.stringify(seen));
  ev(2); ev(4); ok(seen.length === 3, 'stale/duplicate ignored');
  ok(c.statuses[0] === 'connecting' && c.statuses.includes('online'), 'status events connecting -> online');
  // server killed -> reconnecting -> back online with same seat
  const down = mk(await srv(), { opts: {} }); await down.connect(); const me = await down.createRoom('R');
  down.ws.close(); await waitFor(() => down.statuses.includes('reconnecting'), 1000, 'reconnecting status');
  await waitFor(() => down.status === 'online' && down.you.id === me.you.id, 3000, 'online again'); ok(true, 'auto-reconnect + resume');
  const nowhere = new NetClient({ url: 'ws://127.0.0.1:1/ws', storage: null });
  ok(await nowhere.connect().then(() => false, (e) => e.message === 'connect_failed'), 'connect() rejects when server unreachable');
  ok(NetClient.normalizeUrl('', { protocol: 'https:', host: 'a.b' }) === 'wss://a.b/ws' && NetClient.normalizeUrl('', { protocol: 'http:', host: 'a:1' }) === 'ws://a:1/ws', 'default URL from location');
});

// ============================== runner ==============================
(async () => {
  for (const [name, fn] of TESTS) {
    current = name; const before = failed; const t0 = Date.now(); let to;
    try { await Promise.race([fn(), new Promise((_, rej) => { to = setTimeout(() => rej(new Error('test timed out')), 60000); })]); }
    catch (e) { failed++; console.log('  FAIL [' + name + '] threw: ' + (e && e.stack || e)); }
    clearTimeout(to);
    for (const c of clients.splice(0)) { c.opts.reconnect = false; c.close(); }
    for (const s of servers.splice(0)) await s.close();
    console.log((failed === before ? 'ok   ' : 'FAIL ') + name + ' (' + (Date.now() - t0) + ' ms)');
  }
  finished = true;
  console.log(`\npassed: ${passed}  failed: ${failed}`);
  if (failed) process.exitCode = 1;
  // leak detector: everything is closed, so the process must now exit by itself; this unref'd timer only fires if something keeps it alive
  setTimeout(() => { console.log('FAIL: process still alive 4 s after close() (leaked timer/handle)'); process.exit(1); }, 4000).unref();
})();
process.on('exit', (code) => { if (!finished) { console.log('FAIL: test run did not finish'); process.exitCode = 1; } });
