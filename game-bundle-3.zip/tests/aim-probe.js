/* measures weapon stability while aimed: samples gun animation channels, muzzle screen position and the angle between the barrel line and the view's vanishing point */
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const ctx = await b.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 1, hasTouch: true, isMobile: true });
  const p = await ctx.newPage(); const logs = [];
  const extra = process.argv[2] ? JSON.parse(process.argv[2]) : {};
  await p.addInitScript((x) => { try { localStorage.setItem('tallow.settings.v1', JSON.stringify(Object.assign({ quality: 'medium' }, x))); } catch (e) {} }, extra);
  p.on('console', m => { if (m.type() === 'error') logs.push(m.text()); }); p.on('pageerror', e => logs.push('PAGEERROR: ' + e.message));
  await p.goto('file://' + process.cwd() + '/index.html'); await p.waitForTimeout(2500);
  await p.evaluate(() => document.getElementById('mNew').click()); await p.waitForTimeout(300);
  await p.evaluate(() => document.querySelector('#diffList button').click()); await p.waitForTimeout(1500);
  await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find(x => /skip/i.test(x.textContent) && x.offsetParent); if (b) b.click(); });
  await p.waitForFunction(() => window.Turns && window.Turns.canAct && window.Turns.canAct(), null, { timeout: 90000 });
  await p.evaluate(() => document.getElementById('btnAimD').click());
  await p.waitForFunction(() => window.Turns && window.Turns.aim === 'opp', null, { timeout: 60000 }); await p.waitForTimeout(1500);
  const mode = process.argv[3] || 'still';
  const rows = [];
  for (let i = 0; i < 40; i++) {
    if (mode === 'look') await p.evaluate((i) => { window.Renderer.lookHold = true; window.Renderer.lookX = Math.sin(i * 0.4) * 0.3; window.Renderer.lookY = Math.cos(i * 0.3) * 0.2; }, i);
    rows.push(await p.evaluate(() => { const S = window.Stage3D, gp = window.Anim.gun.p, gi = S.gunInfo, C = S.Cam || null; return { gang: gp.gang, goy: gp.goy, gox: gp.gox, mx: gi && gi.muzzleL ? gi.muzzleL.x : null, my: gi && gi.muzzleL ? gi.muzzleL.y : null, aimErr: S.aimErrorPx(), vp: S.cross || null }; }));
    await p.waitForTimeout(100);
  }
  const sd = (a) => { const m = a.reduce((s, v) => s + v, 0) / a.length; return Math.sqrt(a.reduce((s, v) => s + (v - m) * (v - m), 0) / a.length); };
  const col = (k) => rows.map(r => r[k]).filter(v => typeof v === 'number');
  console.log(JSON.stringify({ mode, extra, gang: [Math.min(...col('gang')).toFixed(3), Math.max(...col('gang')).toFixed(3)], goy: [Math.min(...col('goy')).toFixed(2), Math.max(...col('goy')).toFixed(2)], gox: rows[0].gox, muzzleX_sd: +sd(col('mx')).toFixed(2), muzzleY_sd: +sd(col('my')).toFixed(2), muzzleXrange: [Math.min(...col('mx')).toFixed(1), Math.max(...col('mx')).toFixed(1)], aimErr: col('aimErr').length ? [Math.min(...col('aimErr')).toFixed(1), Math.max(...col('aimErr')).toFixed(1)] : null, vp: rows[0].vp }));
  if (process.env.DUMP) console.log(rows.filter((r, i) => i % 3 === 0).map(r => [r.gang, r.goy, r.gox, r.mx, r.my].map(v => v == null ? v : +(+v).toFixed(2)).join(',')).join('\n'));
  console.log(JSON.stringify(await p.evaluate(() => window.Stage3D.aimDbg)));
  console.log(logs.slice(0, 5).join('\n') || 'no console errors');
  await b.close();
})();
