/* samples the render frame counter once per 500 ms during a running 3D game: proves the loop keeps drawing (and shows the pace under software GL) */
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const ctx = await b.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 1, hasTouch: true, isMobile: true });
  const p = await ctx.newPage(); const errs = [];
  await p.addInitScript((Q) => { try { localStorage.setItem('tallow.settings.v1', JSON.stringify({ quality: (typeof Q === 'string' ? Q : 'low') })); } catch (e) {} }, process.env.QUALITY || 'low');
  p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); }); p.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
  await p.goto('file://' + (process.env.DIR || process.cwd()) + '/index.html'); await p.waitForTimeout(2500);
  if (process.env.PREBAKE) { const tb = Date.now(); await p.evaluate(() => { AudioMgr.unlock(); AudioMgr.sfx('gun_fire'); }); await p.waitForFunction(() => AudioMgr.bakedCount() >= 59, null, { timeout: 150000 }).catch(() => {}); console.log('audio baked in', ((Date.now() - tb) / 1000).toFixed(1), 's, count', await p.evaluate(() => AudioMgr.bakedCount())); }
  await p.evaluate(() => document.getElementById('mNew').click()); await p.waitForTimeout(300); await p.evaluate(() => document.querySelector('#diffList button').click()); await p.waitForTimeout(2500);
  await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find(x => /skip/i.test(x.textContent) && x.offsetParent); if (b) b.click(); });
  const t0 = Date.now(); let ready = true; await p.waitForFunction(() => window.Turns && window.Turns.canAct && window.Turns.canAct(), null, { timeout: 150000 }).catch(() => { ready = false; });
  console.log('time to first playable turn:', ((Date.now() - t0) / 1000).toFixed(1) + ' s', ready ? '' : '(NOT reached)');
  const rows = [];
  for (let i = 0; i < 16; i++) { rows.push(await p.evaluate(() => [Renderer.stats.frames, Math.round(performance.now()), document.hidden ? 1 : 0, Renderer.mode || '', Renderer.use3d ? 1 : 0, Renderer.stats.drawMs])); await p.waitForTimeout(500); }
  console.log(rows.map(r => r.join(',')).join('\n'));
  const d = rows[rows.length - 1][0] - rows[0][0], t = (rows[rows.length - 1][1] - rows[0][1]) / 1000;
  console.log('frames', d, 'in', t.toFixed(1), 's =>', (d / t).toFixed(1), 'fps (software GL); JS ms per frame in this window:', ((rows[rows.length - 1][5] - rows[0][5]) / Math.max(1, d)).toFixed(2));
  console.log(errs.length ? 'ERRORS ' + errs.slice(0, 3).join('\n') : 'no console errors');
  await b.close();
})();
