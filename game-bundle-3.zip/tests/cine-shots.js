/* real in-game captures of the round-start cinematic (camera glide + item drop) and the Dealer's rage scene. usage: node tests/cine-shots.js drop|rage [tag] */
const { chromium } = require('playwright');
(async () => {
  const mode = process.argv[2] || 'drop', tag = process.argv[3] || 'a';
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required'] });
  const ctx = await b.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 1, hasTouch: true, isMobile: true });
  const p = await ctx.newPage(); const logs = [];
  await p.addInitScript(() => { try { localStorage.setItem('tallow.settings.v1', JSON.stringify({ quality: 'medium', subtitles: true })); } catch (e) {} });
  p.on('console', m => { if (m.type() === 'error') logs.push(m.text()); }); p.on('pageerror', e => logs.push('PAGEERROR: ' + e.message));
  await p.goto('file://' + process.cwd() + '/index.html', { waitUntil: 'domcontentloaded', timeout: 120000 }); await p.waitForTimeout(2500);
  await p.evaluate(() => document.getElementById('mNew').click()); await p.waitForTimeout(300);
  await p.evaluate(() => document.querySelector('#diffList button').click()); await p.waitForTimeout(2500);
  await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find(x => /skip/i.test(x.textContent) && x.offsetParent); if (b) b.click(); });
  const out = '/tmp/claude-0/shots/cine_' + tag + '_' + mode;
  if (mode === 'drop') {
    // the first round starts by itself: capture while the camera is down on the table and items are landing
    let n = 0, last = 0; const t0 = Date.now();
    while (n < 8 && Date.now() - t0 < 150000) {
      const s = await p.evaluate(() => { const c = window.Renderer.scene.cine; const it = [].concat(window.Renderer.scene.items.p, window.Renderer.scene.items.d).filter(x => x).length; const cm = window.Stage3D && window.Stage3D.Cam ? window.Stage3D.Cam.eye.map(v => +v.toFixed(3)) : null; return { k: c.k, p: +c.p.toFixed(2), items: it, cam: cm }; });
      if (s.k > 0.6 && Date.now() - last > 900) { last = Date.now(); await p.screenshot({ path: `${out}_${n}.png`, timeout: 120000 }); console.log('shot', n, JSON.stringify(s)); n++; } else await p.waitForTimeout(150);
    }
  } else {
    await p.waitForFunction(() => window.Turns && window.Turns.canAct && window.Turns.canAct(), null, { timeout: 150000 }); await p.waitForTimeout(800);
    await p.evaluate(() => { window.__done = false; window.Show.death('d', window.Turns.state || null).then(() => { window.__done = true; }); });
    const marks = [0.9, 2.4, 3.9, 4.3, 5.2, 7.0]; const t0 = Date.now(); let m = 0;
    while (m < marks.length && Date.now() - t0 < 120000) { const el = (Date.now() - t0) / 1000; if (el >= marks[m]) { await p.screenshot({ path: `${out}_${m}.png`, timeout: 120000 }); console.log('shot', m, 'at', el.toFixed(1), JSON.stringify(await p.evaluate(() => ({ rage: window.Anim.dealer.p.rage, k: window.Renderer.scene.cine.k })))); m++; } else await p.waitForTimeout(60); }
  }
  console.log(logs.slice(0, 8).join('\n') || 'no console errors'); await b.close();
})();
