/* frame-exact captures of the Dealer's rage scene: the game runs in slow motion (window.__timeScale) so each (slow) screenshot lands on a chosen moment. usage: node tests/rage-shots.js [tag] */
const { chromium } = require('playwright');
(async () => {
  const tag = process.argv[2] || 'a';
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const ctx = await b.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 1, hasTouch: true, isMobile: true });
  const p = await ctx.newPage(); const logs = [];
  await p.addInitScript(() => { try { localStorage.setItem('tallow.settings.v1', JSON.stringify({ quality: 'medium', subtitles: true })); } catch (e) {} });
  p.on('console', m => { if (m.type() === 'error') logs.push(m.text()); }); p.on('pageerror', e => logs.push('PAGEERROR: ' + e.message));
  await p.goto('file://' + process.cwd() + '/index.html', { waitUntil: 'domcontentloaded', timeout: 120000 }); await p.waitForTimeout(2500);
  await p.evaluate(() => document.getElementById('mNew').click()); await p.waitForTimeout(300);
  await p.evaluate(() => document.querySelector('#diffList button').click()); await p.waitForTimeout(2500);
  await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find(x => /skip/i.test(x.textContent) && x.offsetParent); if (b) b.click(); });
  await p.waitForFunction(() => window.Turns && window.Turns.canAct && window.Turns.canAct(), null, { timeout: 200000 }); await p.waitForTimeout(1000);
  await p.evaluate(() => {
    const o = window.Show.rageSlam; window.Show.rageSlam = function () { o.call(window.Show); window.__slam = true; window.__timeScale = 0.02; };
    window.__timeScale = 1; window.Show.death('d', null).then(() => { window.__done = true; }).catch(e => { window.__err = String(e); });
  });
  const out = '/tmp/claude-0/shots/rage_' + tag + '_'; let n = 0, slamShots = 0, slowed = false; const t0 = Date.now();
  while (n < 9 && Date.now() - t0 < 170000 && !(await p.evaluate(() => window.__done))) {
    const st = await p.evaluate(() => ({ rage: +window.Anim.dealer.p.rage.toFixed(2), cam: +window.Renderer.scene.cine.k.toFixed(2), ly: Math.round(window.Anim.dealer.p.ly || 0), slam: !!window.__slam }));
    if (!st.slam && !slowed && st.rage >= 1.0 && st.ly < 335) { slowed = true; await p.evaluate(() => { window.__timeScale = 0.1; }); }   // raise phase: slow
    await p.screenshot({ path: out + n + '.png', timeout: 90000 }); console.log('shot', n, JSON.stringify(st)); n++;
    if (st.slam && ++slamShots >= 3) await p.evaluate(() => { window.__timeScale = 0.25; });
  }
  console.log(logs.slice(0, 6).join('\n') || 'no console errors'); await b.close();
})();
