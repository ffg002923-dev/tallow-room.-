/* in-game screenshots (software WebGL) of the supplied gun + hands: idle on the table, aiming at the dealer, aiming at yourself.
   Prints the weapon placement debug (clearance in front of the camera), the hand states and the aim error.
   usage: node tests/br-shot.js [settingsJSON] [tag] */
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const ctx = await b.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 1, hasTouch: true, isMobile: true });
  const p = await ctx.newPage(); const logs = [];
  const extra = process.argv[2] && process.argv[2] !== '-' ? JSON.parse(process.argv[2]) : {}, tag = process.argv[3] || 'a';
  await p.addInitScript((x) => { try { localStorage.setItem('tallow.settings.v1', JSON.stringify(Object.assign({ quality: 'low' }, x))); } catch (e) {} }, extra);
  p.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') logs.push(m.type() + ': ' + m.text()); }); p.on('pageerror', (e) => logs.push('PAGEERROR: ' + e.message));
  await p.goto('file://' + process.cwd() + '/index.html'); await p.waitForTimeout(2500);
  await p.evaluate(() => document.getElementById('mNew').click()); await p.waitForTimeout(300);
  await p.evaluate(() => document.querySelector('#diffList button').click()); await p.waitForTimeout(1500);
  await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find((x) => /skip/i.test(x.textContent) && x.offsetParent); if (b) b.click(); });
  await p.waitForFunction(() => window.Turns && window.Turns.canAct && window.Turns.canAct(), null, { timeout: 120000 });
  const dbg = () => p.evaluate(() => { const S = window.Stage3D; return JSON.stringify({ br: S.brDebug && S.brDebug(), hands: S.handStates && S.handStates(), aimErr: S.aimErrorPx && S.aimErrorPx() }); });
  const shot = async (n) => { await p.screenshot({ path: '/tmp/claude-0/shots/br_' + tag + '_' + n + '.png', timeout: 120000 }); };
  await p.waitForTimeout(1500); await shot('idle'); console.log('idle', await dbg());
  await p.evaluate(() => document.getElementById('btnAimD').click());
  await p.waitForFunction(() => window.Turns && window.Turns.aim === 'opp', null, { timeout: 60000 }); await p.waitForTimeout(2000);
  await shot('aimD'); console.log('aimD', await dbg());
  await p.evaluate(() => document.getElementById('btnLower').click());
  await p.waitForFunction(() => window.Turns && window.Turns.aim === null || window.Turns.aim === 'none' || !window.Turns.aim, null, { timeout: 60000 }); await p.waitForTimeout(2500);
  await shot('lowered'); console.log('lowered', await dbg());
  await p.evaluate(() => document.getElementById('btnAimS').click());
  await p.waitForFunction(() => window.Turns && window.Turns.aim === 'self', null, { timeout: 60000 }); await p.waitForTimeout(2000);
  await shot('aimS'); console.log('aimS', await dbg());
  console.log(logs.slice(0, 8).join('\n') || 'no console errors');
  await b.close();
})();
