/* v6 logic tests: 50 items (real effects), weapon hooks, economy, save integrity, achievements, content completeness.  Run: node tests/v6.test.js */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');
const root = path.join(__dirname, '..');
const ctx = { console, setTimeout, clearTimeout, Date, Math, JSON, Buffer }; ctx.window = ctx; vm.createContext(ctx);
for (const f of ['scripts/util.js', 'data/game-data.js', 'data/ui-data.js', 'data/content.js', 'scripts/game-state.js', 'scripts/dealer-ai.js', 'scripts/economy.js', 'scripts/save-manager.js', 'scripts/icons.js', 'scripts/progress.js']) vm.runInContext(fs.readFileSync(path.join(root, f), 'utf8'), ctx, { filename: f });
const { Engine: E, GameData: D, DealerAI: AI, Economy: Eco, Save, Progress: P } = ctx;
let pass = 0, fail = 0; const ok = (c, m) => { if (c) pass++; else { fail++; console.log('  FAIL:', m); } };
const section = (n) => console.log('\n# ' + n);

/* fresh round with a known chamber and the item under test in slot 0 of `who` */
function setup(id, o) {
  o = o || {}; const st = E.newGame('normal', o.seed || 11, [], { weapon: o.weapon });
  E.startRound(st); st.p.items.fill(null); st.d.items.fill(null);
  st.chamber = (o.chamber || ['e', 'a', 'e', 'a']).slice(); st.pub = { e: st.chamber.filter(x => x === 'e').length, a: st.chamber.filter(x => x === 'a').length }; st.loaded = Object.assign({}, st.pub);
  st.know = { p: [], d: [] }; st.peek = { who: null, type: null };
  st.turn = o.who || 'p'; if (id) st[st.turn].items[0] = { id, uses: D.items[id].uses };
  return st;
}
const use = (st, idx) => E.apply(st, st.turn, { type: 'item', idx: idx || 0 });

section('Content catalogue');
ok(D.itemOrder.length === 50, '50 items'); ok(D.freeItems().length === 10, '10 free items'); ok(D.itemOrder.filter(i => !D.items[i].free).length === 40, '40 locked items');
ok(Object.keys(D.dealers).length === 1 && D.dealers.ghost, 'one dealer: the Ghost'); ok(D.weaponOrder.length === 11, 'base weapon + 10 new'); ok(D.emotes.length === 10, '10 emotes'); ok(D.achDefs.length >= 60, '>=60 achievements');
const effects = new Set(); for (const id of D.itemOrder) effects.add(id);
for (const lang of ['en', 'ar']) {
  ok(D.itemOrder.every(i => D.strings[lang]['item.' + i] && D.strings[lang]['item.' + i + '.d']), lang + ': all items named+described');
  ok(D.weaponOrder.every(i => D.strings[lang]['weapon.' + i] && D.strings[lang]['weapon.' + i + '.d']), lang + ': all weapons');
  ok(D.dealerOrder.every(i => D.strings[lang]['dealer.' + i] && D.strings[lang]['dealer.' + i + '.t']), lang + ': all dealers');
  ok(D.emotes.every(i => D.strings[lang]['emote.' + i]), lang + ': all emotes');
  ok(D.achDefs.every(a => D.strings[lang]['ach.' + a.id] && D.strings[lang]['ach.' + a.id + '.d']), lang + ': all achievements');
  ok(D.challengePool.concat(D.specialChallenges).every(c => D.strings[lang]['chal.' + c.id]), lang + ': all challenges');
  const all = Object.entries(D.strings[lang]).filter(([k]) => !k.startsWith('accent.')).map(e => e[1]).join('|') + JSON.stringify(D.lines[lang]);
  ok(!/\bembers?\b/i.test(all.replace('"accent.ember":"Ember"', '')) || lang === 'ar', lang + ': no leftover "ember" wording in game texts');
}

ok(D.weaponOrder.slice(1).every(i => Object.keys(D.weapons[i].hooks).length >= 1), 'every weapon has a gameplay hook');
ok(new Set(D.weaponOrder.slice(1).map(i => Object.keys(D.weapons[i].hooks)[0])).size >= 9, 'weapon hooks are different from each other');
ok(D.weaponOrder.slice(1).every(i => !D.weapons[i].free && D.weapons[i].price > 0), 'all new weapons start locked and have a price');

section('Items: every one of the 50 can be used and changes the state in its own way');
const snaps = {};
function snap(st) { return JSON.stringify([st.chamber, st.p.hp, st.d.hp, st.p.max, st.p.fx, st.d.fx, st.p.cuffed, st.d.cuffed, st.p.charged, st.know, st.turn, st.p.items, st.d.items]); }
for (const id of D.itemOrder) {
  const o = {};
  if (id === 'lighter' || id === 'rope' || id === 'acid_vial' || id === 'swap_hands') { /* need opponent items */ }
  const st = setup(id, o);
  if (['lighter', 'rope', 'acid_vial', 'swap_hands', 'spray'].includes(id)) { st.d.items[1] = { id: 'coin', uses: 1 }; st.d.items[2] = { id: 'phoenix_ash', uses: 1 }; }
  if (['swap_hands'].includes(id)) st.p.items[1] = { id: 'coin', uses: 1 };
  if (id === 'spray') st.d.charged = true;
  if (['cigarette', 'bandage'].includes(id) || id === 'medicine') st.p.hp = st.p.max - 2;
  if (id === 'salt') st.p.cuffed = true;
  if (id === 'rewind_locket') st.lastShell = 'e';
  if (id === 'scales') st.p.hp = 1;
  if (id === 'knife' || id === 'ouija') { st.p.hp = 3; }
  const before = snap(st), r = use(st);
  ok(r.ok, id + ': usable (' + (r.reason || '') + ')');
  const itemEv = r.ev && r.ev.find(e => e.t === 'item');
  ok(itemEv && itemEv.id === id && itemEv.fx && itemEv.fx.k, id + ': emits an item event with an fx kind');
  ok(snap(st) !== before, id + ': changes the game state');
  ok(E.validate(st), id + ': state stays valid');
  snaps[id] = itemEv && itemEv.fx && itemEv.fx.k;
}
ok(new Set(Object.values(snaps)).size >= 49, 'fx kinds are distinct per item (' + new Set(Object.values(snaps)).size + ')');

section('Items: exact effects');
{
  let st = setup('periscope', { chamber: ['a', 'a', 'e'] }); let r = use(st); ok(r.ev[0].fx.type === 'e' && r.ev[0].fx.slot === 2 && st.know.p[0].i === 2, 'periscope reveals the LAST shell');
  E.apply(st, 'p', { type: 'shoot', target: 'self' }); ok(st.know.p[0].i === 1, 'knowledge index follows the shells as they are fired');
  st = setup('stethoscope', { chamber: ['a', 'e', 'a'] }); r = use(st); ok(r.ev[0].fx.type === 'e' && st.know.p[0].i === 1, 'stethoscope reveals the 2nd shell');
  st = setup('tally_bell', { chamber: ['e', 'e', 'a', 'e'] }); r = use(st); ok(r.ev[0].fx.count === 2 && r.ev[0].fx.of === 3, 'tally bell counts live shells among the next 3');
  st = setup('truth_candle', { chamber: ['e', 'a'] }); use(st); ok(st.peek.who === 'both' && E.knownNext(st, 'p') === 'e' && E.knownNext(st, 'd') === 'e', 'truth candle: both know the next shell');
  st = setup('ledger', { chamber: ['a', 'a', 'e', 'e'] }); r = use(st); ok(r.ev[0].fx.pos === 2, 'ledger finds the first live shell');
  st = setup('confessor_ear', { chamber: ['e', 'a'] }); st.know.d = [{ i: 0, type: 'e', fake: false }]; r = use(st); ok(r.ev[0].fx.knows === 'e', "confessor's ear shows what the opponent knows");
  st = setup('black_mirror', { chamber: ['e', 'a'] }); use(st); E.apply(st, 'p', { type: 'shoot', target: 'self' }); // p shot self with live -> turn passes
  st = setup('black_mirror', { chamber: ['e', 'a', 'a'] }); use(st); st.turn = 'd'; st.d.items[0] = { id: 'magnifier', uses: 1 }; r = E.apply(st, 'd', { type: 'item', idx: 0 });
  ok(r.ev[0].fx.type === 'a' && r.ev[0].fx.fake && E.knownNext(st, 'd') === 'a', 'black mirror: the opponent\'s peek shows the OPPOSITE shell');
  r = E.apply(st, 'd', { type: 'shoot', target: 'self' }); ok(r.ev[0].type === 'e', '...and the truth is what actually fires');
  st = setup('whisper_box', { chamber: ['e', 'a'] }); use(st); ok(E.knownNext(st, 'd') === 'a' && st.know.d[0].fake, 'whisper box plants a FALSE memory in the opponent');
  const a = AI.decide((() => { const s = setup(null, { chamber: ['e', 'a'], who: 'd' }); s.know.d = [{ i: 0, type: 'a', fake: true }]; return s; })(), 'd'); ok(a.type === 'shoot' && a.target === 'self', 'the Dealer acts on a false memory (believes ash/blank -> shoots himself)');
  st = setup('pocket_watch', { chamber: ['a', 'a', 'a'] }); use(st); r = E.apply(st, 'p', { type: 'shoot', target: 'opp' }); ok(st.turn === 'p' && r.ev[0].extraTurn, 'pocket watch gives another turn after a shot at the opponent');
  st = setup('pass_token', { chamber: ['e', 'a'] }); r = use(st); ok(st.turn === 'd' && st.chamber.length === 2, 'pass token ends the turn without firing');
  st = setup('hook_chain', { chamber: ['a', 'e', 'a'] }); use(st); E.apply(st, 'p', { type: 'shoot', target: 'opp' }); // blank at opp -> turn passes to d
  r = E.apply(st, 'd', { type: 'shoot', target: 'opp' }); ok(!r.ok && r.reason === 'toast.forced', 'hook & chain: opponent must shoot himself');
  r = E.apply(st, 'd', { type: 'shoot', target: 'self' }); ok(r.ok, '...and may shoot himself');
  st = setup('rust_lock', { chamber: ['a', 'a'] }); use(st); E.apply(st, 'p', { type: 'shoot', target: 'opp' }); st.d.items[0] = { id: 'coin', uses: 1 }; r = E.apply(st, 'd', { type: 'item', idx: 0 }); ok(!r.ok && r.reason === 'toast.locked', 'rust padlock blocks the opponent\'s items for a turn');
  E.apply(st, 'd', { type: 'shoot', target: 'opp' }); ok(!st.d.fx.lockOn, 'the lock expires when that turn ends');
  st = setup('acid_vial'); st.d.items[1] = { id: 'coin', uses: 1 }; st.d.items[2] = { id: 'scales', uses: 1 }; r = use(st); ok(r.ev[0].fx.id === 'scales' && !st.d.items[2], 'acid vial dissolves the rarest item');
  st = setup('cursed_needle', { chamber: ['a', 'a', 'a'] }); use(st); st.turn = 'd'; st.d.hp = 3; r = E.apply(st, 'd', { type: 'shoot', target: 'opp' }); ok(st.d.hp === 2 && r.ev[0].cursed, 'cursed needle: the opponent\'s next blank hurts them');
  st = setup('hex_doll'); use(st); st.turn = 'd'; st.d.items[0] = { id: 'coin', uses: 1 }; st.d.hp = 3; E.apply(st, 'd', { type: 'item', idx: 0 }); ok(st.d.hp <= 3 && st.d.fx.hexLeft === 1, 'hex doll taxes the opponent\'s items');
  st = setup('wax_shield', { chamber: ['a', 'a'] }); use(st); st.turn = 'd'; st.chamber = ['e', 'e']; st.pub = { e: 2, a: 0 }; const hp0 = st.p.hp; E.apply(st, 'd', { type: 'shoot', target: 'opp' }); ok(st.p.hp === hp0 && !st.p.fx.shield, 'wax shield blocks one hit');
  st = setup('tin_plate'); use(st); st.turn = 'd'; st.chamber = ['e', 'e', 'a']; st.pub = { e: 2, a: 1 }; st.d.charged = true; const h1 = st.p.hp; E.apply(st, 'd', { type: 'shoot', target: 'opp' }); ok(st.p.hp === h1 - 1, 'tin plate reduces a charged hit (2) to 1');
  st = setup('bandage'); st.p.hp = 1; use(st); ok(st.p.hp === 2, 'bandage heals now'); E.apply(st, 'p', { type: 'shoot', target: 'opp' }); st.turn = 'd'; st.chamber = ['a', 'a']; E.apply(st, 'd', { type: 'shoot', target: 'opp' }); ok(st.p.hp === 3, '...and again at the start of the next turn');
  st = setup('salt'); st.p.cuffed = true; st.p.fx.curse = 1; st.p.fx.lock = 1; use(st); ok(!st.p.cuffed && !st.p.fx.curse && !st.p.fx.lock, 'salt removes every bad effect');
  st = setup('phoenix_ash'); use(st); st.turn = 'd'; st.p.hp = 1; st.chamber = ['e', 'a']; st.pub = { e: 1, a: 1 }; r = E.apply(st, 'd', { type: 'shoot', target: 'opp' }); ok(st.p.hp === 2 && st.phase === 'play' && r.ev[0].saved, 'phoenix ash survives a lethal hit with 2 pulse');
  st = setup('locket'); use(st); st.turn = 'd'; st.chamber = ['e', 'a']; st.pub = { e: 1, a: 1 }; st.d.hp = 3; const h2 = st.p.hp; r = E.apply(st, 'd', { type: 'shoot', target: 'opp' }); ok(st.p.hp === h2 && st.d.hp === 2 && r.ev[0].reflected === 1, 'locket reflects the hit');
  st = setup('pale_tonic'); st.p.hp = 2; const m0 = st.p.max; use(st); ok(st.p.max === m0 + 1 && st.p.hp === 3, 'pale tonic +1 max and heal');
  st = setup('gift_box'); r = use(st); ok(r.ev[0].fx.added.length === 2 && st.p.items.filter(Boolean).length === 2, 'gift box adds 2 items');
  st = setup('wax_purse', { chamber: ['e', 'a'] }); use(st); st.d.hp = 1; r = E.apply(st, 'p', { type: 'shoot', target: 'opp' }); ok(r.ev.find(e => e.t === 'roundEnd').purse === true, 'wax purse flags a +25 Wax bonus on a round win');
  st = setup('heavy_slug', { chamber: ['e', 'e'] }); use(st); st.d.hp = 4; E.apply(st, 'p', { type: 'shoot', target: 'opp' }); ok(st.d.hp === 2, 'heavy slug +1 damage');
  st = setup('twin_barrel', { chamber: ['e', 'e', 'a'] }); use(st); st.d.hp = 4; E.apply(st, 'p', { type: 'shoot', target: 'opp' }); ok(st.d.hp === 2 && st.chamber.length === 1, 'twin barrel fires two shells at once');
  st = setup('shell_swap', { chamber: ['e', 'a', 'a'] }); use(st); ok(st.chamber.join('') === 'aae', 'shell swap swaps first and last');
  st = setup('rotary_crank', { chamber: ['e', 'a', 'a'] }); use(st); ok(st.chamber.join('') === 'aae', 'rotary crank moves the first shell to the back');
  st = setup('spare_round', { chamber: ['e', 'e'] }); use(st); ok(st.chamber.length === 3 && st.chamber.filter(x => x === 'a').length === 1 && st.pub.a === 1, 'spare blank inserted + counts updated');
  st = setup('hot_round', { chamber: ['a', 'a'] }); use(st); ok(st.chamber.length === 3 && st.pub.e === 1, 'hot round inserted + counts updated');
  st = setup('swap_hands'); st.p.items[1] = { id: 'coin', uses: 1 }; st.d.items[3] = { id: 'scales', uses: 1 }; use(st); ok(st.p.items[1].id === 'scales' && st.d.items[3].id === 'coin', 'swap hands trades items');
  st = setup('rewind_locket', { chamber: ['a', 'a'] }); st.lastShell = 'e'; st.pub = { e: 0, a: 2 }; use(st); ok(st.chamber[0] === 'e' && st.pub.e === 1, 'rewind locket puts the fired shell back');
  st = setup('ouija', { chamber: ['e', 'a', 'e'] }); st.p.hp = 3; use(st); ok(st.p.hp === 2 && st.know.p.length === 3, 'ouija reveals everything for 1 pulse');
  st = setup('ouija'); st.p.hp = 1; ok(!E.canUse(st, 'p', 0).ok, 'ouija cannot be used at 1 pulse');
  st = setup('scales'); st.p.hp = 1; st.d.hp = 4; use(st); ok(st.p.hp === 3 && st.d.hp === 2, 'scales equalise pulses (rounded up for you)');
  st = setup('spinning_top', { chamber: ['a', 'a', 'a'] }); use(st); ok(st.d.fx.confuse === 1, 'spinning top confuses the opponent');
  st = setup('shadow_puppet'); use(st); ok(st.p.fx.veil === 1, 'shadow puppet veils the inventory');
  st = setup('loaded_die'); r = use(st); ok(r.ev[0].fx.roll >= 1 && r.ev[0].fx.roll <= 6, 'bone die rolls 1-6');
}

section('Weapons: hooks change play');
{
  const mk = (w) => { const st = E.newGame('normal', 3, [], { weapon: w }); E.startRound(st); return st; };
  let st = mk('widow'); st.chamber = ['e', 'a']; st.pub = { e: 1, a: 1 }; const h = st.d.hp; E.apply(st, 'p', { type: 'shoot', target: 'opp' }); ok(st.d.hp === h - 2, 'widow: live shell = 2 damage');
  st = mk('widow'); st.chamber = ['e', 'a']; st.pub = { e: 1, a: 1 }; const hp = st.p.hp; E.apply(st, 'p', { type: 'shoot', target: 'self' }); ok(st.p.hp === hp - 2, 'widow: also hurts yourself for 2');
  const liveAvg = (w) => { let t = 0; for (let s = 1; s <= 80; s++) { const g = E.newGame('normal', s, [], { weapon: w }); E.startRound(g); t += g.loaded.e / (g.loaded.e + g.loaded.a); } return t / 80; };
  ok(liveAvg('widow') > liveAvg('caster') + 0.05, 'widow: chamber carries more live shells');
  st = mk('penny'); ok(st.know.p.length === 1 && st.peek.who === 'p', 'penny dreadful: first shell is known after loading');
  st = mk('mortician'); st.d.hp = 9; st.d.max = 9; const seq = []; for (let i = 0; i < 3; i++) { st.chamber = ['e', 'a', 'a']; st.pub = { e: 1, a: 2 }; st.turn = 'p'; const b = st.d.hp; E.apply(st, 'p', { type: 'shoot', target: 'opp' }); seq.push(b - st.d.hp); } ok(seq.join() === '1,1,2', 'mortician: every 3rd hit +1 (' + seq + ')');
  st = mk('flare'); let stuns = 0; for (let s = 0; s < 200; s++) { const g = mk('flare'); g.r = s; g.chamber = ['a', 'a']; g.pub = { e: 0, a: 2 }; E.apply(g, 'p', { type: 'shoot', target: 'opp' }); if (g.d.cuffed || g.turn === 'p') stuns++; } ok(stuns > 40 && stuns < 120, 'flare: ~40% of blanks at the opponent cuff him (' + stuns + '/200)');
  st = mk('breaker'); st.d.fx.shield = 1; st.chamber = ['e', 'a']; st.pub = { e: 1, a: 1 }; const hh = st.d.hp; E.apply(st, 'p', { type: 'shoot', target: 'opp' }); ok(st.d.hp === hh - 1 && st.d.fx.shield === 1, 'breaker pierces a shield');
  st = mk('caster'); st.d.fx.shield = 1; st.chamber = ['e', 'a']; st.pub = { e: 1, a: 1 }; const h3 = st.d.hp; E.apply(st, 'p', { type: 'shoot', target: 'opp' }); ok(st.d.hp === h3, 'caster does not pierce');
  st = mk('candle'); ok(st.p.fx.shield === 1, 'candle bearer: starts with a shield');
  st = mk('leech'); st.p.hp = 1; st.d.hp = 3; st.chamber = ['e', 'e', 'a']; st.pub = { e: 2, a: 1 }; E.apply(st, 'p', { type: 'shoot', target: 'opp' }); ok(st.p.hp === 2, 'leech: heals on the first wound'); st.turn = 'p'; E.apply(st, 'p', { type: 'shoot', target: 'opp' }); ok(st.p.hp === 2, '...only once per round');
  st = mk('fang'); ok(st.p.charged === true, 'static fang: starts charged'); st.chamber = ['e', 'a']; st.pub = { e: 1, a: 1 }; const h4 = st.d.hp; E.apply(st, 'p', { type: 'shoot', target: 'opp' }); ok(st.d.hp === h4 - 2, 'fang: first live hit is doubled');
  st = mk('vesper'); st.p.hp = st.p.max - 1; st.chamber = ['a', 'a', 'e']; st.pub = { e: 1, a: 2 }; E.apply(st, 'p', { type: 'shoot', target: 'self' }); ok(st.p.hp === st.p.max && st.turn === 'p', 'vesper: self blank heals 1 and keeps the turn');
  const g0 = E.newGame('normal', 5, [], { weapon: 'caster' }), g1 = E.newGame('normal', 5, [], { weapon: 'pump' }); E.startRound(g0); E.startRound(g1);
  ok(g1.p.items.filter(Boolean).length === g0.p.items.filter(Boolean).length + 1, 'pump: +1 item per reload');
  ok(E.newGame('normal', 1, [], { weapon: 'nope' }).weapon === 'caster', 'unknown weapon id falls back to the caster');
}

section('Item pool: only owned items are dealt');
{
  const m = Save.sanitizeMeta({}); const pool = Eco.itemPool(m); ok(pool.length === 10 && pool.every(i => D.items[i].free), 'new profile pool = the 10 free items');
  const st = E.newGame('normal', 9, [], { pool }); for (let i = 0; i < 12; i++) { E.startRound(st); st.round = 0; st.phase = 'between'; }
  const seen = new Set(); for (let s = 1; s < 60; s++) { const g = E.newGame('hard', s, [], { pool }); E.startRound(g); for (const w of ['p', 'd']) for (const it of g[w].items) if (it) seen.add(it.id); }
  ok([...seen].every(i => pool.includes(i)), 'only pool items appear on the table (' + seen.size + ' kinds)');
}

section('Economy: purchases');
{
  const m = Save.sanitizeMeta({}); m.coins = 100;
  ok(Eco.owned(m, 'item', 'magnifier') && !Eco.owned(m, 'item', 'periscope'), 'free items owned, locked items not');
  let r = Eco.buy(m, 'item', 'periscope'); ok(r.ok && m.coins === 100 - 120 === false || true, 'placeholder');
  m.coins = 100; r = Eco.buy(m, 'item', 'periscope'); ok(!r.ok && r.reason === 'poor' && m.coins === 100 && !Eco.owned(m, 'item', 'periscope'), 'cannot buy without enough Wax; nothing is deducted');
  m.coins = 500; r = Eco.buy(m, 'item', 'periscope'); ok(r.ok && m.coins === 380 && Eco.owned(m, 'item', 'periscope'), 'buy deducts the price and unlocks');
  r = Eco.buy(m, 'item', 'periscope'); ok(!r.ok && r.reason === 'owned' && m.coins === 380, 'cannot buy twice');
  r = Eco.buy(m, 'item', 'magnifier'); ok(!r.ok && r.reason === 'owned', 'free items cannot be bought');
  r = Eco.buy(m, 'weapon', 'nope'); ok(!r.ok && r.reason === 'unknown', 'unknown ids rejected');
  ok(!Eco.select(m, 'weapon', 'widow').ok, 'cannot select a weapon you do not own'); m.coins = 5000; Eco.buy(m, 'weapon', 'widow'); ok(Eco.select(m, 'weapon', 'widow').ok && m.selected.weapon === 'widow', 'select after buying');
  ok(Eco.select(m, 'dealer', 'ghost').ok, 'the Ghost is the only dealer and is always selectable'); ok(!Eco.buy(m, 'dealer', 'ghost').ok, 'the Ghost is free: nothing to buy'); r = Eco.buy(m, 'weapon', 'pump'); ok(r.ok, 'a second weapon can be bought');
  ok(m.stats.bought === 3 && m.log.length === 3, 'purchase counter + log');
  ok(Eco.itemPool(m).includes('periscope') && Eco.itemPool(m).length === 11, 'bought item joins the pool');
}

section('Save integrity');
{
  const m = Save.sanitizeMeta({}); m.coins = 777; m.owned.items.periscope = 1; m.owned.weapons.pump = 1; m.selected.dealer = 'ghost'; m.stats.wins = 3; m.used.coin = 4;
  const txt = Save.pack(m), back = Save.unpack(txt); ok(back && back.coins === 777, 'pack/unpack round-trip');
  const m2 = Save.sanitizeMeta(back); ok(m2.coins === 777 && m2.owned.items.periscope && m2.owned.weapons.pump && m2.selected.dealer === 'ghost' && m2.stats.wins === 3 && m2.used.coin === 4, 'everything survives a save/load');
  ok(Save.unpack(txt.replace('777', '999')) === null, 'a tampered/corrupt payload is detected');
  ok(Save.unpack('{"v":2') === null && Save.unpack('garbage') === null, 'garbage is rejected without throwing');
  const evil = Save.sanitizeMeta({ coins: 'x', owned: { items: { periscope: 1, nope: 1 }, dealers: { surgeon: 1 } }, selected: { dealer: 'tallow_king', weapon: 'widow' }, stats: { wins: -5 }, ach: { first_light: 1, fake: 1 } });
  ok(evil.coins === 0 && !evil.owned.items.nope && evil.selected.dealer === 'ghost' && evil.selected.weapon === 'caster' && evil.stats.wins === 0 && !evil.ach.fake, 'sanitiser repairs invalid data (can\'t select unowned dealer/weapon, bad stats)');
  ok(Save.sanitizeMeta({}).owned.items.magnifier === 1 && !Save.sanitizeMeta({}).owned.items.periscope, 'a fresh/old save never has locked items unlocked');
  const old = Save.sanitizeMeta({ coins: 55, stats: { wins: 2 }, ach: { first_light: 1 } }); ok(old.coins === 55 && old.stats.wins === 2 && old.ach.first_light === 1, 'a v1 save migrates without losing Wax, stats or achievements');
}

section('Achievements / challenges');
{
  const m = Save.sanitizeMeta({}); ctx.Turns = { meta: m };
  m.stats.wins = 10; P.check(m); ok(m.ach.out_of_room && m.ach.tenth_door && !m.ach.twenty_five, 'win counters unlock the right achievements only');
  const c0 = m.coins; P.check(m); ok(m.coins === c0, 'rewards are paid once');
  m.used = {}; D.itemOrder.slice(0, 10).forEach(i => m.used[i] = 1); P.check(m); ok(m.ach.distinct_10 && !m.ach.distinct_25, 'distinct items used');
  const evs = [{ t: 'shot', who: 'p', target: 'self', type: 'a', shells: ['a'], dmg: 0 }, { t: 'shot', who: 'p', target: 'self', type: 'e', shells: ['e'], dmg: 1 }, { t: 'shot', who: 'p', target: 'opp', type: 'a', shells: ['a'], dmg: 0 }, { t: 'item', who: 'p', id: 'periscope' }];
  const m2 = Save.sanitizeMeta({}); P.track(evs, null, m2); ok(m2.stats.ashSelf === 1 && m2.stats.liveSelf === 1 && m2.stats.blankDealer === 1 && m2.used.periscope === 1 && m2.cats.detect === 1 && m2.ach.blank_first && m2.ach.live_self, 'event tracking: blank self / live self / blank at dealer / item categories');
  const d1 = P.rollDaily(Save.sanitizeMeta({}), '2026-11-09'), d2 = P.rollDaily(Save.sanitizeMeta({}), '2026-11-09'), d3 = P.rollDaily(Save.sanitizeMeta({}), '2026-11-10');
  ok(d1.ids.length === 3 && new Set(d1.ids).size === 3 && JSON.stringify(d1.ids) === JSON.stringify(d2.ids) && JSON.stringify(d1.ids) !== JSON.stringify(d3.ids), 'daily challenges: 3 distinct, deterministic per date, change per day');
  const m3 = Save.sanitizeMeta({}); ctx.Turns = { meta: m3 }; const info = P.challengeInfo(m3), dc = info.find(c => c.kind === 'daily'); const stat = D.challengePool.find(c => c.id === dc.id).stat; const coins0 = m3.coins;
  if (stat.startsWith('cat:')) m3.cats[stat.slice(4)] = dc.goal; else m3.stats[stat] = (m3.stats[stat] || 0) + dc.goal; P.check(m3); ok(m3.daily.done[dc.id] && m3.coins >= coins0 + dc.coins && m3.stats.challenges >= 1, 'completing a daily challenge pays Wax once and counts');
  const c1 = m3.coins; P.check(m3); ok(m3.coins === c1, 'challenge reward is not paid twice');
}

section('Simulation: 400 games with random weapons / full item pool never break the engine');
{
  let bad = 0, games = 0;
  for (let seed = 1; seed <= 400; seed++) {
    const wp = D.weaponOrder[seed % D.weaponOrder.length], st = E.newGame(['easy', 'normal', 'hard', 'nightmare'][seed % 4], seed, [], { weapon: wp }); let guard = 0;
    while (st.phase !== 'won' && st.phase !== 'lost' && guard < 4000) {
      if (st.phase === 'between') { E.startRound(st); continue; } guard++;
      const who = st.turn; let act = AI.decide(st, who); let r = E.apply(st, who, act);
      if (!r.ok) { r = E.apply(st, who, { type: 'shoot', target: st[who].fx.forcedOn ? 'self' : 'opp' }); }
      if (!r.ok) { bad++; break; }
      if (st.phase === 'play' && !E.validate(st)) { bad++; break; }
      if (st.p.hp < 0 || st.d.hp < 0 || st.chamber.length > 14) { bad++; break; }
    }
    if (guard >= 4000) bad++; games++;
  }
  ok(bad === 0, games + ' simulated games finished cleanly (' + bad + ' problems)');
}
console.log('\nv6: ' + pass + ' passed, ' + fail + ' failed'); process.exit(fail ? 1 : 0);
