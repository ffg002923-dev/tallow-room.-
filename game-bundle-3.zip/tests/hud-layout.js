/* in-game HUD layout check at several screen sizes / preference variants (2D renderer: fast and deterministic).
   Reports: overlapping HUD controls, controls outside the screen, touch targets under 40 px, and writes screenshots. */
const { chromium } = require('playwright');
const OUT = process.env.SHOTS || '/tmp/claude-0/shots';
const SIZES = (process.env.SIZES || '915x412,740x360,1280x720,2400x1080,360x740').split(',').map((s) => s.split('x').map(Number));
const VARIANTS = JSON.parse(process.env.VARIANTS || '[{},{"hudSide":"left","uiScale":1.2,"hudLabels":false},{"lang":"ar","uiScale":0.85,"hudAlpha":0.6}]');
(async () => {
  const b = await chromium.launch(); let problems = 0;
  for (const [w, h] of SIZES) for (const [vi, v] of VARIANTS.entries()) {
    const ctx = await b.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: 1, hasTouch: true, isMobile: w < 1000 });
    const p = await ctx.newPage(); const logs = []; p.on('console', (m) => { if (m.type() === 'error') logs.push(m.text()); }); p.on('pageerror', (e) => logs.push('PAGEERROR ' + e.message));
    await p.addInitScript((x) => { try { localStorage.setItem('tallow.settings.v1', JSON.stringify(Object.assign({ quality: 'low', three: false }, x))); localStorage.setItem('tallow.meta.v1', JSON.stringify({ tutorial: true })); } catch (e) {} }, v);
    await p.goto('file://' + process.cwd() + '/index.html'); await p.waitForTimeout(1500);
    await p.evaluate(() => document.getElementById('mNew').click()); await p.waitForTimeout(200);
    await p.evaluate(() => document.querySelector('#diffList button').click());
    if (w < h) { console.log('  [' + w + 'x' + h + '] portrait: rotate prompt shown =', await p.evaluate(() => !document.getElementById('rotate').classList.contains('hidden')), '(game pauses until the phone is turned)'); await ctx.close(); continue; }
    await p.waitForFunction(() => window.Turns && window.Turns.canAct && window.Turns.canAct(), null, { timeout: 90000 }); await p.waitForTimeout(400);
    const measure = async (tag) => {
      const r = await p.evaluate(() => {
        const out = [], els = [...document.querySelectorAll('#hud .gbtn, #hud .ibtn, #hud .hud-mid, #hud .side, #hud #prompt, #hud #status .status')].filter((e) => e.offsetParent && e.getBoundingClientRect().width > 0);
        const rect = (e) => e.getBoundingClientRect(), vw = innerWidth, vh = innerHeight, name = (e) => e.id || e.className.split(' ')[0];
        for (const e of els) { const b = rect(e); if (b.left < -1 || b.top < -1 || b.right > vw + 1 || b.bottom > vh + 1) out.push('off-screen ' + name(e)); if ((e.matches('.gbtn,.ibtn')) && (b.width < 37 || b.height < 37)) out.push('small target ' + name(e) + ' ' + Math.round(b.width) + 'x' + Math.round(b.height)); }
        for (let i = 0; i < els.length; i++) for (let j = i + 1; j < els.length; j++) { const a = rect(els[i]), c = rect(els[j]); if (els[i].contains(els[j]) || els[j].contains(els[i])) continue; const ox = Math.min(a.right, c.right) - Math.max(a.left, c.left), oy = Math.min(a.bottom, c.bottom) - Math.max(a.top, c.top); if (ox > 2 && oy > 2) out.push('overlap ' + name(els[i]) + ' / ' + name(els[j]) + ' (' + Math.round(ox) + 'x' + Math.round(oy) + ')'); }
        out.push('#' + els.filter((e) => e.matches('.gbtn')).map((e) => e.id + ':' + Math.round(rect(e).width)).join(','));
        return out;
      });
      const bad = r.filter((x) => x[0] !== '#'); problems += bad.length; console.log('  [' + w + 'x' + h + ' v' + vi + '] ' + tag + ': ' + (bad.length ? bad.join(' | ') : 'ok') + '   ' + r.filter((x) => x[0] === '#')[0]);
    };
    await measure('turn'); await p.screenshot({ path: OUT + '/hud_' + w + 'x' + h + '_v' + vi + '_a.png' });
    await p.evaluate(() => document.getElementById('btnAimD').click()); await p.waitForFunction(() => window.Turns && window.Turns.aim === 'opp', null, { timeout: 60000 }); await p.waitForTimeout(500);
    await measure('aimed'); await p.screenshot({ path: OUT + '/hud_' + w + 'x' + h + '_v' + vi + '_b.png' });
    await p.evaluate(() => document.getElementById('btnInv').click()); await p.waitForTimeout(500); await p.screenshot({ path: OUT + '/hud_' + w + 'x' + h + '_v' + vi + '_c.png' });
    if (logs.length) { problems += logs.length; console.log('  console errors:', logs.slice(0, 3).join(' | ')); }
    await ctx.close();
  }
  console.log('hud layout problems: ' + problems); await b.close();
})();
