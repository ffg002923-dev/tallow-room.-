'use strict';
/* ws.js — minimal RFC 6455 WebSocket *server* (text messages only), Node built-ins only.
 * attachWebSocket(httpServer, {path, onConnection, verifyOrigin, maxPayload, pingMs, maxMissed, rate})
 *   socket.send(str) · socket.close(code, reason) · socket.terminate()
 *   events: 'message'(str) · 'close'(code, reason)
 *   socket.rtt = last heartbeat round trip (ms, or null)
 * Implemented: handshake (Sec-WebSocket-Accept), masking, fragmentation, ping/pong/close,
 * UTF-8 validation, payload limit (1009), per-socket token-bucket rate limit (1008),
 * heartbeat (ping every pingMs, dropped after maxMissed unanswered pings), write backpressure cap.
 * Not implemented (not needed): binary messages (rejected 1003), extensions/permessage-deflate, subprotocols. */
const crypto = require('crypto');
const { EventEmitter } = require('events');

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const OPEN = 1, CLOSING = 2, CLOSED = 3;
const utf8 = new TextDecoder('utf-8', { fatal: true });
const VALID_CODES = new Set([1000, 1001, 1002, 1003, 1007, 1008, 1009, 1010, 1011]);

function frame(op, payload) {
  const len = payload.length;
  let head;
  if (len < 126) head = Buffer.from([0x80 | op, len]);
  else if (len < 65536) { head = Buffer.alloc(4); head[0] = 0x80 | op; head[1] = 126; head.writeUInt16BE(len, 2); }
  else { head = Buffer.alloc(10); head[0] = 0x80 | op; head[1] = 127; head.writeUInt32BE(0, 2); head.writeUInt32BE(len, 6); }
  return Buffer.concat([head, payload]);
}

class WSConn extends EventEmitter {
  constructor(sock, o) {
    super();
    this.sock = sock; this.o = o; this.state = OPEN;
    this.buf = Buffer.alloc(0);
    this.fragOp = null; this.frags = []; this.fragLen = 0;
    this.tokens = o.rate.burst; this.tokAt = Date.now();
    this.missed = 0; this.pingAt = 0; this.rtt = null;
    this.closeCode = 1006; this.closeReason = ''; this.timers = [];
    sock.on('data', (d) => this._onData(d));
    sock.on('error', () => {});
    sock.on('close', () => this._finish());
    this.hb = setInterval(() => this._heartbeat(), o.pingMs);
  }
  get readyState() { return this.state; }
  send(str) {
    if (this.state !== OPEN) return false;
    if (this.sock.writableLength > 1 << 20) { this.terminate(); return false; } // slow consumer
    this.sock.write(frame(1, Buffer.from(String(str), 'utf8')));
    return true;
  }
  close(code = 1000, reason = '') {
    if (this.state !== OPEN) return;
    this.state = CLOSING; this.closeCode = code; this.closeReason = reason;
    const r = Buffer.from(String(reason).slice(0, 100), 'utf8');
    const p = Buffer.alloc(2 + r.length); p.writeUInt16BE(code, 0); r.copy(p, 2);
    try { this.sock.write(frame(8, p)); } catch (e) { /* ignore */ }
    const t = setTimeout(() => this.terminate(), 1500); // peer did not echo close
    this.timers.push(t);
  }
  terminate() { this.state = CLOSING; try { this.sock.destroy(); } catch (e) { /* ignore */ } this._finish(); }
  _finish() {
    if (this.state === CLOSED) return;
    this.state = CLOSED; clearInterval(this.hb); this.timers.forEach(clearTimeout);
    this.buf = Buffer.alloc(0); this.frags = [];
    try { this.sock.destroy(); } catch (e) { /* ignore */ }
    this.emit('close', this.closeCode, this.closeReason);
  }
  _heartbeat() {
    if (this.state !== OPEN) return;
    if (this.missed >= this.o.maxMissed) { this.closeReason = 'heartbeat'; return this.terminate(); }
    this.missed++; this.pingAt = Date.now();
    this.sock.write(frame(9, Buffer.alloc(0)));
  }
  _fail(code, reason) { this.close(code, reason); this.buf = Buffer.alloc(0); }
  _onData(chunk) {
    if (this.state !== OPEN) { if (this.state === CLOSING) this._closingData(chunk); return; }
    this.buf = this.buf.length ? Buffer.concat([this.buf, chunk]) : chunk;
    this._parse();
  }
  _closingData(chunk) { // while closing, only look for the peer's close frame
    this.buf = Buffer.concat([this.buf, chunk]);
    if (this.buf.length >= 2 && (this.buf[0] & 0x0f) === 8) this.sock.end();
    if (this.buf.length > 4096) this.sock.destroy();
  }
  _parse() {
    for (;;) {
      const b = this.buf;
      if (b.length < 2) return;
      const fin = !!(b[0] & 0x80), op = b[0] & 0x0f, masked = !!(b[1] & 0x80);
      if (b[0] & 0x70) return this._fail(1002, 'rsv');
      if (!masked) return this._fail(1002, 'unmasked');
      let len = b[1] & 0x7f, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) {
        if (b.length < 10) return;
        if (b.readUInt32BE(2) !== 0) return this._fail(1009, 'too big');
        len = b.readUInt32BE(6); off = 10;
      }
      if (op >= 8 && (len > 125 || !fin)) return this._fail(1002, 'bad control');
      if (len > this.o.maxPayload || this.fragLen + len > this.o.maxPayload) return this._fail(1009, 'too big');
      if (b.length < off + 4 + len) return; // wait for rest
      const mask = b.subarray(off, off + 4);
      const pl = Buffer.allocUnsafe(len);
      for (let i = 0; i < len; i++) pl[i] = b[off + 4 + i] ^ mask[i & 3];
      this.buf = b.subarray(off + 4 + len);
      this.missed = 0; // any traffic proves liveness
      if (!this._frame(fin, op, pl) || this.state !== OPEN) return;
    }
  }
  _frame(fin, op, pl) {
    switch (op) {
      case 0: // continuation
        if (this.fragOp === null) return this._fail(1002, 'unexpected continuation'), false;
        this.frags.push(pl); this.fragLen += pl.length;
        if (fin) { const all = Buffer.concat(this.frags); const o = this.fragOp; this.fragOp = null; this.frags = []; this.fragLen = 0; return this._msg(o, all); }
        return true;
      case 1: case 2:
        if (this.fragOp !== null) return this._fail(1002, 'expected continuation'), false;
        if (fin) return this._msg(op, pl);
        this.fragOp = op; this.frags = [pl]; this.fragLen = pl.length; return true;
      case 8: {
        let code = 1005, reason = '';
        if (pl.length === 1) return this._fail(1002, 'bad close'), false;
        if (pl.length >= 2) {
          code = pl.readUInt16BE(0);
          if (!(VALID_CODES.has(code) || (code >= 3000 && code <= 4999))) return this._fail(1002, 'bad close code'), false;
          try { reason = utf8.decode(pl.subarray(2)); } catch (e) { return this._fail(1007, 'bad utf8'), false; }
        }
        this.closeCode = code; this.closeReason = reason; this.state = CLOSING;
        try { this.sock.write(frame(8, pl.length >= 2 ? pl.subarray(0, 2) : Buffer.alloc(0))); } catch (e) { /* ignore */ }
        this.sock.end();
        const t = setTimeout(() => this.terminate(), 1000); this.timers.push(t);
        return false;
      }
      case 9: this.sock.write(frame(10, pl)); return true;
      case 10: if (this.pingAt) { this.rtt = Date.now() - this.pingAt; this.pingAt = 0; } return true;
      default: return this._fail(1002, 'bad opcode'), false;
    }
  }
  _msg(op, data) {
    if (op === 2) return this._fail(1003, 'binary unsupported'), false;
    const now = Date.now(), r = this.o.rate; // token bucket
    this.tokens = Math.min(r.burst, this.tokens + (now - this.tokAt) * r.perSec / 1000); this.tokAt = now;
    if (this.tokens < 1) return this._fail(1008, 'rate limit'), false;
    this.tokens--;
    let s;
    try { s = utf8.decode(data); } catch (e) { return this._fail(1007, 'bad utf8'), false; }
    this.emit('message', s);
    return true;
  }
}

function attachWebSocket(httpServer, opts = {}) {
  const o = {
    path: '/ws', maxPayload: 64 * 1024, pingMs: 15000, maxMissed: 2,
    rate: Object.assign({ perSec: 30, burst: 60 }, opts.rate || {}),
    verifyOrigin: null, onConnection: () => {}, ...opts,
  };
  o.rate = Object.assign({ perSec: 30, burst: 60 }, opts.rate || {});
  const conns = new Set();
  const reject = (sock, status, text) => {
    try { sock.end(`HTTP/1.1 ${status} ${text}\r\nConnection: close\r\nContent-Length: 0\r\n\r\n`); } catch (e) { /* ignore */ }
    setTimeout(() => sock.destroy(), 500).unref();
  };
  function onUpgrade(req, sock, head) {
    sock.on('error', () => {});
    let pathname = '';
    try { pathname = new URL(req.url, 'http://x').pathname; } catch (e) { return reject(sock, 400, 'Bad Request'); }
    if (pathname !== o.path) return reject(sock, 404, 'Not Found');
    const key = req.headers['sec-websocket-key'];
    if (req.method !== 'GET' || String(req.headers.upgrade || '').toLowerCase() !== 'websocket' ||
        !/upgrade/i.test(req.headers.connection || '') || !key || Buffer.from(key, 'base64').length !== 16) return reject(sock, 400, 'Bad Request');
    if (req.headers['sec-websocket-version'] !== '13') {
      return sock.end('HTTP/1.1 426 Upgrade Required\r\nSec-WebSocket-Version: 13\r\nContent-Length: 0\r\nConnection: close\r\n\r\n');
    }
    if (o.verifyOrigin && !o.verifyOrigin(req.headers.origin, req)) return reject(sock, 403, 'Forbidden');
    const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
    sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
    sock.setNoDelay(true); sock.setTimeout(0);
    const c = new WSConn(sock, o);
    conns.add(c); c.on('close', () => conns.delete(c));
    c.req = req;
    try { o.onConnection(c, req); } catch (e) { c.close(1011, 'server error'); }
    if (head && head.length) c._onData(head);
  }
  httpServer.on('upgrade', onUpgrade);
  return {
    conns,
    /** close every socket (1001) and stop listening for upgrades */
    close() { httpServer.off('upgrade', onUpgrade); for (const c of [...conns]) { c.close(1001, 'going away'); c.terminate(); } },
  };
}

module.exports = { attachWebSocket, WSConn, frame };
