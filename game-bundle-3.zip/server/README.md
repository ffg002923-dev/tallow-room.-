# Tallow Room multiplayer server

Zero dependencies (Node >= 18 built-ins). Serves the game files AND the WebSocket endpoint (`/ws`) from one port, plus `GET /health`.

## Run locally
    node server/server.js          # http://localhost:8080  (PORT, HOST, MAX_ROOMS, ALLOWED_ORIGINS env vars)
Open the game from that URL on two or more devices/tabs on the same network (use your LAN IP) and use PLAY WITH FRIENDS -> create / join with the room code.

## Deploy (needed for play over the internet)
- Render: push the folder to GitHub -> New Web Service -> Docker (render.yaml is included). Use the wss URL it gives you.
- Fly.io: `fly launch --no-deploy` then `fly deploy` (fly.toml included).
- Any VPS: `docker build -t tallow . && docker run -p 8080:8080 tallow`, put it behind HTTPS (Caddy/nginx) so browsers can use `wss://`.
If the game is hosted elsewhere (e.g. static hosting), enter the server URL in Settings > Multiplayer server, and set ALLOWED_ORIGINS to the game's origin.

## What is authoritative
The server owns the match state (scripts/mp-engine.js): turn order, shell chamber, items, damage. Clients only send intents; hidden information (what an item revealed) is sent only to its owner. Turn timer auto-plays AFK seats; disconnects get a grace period and a resume token; rate limits and message-size limits apply.

## Honest limits
- Tested here with automated multi-client tests (182 checks) against a local server. NOT tested on real phones or over the real internet.
- Multiplayer uses an 18-item subset and the standard weapon; the full 50 items/weapons are single-player.
- No accounts/anti-cheat for coins: multiplayer rewards are local to each client.
