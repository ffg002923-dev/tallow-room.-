'use strict';
/* engine-loader.js — loads the browser-style UMD game engine into an isolated vm context so it can run in Node.
 * Files are executed in order; missing optional files are skipped. Returns the `Engine` object (or null). */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const FILES = [
  ['scripts/util.js', true],
  ['data/game-data.js', true],
  ['data/ui-data.js', false],
  ['data/content.js', false], // may not exist yet
  ['scripts/mp-engine.js', true],
];
const API = ['newMatch', 'startRound', 'apply', 'forfeit', 'viewFor', 'maskEvent'];

function loadEngine(root = path.join(__dirname, '..')) {
  // `window` is deliberately undefined so the UMD wrappers fall back to the context's globalThis.
  const ctx = vm.createContext({ console, Math, Date, JSON, setTimeout, clearTimeout });
  for (const [rel, required] of FILES) {
    const file = path.join(root, rel);
    if (!fs.existsSync(file)) { if (required) throw new Error('engine file missing: ' + rel); continue; }
    vm.runInContext(fs.readFileSync(file, 'utf8'), ctx, { filename: file });
  }
  return vm.runInContext('typeof MPEngine !== "undefined" ? MPEngine : null', ctx);
}

/** true if the engine implements the multiplayer contract (see README) */
function hasMultiplayerApi(engine) {
  return !!engine && API.every((k) => typeof engine[k] === 'function');
}

module.exports = { loadEngine, hasMultiplayerApi, API };
