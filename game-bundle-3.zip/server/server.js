'use strict';
/* server.js — static file host + /health + /ws multiplayer endpoint. Node built-ins only.
 * Config (env only, no secrets): PORT (8080), MAX_ROOMS (500), ALLOWED_ORIGINS (comma list; empty = any). */
const http = require('http');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { attachWebSocket } = require('./ws');
const { Rooms } = require('./rooms');

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json',
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.webp': 'image/webp', '.gif': 'image/gif', '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon', '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg', '.wav': 'audio/wav', '.m4a': 'audio/mp4',
  '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.txt': 'text/plain; charset=utf-8', '.wasm': 'application/wasm',
  '.glb': 'model/gltf-binary', '.map': 'application/json',
};
const COMPRESSIBLE = new Set(['.html', '.js', '.mjs', '.css', '.json', '.svg', '.webmanifest', '.txt', '.map']);
// never served even though they live in the game root
const HIDDEN_TOP = new Set(['server', 'tests', 'tools', 'node_modules']);
const HIDDEN_FILES = new Set(['dockerfile', 'render.yaml', 'fly.toml', 'package.json', 'package-lock.json']);

function createServer(opts = {}) {
  const staticDir = path.resolve(opts.staticDir || path.join(__dirname, '..'));
  const now = opts.now || Date.now;
  const started = now();
  const allowed = (opts.allowedOrigins || []).map((s) => s.trim()).filter(Boolean);
  const rooms = new Rooms({ ...opts, engine: opts.engine || null, now });
  const gzCache = new Map();
  let realRoot = null;

  function send(res, status, body, type = 'text/plain; charset=utf-8', extra = {}) {
    res.writeHead(status, { 'Content-Type': type, 'Content-Length': Buffer.byteLength(body), 'X-Content-Type-Options': 'nosniff', ...extra });
    res.end(body);
  }

  async function serveStatic(req, res) {
    let rel;
    try { rel = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch (e) { return send(res, 400, 'Bad request'); }
    if (rel.includes('\0')) return send(res, 400, 'Bad request');
    if (/(^|[\\/])(\.\.|%2e%2e)([\\/]|$)/i.test((req.url || '').split('?')[0])) return send(res, 403, 'Forbidden');
    const parts = rel.split(/[\\/]+/).filter(Boolean);
    if (parts.includes('..')) return send(res, 403, 'Forbidden');
    if (parts.some((s) => s.startsWith('.')) || HIDDEN_TOP.has((parts[0] || '').toLowerCase()) || (parts.length === 1 && HIDDEN_FILES.has(parts[0].toLowerCase()))) return send(res, 404, 'Not found');
    let file = path.join(staticDir, ...parts);
    if (file !== staticDir && !file.startsWith(staticDir + path.sep)) return send(res, 403, 'Forbidden');
    try {
      realRoot = realRoot || await fs.promises.realpath(staticDir);
      let st = await fs.promises.stat(file);
      if (st.isDirectory()) { file = path.join(file, 'index.html'); st = await fs.promises.stat(file); } // no listings
      const real = await fs.promises.realpath(file);
      if (real !== realRoot && !real.startsWith(realRoot + path.sep)) return send(res, 403, 'Forbidden'); // symlink escape
      if (!st.isFile()) return send(res, 404, 'Not found');
      const ext = path.extname(file).toLowerCase();
      const type = MIME[ext] || 'application/octet-stream';
      const hdr = { 'Content-Type': type, 'X-Content-Type-Options': 'nosniff', 'Last-Modified': st.mtime.toUTCString(), 'Accept-Ranges': 'bytes',
        'Cache-Control': ext === '.html' || ext === '.js' ? 'no-cache' : 'public, max-age=3600' };
      const ims = req.headers['if-modified-since'];
      if (ims && Date.parse(ims) >= Math.floor(st.mtimeMs / 1000) * 1000 && ext !== '.html' && ext !== '.js') { res.writeHead(304, hdr); return res.end(); }
      const range = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
      if (range && (range[1] || range[2])) { // single byte range (audio seeking on mobile)
        let a = range[1] === '' ? Math.max(0, st.size - +range[2]) : +range[1];
        let b = range[1] === '' || range[2] === '' ? st.size - 1 : Math.min(+range[2], st.size - 1);
        if (a > b || a >= st.size) { res.writeHead(416, { 'Content-Range': 'bytes */' + st.size }); return res.end(); }
        res.writeHead(206, { ...hdr, 'Content-Range': `bytes ${a}-${b}/${st.size}`, 'Content-Length': b - a + 1 });
        return req.method === 'HEAD' ? res.end() : fs.createReadStream(file, { start: a, end: b }).pipe(res);
      }
      if (COMPRESSIBLE.has(ext) && st.size < 4e6 && /\bgzip\b/.test(req.headers['accept-encoding'] || '')) {
        const key = file + ':' + st.mtimeMs; let gz = gzCache.get(key);
        if (!gz) { gz = zlib.gzipSync(await fs.promises.readFile(file)); if (gzCache.size > 200) gzCache.clear(); gzCache.set(key, gz); }
        res.writeHead(200, { ...hdr, 'Content-Encoding': 'gzip', 'Content-Length': gz.length, Vary: 'Accept-Encoding' });
        return res.end(req.method === 'HEAD' ? undefined : gz);
      }
      res.writeHead(200, { ...hdr, 'Content-Length': st.size });
      if (req.method === 'HEAD') return res.end();
      fs.createReadStream(file).on('error', () => res.destroy()).pipe(res);
    } catch (e) { send(res, 404, 'Not found'); }
  }

  const server = http.createServer((req, res) => {
    try {
      const pathname = (req.url || '/').split('?')[0];
      if (pathname === '/health') {
        const s = rooms.stats();
        return send(res, 200, JSON.stringify({ ok: true, rooms: s.rooms, players: s.players, uptime: Math.round((now() - started) / 1000) }), 'application/json; charset=utf-8', { 'Cache-Control': 'no-store' });
      }
      if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Method not allowed', undefined, { Allow: 'GET, HEAD' });
      serveStatic(req, res).catch(() => { if (!res.headersSent) send(res, 500, 'Server error'); else res.destroy(); });
    } catch (e) { if (!res.headersSent) send(res, 500, 'Server error'); }
  });
  server.headersTimeout = 20000; server.requestTimeout = 30000;

  const ws = attachWebSocket(server, {
    path: '/ws', pingMs: opts.pingMs || 15000, maxPayload: opts.wsMaxPayload || 64 * 1024, rate: opts.rate,
    verifyOrigin: allowed.length ? (origin) => !origin || allowed.includes(origin) : null,
    onConnection: (sock) => rooms.handleConnection(sock),
  });

  const api = {
    server, rooms, ws, port: null, url: null, wsUrl: null,
    listen(port = opts.port === undefined ? Number(process.env.PORT) || 8080 : opts.port, host = opts.host) {
      return new Promise((resolve, reject) => {
        server.once('error', reject);
        server.listen(port, host, () => {
          server.off('error', reject);
          api.port = server.address().port;
          const h = host && host !== '0.0.0.0' && host !== '::' ? host : '127.0.0.1';
          api.url = `http://${h}:${api.port}`; api.wsUrl = `ws://${h}:${api.port}/ws`;
          resolve(api.url);
        });
      });
    },
    /** stop everything: clears all room timers, closes sockets, resolves when the port is released */
    close() {
      rooms.shutdown(); ws.close();
      return new Promise((resolve) => { server.close(() => resolve()); if (server.closeAllConnections) server.closeAllConnections(); });
    },
  };
  return api;
}

module.exports = { createServer, MIME };

if (require.main === module) {
  const { loadEngine, hasMultiplayerApi } = require('./engine-loader');
  let engine = null;
  try { engine = loadEngine(); } catch (e) { console.error('[tallow] engine failed to load:', e.message); }
  if (!hasMultiplayerApi(engine)) console.warn('[tallow] WARNING: engine lacks the multiplayer API (newMatch/forfeit/viewFor/maskEvent); rooms work but matches cannot start.');
  const app = createServer({
    engine, port: Number(process.env.PORT) || 8080, host: process.env.HOST || '0.0.0.0',
    maxRooms: Number(process.env.MAX_ROOMS) || 500,
    allowedOrigins: (process.env.ALLOWED_ORIGINS || '').split(','),
    log: (...a) => console.error('[tallow]', ...a),
  });
  app.listen().then((url) => console.log(`[tallow] listening on ${url} (ws path /ws)`));
  const stop = () => app.close().then(() => process.exit(0));
  process.on('SIGTERM', stop); process.on('SIGINT', stop);
}
