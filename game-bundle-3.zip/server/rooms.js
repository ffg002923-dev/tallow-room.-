'use strict';
/* rooms.js — rooms, sessions and the authoritative match loop.
 * The engine (see README "Engine contract") owns all rules; this file only validates intents, serialises
 * them per room, masks events per seat, versions every broadcast (`ver`) and keeps the game from stalling
 * (turn timer, forfeit on lost connection, intermission/results timers). All state lives in memory. */
const crypto = require('crypto');

const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const MAX_PLAYERS = 4, SLOTS_MAX = 64;
const DEFAULTS = {
  turnMs: 45000, graceMs: 60000, intermissionMs: 4000, resultsMs: 8000, idleMs: 5 * 60000,
  statusMs: 5000, emoteMs: 1500, maxRooms: 500, maxSettingsBytes: 512,
};

/** name: strip control chars + angle brackets, trim, max 16 chars; falls back to "Player N" */
function sanitizeName(raw, seatIdx) {
  let s = typeof raw === 'string' ? raw : '';
  s = s.replace(/[\u0000-\u001f\u007f-\u009f\u2028\u2029<>]/g, '').replace(/\s+/g, ' ').trim();
  s = Array.from(s).slice(0, 16).join('').trim();
  return s || 'Player ' + (seatIdx + 1);
}

function cleanSettings(raw, max) {
  if (raw === undefined || raw === null) return null;
  if (typeof raw !== 'object' || Array.isArray(raw)) return false;
  let json; try { json = JSON.stringify(raw); } catch (e) { return false; }
  if (json.length > max) return false;
  const out = {};
  for (const k of Object.keys(raw)) if (k !== '__proto__' && k !== 'constructor') out[k] = raw[k];
  if (out.weaponMode !== undefined && out.weaponMode !== 'own' && out.weaponMode !== 'caster') return false;
  if (out.dealer !== undefined && !(typeof out.dealer === 'string' && /^[\w-]{1,32}$/.test(out.dealer))) return false;
  return out; // difficulty & others are kept opaque/ignored
}

const safeEq = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };

class Room {
  constructor(mgr, code) {
    this.mgr = mgr; this.code = code; this.players = []; this.hostId = null;
    this.phase = 'lobby'; // 'lobby' | 'match' (match includes the post-game results window)
    this.settings = { dealer: 'default', weaponMode: 'own' };
    this.st = null; this.ver = 0; this.over = false; this.last = null; this.dl = null;
    this.q = []; this.draining = false; this.dead = false; this.dirty = false;
    this.turnT = this.phaseT = this.idleT = null;
    this.statusT = setInterval(() => { if (this.dirty) { this.dirty = false; this.broadcastLobby(); } }, mgr.o.statusMs);
  }
  /** serialise every state-changing job for this room (actions, timers, forfeits) */
  run(fn) {
    this.q.push(fn);
    if (this.draining) return;
    this.draining = true;
    try { while (this.q.length && !this.dead) { try { this.q.shift()(); } catch (e) { this.mgr.log('room job error', e && e.stack || e); } } }
    finally { this.draining = false; }
  }
  get active() { return this.players.filter((p) => !p.gone); }
  get connected() { return this.players.filter((p) => p.connected && !p.gone); }
  byId(id) { return this.players.find((p) => p.id === id); }
  tx(p, obj) { if (p.conn) p.conn.socket.send(JSON.stringify(Object.assign({ v: 1 }, obj))); }
  txAll(obj) { const s = JSON.stringify(Object.assign({ v: 1 }, obj)); for (const p of this.connected) p.conn.socket.send(s); }
  pub(p) {
    const rtt = p.ping != null ? p.ping : (p.conn && p.conn.socket.rtt != null ? p.conn.socket.rtt : null);
    return { id: p.id, name: p.name, seat: p.seat, ready: p.id === this.hostId ? true : p.ready, connected: p.connected, host: p.id === this.hostId, ping: rtt, out: !!p.gone };
  }
  lobbyMsg() {
    return { t: 'lobby', room: this.code, phase: this.phase, host: this.hostId, settings: this.settings, max: MAX_PLAYERS,
      players: this.active.map((p) => this.pub(p)), last: this.last, ver: this.ver };
  }
  broadcastLobby() { this.txAll(this.lobbyMsg()); }
  pickHost(excludeId) {
    const c = this.active.filter((p) => p.id !== excludeId);
    const h = c.find((p) => p.connected) || c[0];
    this.hostId = h ? h.id : null;
  }
  touchIdle() { // destroy a room that nobody has been connected to for idleMs
    clearTimeout(this.idleT); this.idleT = null;
    if (this.connected.length === 0 && !this.dead) this.idleT = setTimeout(() => this.destroy(), this.mgr.o.idleMs);
  }
  destroy() {
    if (this.dead) return; this.dead = true;
    clearTimeout(this.turnT); clearTimeout(this.phaseT); clearTimeout(this.idleT); clearInterval(this.statusT);
    for (const p of this.players) {
      clearTimeout(p.graceT);
      if (p.conn) { p.conn.player = null; p.conn.room = null; p.conn = null; }
    }
    this.mgr.rooms.delete(this.code);
  }
}

class Rooms {
  constructor(opts = {}) {
    this.o = Object.assign({}, DEFAULTS, opts);
    this.engine = opts.engine || null; this.now = opts.now || Date.now;
    this.log = opts.log || (() => {});
    this.rooms = new Map(); this.closed = false;
  }
  stats() { let players = 0; for (const r of this.rooms.values()) players += r.connected.length; return { rooms: this.rooms.size, players }; }
  shutdown() { this.closed = true; for (const r of [...this.rooms.values()]) r.destroy(); }

  // ---------- connection plumbing ----------
  handleConnection(socket) {
    const conn = { socket, player: null, room: null, errs: 0, joinFails: 0 };
    socket.on('message', (raw) => this.onMessage(conn, raw));
    socket.on('close', () => this.onClose(conn));
  }
  send(conn, obj) { conn.socket.send(JSON.stringify(Object.assign({ v: 1 }, obj))); }
  err(conn, code, msg, m) { this.send(conn, { t: 'err', code, msg: msg || code, ref: m && m.rid }); }
  bad(conn, code, m) {
    this.err(conn, code, null, m);
    if (++conn.errs > 25) conn.socket.close(1008, 'too many errors');
  }
  onMessage(conn, raw) {
    if (this.closed) return;
    let m;
    try { m = JSON.parse(raw); } catch (e) { return this.bad(conn, 'bad_json'); }
    if (!m || typeof m !== 'object' || Array.isArray(m) || typeof m.t !== 'string') return this.bad(conn, 'bad_message');
    if (m.v !== undefined && m.v !== 1) return this.bad(conn, 'bad_version', m);
    if (m.rid !== undefined && !(typeof m.rid === 'number' || (typeof m.rid === 'string' && m.rid.length < 32))) delete m.rid;
    const h = Object.prototype.hasOwnProperty.call(HANDLERS, m.t) ? HANDLERS[m.t] : null;
    if (!h) return this.bad(conn, 'unknown_type', m);
    try { h.call(this, conn, m); } catch (e) { this.log('handler error', m.t, e && e.stack || e); this.err(conn, 'server_error', null, m); }
  }
  onClose(conn) {
    if (this.closed) return;
    const p = conn.player, room = conn.room;
    conn.player = conn.room = null;
    if (!p || !room || room.dead || p.conn !== conn) return;
    p.conn = null; p.connected = false;
    if (room.hostId === p.id) room.pickHost(p.id);
    clearTimeout(p.graceT);
    p.graceT = setTimeout(() => this.drop(room, p, 'timeout'), this.o.graceMs);
    room.touchIdle(); room.broadcastLobby();
  }

  // ---------- membership ----------
  newCode() {
    for (;;) {
      let c = ''; for (let i = 0; i < 5; i++) c += CODE_CHARS[crypto.randomInt(CODE_CHARS.length)];
      if (!this.rooms.has(c)) return c;
    }
  }
  addPlayer(room, conn, name, weapon) {
    const used = new Set(room.players.map((p) => p.seat));
    let idx = 0; while (used.has('s' + idx)) idx++;
    const p = { id: crypto.randomBytes(4).toString('hex'), name: sanitizeName(name, idx), seat: 's' + idx, ready: false, connected: true,
      token: crypto.randomBytes(24).toString('hex'), ping: null, weapon: typeof weapon === 'string' && /^[\w-]{1,24}$/.test(weapon) ? weapon : null,
      conn, graceT: null, lastEmote: 0, gone: false };
    room.players.push(p); conn.player = p; conn.room = room;
    if (!room.hostId) room.hostId = p.id;
    room.touchIdle();
    return p;
  }
  joined(conn, m, resumed) {
    const room = conn.room, p = conn.player;
    this.send(conn, { t: 'joined', ref: m.rid, room: room.code, resumed: !!resumed, you: { id: p.id, seat: p.seat, name: p.name, token: p.token }, host: room.hostId });
  }
  /** player leaves for good (explicit leave / grace expired). Lobby: removed. Running match: forfeited. */
  drop(room, p, why) {
    if (room.dead || p.gone || !room.players.includes(p)) return;
    clearTimeout(p.graceT);
    if (p.conn) { p.conn.player = null; p.conn.room = null; p.conn = null; }
    p.connected = false;
    if (room.phase === 'lobby') room.players = room.players.filter((x) => x !== p);
    else { p.gone = true; this.forfeitSeat(room, p); }
    if (room.hostId === p.id) room.pickHost(p.id);
    if (!room.active.length) return room.destroy();
    room.touchIdle(); room.broadcastLobby();
  }

  // ---------- match flow ----------
  startMatch(room) {
    const E = this.engine;
    for (const p of room.players.filter((x) => !x.connected)) { clearTimeout(p.graceT); room.players = room.players.filter((x) => x !== p); }
    const seats = room.players.map((p) => p.seat).sort();
    const weapons = {};
    for (const p of room.players) { const w = room.settings.weaponMode === 'caster' ? 'caster' : p.weapon; if (w) weapons[p.seat] = w; }
    const st = E.newMatch(seats, { seed: crypto.randomInt(1, 0x7fffffff), weapons });
    room.st = st; room.ver = 0; room.over = false; room.phase = 'match'; room.last = null;
    for (const p of room.players) { p.ready = false; p.gone = false; }
    for (const p of room.connected) room.tx(p, { t: 'match', ver: 0, seats, settings: room.settings, players: room.players.map((x) => room.pub(x)), state: E.viewFor(st, p.seat) });
    room.broadcastLobby();
    this.publish(room, st.phase === 'between' ? E.startRound(st) : []);
    this.afterChange(room);
  }
  /** version + mask + broadcast one batch of events; every seat receives the same ver sequence */
  publish(room, ev, meta) {
    const st = room.st, E = this.engine;
    ev = Array.isArray(ev) ? ev.slice() : [];
    const becameOver = st.phase === 'over' && !room.over;
    if (becameOver && !ev.some((e) => e && e.t === 'matchOver')) ev.push({ t: 'matchOver', winner: st.winner || null, roundWins: st.roundWins });
    if (!ev.length) return;
    room.ver++;
    room.dl = st.phase === 'play' ? this.now() + this.o.turnMs : null;
    for (const p of room.connected) {
      const out = [];
      for (const e of ev) { const x = E.maskEvent(e, p.seat, st); if (x !== null && x !== undefined) out.push(x); }
      room.tx(p, Object.assign({ t: 'ev', ver: room.ver, ev: out, turn: st.turn, phase: st.phase, dl: room.dl }, meta));
    }
    if (becameOver) {
      room.over = true;
      const names = {}; for (const p of room.players) names[p.seat] = p.name;
      room.last = { winner: st.winner || null, roundWins: Object.assign({}, st.roundWins), names };
      room.txAll({ t: 'results', ver: room.ver, ...room.last });
    }
  }
  afterChange(room) {
    clearTimeout(room.turnT); clearTimeout(room.phaseT); room.turnT = room.phaseT = null;
    const st = room.st; if (!st || room.dead) return;
    if (st.phase === 'play') {
      const ver = room.ver;
      room.turnT = setTimeout(() => room.run(() => this.autoTurn(room, ver)), this.o.turnMs);
    } else if (st.phase === 'between') {
      room.phaseT = setTimeout(() => room.run(() => {
        if (room.st !== st || st.phase !== 'between') return;
        this.publish(room, this.engine.startRound(st)); this.afterChange(room);
      }), this.o.intermissionMs);
    } else if (st.phase === 'over') {
      room.phaseT = setTimeout(() => room.run(() => this.endMatch(room)), this.o.resultsMs);
    }
  }
  /** turn timeout: act for the player through the engine so the game can never stall */
  autoTurn(room, ver) {
    const st = room.st, E = this.engine;
    if (!st || room.ver !== ver || st.phase !== 'play') return;
    const seat = st.turn;
    const foes = (st.order || st.seats).filter((s) => s !== seat && st[s] && st[s].alive !== false);
    const tries = [];
    if (typeof E.autoAction === 'function') { try { tries.push(E.autoAction(st, seat)); } catch (e) { /* fall through */ } }
    if (foes.length) tries.push({ type: 'shoot', target: foes[0] });
    tries.push({ type: 'shoot', target: seat });
    for (const a of tries) {
      let r; try { r = E.apply(st, seat, a); } catch (e) { r = null; }
      if (r && r.ok) { this.publish(room, r.ev, { auto: seat }); return this.afterChange(room); }
    }
    this.forfeitSeat(room, room.players.find((p) => p.seat === seat) || { seat });
  }
  forfeitSeat(room, p) {
    room.run(() => {
      const st = room.st; if (!st || room.over || st.phase === 'over') return;
      let ev = []; try { ev = this.engine.forfeit(st, p.seat) || []; } catch (e) { this.log('forfeit error', e); }
      this.publish(room, ev); this.afterChange(room);
    });
  }
  endMatch(room) {
    if (room.dead) return;
    room.phase = 'lobby'; room.st = null; room.over = false; room.dl = null;
    room.players = room.players.filter((p) => { if (p.gone || !p.connected) { clearTimeout(p.graceT); return false; } return true; });
    for (const p of room.players) p.ready = false;
    if (!room.players.length) return room.destroy();
    if (!room.byId(room.hostId)) room.pickHost(null);
    room.broadcastLobby();
  }
}

// ---------- message handlers: `this` is Rooms ----------
const need = (conn) => conn.player && conn.room && !conn.room.dead;
const HANDLERS = {
  create(conn, m) {
    if (conn.player) this.drop(conn.room, conn.player, 'leave');
    if (this.rooms.size >= this.o.maxRooms) return this.err(conn, 'room_limit', null, m);
    const s = cleanSettings(m.settings, this.o.maxSettingsBytes);
    if (s === false) return this.err(conn, 'bad_settings', null, m);
    const room = new Room(this, this.newCode());
    this.rooms.set(room.code, room);
    if (s) room.settings = Object.assign(room.settings, s);
    this.addPlayer(room, conn, m.name, m.weapon);
    this.joined(conn, m); room.broadcastLobby();
  },
  join(conn, m) {
    if (conn.player) this.drop(conn.room, conn.player, 'leave');
    const code = typeof m.room === 'string' ? m.room.trim().toUpperCase() : '';
    const room = this.rooms.get(code);
    const fail = (c) => { if (++conn.joinFails > 12) conn.socket.close(1008, 'too many attempts'); this.err(conn, c, null, m); };
    if (!room) return fail('room_not_found');
    if (room.phase !== 'lobby') return fail('match_in_progress');
    if (room.active.length >= MAX_PLAYERS) return fail('room_full');
    this.addPlayer(room, conn, m.name, m.weapon);
    this.joined(conn, m); room.broadcastLobby();
  },
  resume(conn, m) {
    const room = this.rooms.get(typeof m.room === 'string' ? m.room.trim().toUpperCase() : '');
    const p = room && typeof m.token === 'string' ? room.players.find((x) => !x.gone && safeEq(x.token, m.token)) : null;
    if (!p) { if (++conn.joinFails > 12) conn.socket.close(1008, 'too many attempts'); return this.err(conn, 'resume_failed', null, m); }
    if (conn.player && conn.player !== p) this.drop(conn.room, conn.player, 'leave');
    if (p.conn && p.conn !== conn) { const old = p.conn; p.conn = null; old.player = null; old.room = null; old.socket.close(4000, 'replaced'); }
    clearTimeout(p.graceT); p.conn = conn; p.connected = true; conn.player = p; conn.room = room;
    if (!room.hostId || !room.byId(room.hostId) || !room.byId(room.hostId).connected) room.hostId = p.id;
    room.touchIdle();
    this.joined(conn, m, true);
    if (room.st) room.tx(p, { t: 'state', ver: room.ver, state: this.engine.viewFor(room.st, p.seat), turn: room.st.turn, phase: room.st.phase, dl: room.dl });
    room.broadcastLobby();
  },
  leave(conn, m) {
    if (need(conn)) this.drop(conn.room, conn.player, 'leave');
    this.send(conn, { t: 'ok', ref: m.rid });
  },
  ready(conn, m) {
    if (!need(conn)) return this.err(conn, 'not_in_room', null, m);
    if (conn.room.phase !== 'lobby') return this.err(conn, 'match_in_progress', null, m);
    conn.player.ready = !!m.ready; conn.room.broadcastLobby();
    this.send(conn, { t: 'ok', ref: m.rid });
  },
  settings(conn, m) {
    if (!need(conn)) return this.err(conn, 'not_in_room', null, m);
    const room = conn.room;
    if (room.hostId !== conn.player.id) return this.err(conn, 'not_host', null, m);
    if (room.phase !== 'lobby') return this.err(conn, 'match_in_progress', null, m);
    const s = cleanSettings(m.settings, this.o.maxSettingsBytes);
    if (!s) return this.err(conn, 'bad_settings', null, m);
    room.settings = Object.assign({ dealer: 'default', weaponMode: 'own' }, s); room.broadcastLobby();
    this.send(conn, { t: 'ok', ref: m.rid });
  },
  start(conn, m) {
    if (!need(conn)) return this.err(conn, 'not_in_room', null, m);
    const room = conn.room;
    room.run(() => {
      if (room.hostId !== conn.player.id) return this.err(conn, 'not_host', null, m);
      if (room.phase !== 'lobby') return this.err(conn, 'match_in_progress', null, m);
      const c = room.connected;
      if (c.length < 2) return this.err(conn, 'need_players', null, m);
      if (c.some((p) => p.id !== room.hostId && !p.ready)) return this.err(conn, 'not_ready', null, m);
      const E = this.engine;
      if (!E || typeof E.newMatch !== 'function' || typeof E.apply !== 'function') return this.err(conn, 'engine_unavailable', null, m);
      this.startMatch(room);
      this.send(conn, { t: 'ok', ref: m.rid });
    });
  },
  act(conn, m) {
    const seq = m.seq;
    if (!Number.isSafeInteger(seq)) return this.bad(conn, 'bad_seq', m);
    if (!need(conn)) return this.send(conn, { t: 'rej', seq, reason: 'not_in_room' });
    const room = conn.room, p = conn.player, rej = (reason) => this.send(conn, { t: 'rej', seq, reason });
    const a = m.action, E = this.engine;
    if (!a || typeof a !== 'object' || (a.type !== 'shoot' && a.type !== 'item')) return rej('bad_action');
    const act = { type: a.type };
    if (a.target !== undefined) { if (typeof a.target !== 'string' || a.target.length > 24) return rej('bad_target'); act.target = a.target; }
    if (a.idx !== undefined) { if (!Number.isInteger(a.idx) || a.idx < 0 || a.idx >= SLOTS_MAX) return rej('bad_action'); act.idx = a.idx; }
    room.run(() => {
      const st = room.st;
      if (room.phase !== 'match' || !st || room.over || st.phase !== 'play') return rej('no_match');
      if (p.gone || st.turn !== p.seat) return rej('not_your_turn');
      if (act.type === 'shoot' && !(typeof act.target === 'string' && st.seats.includes(act.target))) return rej('bad_target');
      let r; try { r = E.apply(st, p.seat, act); } catch (e) { this.log('apply error', e); return rej('engine_error'); }
      if (!r || !r.ok) return rej((r && r.reason) || 'illegal');
      this.publish(room, r.ev);
      if (E.openSlap) E.openSlap(st, this.now());
      this.send(conn, { t: 'ack', seq, ver: room.ver });
      this.afterChange(room);
    });
  },
  slap(conn, m) {
    if (!need(conn)) return this.err(conn, 'not_in_room', null, m);
    const room = conn.room, p = conn.player, E = this.engine;
    room.run(() => {
      const st = room.st;
      if (room.phase !== 'match' || !st || room.over || p.gone || !E || typeof E.slap !== 'function') return this.send(conn, { t: 'slapRej', reason: 'no_match' });
      let r; try { r = E.slap(st, p.seat, this.now()); } catch (e) { this.log('slap error', e); return this.send(conn, { t: 'slapRej', reason: 'engine_error' }); }
      if (!r || !r.ok) return this.send(conn, { t: 'slapRej', reason: (r && r.reason) || 'illegal' });
      this.publish(room, r.ev);
      this.afterChange(room);
    });
  },
  emote(conn, m) {
    if (!need(conn)) return this.err(conn, 'not_in_room', null, m);
    if (typeof m.id !== 'string' || !/^[a-z_]{1,24}$/.test(m.id)) return this.bad(conn, 'bad_emote', m);
    const p = conn.player, t = this.now();
    if (t - p.lastEmote < this.o.emoteMs) return; // rate limited: silently dropped
    p.lastEmote = t;
    conn.room.txAll({ t: 'emote', seat: p.seat, id: m.id });
  },
  ping(conn, m) {
    const c = typeof m.c === 'number' && isFinite(m.c) ? m.c : 0;
    this.send(conn, { t: 'pong', c, s: this.now() });
    if (need(conn) && typeof m.rtt === 'number' && m.rtt >= 0 && m.rtt < 60000) {
      const r = Math.round(m.rtt), p = conn.player;
      if (p.ping === null || Math.abs(p.ping - r) > 5) { p.ping = r; conn.room.dirty = true; }
    }
  },
  sync(conn, m) {
    if (!need(conn)) return this.err(conn, 'not_in_room', null, m);
    const room = conn.room, p = conn.player;
    if (room.st) room.tx(p, { t: 'state', ver: room.ver, state: this.engine.viewFor(room.st, p.seat), turn: room.st.turn, phase: room.st.phase, dl: room.dl });
    room.tx(p, room.lobbyMsg());
  },
};

module.exports = { Rooms, Room, sanitizeName, cleanSettings, CODE_CHARS, MAX_PLAYERS };
