Intentionally empty: all art/audio in this build is generated procedurally at runtime (see README). Drop replacement files here.
