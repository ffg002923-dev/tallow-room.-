/* content.js — the v6 content catalogue (data only): 50 items, 11 weapons, 1 dealer (the Ghost), 10 emotes, 63 achievements, challenges.
   Merges into GameData. Every entry is consumed by real systems: items by Engine (game-state.js), weapons by Engine hooks,
   dealers by Stage3D/Dialogue/Audio, achievements by Progress, prices by Economy. EN + AR texts live here too. */
(function (G) {
  'use strict';
  const D = G.GameData;
  const RAR = { common: 0, rare: 1, epic: 2, legendary: 3 };
  D.rarity = RAR;

  /* ------------------------------------------------------------------ ITEMS (13 original + 37 new = 50; 10 free, 40 locked) */
  // [id, category, free, price, rarity, uses, dealWeight, nameEN, descEN, nameAR, descAR]
  const NEW_ITEMS = [
    ['periscope', 'detect', 0, 120, 'common', 1, 5, 'Brass Periscope', 'Reveals the LAST shell in the chamber.', 'منظار نحاسي', 'يكشف آخر طلقة في الحجرة.'],
    ['stethoscope', 'detect', 0, 120, 'common', 1, 5, 'Cracked Stethoscope', 'Reveals the SECOND shell in the chamber.', 'سماعة متشققة', 'تكشف الطلقة الثانية في الحجرة.'],
    ['tally_bell', 'detect', 0, 140, 'common', 1, 4, 'Tally Bell', 'Rings once per LIVE SHELL among the next 3 shells (you learn the count).', 'جرس العدّ', 'يرنّ مرة لكل طلقة حقيقية ضمن الطلقات الثلاث التالية (تعرف العدد).'],
    ['truth_candle', 'detect', 0, 260, 'rare', 1, 3, 'Truth Candle', 'The next shell is revealed to BOTH players.', 'شمعة الحقيقة', 'تُكشف الطلقة التالية للاعبين معاً.'],
    ['ledger', 'detect', 0, 200, 'rare', 1, 3, 'Gravedigger Ledger', 'Tells you the position of the first LIVE SHELL (if any).', 'سجل حفّار القبور', 'يخبرك بموضع أول طلقة حقيقية (إن وُجدت).'],
    ['confessor_ear', 'know', 0, 180, 'rare', 1, 3, "Confessor's Ear", 'Shows what the opponent currently knows about the next shell.', 'أذن المعترف', 'تُظهر ما يعرفه الخصم حالياً عن الطلقة التالية.'],
    ['black_mirror', 'deceive', 0, 220, 'rare', 1, 3, 'Black Mirror', "The opponent's next reveal (magnifier, periscope...) shows the OPPOSITE shell.", 'المرآة السوداء', 'أول كشف يقوم به الخصم (عدسة، منظار...) يُظهر الطلقة المعاكسة.'],
    ['whisper_box', 'deceive', 0, 240, 'rare', 1, 3, 'Whisper Box', 'Plants a FALSE memory: the opponent believes the next shell is the opposite of the truth.', 'صندوق الهمس', 'يزرع ذاكرة كاذبة: يعتقد الخصم أن الطلقة التالية عكس الحقيقة.'],
    ['shadow_puppet', 'deceive', 0, 160, 'common', 1, 3, 'Shadow Puppet', 'Your items are hidden from the opponent until your turn ends.', 'دمية الظل', 'تُخفى أدواتك عن الخصم حتى ينتهي دورك.'],
    ['pocket_watch', 'tempo', 0, 420, 'epic', 1, 2, 'Stopped Pocket Watch', 'After your next shot at the opponent you take ANOTHER turn.', 'ساعة جيب متوقفة', 'بعد طلقتك التالية على الخصم تلعب دوراً آخر.'],
    ['pass_token', 'tempo', 0, 90, 'common', 1, 5, 'Pass Token', 'End your turn without shooting.', 'رمز التمرير', 'أنهِ دورك دون إطلاق النار.'],
    ['loaded_die', 'tempo', 0, 150, 'common', 1, 4, 'Bone Die', 'Roll: 1-2 lose your turn, 3-4 peek at the next shell, 5 heal 1, 6 extra turn.', 'نرد عظمي', 'ارمِ: 1-2 تخسر دورك، 3-4 تكشف الطلقة، 5 تشفي نبضاً، 6 دور إضافي.'],
    ['hook_chain', 'disable', 0, 210, 'rare', 1, 3, 'Hook & Chain', "The opponent's next shot MUST target themselves.", 'خطاف وسلسلة', 'طلقة الخصم التالية يجب أن تكون على نفسه.'],
    ['spinning_top', 'tempo', 0, 170, 'common', 1, 4, 'Spinning Top', "50%: the opponent's next shot target is flipped.", 'فرفارة', 'بنسبة 50% يُعكس هدف طلقة الخصم التالية.'],
    ['rust_lock', 'disable', 0, 190, 'rare', 1, 3, 'Rust Padlock', 'The opponent cannot use items on their next turn.', 'قفل صدئ', 'لا يستطيع الخصم استخدام الأدوات في دوره التالي.'],
    ['acid_vial', 'disable', 0, 300, 'epic', 1, 2, 'Acid Vial', "Dissolves the opponent's rarest item.", 'قارورة حمض', 'تذيب أندر أداة لدى الخصم.'],
    ['cursed_needle', 'disable', 0, 230, 'rare', 1, 3, 'Cursed Needle', 'The next BLANK SHELL the opponent fires hurts them for 1 (never fatal).', 'إبرة ملعونة', 'أول طلقة فارغة يطلقها الخصم تؤذيه بنبضة (غير قاتلة).'],
    ['hex_doll', 'disable', 0, 480, 'epic', 1, 2, 'Hex Doll', 'The opponent loses 1 pulse each time they use an item (2 times, never fatal).', 'دمية السحر', 'يخسر الخصم نبضة عند كل أداة يستخدمها (مرتان، غير قاتلة).'],
    ['wax_shield', 'defense', 0, 130, 'common', 1, 5, 'Wax Shield', 'Blocks the next hit completely.', 'درع شمعي', 'يمنع الإصابة التالية بالكامل.'],
    ['tin_plate', 'defense', 0, 150, 'common', 1, 4, 'Tin Plate', 'Reduces damage by 1 for the next 2 hits.', 'صفيحة قصدير', 'تقلل الضرر بمقدار 1 لإصابتين.'],
    ['bandage', 'defense', 0, 110, 'common', 1, 5, 'Bandage Roll', 'Heal 1 now and 1 more at the start of your next turn.', 'لفافة ضمادات', 'تشفي نبضة الآن ونبضة عند بداية دورك التالي.'],
    ['salt', 'defense', 0, 140, 'common', 1, 4, 'Smelling Salts', 'Removes every bad effect on you (cuffs, curse, lock, hex...).', 'ملح منعش', 'يزيل كل تأثير سيئ عليك (أصفاد، لعنة، قفل...).'],
    ['phoenix_ash', 'defense', 0, 750, 'legendary', 1, 1, 'Phoenix Ash', 'The next lethal hit leaves you alive with 2 pulse.', 'رماد العنقاء', 'الإصابة القاتلة التالية تُبقيك حياً بنبضتين.'],
    ['locket', 'defense', 0, 520, 'epic', 1, 2, 'Reflective Locket', 'The next hit on you is reflected: the shooter takes 1 (never fatal).', 'قلادة عاكسة', 'تنعكس الإصابة التالية عليك: يتلقى مطلق النار نبضة (غير قاتلة).'],
    ['pale_tonic', 'support', 0, 200, 'rare', 1, 3, 'Pale Tonic', '+1 maximum pulse for this round and heal 1.', 'مقوٍّ شاحب', '+1 نبض أقصى لهذه الجولة مع شفاء نبضة.'],
    ['gift_box', 'support', 0, 220, 'rare', 1, 3, 'Gift Box', 'Gain 2 random items now.', 'صندوق هدايا', 'احصل على أداتين عشوائيتين الآن.'],
    ['wax_purse', 'support', 0, 180, 'rare', 1, 3, 'Wax Purse', '+25 Wax if you win this round.', 'محفظة الشمع', '+25 شمع إن ربحت هذه الجولة.'],
    ['heavy_slug', 'strategy', 0, 240, 'rare', 1, 3, 'Heavy Slug', 'Your next LIVE SHELL deals +1 damage.', 'رصاصة ثقيلة', 'طلقتك الحقيقية التالية تضرب بزيادة 1.'],
    ['twin_barrel', 'strategy', 0, 540, 'epic', 1, 2, 'Twin Barrel', 'Your next shot fires TWO shells at once (damage adds up).', 'ماسورة مزدوجة', 'طلقتك التالية تُطلق طلقتين معاً (يتراكم الضرر).'],
    ['shell_swap', 'strategy', 0, 160, 'common', 1, 4, 'Shell Swap', 'Swaps the next shell with the last shell.', 'مبدّل الطلقات', 'يبدّل الطلقة التالية بالأخيرة.'],
    ['rotary_crank', 'strategy', 0, 130, 'common', 1, 4, 'Rotary Crank', 'Moves the next shell to the back of the chamber.', 'ذراع دوّارة', 'ينقل الطلقة التالية إلى آخر الحجرة.'],
    ['spare_round', 'strategy', 0, 110, 'common', 1, 4, 'Spare Blank', 'Inserts one extra BLANK SHELL at a random position.', 'طلقة فارغة إضافية', 'يُدخل طلقة فارغة إضافية في موضع عشوائي.'],
    ['hot_round', 'strategy', 0, 150, 'common', 1, 3, 'Hot Round', 'Inserts one extra LIVE SHELL at a random position.', 'طلقة حقيقية ساخنة', 'يُدخل طلقة حقيقية إضافية في موضع عشوائي.'],
    ['swap_hands', 'strategy', 0, 170, 'common', 1, 3, 'Swap Hands', 'Trade one random item of yours for one random item of the opponent.', 'تبادل الأيدي', 'بادل أداة عشوائية لديك بأداة عشوائية لدى الخصم.'],
    ['rewind_locket', 'rare', 0, 620, 'epic', 1, 2, 'Rewind Locket', 'The shell that was just fired is put back as the next shell.', 'قلادة الإرجاع', 'تُعاد الطلقة التي أُطلقت للتو لتصبح الطلقة التالية.'],
    ['ouija', 'rare', 0, 680, 'epic', 1, 2, 'Ouija Planchette', 'Reveals the ENTIRE chamber order to you, at the cost of 1 pulse (not usable at 1 pulse).', 'مؤشر الأرواح', 'يكشف ترتيب الحجرة كاملاً مقابل نبضة (لا يعمل عند نبضة واحدة).'],
    ['scales', 'rare', 0, 800, 'legendary', 1, 1, 'Scales of Judgment', 'Both pulses become equal to the average (rounded up for you).', 'ميزان الحكم', 'يصبح نبض الطرفين متساوياً عند المتوسط (يُقرَّب لصالحك).']
  ];
  // the 13 original items keep their existing engine code; they only gain a category / price / rarity / free flag
  const OLD = { magnifier: ['detect', 1, 0, 'common'], handcuffs: ['disable', 1, 0, 'common'], cigarette: ['support', 1, 0, 'common'], battery: ['strategy', 1, 0, 'common'], medicine: ['support', 1, 0, 'common'], can: ['detect', 1, 0, 'common'], lighter: ['disable', 1, 0, 'common'], scrambler: ['deceive', 1, 0, 'common'], coin: ['rare', 1, 0, 'rare'], knife: ['strategy', 1, 0, 'common'], blank: ['strategy', 0, 150, 'common'], spray: ['know', 0, 170, 'rare'], rope: ['disable', 0, 190, 'rare'] };
  D.itemCats = ['detect', 'tempo', 'disable', 'defense', 'support', 'strategy', 'deceive', 'know', 'rare'];
  for (const id of Object.keys(OLD)) { const o = OLD[id], it = D.items[id]; it.cat = o[0]; it.free = !!o[1]; it.price = o[2]; it.rarity = o[3]; }
  const sEn = D.strings.en, sAr = D.strings.ar;
  for (const r of NEW_ITEMS) {
    D.items[r[0]] = { w: r[6], uses: r[5], sfx: 'fx_' + r[0], cat: r[1], free: !!r[2], price: r[3], rarity: r[4] };
    sEn['item.' + r[0]] = r[7]; sEn['item.' + r[0] + '.d'] = r[8]; sAr['item.' + r[0]] = r[9]; sAr['item.' + r[0] + '.d'] = r[10];
  }
  D.itemOrder = Object.keys(D.items);
  D.itemWeights = function (pool) { const ids = pool || D.itemOrder; return ids.map((id) => [id, D.items[id].w]); };
  D.freeItems = () => D.itemOrder.filter((id) => D.items[id].free);

  /* ------------------------------------------------------------------ WEAPONS (base Caster + 10) — hooks read by Engine */
  // hooks: dmg (live damage), liveBias (+live shells per reload), extraItems, peekStart, shieldStart, chargeStart, lifesteal (heal 1 on first hit per round), crit (every Nth live hit +1), pierce, stunBlank (chance a blank at the opponent cuffs them), selfBlankHeal
  D.weapons = {
    caster: { free: true, price: 0, rarity: 'common', hooks: {}, stats: { power: 3, control: 3, risk: 3, utility: 3 }, build: { len: 3.81, barrel: 'long', stock: 'wood' } },
    pump: { free: false, price: 300, rarity: 'common', hooks: { extraItems: 1 }, stats: { power: 3, control: 3, risk: 2, utility: 5 }, build: { len: 3.6, barrel: 'long', stock: 'wood', pump: 1 } },
    widow: { free: false, price: 650, rarity: 'epic', hooks: { dmg: 2, liveBias: 1 }, stats: { power: 5, control: 2, risk: 5, utility: 1 }, build: { len: 2.6, barrel: 'twin', stock: 'cut' } },
    penny: { free: false, price: 450, rarity: 'rare', hooks: { peekStart: 1 }, stats: { power: 2, control: 4, risk: 2, utility: 4 }, build: { len: 2.4, barrel: 'revolver', stock: 'grip' } },
    mortician: { free: false, price: 800, rarity: 'epic', hooks: { crit: 3 }, stats: { power: 4, control: 4, risk: 3, utility: 2 }, build: { len: 2.7, barrel: 'cannon', stock: 'grip' } },
    flare: { free: false, price: 400, rarity: 'rare', hooks: { stunBlank: 0.4 }, stats: { power: 2, control: 3, risk: 2, utility: 4 }, build: { len: 2.2, barrel: 'flare', stock: 'grip' } },
    breaker: { free: false, price: 900, rarity: 'epic', hooks: { pierce: 1 }, stats: { power: 4, control: 3, risk: 3, utility: 3 }, build: { len: 3.9, barrel: 'lever', stock: 'wood' } },
    candle: { free: false, price: 520, rarity: 'rare', hooks: { shieldStart: 1 }, stats: { power: 2, control: 4, risk: 1, utility: 4 }, build: { len: 3.7, barrel: 'musket', stock: 'wood' } },
    leech: { free: false, price: 700, rarity: 'epic', hooks: { lifesteal: 1 }, stats: { power: 3, control: 3, risk: 3, utility: 4 }, build: { len: 3.0, barrel: 'bell', stock: 'rust' } },
    fang: { free: false, price: 1000, rarity: 'legendary', hooks: { chargeStart: 1 }, stats: { power: 5, control: 3, risk: 4, utility: 2 }, build: { len: 3.3, barrel: 'coil', stock: 'metal' } },
    vesper: { free: false, price: 1200, rarity: 'legendary', hooks: { selfBlankHeal: 1 }, stats: { power: 3, control: 5, risk: 2, utility: 4 }, build: { len: 4.0, barrel: 'bone', stock: 'bone' } }
  };
  D.weaponOrder = Object.keys(D.weapons);
  const W = [
    ['caster', 'The Caster', 'The original. Balanced and honest.', 'القاذف', 'السلاح الأصلي. متوازن وصادق.'],
    ['pump', 'Gravedigger Pump', 'Racks a fresh item onto the table every reload (+1 item).', 'مضخة حفّار القبور', 'تضيف أداة جديدة إلى الطاولة عند كل تلقيم (+1 أداة).'],
    ['widow', 'Sawn-off Widow', 'Live shells deal 2 damage to ANYONE (yourself too). The chamber carries more live shells.', 'الأرملة المقطوعة', 'الطلقة الحقيقية تضرب بـ2 على أي شخص (حتى أنت). الحجرة تحمل طلقات حقيقية أكثر.'],
    ['penny', 'Penny Dreadful', 'You see the first shell after every reload.', 'المسدس الرخيص', 'ترى الطلقة الأولى بعد كل تلقيم.'],
    ['mortician', "Mortician's Cannon", 'Every 3rd live hit you land deals +1 damage.', 'مدفع متعهد الدفن', 'كل إصابة حقيقية ثالثة تضرب بزيادة 1.'],
    ['flare', 'Signal Flare', 'A blank fired at the opponent has a 40% chance to cuff them.', 'مسدس الإشارة', 'الطلقة الفارغة على الخصم تقيّده بنسبة 40%.'],
    ['breaker', 'Widow Breaker', 'Pierces Wax Shield and Tin Plate.', 'كاسر الأرامل', 'يخترق الدرع الشمعي وصفيحة القصدير.'],
    ['candle', 'Candle Bearer', 'You start every round behind a Wax Shield.', 'حامل الشمعة', 'تبدأ كل جولة خلف درع شمعي.'],
    ['leech', 'Rusted Leech', 'Heal 1 the first time you wound the opponent each round.', 'العلقة الصدئة', 'تشفي نبضة أول مرة تصيب فيها الخصم في كل جولة.'],
    ['fang', 'Static Fang', 'You start every round with the next live shell charged (double damage).', 'ناب الكهرباء', 'تبدأ كل جولة وطلقتك الحقيقية التالية مشحونة (ضعف الضرر).'],
    ['vesper', 'Bone Vesper', 'Shooting yourself with a blank heals 1 (once per round) and keeps your turn.', 'عظمة الغسق', 'إطلاق طلقة فارغة على نفسك يشفي نبضة (مرة كل جولة) ويُبقي دورك.']
  ];
  for (const r of W) { sEn['weapon.' + r[0]] = r[1]; sEn['weapon.' + r[0] + '.d'] = r[2]; sAr['weapon.' + r[0]] = r[3]; sAr['weapon.' + r[0] + '.d'] = r[4]; }

  /* ------------------------------------------------------------------ DEALERS (18). head/outfit = 3D builders in dealer-models.js; voice = formant synth params; style = speech mannerism (dialogue.js) */
  const Dl = [
    // id, free, price, rarity, head, outfit, voice{pitch,rate,rough,breath}, style, demeanor{aggr,humor,patience}, EN name, EN title, AR name, AR title
    ['ghost', 1, 0, 'common', 'ghost', 'shroud', { pitch: 0.82, rate: 0.9, rough: 0.35, breath: 0.7 }, 'whisper', [0.5, 0.3, 0.7], 'The Ghost', 'The only host', 'الشبح', 'المضيف الوحيد'],
  ];
  D.dealers = {}; D.dealerOrder = [];
  for (const r of Dl) {
    D.dealers[r[0]] = { id: r[0], free: !!r[1], price: r[2], rarity: r[3], head: r[4], outfit: r[5], voice: r[6], style: r[7], demeanor: { aggr: r[8][0], humor: r[8][1], patience: r[8][2] } };
    D.dealerOrder.push(r[0]);
    sEn['dealer.' + r[0]] = r[9]; sEn['dealer.' + r[0] + '.t'] = r[10]; sAr['dealer.' + r[0]] = r[11]; sAr['dealer.' + r[0] + '.t'] = r[12];
  }

  /* ------------------------------------------------------------------ EMOTES (10) */
  D.emotes = ['ok', 'clap', 'welcome', 'thumbs_up', 'thumbs_down', 'refuse', 'challenge', 'wave', 'wonder', 'victory'];
  const EM = [['OK', 'تمام'], ['Applause', 'تصفيق'], ['Welcome', 'ترحيب'], ['Thumbs up', 'إبهام للأعلى'], ['Thumbs down', 'إبهام للأسفل'], ['No way', 'رفض'], ['Challenge', 'تحدٍّ'], ['Goodbye', 'وداع'], ['Surprise', 'استغراب'], ['Victory dance', 'احتفال بالفوز']];
  D.emotes.forEach((id, i) => { sEn['emote.' + id] = EM[i][0]; sAr['emote.' + id] = EM[i][1]; });

  /* ------------------------------------------------------------------ ACHIEVEMENTS: 40 new on top of the 28 in ui-data.js => 68 */
  // [id, category, tier, stat, goal, coins, icon, EN name, EN desc, AR name, AR desc]
  const A = [
    ['tenth_door', 'win', 'c', 'wins', 10, 80, 'door', 'Tenth Door', 'Win 10 games.', 'الباب العاشر', 'اربح 10 ألعاب.'],
    ['twenty_five', 'win', 'a', 'wins', 25, 150, 'star', 'Quarter Century', 'Win 25 games.', 'ربع قرن', 'اربح 25 لعبة.'],
    ['round_collector', 'win', 'c', 'rounds', 25, 60, 'candle', 'Round Collector', 'Win 25 rounds.', 'جامع الجولات', 'اربح 25 جولة.'],
    ['round_hundred', 'win', 'a', 'rounds', 100, 160, 'candle', 'A Hundred Candles', 'Win 100 rounds.', 'مئة شمعة', 'اربح 100 جولة.'],
    ['seasoned', 'win', 'b', 'games', 10, 25, 'grid', 'Seasoned', 'Start 10 games.', 'متمرّس', 'ابدأ 10 ألعاب.'],
    ['trigger_100', 'shoot', 'c', 'shots', 100, 60, 'target', 'Hundred Pulls', 'Fire 100 shots.', 'مئة سحبة', 'أطلق 100 طلقة.'],
    ['dealer_50', 'shoot', 'a', 'hits', 50, 120, 'target', 'Fifty Wounds', 'Hit the Dealer with 50 LIVE SHELLS.', 'خمسون جرحاً', 'أصب الموزّع بـ50 طلقة حقيقية.'],
    ['dealer_200', 'shoot', 'l', 'hits', 200, 280, 'target', 'Two Hundred Wounds', 'Hit the Dealer with 200 LIVE SHELLS.', 'مئتا جرح', 'أصب الموزّع بـ200 طلقة حقيقية.'],
    ['dmg_500', 'shoot', 'l', 'dmgDealt', 500, 300, 'fist', 'Pound of Flesh', 'Deal 500 damage in total.', 'رطل من اللحم', 'ألحق 500 ضرر إجمالاً.'],
    ['finisher', 'shoot', 'c', 'finishers', 10, 70, 'skull', 'Finisher', 'Deliver the final blow of a round 10 times.', 'الضربة القاضية', 'وجّه الضربة الأخيرة في الجولة 10 مرات.'],
    ['live_streak3', 'shoot', 'a', 'liveStreak', 3, 110, 'bolt', 'Three in a Row', 'Land 3 LIVE SHELLS on the Dealer in a row.', 'ثلاث متتالية', 'أصب الموزّع بـ3 طلقات حقيقية متتالية.'],
    ['blank_first', 'blank', 'b', 'ashSelf', 1, 10, 'cloud', 'Click', 'Shoot yourself with a BLANK SHELL.', 'نقرة', 'أطلق طلقة فارغة على نفسك.'],
    ['blank_25', 'blank', 'c', 'ashSelf', 25, 60, 'cloud', 'Dry Hands', 'Survive 25 BLANK SHELLS fired at yourself.', 'أيدٍ جافة', 'انجُ من 25 طلقة فارغة على نفسك.'],
    ['blank_100', 'blank', 'a', 'ashSelf', 100, 150, 'cloud', 'Ash Collector', 'Survive 100 BLANK SHELLS fired at yourself.', 'جامع الرماد', 'انجُ من 100 طلقة فارغة على نفسك.'],
    ['blank_dealer', 'blank', 'c', 'blankDealer', 25, 50, 'hand', 'Mercy Shots', 'Fire 25 BLANK SHELLS at the Dealer.', 'طلقات الرحمة', 'أطلق 25 طلقة فارغة على الموزّع.'],
    ['blank_pro', 'blank', 'l', 'ash3', 25, 260, 'cloud', 'Walks in Ash', 'Complete 25 chains of 3 BLANK SHELLS.', 'سائر الرماد الأكبر', 'أكمل 25 سلسلة من 3 طلقات فارغة.'],
    ['live_self', 'live', 'b', 'liveSelf', 1, 10, 'heart', 'Ouch', 'Shoot yourself with a LIVE SHELL.', 'آخ', 'أطلق طلقة حقيقية على نفسك.'],
    ['live_self_10', 'live', 'c', 'liveSelf', 10, 50, 'heart', 'Slow Learner', 'Shoot yourself with LIVE SHELLS 10 times.', 'بطيء التعلّم', 'أطلق طلقة حقيقية على نفسك 10 مرات.'],
    ['live_taken', 'live', 'c', 'dmgTaken', 50, 60, 'heart', 'Scarred', 'Take 50 damage in total.', 'مُندَّب', 'تلقَّ 50 ضرراً إجمالاً.'],
    ['live_double', 'live', 'a', 'charged', 25, 120, 'bolt', 'Double Trouble', 'Land 25 charged LIVE SHELLS.', 'مشكلة مضاعفة', 'سدّد 25 طلقة حقيقية مشحونة.'],
    ['items_250', 'item', 'a', 'itemsUsed', 250, 130, 'gear', 'Toolbox', 'Use 250 items.', 'صندوق العدّة', 'استخدم 250 أداة.'],
    ['items_1000', 'item', 'l', 'itemsUsed', 1000, 320, 'gear', 'Arsenal of Odds', 'Use 1000 items.', 'ترسانة الاحتمالات', 'استخدم 1000 أداة.'],
    ['distinct_10', 'item', 'c', 'itemDistinct', 10, 60, 'grid', 'Ten Tools', 'Use 10 different items.', 'عشر أدوات', 'استخدم 10 أدوات مختلفة.'],
    ['distinct_25', 'item', 'a', 'itemDistinct', 25, 150, 'grid', 'Twenty-five Tools', 'Use 25 different items.', 'خمس وعشرون أداة', 'استخدم 25 أداة مختلفة.'],
    ['distinct_50', 'item', 'l', 'itemDistinct', 50, 400, 'grid', 'Master of Fifty', 'Use all 50 items.', 'سيد الخمسين', 'استخدم الأدوات الخمسين كلها.'],
    ['owner_20', 'item', 'c', 'itemsOwned', 20, 60, 'bag', 'Collector', 'Own 20 items.', 'جامع', 'امتلك 20 أداة.'],
    ['owner_50', 'item', 'l', 'itemsOwned', 50, 350, 'bag', 'Complete Cabinet', 'Own all 50 items.', 'الخزانة الكاملة', 'امتلك الأدوات الخمسين.'],
    ['spotless_3', 'flawless', 'a', 'perfect', 3, 150, 'shield', 'Spotless Trio', 'Win 3 games without losing pulse.', 'ثلاثية نظيفة', 'اربح 3 ألعاب دون أن تفقد نبضاً.'],
    ['thread_5', 'flawless', 'a', 'thread', 5, 100, 'thread', 'Hanging by a Thread', 'Win 5 rounds with 1 pulse left.', 'معلّق بخيط', 'اربح 5 جولات ونبضك واحد.'],
    ['bare_10', 'flawless', 'a', 'bare', 10, 110, 'hand', 'Empty Pockets', 'Win 10 rounds without items.', 'جيوب فارغة', 'اربح 10 جولات دون أدوات.'],
    ['friends_first', 'friends', 'b', 'mpGames', 1, 30, 'star', 'Company', 'Finish a match with friends.', 'رفقة', 'أنهِ مباراة مع الأصدقاء.'],
    ['friends_win', 'friends', 'c', 'mpWins', 1, 60, 'crown', 'Last One Standing', 'Win a match with friends.', 'الأخير واقفاً', 'اربح مباراة مع الأصدقاء.'],
    ['friends_10', 'friends', 'a', 'mpGames', 10, 120, 'star', 'Regular Guest', 'Finish 10 matches with friends.', 'ضيف دائم', 'أنهِ 10 مباريات مع الأصدقاء.'],
    ['friends_wins_10', 'friends', 'l', 'mpWins', 10, 300, 'crown', 'Table Master', 'Win 10 matches with friends.', 'سيد الطاولة', 'اربح 10 مباريات مع الأصدقاء.'],
    ['friends_four', 'friends', 'c', 'mp4', 1, 80, 'grid', 'Full Table', 'Finish a match with 4 players.', 'طاولة ممتلئة', 'أنهِ مباراة بأربعة لاعبين.'],
    ['weapons_1', 'weapon', 'b', 'weaponsOwned', 1, 40, 'target', 'Second Opinion', 'Buy your first new weapon.', 'رأي ثانٍ', 'اشترِ أول سلاح جديد.'],
    ['weapons_5', 'weapon', 'a', 'weaponsOwned', 5, 150, 'target', 'Gun Rack', 'Buy 5 new weapons.', 'رف الأسلحة', 'اشترِ 5 أسلحة جديدة.'],
    ['weapons_10', 'weapon', 'l', 'weaponsOwned', 10, 450, 'target', 'Full Armoury', 'Buy all 10 new weapons.', 'مخزن السلاح الكامل', 'اشترِ الأسلحة العشرة الجديدة.'],
    ['weapons_win5', 'weapon', 'a', 'weaponsWon', 5, 140, 'crown', 'Versatile', 'Win with 5 different weapons.', 'متعدد المهارات', 'اربح بخمسة أسلحة مختلفة.'],
    ['daily_1', 'challenge', 'b', 'challenges', 1, 25, 'star', 'First Challenge', 'Complete a challenge.', 'أول تحدٍّ', 'أكمل تحدياً.'],
    ['daily_10', 'challenge', 'c', 'challenges', 10, 70, 'star', 'Daily Habit', 'Complete 10 challenges.', 'عادة يومية', 'أكمل 10 تحديات.'],
    ['daily_50', 'challenge', 'l', 'challenges', 50, 300, 'star', 'Challenger', 'Complete 50 challenges.', 'المتحدّي', 'أكمل 50 تحدياً.'],
    ['emote_all', 'secret', 'c', 'emoteDistinct', 10, 60, 'hand', 'Expressive', 'Use all 10 hand gestures.', 'معبّر', 'استخدم الحركات العشر.'],
    ['emote_50', 'secret', 'a', 'emotes', 50, 90, 'hand', 'Showman', 'Use hand gestures 50 times.', 'استعراضي', 'استخدم الحركات 50 مرة.'],
    ['secret_phoenix', 'secret', 'l', 'phoenixSaves', 1, 200, 'crown', 'From the Ashes', 'Survive a lethal hit thanks to Phoenix Ash.', 'من بين الرماد', 'انجُ من إصابة قاتلة بفضل رماد العنقاء.'],
    ['secret_reflect', 'secret', 'a', 'reflects', 1, 120, 'shield', 'Not Today', 'Reflect a hit with the Reflective Locket.', 'ليس اليوم', 'اعكس إصابة بالقلادة العاكسة.'],
    ['secret_nofire', 'secret', 'l', 'passWins', 1, 220, 'skull', 'Patience', 'Win a round after using a Pass Token.', 'صبر', 'اربح جولة بعد استخدام رمز التمرير.'],
    ['pro_nm_perfect', 'pro', 'l', 'nmPerfect', 1, 500, 'skull', 'Nightmare, Untouched', 'Win on Nightmare without losing pulse.', 'كابوس بلا خدش', 'اربح في الكابوس دون أن تفقد نبضاً.'],
    ['pro_speed', 'pro', 'a', 'speedWins', 1, 150, 'clock', 'Quick Draw', 'Win a full game in under 5 minutes.', 'سحب سريع', 'اربح لعبة كاملة في أقل من 5 دقائق.'],
    ['pro_comeback', 'pro', 'a', 'comebacks', 3, 160, 'thread', 'Comeback', 'Win 3 rounds after being down to 1 pulse against 3+.', 'عودة', 'اربح 3 جولات بعد أن نزل نبضك إلى 1 والخصم 3 أو أكثر.'],
    ['pro_hard5', 'pro', 'a', 'hardWins', 5, 180, 'crown', 'Hard Mode Regular', 'Win 5 games on Hard or Nightmare.', 'معتاد الصعب', 'اربح 5 ألعاب في الصعب أو الكابوس.']
  ];
  D.achCats = ['win', 'shoot', 'blank', 'live', 'item', 'flawless', 'friends', 'dealer', 'weapon', 'challenge', 'secret', 'pro'];
  for (const r of A) {
    D.achDefs.push({ id: r[0], cat: r[1], tier: r[2], stat: r[3], goal: r[4], coins: r[5], icon: r[6] });
    sEn['ach.' + r[0]] = r[7]; sEn['ach.' + r[0] + '.d'] = r[8]; sAr['ach.' + r[0]] = r[9]; sAr['ach.' + r[0] + '.d'] = r[10];
  }
  const OLDCAT = { first_light: 'win', spark: 'shoot', curious: 'item', first_buy: 'challenge', nerves: 'live', warming_up: 'shoot', out_of_room: 'win', bare_hands: 'flawless', thread: 'flawless', pack_rat: 'item', cold_aim: 'shoot', regular: 'win', tinkerer: 'item', ash_walker: 'blank', untouched: 'flawless', veteran: 'win', ghost_walker: 'blank', heavy_hand: 'shoot', overcharged: 'live', unbroken: 'blank', dark_hour: 'challenge', hoarder: 'challenge', nightmare: 'pro', phantom: 'flawless', keeper: 'win', nightmare_master: 'pro', five_hundred: 'shoot', wax_saint: 'secret' };
  for (const a of D.achDefs) if (!a.cat) a.cat = OLDCAT[a.id] || 'win';
  const wax = D.achDefs.find((a) => a.id === 'wax_saint'); if (wax) wax.goal = D.achDefs.length - 1;
  const pack = D.achDefs.find((a) => a.id === 'pack_rat'); if (pack) pack.goal = 13;
  D.achievements = D.achDefs.map((a) => a.id);
  D.rarityOfTier = { b: 'common', c: 'rare', a: 'epic', l: 'legendary' };

  /* ------------------------------------------------------------------ CHALLENGES (daily: 3 picked from the pool by date; special: permanent goals) */
  D.challengePool = [
    { id: 'c_rounds2', stat: 'rounds', goal: 2, coins: 30 }, { id: 'c_shots15', stat: 'shots', goal: 15, coins: 25 }, { id: 'c_items6', stat: 'itemsUsed', goal: 6, coins: 25 },
    { id: 'c_hits5', stat: 'hits', goal: 5, coins: 30 }, { id: 'c_blank4', stat: 'ashSelf', goal: 4, coins: 30 }, { id: 'c_game1', stat: 'wins', goal: 1, coins: 50 },
    { id: 'c_detect4', stat: 'cat:detect', goal: 4, coins: 30 }, { id: 'c_defense3', stat: 'cat:defense', goal: 3, coins: 30 }, { id: 'c_cuffs2', stat: 'cuffs', goal: 2, coins: 25 },
    { id: 'c_dmg8', stat: 'dmgDealt', goal: 8, coins: 30 }, { id: 'c_self3', stat: 'selfShots', goal: 3, coins: 20 }, { id: 'c_emote3', stat: 'emotes', goal: 3, coins: 15 }
  ];
  D.specialChallenges = [
    { id: 's_ten_wins', stat: 'wins', goal: 10, coins: 200 }, { id: 's_big_spender', stat: 'bought', goal: 10, coins: 150 }, { id: 's_nm', stat: 'nightmareWins', goal: 3, coins: 300 },
    { id: 's_marksman', stat: 'hits', goal: 100, coins: 220 }, { id: 's_everything', stat: 'itemDistinct', goal: 30, coins: 250 }, { id: 's_social', stat: 'mpGames', goal: 5, coins: 180 }
  ];
  const CT = { c_rounds2: ['Win 2 rounds', 'اربح جولتين'], c_shots15: ['Fire 15 shots', 'أطلق 15 طلقة'], c_items6: ['Use 6 items', 'استخدم 6 أدوات'], c_hits5: ['Hit the Dealer 5 times', 'أصب الموزّع 5 مرات'], c_blank4: ['Survive 4 self-shot BLANK SHELLS', 'انجُ من 4 طلقات فارغة على نفسك'], c_game1: ['Win a full game', 'اربح لعبة كاملة'], c_detect4: ['Use 4 detection items', 'استخدم 4 أدوات كشف'], c_defense3: ['Use 3 defensive items', 'استخدم 3 أدوات دفاعية'], c_cuffs2: ['Cuff the opponent twice', 'قيّد الخصم مرتين'], c_dmg8: ['Deal 8 damage', 'ألحق 8 ضرر'], c_self3: ['Shoot yourself 3 times', 'أطلق على نفسك 3 مرات'], c_emote3: ['Use 3 hand gestures', 'استخدم 3 حركات يد'], s_ten_wins: ['Win 10 games', 'اربح 10 ألعاب'], s_big_spender: ['Buy 10 things', 'اشترِ 10 عناصر'], s_nm: ['Win 3 Nightmare games', 'اربح 3 ألعاب كابوس'], s_marksman: ['Hit the Dealer 100 times', 'أصب الموزّع 100 مرة'], s_everything: ['Use 30 different items', 'استخدم 30 أداة مختلفة'], s_social: ['Finish 5 matches with friends', 'أنهِ 5 مباريات مع الأصدقاء'] };
  for (const k of Object.keys(CT)) { sEn['chal.' + k] = CT[k][0]; sAr['chal.' + k] = CT[k][1]; }

  /* ------------------------------------------------------------------ terminology: LIVE SHELL / BLANK SHELL everywhere */
  Object.assign(sEn, { 'hud.embers': 'LIVE SHELLS', 'hud.ash': 'BLANK SHELLS', 'hud.liveShort': 'LIVE', 'hud.blankShort': 'BLANK', 'hud.peekEmber': 'Next shell: LIVE SHELL', 'hud.peekAsh': 'Next shell: BLANK SHELL', 'toast.ember': 'LIVE SHELL', 'toast.ash': 'BLANK SHELL', 'banner.load': '{e} LIVE SHELLS · {a} BLANK SHELLS', 'status.charged': 'CASTER CHARGED', 'shell.live': 'LIVE SHELL', 'shell.blank': 'BLANK SHELL', 'hud.shellsLine': 'LIVE SHELLS: {e}   BLANK SHELLS: {a}' });
  Object.assign(sAr, { 'hud.embers': 'LIVE SHELLS', 'hud.ash': 'BLANK SHELLS', 'hud.liveShort': 'LIVE', 'hud.blankShort': 'BLANK', 'hud.peekEmber': 'الطلقة التالية: LIVE SHELL', 'hud.peekAsh': 'الطلقة التالية: BLANK SHELL', 'toast.ember': 'LIVE SHELL', 'toast.ash': 'BLANK SHELL', 'banner.load': '{e} LIVE SHELLS · {a} BLANK SHELLS', 'status.charged': 'القاذف مشحون', 'shell.live': 'LIVE SHELL', 'shell.blank': 'BLANK SHELL', 'hud.shellsLine': 'LIVE SHELLS: {e}   BLANK SHELLS: {a}' });
  for (const lang of [sEn, sAr]) for (const k of Object.keys(lang)) {
    if (typeof lang[k] !== 'string') continue;
    if (lang === sEn && k.startsWith('tut.')) lang[k] = lang[k].replace(/EMBERS/g, 'LIVE SHELLS').replace(/ASH/g, 'BLANK SHELLS').replace(/Embers/g, 'LIVE SHELLS').replace(/ash/g, 'a BLANK SHELL').replace(/embers?/g, 'LIVE SHELLS');
  }
  sEn['tut.1'] = 'The Caster is loaded with LIVE SHELLS and BLANK SHELLS in secret. A LIVE SHELL hurts. A BLANK SHELL does nothing. Only the counts are shown.';
  sEn['tut.2'] = 'On your turn aim at the Dealer or at yourself. Shooting yourself with a BLANK SHELL lets you go again. A LIVE SHELL hurts.';
  sAr['tut.1'] = 'القاذف محمّل سراً بـ LIVE SHELLS و BLANK SHELLS. الطلقة الحقيقية (LIVE) تؤذي، والفارغة (BLANK) لا تفعل شيئاً. يُعرض العدد فقط.';
  sAr['tut.2'] = 'في دورك صوّب نحو الموزّع أو نحو نفسك. إن أطلقت BLANK SHELL على نفسك تلعب مرة أخرى، وإن أطلقت LIVE SHELL فستتأذى.';
  /* sweep the old wording (ember/ash) out of gameplay texts and dealer lines */
  const enFix = (s) => s.replace(/\bEMBERS\b/g, 'LIVE SHELLS').replace(/\bASH\b/g, 'BLANK SHELLS').replace(/\bembers\b/g, 'live shells').replace(/\bember\b/g, 'live shell').replace(/\bEmbers\b/g, 'Live shells').replace(/\bEmber\b/g, 'Live shell').replace(/\bash\b/g, 'blank').replace(/\bAsh\b(?! Collector| Walker)/g, (m, off, str) => (/Phoenix $/.test(str.slice(0, off)) ? m : 'Blank'));
  const arFix = (s) => s.replace(/جمرات/g, 'LIVE SHELLS').replace(/جمرة/g, 'LIVE SHELL').replace(/رماداً/g, 'BLANK SHELL').replace(/رماد/g, 'BLANK SHELL');
  const gameplayKey = (k) => /^ach\..*\.d$/.test(k) || /^(tut\.|hud\.|toast\.|banner\.|end\.|diff\.|status\.)/.test(k) || (/^item\./.test(k) && /\.d$/.test(k));
  for (const k of Object.keys(sEn)) if (gameplayKey(k) && typeof sEn[k] === 'string') sEn[k] = enFix(sEn[k]);
  for (const k of Object.keys(sAr)) if (gameplayKey(k) && typeof sAr[k] === 'string' && !/^item\.(phoenix_ash)/.test(k)) sAr[k] = arFix(sAr[k]);
  for (const lg of ['en', 'ar']) for (const c of Object.keys(D.lines[lg])) D.lines[lg][c] = D.lines[lg][c].map((l) => (lg === 'en' ? enFix(l) : arFix(l)));
  sEn['hud.embers'] = 'LIVE SHELLS'; sEn['hud.ash'] = 'BLANK SHELLS'; sAr['hud.embers'] = 'LIVE SHELLS'; sAr['hud.ash'] = 'BLANK SHELLS';
  D.contentVersion = 6;
  if (typeof module !== 'undefined' && module.exports) module.exports = D;
})(typeof window !== 'undefined' ? window : globalThis);
