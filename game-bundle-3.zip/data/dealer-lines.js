/* dealer-lines.js — extra Dealer dialogue (v7.6). Adds varied lines to GameData.lines; every category keeps the SAME number of lines in EN and AR
   (U.line picks one index for both languages). Show.say() never repeats the previous line of a category. */
(function (G) {
  'use strict';
  const D = G.GameData; if (!D || !D.lines) return;
  const add = {
    round1: [['Welcome back to the table!', 'ها قد عدتم إلى الطاولة!'], ['Let us see who lasts this time.', 'لنرَ من سيصمد هذه المرة.'], ['Nobody leaves without paying.', 'لا أحد يغادر دون أن يدفع الثمن.'], ['Get ready... tonight is no ordinary night.', 'استعدوا... فالليلة لن تكون عادية.']],
    round2: [['Still breathing? How rude of you.', 'ما زلت تتنفس؟ يا لوقاحتك.'], ['The candles burn lower. So do you.', 'الشموع تذوب... وأنت كذلك.'], ['Round two. Do try to keep up.', 'الجولة الثانية. حاول أن تجاريني.'], ['I was only warming up.', 'كنت أسخّن فقط.']],
    round3: [['The last round. I can taste it.', 'الجولة الأخيرة. أستطيع تذوّقها.'], ['Everything ends at this table.', 'كل شيء ينتهي عند هذه الطاولة.'], ['Say your prayers, if you know any.', 'ادعُ... إن كنت تعرف دعاءً.'], ['Close now. So very close.', 'قريب الآن... قريب جداً.']],
    playerSelfAsh: [['Hahaha! I knew you would survive.', 'هاهاها! كنت أعلم أنك ستنجو.'], ['Your luck is better than I expected.', 'حظك أفضل مما توقعت.'], ['Enjoy your victory... if you can.', 'استمتع بانتصارك... إن استطعت.']],
    dealerAsh: [['Hahaha! I knew you would survive.', 'هاهاها! كنت أعلم أنك ستنجو.'], ['Your luck is better than I expected.', 'حظك أفضل مما توقعت.'], ['Enjoy your victory... if you can.', 'استمتع بانتصارك... إن استطعت.']],
    lose: [['What have you done?!', 'ماذا فعلت؟!'], ['My patience is gone!', 'لقد نفد صبري!'], ['You test my limits!', 'أنتم تختبرون حدودي!'], ['This is not the end!', 'هذه ليست النهاية!']],
    idle: [['Have you lost your nerve?', 'هل فقدت شجاعتك؟'], ['Do not keep me waiting.', 'لا تجعلني أنتظر طويلاً.'], ['I hear your breathing... you are afraid.', 'أسمع أنفاسك... أنت خائف.']]
  };
  for (const cat of Object.keys(add)) for (const [en, ar] of add[cat]) { (D.lines.en[cat] = D.lines.en[cat] || []).push(en); (D.lines.ar[cat] = D.lines.ar[cat] || []).push(ar); }
})(typeof window !== 'undefined' ? window : globalThis);
