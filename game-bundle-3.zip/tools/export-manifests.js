/* Exports the JSON manifests from the JS data tables and validates them. Run: node tools/export-manifests.js */
const fs = require('fs'), path = require('path'), vm = require('vm');
const root = path.join(__dirname, '..');
const ctx = { console }; ctx.window = ctx; ctx.globalThis = ctx; vm.createContext(ctx);
for (const f of ['scripts/util.js', 'data/game-data.js', 'data/animations.js', 'scripts/audio-manager.js']) vm.runInContext(fs.readFileSync(path.join(root, f), 'utf8'), ctx, { filename: f });
const D = ctx.GameData, A = ctx.AnimData, Au = ctx.AudioMgr;
const rep = A.validate(); const missing = A.allSfxRefs().filter((n) => !Au.SFX[n]);
if (rep.errors.length || missing.length) { console.error('INVALID', rep.errors, missing); process.exit(1); }
const w = (n, o) => fs.writeFileSync(path.join(root, 'data', n), JSON.stringify(o, null, 2));
w('items.json', { order: D.itemOrder, items: D.items });
w('game-config.json', { config: D.config, difficulties: D.difficulties, achievements: D.achievements, endings: D.endings });
w('animations.json', A.exportManifest());
w('audio-manifest.json', { sfx: Object.keys(Au.SFX).sort(), referencedByAnimations: A.allSfxRefs().sort(), note: 'All sounds are synthesized at runtime with Web Audio; no audio files are shipped.' });
console.log('manifests written; clips:', Object.keys(A.clips).length, 'sfx:', Object.keys(Au.SFX).length);
