#!/usr/bin/env node
/* build-models.js — converts the three supplied GLB files into data/models.js (base64, so the game still runs from file://).
   usage: node tools/build-models.js <dir-with-glbs>
   - reads every mesh node (POSITION, COLOR_0, indices) with its node transform
   - converts the Z-up trimesh data to the engine's Y-up space
   - un-welds + re-welds the geometry with crease-angle smooth normals (the files carry no normals)
   - the character file has NO skeleton and NO skin, so a real skeleton is authored here (joint positions are measured from the
     model's own parts) and per-vertex skin weights (4 joints / vertex) are computed from the part names + vertex position.
   - the files' only animation is a turntable rotation of the wrapper node; it is not used by the game. */
'use strict';
const fs = require('fs'), path = require('path');
const dir = process.argv[2] || '/mnt/user-data/attachments/ab1b31d3-7dbc-594d-a565-293f354ee790';
const files = fs.readdirSync(dir).filter((f) => f.endsWith('.glb'));
const find = (k) => path.join(dir, files.find((f) => f.includes(k)));

function readGLB(file) {
  const d = fs.readFileSync(file); const jl = d.readUInt32LE(12);
  const json = JSON.parse(d.slice(20, 20 + jl).toString('utf8').replace(/[\0\s]+$/, ''));
  let off = 20 + jl; off += 8; // bin chunk header (length+type)
  const bin = d.slice(off);
  return { json, bin };
}
function acc(g, idx) {
  const a = g.json.accessors[idx], bv = g.json.bufferViews[a.bufferView], n = { 5126: 4, 5123: 2, 5121: 1, 5125: 4 }[a.componentType], c = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4 }[a.type];
  const base = (bv.byteOffset || 0) + (a.byteOffset || 0), stride = bv.byteStride || n * c, out = new Float64Array(a.count * c);
  for (let i = 0; i < a.count; i++) for (let k = 0; k < c; k++) {
    const o = base + i * stride + k * n; let v;
    if (a.componentType === 5126) v = g.bin.readFloatLE(o); else if (a.componentType === 5123) v = g.bin.readUInt16LE(o); else if (a.componentType === 5121) v = g.bin.readUInt8(o); else v = g.bin.readUInt32LE(o);
    if (a.normalized) v /= a.componentType === 5121 ? 255 : 65535; out[i * c + k] = v;
  }
  return out;
}
const mulM = (a, b) => { const o = new Array(16).fill(0); for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) for (let k = 0; k < 4; k++) o[c * 4 + r] += a[k * 4 + r] * b[c * 4 + k]; return o; };
function nodeLocal(n) {
  if (n.matrix) return n.matrix.slice();
  const t = n.translation || [0, 0, 0], q = n.rotation || [0, 0, 0, 1], s = n.scale || [1, 1, 1];
  const [x, y, z, w] = q;
  const m = [1 - 2 * (y * y + z * z), 2 * (x * y + z * w), 2 * (x * z - y * w), 0, 2 * (x * y - z * w), 1 - 2 * (x * x + z * z), 2 * (y * z + x * w), 0, 2 * (x * z + y * w), 2 * (y * z - x * w), 1 - 2 * (x * x + y * y), 0, t[0], t[1], t[2], 1];
  for (let i = 0; i < 3; i++) { m[i] *= s[0]; m[4 + i] *= s[1]; m[8 + i] *= s[2]; }
  return m;
}
/* returns [{name, pos[], col[], idx[]}] in the file's own (Z-up) space, node transforms applied, the turntable wrapper's animation ignored */
function parts(g) {
  const out = [], J = g.json, nodes = J.nodes;
  const walk = (i, parent) => {
    const n = nodes[i], M = mulM(parent, nodeLocal(n));
    if (n.mesh !== undefined) {
      const mesh = J.meshes[n.mesh];
      for (const p of mesh.primitives) {
        const P = acc(g, p.attributes.POSITION), I = acc(g, p.indices), C = p.attributes.COLOR_0 !== undefined ? acc(g, p.attributes.COLOR_0) : null, cc = C ? (J.accessors[p.attributes.COLOR_0].type === 'VEC4' ? 4 : 3) : 0;
        const pos = [], col = [];
        for (let i2 = 0; i2 < P.length / 3; i2++) {
          const x = P[i2 * 3], y = P[i2 * 3 + 1], z = P[i2 * 3 + 2];
          pos.push(M[0] * x + M[4] * y + M[8] * z + M[12], M[1] * x + M[5] * y + M[9] * z + M[13], M[2] * x + M[6] * y + M[10] * z + M[14]);
          col.push(C ? C[i2 * cc] : 0.5, C ? C[i2 * cc + 1] : 0.5, C ? C[i2 * cc + 2] : 0.5);
        }
        out.push({ name: n.name || mesh.name, pos, col, idx: Array.from(I) });
      }
    }
    for (const c of n.children || []) walk(c, M);
  };
  const scene = J.scenes[J.scene || 0]; for (const r of scene.nodes) walk(r, [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
  return out;
}
const sstep = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const bbox = (pt) => { const lo = [1e9, 1e9, 1e9], hi = [-1e9, -1e9, -1e9]; for (let i = 0; i < pt.pos.length; i += 3) for (let k = 0; k < 3; k++) { lo[k] = Math.min(lo[k], pt.pos[i + k]); hi[k] = Math.max(hi[k], pt.pos[i + k]); } return { lo, hi, c: lo.map((v, k) => (v + hi[k]) / 2) }; };

/* converts parts -> one welded, crease-smoothed geometry. tf maps file space -> engine space. weightFn(partName, fileSpacePos) -> [[bone,w]..] */
function build(prts, tf, weightFn, groupOf) {
  const groups = {}; const P = [], N = [], C = [], I = [], J = [], W = [];
  const order = []; for (const p of prts) { const g = groupOf ? groupOf(p.name) : 'all'; if (!groups[g]) { groups[g] = []; order.push(g); } groups[g].push(p); }
  const out = { groups: [] };
  const key = new Map();
  for (const gname of order) {
    const start = I.length;
    key.clear();
    for (const pt of groups[gname]) {
      const T = pt.idx.length / 3, tris = [];
      const pv = (i) => [pt.pos[i * 3], pt.pos[i * 3 + 1], pt.pos[i * 3 + 2]];
      // face normals (in file space; handedness preserved by tf being a proper rotation)
      const fn = [];
      for (let t = 0; t < T; t++) { const a = pv(pt.idx[t * 3]), b = pv(pt.idx[t * 3 + 1]), c = pv(pt.idx[t * 3 + 2]); const u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], v = [c[0] - a[0], c[1] - a[1], c[2] - a[2]]; const n = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]]; const l = Math.hypot(...n) || 1; fn.push({ n: n.map((x) => x / l), a: l }); }
      // vertex -> faces by position
      const byPos = new Map(); const pk = (p) => p.map((x) => Math.round(x * 1e4)).join(',');
      for (let t = 0; t < T; t++) for (let k = 0; k < 3; k++) { const kk = pk(pv(pt.idx[t * 3 + k])); if (!byPos.has(kk)) byPos.set(kk, []); byPos.get(kk).push(t); }
      const cosC = Math.cos(38 * Math.PI / 180);
      for (let t = 0; t < T; t++) for (let k = 0; k < 3; k++) {
        const vi = pt.idx[t * 3 + k], p = pv(vi), faces = byPos.get(pk(p)); let nx = 0, ny = 0, nz = 0;
        for (const f of faces) { const d = fn[f].n[0] * fn[t].n[0] + fn[f].n[1] * fn[t].n[1] + fn[f].n[2] * fn[t].n[2]; if (d >= cosC) { nx += fn[f].n[0] * fn[f].a; ny += fn[f].n[1] * fn[f].a; nz += fn[f].n[2] * fn[f].a; } }
        const l = Math.hypot(nx, ny, nz) || 1; const nrm = [nx / l, ny / l, nz / l];
        const wp = tf(p), wn = tf(nrm); const col = [pt.col[vi * 3], pt.col[vi * 3 + 1], pt.col[vi * 3 + 2]];
        const kk = [wp.map((x) => Math.round(x * 1e4)).join(','), wn.map((x) => Math.round(x * 50)).join(','), col.map((x) => Math.round(x * 255)).join(',')].join('|');
        let id = key.get(kk);
        if (id === undefined) {
          id = P.length / 3; key.set(kk, id); P.push(...wp); N.push(...wn); C.push(...col);
          if (weightFn) { const w = weightFn(pt.name, p).sort((a, b) => b[1] - a[1]).slice(0, 4); let s = 0; for (const e of w) s += e[1]; for (let q = 0; q < 4; q++) { J.push(w[q] ? w[q][0] : 0); W.push(w[q] ? w[q][1] / s : 0); } }
        }
        tris.push(id);
      }
      // flip winding if tf were improper (it is not) — keep as is
      for (const id of tris) I.push(id);
    }
    out.groups.push({ name: gname, start, count: I.length - start });
  }
  out.P = P; out.N = N; out.C = C; out.I = I; out.J = J; out.W = W; return out;
}
const b64 = (arr) => Buffer.from(arr.buffer, arr.byteOffset, arr.byteLength).toString('base64');
function pack(g, extra) {
  const r = { groups: g.groups, nv: g.P.length / 3, p: b64(new Float32Array(g.P)), n: b64(new Int8Array(g.N.map((v) => Math.round(v * 127)))), c: b64(new Uint8Array(g.C.map((v) => Math.round(v * 255)))), i: b64(new Uint16Array(g.I)) };
  if (g.J.length) { r.j = b64(new Uint8Array(g.J)); const wq = new Uint8Array(g.W.length); for (let v = 0; v < g.W.length / 4; v++) { let sum = 0; for (let k = 1; k < 4; k++) { wq[v * 4 + k] = Math.round(g.W[v * 4 + k] * 255); sum += wq[v * 4 + k]; } wq[v * 4] = 255 - sum; } /* weights sum to exactly 255 */
    r.w = b64(wq); }
  if (g.P.length / 3 > 65535) throw new Error('too many vertices for Uint16 indices');
  return Object.assign(r, extra);
}

/* ============================ TABLE ============================ */
const tableG = readGLB(find('table')), tparts = parts(tableG);
{ // centre on x/y, floor at z=0 (already), Z-up -> Y-up: (x,y,z) -> (x, z, -y)
  var tAll = { pos: [].concat(...tparts.map((p) => p.pos)) }; const bb = bbox(tAll);
  var tCx = bb.c[0], tCy = bb.c[1];
}
const tf_table = (p) => [p[0] - tCx * 0, p[2], -(p[1])];
const tf_tableP = (p) => [p[0], p[2], -p[1]];
const tableB = build(tparts, tf_tableP, null, () => 'table');
const tableTopZ = Math.max(...tparts.filter((p) => /^Tabletop|Plank_seam/.test(p.name)).map((p) => bbox(p).hi[2]));
const topMain = bbox(tparts.find((p) => /Tabletop_main/.test(p.name)));
const tableMeta = { topY: tableTopZ, top: { x: [topMain.lo[0], topMain.hi[0]], z: [-topMain.hi[1], -topMain.lo[1]], y: topMain.hi[2] }, size: [4.48, 1.7, 2.6],
  legs: tparts.filter((p) => /^Leg_[LR]_[FB]$/.test(p.name)).map((p) => { const b = bbox(p); return { x: [b.lo[0], b.hi[0]], z: [-b.hi[1], -b.lo[1]], y: [b.lo[2], b.hi[2]] }; }),
  apron: tparts.filter((p) => /apron/.test(p.name)).map((p) => { const b = bbox(p); return { x: [b.lo[0], b.hi[0]], z: [-b.hi[1], -b.lo[1]], y: [b.lo[2], b.hi[2]] }; }),
  rimTopY: Math.max(...tparts.filter((p) => /_rim$/.test(p.name)).map((p) => bbox(p).hi[2])) };

/* ============================ SHOTGUN ============================ */
const gunG = readGLB(find('shotgun')), gparts = parts(gunG);
const tf_gun = (p) => [p[0], p[2], -p[1]]; // barrel stays along +x, up = +y, file +y (side) -> -z
const gunB = build(gparts, tf_gun, null, (n) => (/^Fore_end/.test(n) ? 'fore' : 'body'));
const gb = (name) => bbox(gparts.find((p) => p.name === name)), cv = (c) => tf_gun(c);
const gripB = gb('Grip'), foreB = gb('Fore_end'), barrelB = gb('Outer_barrel'), muzzleB = gb('Muzzle_rim'), stockB = gb('Stock_end_pad'), recvB = gb('Receiver_shell');
const gunMeta = {
  grip: cv([gripB.c[0], gripB.c[1], gripB.c[2]]), gripSize: [gripB.hi[0] - gripB.lo[0], gripB.hi[2] - gripB.lo[2], gripB.hi[1] - gripB.lo[1]],
  gripTop: cv([gripB.c[0], gripB.c[1], gripB.hi[2]]), trigger: cv([gripB.hi[0] + 0.12, 0, recvB.lo[2]]),
  fore: cv([foreB.c[0], foreB.c[1], foreB.c[2]]), foreSize: [foreB.hi[0] - foreB.lo[0], foreB.hi[2] - foreB.lo[2], foreB.hi[1] - foreB.lo[1]],
  muzzle: cv([muzzleB.hi[0], 0, (muzzleB.lo[2] + muzzleB.hi[2]) / 2]), butt: cv([stockB.lo[0], 0, stockB.c[2]]), ejection: cv([recvB.c[0] + 0.1, recvB.c[1], recvB.hi[2]]),
  bounds: { x: [-1.88, 1.93], y: [-0.4, 0.55], z: [-0.21, 0.21] }, sideRestY: 0.17, // distance from the model axis to the flat side (resting on its side)
  length: 1.93 + 1.88
};

/* ============================ HOODED SKULL CHARACTER ============================ */
const chG = readGLB(find('hooded_skull')), cparts = parts(chG);
const tf_ch = (p) => [-p[0], p[2], p[1]]; // Z-up, face towards +Y  ->  Y-up, face towards +Z (proper rotation: 90deg about X then 180deg about Y)
const P0 = (name) => cparts.find((p) => p.name === name);
const B0 = (name) => bbox(P0(name));
const topOf = (name, frac) => { const p = P0(name); let mz = -1e9; for (let i = 2; i < p.pos.length; i += 3) mz = Math.max(mz, p.pos[i]); const pts = []; for (let i = 0; i < p.pos.length; i += 3) if (p.pos[i + 2] >= mz - frac) pts.push([p.pos[i], p.pos[i + 1], p.pos[i + 2]]); return pts.reduce((a, q) => [a[0] + q[0] / pts.length, a[1] + q[1] / pts.length, a[2] + q[2] / pts.length], [0, 0, 0]); };
// ---- measured joint positions (file space) ----
const J = {};
J.root = [0, 0, 0]; J.pelvis = [0, 0.0, 1.25]; J.spine = [0, 0, 1.65]; J.chest = [0, 0, 2.05]; J.neck = [0, 0.14, 2.42]; J.head = [0, 0.2, 2.58]; J.jaw = [0, 0.2, 2.86];
for (const s of ['L', 'R']) {
  const sg = s === 'L' ? -1 : 1, sh = B0(s === 'L' ? 'Shoulder_left' : 'Shoulder_right'), up = topOf(s + '_upper_sleeve', 0.12), el = B0(s + '_elbow'), pal = B0(s + '_glove_palm');
  J['upperarm_' + s] = [sg * 0.52, up[1], up[2] - 0.05]; J['forearm_' + s] = el.c.slice(); J['hand_' + s] = [pal.c[0], pal.lo[1] + 0.03, pal.c[2]];
  for (let f = 0; f < 4; f++) { const b = B0(s + '_finger_' + f); J[`finger${f}_` + s] = [b.c[0], b.lo[1], b.c[2]]; }
  const tb = B0(s + '_thumb'); J['thumb_' + s] = [sg * 0.5 + (s === 'L' ? -0.0 : 0.0), tb.lo[1] + 0.05, tb.c[2]]; J['thumb_' + s][0] = sg * (Math.abs(tb.c[0]) + 0.04);
  J['upleg_' + s] = [sg * 0.28, 0, 1.45]; J['lowleg_' + s] = [sg * 0.28, 0, 0.8]; J['foot_' + s] = [sg * 0.28, 0.05, 0.2];
}
const BONES = [['root', null], ['pelvis', 'root'], ['spine', 'pelvis'], ['chest', 'spine'], ['neck', 'chest'], ['head', 'neck'], ['jaw', 'head']];
for (const s of ['L', 'R']) {
  BONES.push(['upperarm_' + s, 'chest'], ['forearm_' + s, 'upperarm_' + s], ['hand_' + s, 'forearm_' + s]);
  for (let f = 0; f < 4; f++) BONES.push([`finger${f}_` + s, 'hand_' + s]);
  BONES.push(['thumb_' + s, 'hand_' + s], ['upleg_' + s, 'pelvis'], ['lowleg_' + s, 'upleg_' + s], ['foot_' + s, 'lowleg_' + s]);
}
const BI = {}; BONES.forEach((b, i) => { BI[b[0]] = i; });
const hat = (z, pts) => { // piecewise-linear partition of unity over [[z,bone]..]
  if (z <= pts[0][0]) return [[pts[0][1], 1]]; if (z >= pts[pts.length - 1][0]) return [[pts[pts.length - 1][1], 1]];
  for (let i = 0; i < pts.length - 1; i++) if (z <= pts[i + 1][0]) { const t = (z - pts[i][0]) / (pts[i + 1][0] - pts[i][0]); return [[pts[i][1], 1 - t], [pts[i + 1][1], t]]; }
};
const trunk = (z) => hat(z, [[1.15, 'pelvis'], [1.65, 'spine'], [2.1, 'chest']]);
function weightFn(name, p) {
  const [x, y, z] = p, side = x < 0 ? 'L' : 'R', pairs = [];
  const A = (b, w) => { if (w > 0.001) pairs.push([BI[b], w]); };
  const AA = (arr) => arr.forEach(([b, w]) => A(b, w));
  const sd = /^L_/.test(name) ? 'L' : /^R_/.test(name) ? 'R' : side;
  if (/trouser_leg/.test(name)) { const t = sstep(0.95, 0.65, z); const s2 = sd; const top = sstep(1.3, 1.5, z); A('lowleg_' + s2, t); A('upleg_' + s2, (1 - t) * (top > 0 ? 1 : 1) * (1 - 0)); }
  else if (/boot/.test(name)) A('foot_' + sd, 1);
  else if (name === 'Jacket_torso') AA(trunk(z));
  else if (/^Shoulder_/.test(name)) { const o = sstep(0.32, 0.72, Math.abs(x)); A('upperarm_' + side, o); A('chest', 1 - o); }
  else if (/_upper_sleeve$/.test(name)) { const e = J['forearm_' + sd]; const t = sstep(e[2] + 0.1, e[2] - 0.1, z) * 0.0; const tp = sstep(2.05, 2.25, z); A('upperarm_' + sd, 1 - tp * 0.35); A('chest', tp * 0.35); }
  else if (/_elbow$/.test(name)) { const e = J['forearm_' + sd]; const t = sstep(-0.16, 0.16, e[2] - z); A('forearm_' + sd, t); A('upperarm_' + sd, 1 - t); }
  else if (/_fore_sleeve$/.test(name)) { const e = J['forearm_' + sd]; const t = sstep(e[2] + 0.12, e[2] - 0.05, z); A('forearm_' + sd, 1 - t * 0.0); A('upperarm_' + sd, 0); A('forearm_' + sd, 0); pairs.length = 0; A('forearm_' + sd, 1); }
  else if (/_cuff$/.test(name)) { const h = J['hand_' + sd]; const t = sstep(h[1] - 0.12, h[1] + 0.1, y) * 0.35; A('hand_' + sd, t); A('forearm_' + sd, 1 - t); }
  else if (/_glove_palm$/.test(name)) A('hand_' + sd, 1);
  else if (/_finger_\d$/.test(name)) { const f = +name.slice(-1), b = J[`finger${f}_` + sd], t = sstep(b[1], b[1] + 0.05, y); A(`finger${f}_` + sd, t); A('hand_' + sd, 1 - t); }
  else if (/_thumb$/.test(name)) { const b = J['thumb_' + sd], t = sstep(b[1] - 0.03, b[1] + 0.05, y); A('thumb_' + sd, t); A('hand_' + sd, 1 - t); }
  else if (name === 'Neck_shadow') { const t = sstep(2.3, 2.7, z); A('head', t); A('neck', 1 - t); }
  else if (name === 'Raised_collar') { const t = sstep(2.2, 2.55, z); A('neck', t * 0.7); A('head', t * 0.3 * 0); A('chest', 1 - t * 0.7); }
  else if (/^Hood_outer$|^Hood_|_hood_fold$/.test(name)) { const t = sstep(2.25, 2.95, z); A('head', t); A('neck', (1 - t) * 0.55); A('chest', (1 - t) * 0.45); }
  else if (name === 'Jawbone') { const t = 1 - sstep(2.7, 2.92, z); A('jaw', t); A('head', 1 - t); }
  else if (/^Lower_tooth/.test(name)) A('jaw', 1);
  else if (/^(Skull_mask_base|Brow_ridge|.*eye.*|Nasal_cavity|.*cheekbone|Mouth_cavity|Upper_tooth.*)$/.test(name)) A('head', 1);
  else if (/_patch$|^Coat_|_lapel_edge$|^Jacket_stitch/.test(name)) AA(trunk(z));
  else AA(trunk(z));
  if (!pairs.length) pairs.push([BI.chest, 1]);
  return pairs;
}
const chB = build(cparts, tf_ch, weightFn, () => 'body');
// rig (rest pose: all joint rotations identity; positions converted to engine space)
const rig = { bones: BONES.map(([n, p]) => ({ n, p: p === null ? -1 : BI[p], t: tf_ch(J[n]) })) };
const all = { pos: [].concat(...cparts.map((p) => p.pos)) }, cbb = bbox(all);
const chMeta = { rig, height: cbb.hi[2], head: { c: tf_ch([0, 0.3, 2.93]), r: 0.54 }, eyeL: tf_ch(B0('R_eye_dark_inner').c), eyeR: tf_ch(B0('L_eye_dark_inner').c), mouth: tf_ch([0, 0.55, 2.7]),
  bbox: { lo: tf_ch(cbb.lo), hi: tf_ch(cbb.hi) }, fingerLen: 0.145 };

const OUT = path.join(__dirname, '..', 'data', 'models.js');
const models = { table: pack(tableB, { meta: tableMeta }), gun: pack(gunB, { meta: gunMeta }), dealer: pack(chB, { meta: chMeta }) };
fs.writeFileSync(OUT, '/* generated by tools/build-models.js from the supplied GLB files — do not edit */\n(function(G){G.MODELS=' + JSON.stringify(models) + ';})(typeof window!==\'undefined\'?window:globalThis);\n');
console.log('wrote', OUT, (fs.statSync(OUT).size / 1024).toFixed(0) + ' KB', 'table verts', models.table.nv, 'gun', models.gun.nv, 'character', models.dealer.nv, 'bones', BONES.length);
console.log('table top y', tableTopZ, 'gun meta', JSON.stringify(gunMeta.grip), JSON.stringify(gunMeta.fore), JSON.stringify(gunMeta.muzzle));
console.log('char joints (engine space):'); for (const b of rig.bones) console.log(' ', b.n.padEnd(12), b.t.map((v) => v.toFixed(2)).join(' '));
