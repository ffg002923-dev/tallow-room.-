"""Minimal binary-FBX reader (7.x, incl. 7500 64-bit offsets). Returns a tree of Node(name, props, children)."""
import struct, zlib, sys

class Node:
    __slots__ = ('name', 'props', 'children')
    def __init__(self, name): self.name = name; self.props = []; self.children = []
    def find(self, name): return [c for c in self.children if c.name == name]
    def first(self, name):
        r = self.find(name); return r[0] if r else None

def read_array(buf, off, code):
    n, enc, clen = struct.unpack_from('<III', buf, off); off += 12
    data = buf[off:off + clen]; off += clen
    if enc == 1: data = zlib.decompress(data)
    fmt = {'f': 'f', 'd': 'd', 'l': 'q', 'i': 'i', 'b': 'b'}[code]
    import array
    a = struct.unpack('<%d%s' % (n, fmt), data)
    return list(a), off

def parse(path):
    buf = open(path, 'rb').read()
    assert buf[:18] == b'Kaydara FBX Binary', buf[:24]
    ver = struct.unpack_from('<I', buf, 23)[0]
    big = ver >= 7500
    off = 27
    def rec(off):
        if big:
            end, nprops, plen, nlen = struct.unpack_from('<QQQB', buf, off); off += 25
        else:
            end, nprops, plen, nlen = struct.unpack_from('<IIIB', buf, off); off += 13
        if end == 0: return None, off
        n = Node(buf[off:off + nlen].decode('latin1')); off += nlen
        for _ in range(nprops):
            t = chr(buf[off]); off += 1
            if t == 'Y': n.props.append(struct.unpack_from('<h', buf, off)[0]); off += 2
            elif t == 'C': n.props.append(bool(buf[off])); off += 1
            elif t == 'I': n.props.append(struct.unpack_from('<i', buf, off)[0]); off += 4
            elif t == 'F': n.props.append(struct.unpack_from('<f', buf, off)[0]); off += 4
            elif t == 'D': n.props.append(struct.unpack_from('<d', buf, off)[0]); off += 8
            elif t == 'L': n.props.append(struct.unpack_from('<q', buf, off)[0]); off += 8
            elif t in 'fdlib':
                a, off = read_array(buf, off, t); n.props.append(a)
            elif t == 'S':
                l = struct.unpack_from('<I', buf, off)[0]; off += 4; n.props.append(buf[off:off + l].decode('utf8', 'replace')); off += l
            elif t == 'R':
                l = struct.unpack_from('<I', buf, off)[0]; off += 4; n.props.append(bytes(buf[off:off + l])); off += l
            else: raise ValueError('bad prop type %r at %d' % (t, off))
        while off < end:
            c, off = rec(off)
            if c is None: break
            n.children.append(c)
        return n, end
    root = Node('root')
    while off < len(buf) - 32:
        n, off2 = rec(off)
        if n is None: break
        root.children.append(n); off = off2
    return ver, root

if __name__ == '__main__':
    ver, root = parse(sys.argv[1])
    print('version', ver, 'top-level:', [c.name for c in root.children])
