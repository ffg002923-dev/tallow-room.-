import numpy as np, heapq, collections
def weld(V, T, tol=1e-4):
    key = {}; remap = np.zeros(len(V), int); Vw = []
    for v in range(len(V)):
        k = tuple(np.round(V[v] / tol).astype(int))
        if k not in key: key[k] = len(key); Vw.append(V[v])
        remap[v] = key[k]
    Tw = remap[T]; keep = [len(set(t)) == 3 for t in Tw]; return np.array(Vw), Tw[keep], remap
def adjacency(Vw, Tw):
    nb = [dict() for _ in range(len(Vw))]
    for t in Tw:
        for k in range(3):
            a, b = t[k], t[(k + 1) % 3]; d = float(np.linalg.norm(Vw[a] - Vw[b])); nb[a][b] = d; nb[b][a] = d
    return nb
def tri_normals(Vw, Tw):
    A, B, C = Vw[Tw[:, 0]], Vw[Tw[:, 1]], Vw[Tw[:, 2]]; n = np.cross(B - A, C - A); a = np.linalg.norm(n, axis=1); return n / (a[:, None] + 1e-12), a / 2
def find_cap(Vw, Tw, verbose=False):
    n, area = tri_normals(Vw, Tw); cent = Vw[Tw].mean(1)
    # cluster triangles by plane
    groups = collections.defaultdict(list)
    for k in range(len(Tw)):
        d = float(n[k] @ cent[k]); groups[(tuple(np.round(n[k], 2)), round(d, 1))].append(k)
    cands = []
    for key, ks in groups.items():
        if len(ks) < 4: continue
        nn = n[ks].mean(0); nn /= np.linalg.norm(nn); P = Vw[Tw[ks]].reshape(-1, 3); p0 = P.mean(0); 
        # all vertices on the inner side?
        s = (Vw - p0) @ nn; 
        for sign in (1, -1):
            if (s * sign).min() > -0.02: cands.append((area[ks].sum(), sign, ks, nn * sign, p0, (s * sign).max()))
    cands.sort(key=lambda c: -c[0])
    if verbose:
        for c in cands[:6]: print('cap cand: area %.3f tris %d normal(inward) %s depth %.2f' % (c[0], len(c[2]), np.round(c[3], 3), c[5]))
    return cands
def dijkstra(nb, src, n):
    g = np.full(n, np.inf); h = []
    for s in src: g[s] = 0; heapq.heappush(h, (0.0, s))
    par = np.full(n, -1)
    while h:
        d, u = heapq.heappop(h)
        if d > g[u]: continue
        for v, w in nb[u].items():
            nd = d + w
            if nd < g[v]: g[v] = nd; par[v] = u; heapq.heappush(h, (nd, v))
    return g, par
def tips_by_persistence(nb, g, minpers):
    """merge-tree on superlevel sets of g: returns list of dict(tip, peak, merge, pers) sorted by peak, and a label array (finger id for vertices above their merge level, -1 below)"""
    n = len(g); order = np.argsort(-g); par = list(range(n)); rep_peak = {}; comp_tip = {}  # comp root -> tip vertex
    def find(a):
        while par[a] != a: par[a] = par[par[a]]; a = par[a]
        return a
    done = np.zeros(n, bool); events = []; label_at = np.full(n, -1)
    for v in order:
        done[v] = True; roots = set()
        for u in nb[v]:
            if done[u]: roots.add(find(u))
        if not roots: comp_tip[v] = v; label_at[v] = v; continue
        roots = list(roots); best = max(roots, key=lambda r: g[comp_tip[r]])
        for r in roots:
            if r == best: continue
            events.append((comp_tip[r], g[v]))   # this component dies (merges into a taller one) at level g[v]
            par[r] = best
        par[v] = best; label_at[v] = comp_tip[best]
        # v joins: if more than one root merged, the surviving component keeps its tip
    # surviving global max never dies
    gt = comp_tip[find(order[0])]
    out = []
    for tip, lvl in events: out.append(dict(tip=int(tip), peak=float(g[tip]), merge=float(lvl), pers=float(g[tip] - lvl)))
    out.append(dict(tip=int(gt), peak=float(g[gt]), merge=0.0, pers=float(g[gt])))
    out = [o for o in out if o['pers'] >= minpers]; out.sort(key=lambda o: -o['peak']); return out

def cap_region(Vw, Tw, normal_in, depth_tol=0.35, dot_min=0.93):
    """vertices of the flat wrist end: triangles facing -normal_in near the minimum depth"""
    n, area = tri_normals(Vw, Tw); cent = Vw[Tw].mean(1); dep = (cent - Vw[np.argmin(Vw @ normal_in)]) @ normal_in
    dmin = (Vw @ normal_in).min(); dep = cent @ normal_in - dmin
    sel = np.where((n @ (-normal_in) > dot_min) & (dep < depth_tol))[0]
    return sel, sorted(set(Tw[sel].flatten().tolist()))
def pca_line(P):
    c = P.mean(0); u, s, vt = np.linalg.svd(P - c, full_matrices=False); return c, vt[0]
def smooth_poly(P, k=1):
    Q = P.copy()
    for i in range(1, len(P) - 1): Q[i] = (P[i - 1] + 2 * P[i] + P[i + 1]) / 4
    return Q
def polyline_bins(Vw, g, ids, g0, g1, w):
    nbin = max(3, int(round((g1 - g0) / w))); edges = np.linspace(g0, g1 + 1e-6, nbin + 1); pts = []
    for k in range(nbin):
        sel = [v for v in ids if edges[k] <= g[v] < edges[k + 1]]
        if sel: pts.append(Vw[sel].mean(0))
    return np.array(pts)
def resample(P, d):
    """points at arc-length positions d (array) along polyline P (n,3); extrapolates linearly at the ends"""
    seg = np.linalg.norm(np.diff(P, axis=0), axis=1); cum = np.r_[0, np.cumsum(seg)]; out = []
    for x in d:
        if x <= 0: dirv = (P[1] - P[0]) / (seg[0] + 1e-12); out.append(P[0] + dirv * x)
        elif x >= cum[-1]: dirv = (P[-1] - P[-2]) / (seg[-1] + 1e-12); out.append(P[-1] + dirv * (x - cum[-1]))
        else:
            k = np.searchsorted(cum, x) - 1; t = (x - cum[k]) / (seg[k] + 1e-12); out.append(P[k] * (1 - t) + P[k + 1] * t)
    return np.array(out), cum[-1]

# ---- original armature topology (Armature_005 of the supplied FBX): lengths measured from the file
# bone name -> (role, parent). Lengths = distance to the first child's head (the file's bones have no tail data).
ARM_NAMES = ['Bone', 'Bone_001', 'Bone_002', 'Bone_003', 'Bone_004', 'Bone_005', 'Bone_006', 'Bone_007', 'Bone_008', 'Bone_009', 'Bone_010', 'Bone_011', 'Bone_012', 'Bone_013', 'Bone_014', 'Bone_015', 'Bone_016', 'Bone_017', 'Bone_018', 'Bone_019']
FINGERS = ['index', 'middle', 'ring', 'pinky']
# role names -> original FBX bone names (chains read from the file hierarchy)
ROLE2BONE = {'wrist': 'Bone', 'thumb1': 'Bone_001', 'thumb2': 'Bone_002', 'thumb3': 'Bone_003',
             'index0': 'Bone_004', 'index1': 'Bone_008', 'index2': 'Bone_009', 'index3': 'Bone_010',
             'middle0': 'Bone_005', 'middle1': 'Bone_011', 'middle2': 'Bone_012', 'middle3': 'Bone_013',
             'ring0': 'Bone_006', 'ring1': 'Bone_014', 'ring2': 'Bone_015', 'ring3': 'Bone_016',
             'pinky0': 'Bone_007', 'pinky1': 'Bone_017', 'pinky2': 'Bone_018', 'pinky3': 'Bone_019'}
ARM_LEN = {'wrist': 0.665, 'thumb1': 0.866, 'thumb2': 0.662, 'thumb3': 0.55,
           'index0': 1.235, 'index1': 0.673, 'index2': 0.544, 'index3': 0.45,
           'middle0': 1.167, 'middle1': 0.785, 'middle2': 0.526, 'middle3': 0.45,
           'ring0': 1.140, 'ring1': 0.460, 'ring2': 0.614, 'ring3': 0.45,
           'pinky0': 1.154, 'pinky1': 0.572, 'pinky2': 0.453, 'pinky3': 0.40}

def point_seg(P, A, B):
    d = B - A; l2 = float(d @ d) + 1e-12; t = np.clip(((P - A) @ d) / l2, 0, 1); Q = A + t[:, None] * d; return np.linalg.norm(P - Q, axis=1), t

def rig_hand(V, T, verbose=False, bin_w=0.14):
    cands = find_cap(V, T); best = None
    for c in cands:
        nin = c[3]; depth = (V @ nin).max() - (V @ nin).min()
        if depth < 2.5: continue
        sel, cv = cap_region(V, T, nin, 0.3, 0.93); a = tri_normals(V, T)[1][sel].sum() if len(sel) else 0
        if best is None or a > best[0]: best = (a, nin, sel, cv)
    area, nin, sel, cv = best
    nb = adjacency(V, T); g, par = dijkstra(nb, cv, len(V)); tips = tips_by_persistence(nb, g, 0.45)
    assert len(tips) == 5, ('expected 5 tips', len(tips))
    # thumb = shortest tip
    tips_sorted = sorted(tips, key=lambda t: t['peak']); thumb = tips_sorted[0]; fing = [t for t in tips if t is not thumb]
    # base level per tip: for dying tips their merge level, for the global tallest the largest merge level of the others
    maxmerge = max(t['merge'] for t in fing); 
    for t in tips: t['base'] = t['merge'] if t['merge'] > 0 else maxmerge
    # vertex labels by merge-tree processing (rerun to get labels)
    n = len(g); order = np.argsort(-g); par_ = list(range(n)); comp_tip = {}; done = np.zeros(n, bool); label = np.full(n, -1)
    def find(a):
        while par_[a] != a: par_[a] = par_[par_[a]]; a = par_[a]
        return a
    for v in order:
        done[v] = True; roots = set(find(u) for u in nb[v] if done[u])
        if not roots: comp_tip[v] = v; label[v] = v; continue
        roots = list(roots); bestr = max(roots, key=lambda r: g[comp_tip[r]])
        for r in roots:
            if r != bestr: par_[r] = bestr
        par_[v] = bestr; label[v] = comp_tip[bestr]
    tipids = {t['tip']: t for t in tips}
    fverts = {t['tip']: [v for v in range(n) if label[v] == t['tip'] and g[v] >= t['base'] - 1e-9] for t in tips}
    # finger bases (centroid of the vertices in the lowest bins) to order the four fingers from the thumb side
    base_pt = {t['tip']: V[[v for v in fverts[t['tip']] if g[v] < t['base'] + 0.25]].mean(0) if len(fverts[t['tip']]) else V[t['tip']] for t in tips}
    fb = np.array([base_pt[t['tip']] for t in fing]); c0, ax = pca_line(fb); proj = (fb - c0) @ ax
    tb = base_pt[thumb['tip']]; sgn = 1 if abs(((tb - c0) @ ax) - proj.min()) < abs(((tb - c0) @ ax) - proj.max()) else -1
    ordr = np.argsort(proj * sgn); fing = [fing[i] for i in ordr]   # index ... pinky (nearest to the thumb first)
    chains = {}
    wc = V[cv].mean(0)
    for name, t in zip(FINGERS + ['thumb'], fing + [thumb]):
        ids = fverts[t['tip']]; P = polyline_bins(V, g, ids, t['base'], t['peak'] + 0.01, bin_w); P = smooth_poly(P)
        chains[name] = dict(tip=t, poly=P, ids=ids)
    return dict(V=V, T=T, nb=nb, g=g, cv=cv, nin=nin, wc=wc, chains=chains, label=label, tips=tips, par=par)

def unit(v): v = np.asarray(v, float); return v / (np.linalg.norm(v) + 1e-12)
def rot_axis(a, ang):
    a = unit(a); c, s = np.cos(ang), np.sin(ang); x, y, z = a
    return np.array([[c + x * x * (1 - c), x * y * (1 - c) - z * s, x * z * (1 - c) + y * s], [y * x * (1 - c) + z * s, c + y * y * (1 - c), y * z * (1 - c) - x * s], [z * x * (1 - c) - y * s, z * y * (1 - c) + x * s, c + z * z * (1 - c)]])
def signed_angle(a, b, axis): a, b = unit(a), unit(b); return float(np.arctan2(np.cross(a, b) @ unit(axis), a @ b))

def build_skeleton(r, ext_f=0.25, tip_inset=0.12, sigma=0.17):
    V, g, chains, wc, nin = r['V'], r['g'], r['chains'], r['wc'], r['nin']
    J = {}          # role -> head position
    tail = {}       # role -> tail position
    info = {}
    mcp = {}
    for f in FINGERS + ['thumb']:
        P = chains[f]['poly']; seg = np.linalg.norm(np.diff(P, axis=0), axis=1); Lp = seg.sum()
        ext = ext_f if f != 'thumb' else 0.12
        if f != 'thumb':
            a1, a2, a3 = ARM_LEN[f + '1'], ARM_LEN[f + '2'], ARM_LEN[f + '3']; tot = Lp + ext - tip_inset; s = tot / (a1 + a2 + a3)
            d = np.array([-ext, -ext + s * a1, -ext + s * (a1 + a2), Lp - tip_inset])
            Q, _ = resample(P, d); J[f + '1'], J[f + '2'], J[f + '3'], tail[f + '3'] = Q[0], Q[1], Q[2], Q[3]; mcp[f] = Q[0]
        else:
            a2, a3 = ARM_LEN['thumb2'], ARM_LEN['thumb3']; tot = Lp + ext - tip_inset; s = tot / (a2 + a3)
            d = np.array([-ext, -ext + s * a2, Lp - tip_inset]); Q, _ = resample(P, d); J['thumb2'], J['thumb3'], tail['thumb3'] = Q[0], Q[1], Q[2]; mcp['thumb'] = Q[0]
    mc = np.mean([mcp[f] for f in FINGERS], axis=0); fwd = unit(nin)     # nin points from the wrist into the hand
    root = wc + fwd * 0.2; Cp = root + (mc - root) * (0.665 / (0.665 + 1.19))
    J['wrist'] = root; tail['wrist'] = Cp
    for f in FINGERS: J[f + '0'] = Cp; tail[f + '0'] = mcp[f]
    J['thumb1'] = Cp; tail['thumb1'] = mcp['thumb']
    for f in FINGERS + ['thumb']:
        names = ([f + '0'] if f != 'thumb' else []) + ([f + '1', f + '2', f + '3'])
        for i, nme in enumerate(names):
            if nme in J and nme not in tail: tail[nme] = J[names[i + 1]] if i + 1 < len(names) else tail[nme]
    # fix tails: bone k's tail = head of its child
    for f in FINGERS: tail[f + '1'] = J[f + '2']; tail[f + '2'] = J[f + '3']
    tail['thumb1'] = J['thumb2']; tail['thumb2'] = J['thumb3']
    # palm normal (toward the side the fingers curl to)
    pn = np.zeros(3)
    for f in FINGERS:
        v = tail[f + '3'] - J[f + '1']; pn += v - (v @ fwd) * fwd
    pn = unit(pn - (pn @ fwd) * fwd)
    # flexion axes + bind angles
    axis = {}; ang = {}
    for f in FINGERS + ['thumb']:
        names = ([f + '0'] if f != 'thumb' else ['wrist_dir']) 
        if f != 'thumb': pts = [J[f + '0'], J[f + '1'], J[f + '2'], J[f + '3'], tail[f + '3']]; roles = [f + '1', f + '2', f + '3']
        else: pts = [J['thumb1'], J['thumb2'], J['thumb3'], tail['thumb3']]; roles = ['thumb2', 'thumb3']
        dirs = [pts[i + 1] - pts[i] for i in range(len(pts) - 1)]; acc = np.zeros(3)
        for i in range(len(dirs) - 1): acc += np.cross(dirs[i], dirs[i + 1])
        strong = np.linalg.norm(acc) > 0.18 * sum(np.linalg.norm(dirs[i]) * np.linalg.norm(dirs[i + 1]) for i in range(len(dirs) - 1)) * 0.2
        a = unit(acc) if strong else unit(np.cross(dirs[1], pn))
        axis[f] = a
        for k, rname in enumerate(roles):  # bend of bone `rname` relative to the previous bone
            i = len(dirs) - len(roles) + k; ang[rname] = signed_angle(dirs[i - 1], dirs[i], a)
    # weights (gaussian on distance to the allowed bone segments)
    n = len(V); bones = list(J.keys()); weights = np.zeros((n, len(bones)))
    palm_roles = ['wrist'] + [f + '0' for f in FINGERS] + ['thumb1']
    fid = {}
    for f in FINGERS + ['thumb']:
        for v in chains[f]['ids']: fid[v] = f
    for v in range(n):
        p = V[v:v + 1]
        if v in fid:
            f = fid[v]; allowed = ([f + '0'] if f != 'thumb' else ['thumb1']) + [f + '1', f + '2', f + '3'] if f != 'thumb' else ['thumb1', 'thumb2', 'thumb3']
        else:
            allowed = palm_roles + [f + '1' for f in FINGERS] + ['thumb2']
        ds = []
        for b in allowed:
            d, t = point_seg(p, J[b], tail[b]); ds.append(float(d[0]))
        ds = np.array(ds); w = np.exp(-(ds / sigma) ** 2 * 0.5) + 1e-9; w /= w.sum()
        for b, ww in zip(allowed, w): weights[v, bones.index(b)] = ww
    # keep the 4 largest
    for v in range(n):
        idx = np.argsort(-weights[v])[4:]; weights[v, idx] = 0; weights[v] /= weights[v].sum()
    parent = {'wrist': None, 'thumb1': 'wrist', 'thumb2': 'thumb1', 'thumb3': 'thumb2'}
    for f in FINGERS: parent[f + '0'] = 'wrist'; parent[f + '1'] = f + '0'; parent[f + '2'] = f + '1'; parent[f + '3'] = f + '2'
    return dict(J=J, tail=tail, axis=axis, ang=ang, bones=bones, weights=weights, parent=parent, fwd=fwd, pn=pn, wc=wc)

def pose_matrices(sk, curl, order=None):
    """curl: dict finger->c (1 = bind pose, 0 = open). returns skin matrices (4x4) per bone in bind (hand-local) space"""
    J, parent, axis, ang = sk['J'], sk['parent'], sk['axis'], sk['ang']; S = {}
    def rec(b):
        if b in S: return S[b]
        p = parent[b]; Sp = rec(p) if p else np.eye(4); M = np.eye(4)
        f = None
        if b[:-1] in FINGERS and b[-1] in '123': f = b[:-1]
        elif b[:-1] == 'thumb' and b[-1] in '23': f = 'thumb'
        if f is not None and f in curl:
            c = curl[f]; gam = 0.1; beta = ang[b]; d = (c - 1.0) * (beta - gam * np.sign(beta))
            R = rot_axis(axis[f], d); M[:3, :3] = R; M[:3, 3] = J[b] - R @ J[b]
        S[b] = Sp @ M; return S[b]
    for b in sk['bones']: rec(b)
    return S
def skin_vertices(V, sk, S):
    W = sk['weights']; bones = sk['bones']; out = np.zeros_like(V); Vh = np.c_[V, np.ones(len(V))]
    for k, b in enumerate(bones):
        w = W[:, k]
        if not w.any(): continue
        out += w[:, None] * (Vh @ S[b].T)[:, :3]
    return out
