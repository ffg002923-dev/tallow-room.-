import numpy as np, collections
from fbxparse import parse

def nm(o): return o.props[1].split('\x00')[0]

def p70(o):
    p = o.first('Properties70'); out = {}
    if p:
        for c in p.children: out[c.props[0]] = c.props[4:]
    return out

def euler_xyz_deg(r):
    rx, ry, rz = [np.radians(v) for v in r]
    cx, sx, cy, sy, cz, sz = np.cos(rx), np.sin(rx), np.cos(ry), np.sin(ry), np.cos(rz), np.sin(rz)
    Rx = np.array([[1,0,0],[0,cx,-sx],[0,sx,cx]]); Ry = np.array([[cy,0,sy],[0,1,0],[-sy,0,cy]]); Rz = np.array([[cz,-sz,0],[sz,cz,0],[0,0,1]])
    return Rz @ Ry @ Rx

class Scene: pass

def load(path):
    ver, root = parse(path)
    objs = root.first('Objects'); conns = root.first('Connections')
    byid = {o.props[0]: o for o in objs.children}
    S = Scene(); S.byid = byid; S.root = root
    parent = {}; children = collections.defaultdict(list); links = collections.defaultdict(list)
    for c in conns.children:
        t, a, b = c.props[0], c.props[1], c.props[2]
        if a in byid and b in byid:
            oa, ob = byid[a], byid[b]
            if oa.name == 'Model' and ob.name == 'Model' and t == 'OO': parent[a] = b; children[b].append(a)
            else: links[b].append((a, oa.name, c.props[3] if len(c.props) > 3 else ''))
        elif b == 0 and a in byid and byid[a].name == 'Model': parent[a] = 0; children[0].append(a)
    S.parent, S.children, S.links = parent, children, links
    S.models = [i for i, o in byid.items() if o.name == 'Model']
    S.local = {}; S.world = {}; S.props = {}
    for i in S.models:
        pr = p70(byid[i]); S.props[i] = pr
        T = np.array(pr.get('Lcl Translation', [0, 0, 0]), float); R = pr.get('Lcl Rotation', [0, 0, 0]); Sc = np.array(pr.get('Lcl Scaling', [1, 1, 1]), float)
        M = np.eye(4); M[:3, :3] = euler_xyz_deg(R) @ np.diag(Sc); M[:3, 3] = T
        S.local[i] = M
    def W(i):
        if i in S.world: return S.world[i]
        p = parent.get(i, 0); S.world[i] = (W(p) @ S.local[i]) if p else S.local[i]; return S.world[i]
    for i in S.models: W(i)
    return S

def geometry(g):
    V = np.array(g.first('Vertices').props[0], float).reshape(-1, 3)
    pvi = np.array(g.first('PolygonVertexIndex').props[0], int)
    polys = []; cur = []
    for k, idx in enumerate(pvi):
        if idx < 0: cur.append(~idx); polys.append(cur); cur = []
        else: cur.append(idx)
    def layer(name, dkey, ikey):
        L = g.first(name)
        if not L: return None
        mp = L.first('MappingInformationType').props[0]; rf = L.first('ReferenceInformationType').props[0]
        d = np.array(L.first(dkey).props[0], float) if L.first(dkey) else None
        ix = np.array(L.first(ikey).props[0], int) if (ikey and L.first(ikey)) else None
        return mp, rf, d, ix
    return V, polys, layer('LayerElementNormal', 'Normals', 'NormalsIndex'), layer('LayerElementUV', 'UV', 'UVIndex'), layer('LayerElementMaterial', 'Materials', None)
