#!/usr/bin/env python3
"""build-ghost-dealer.py — turns the supplied ghost GLB (tools/ghost/ghost.glb: ONE static mesh, 228k vertices, no skeleton, no animation)
into the game's dealer model and writes it into data/models.js (replacing the old hooded-skull dealer, which is removed).
  * mesh: grid-cluster decimation to <= ~40k vertices (uint16 indices), baked vertex colours from the base-colour texture, smooth normals
  * frame: uniform scale to the dealer's height (3.77), feet on y=0, facing +Z (same frame the game code expects)
  * skeleton: 22 NEW bones authored for this body (not copied from the old dealer):
      root > pelvis > spine > chest > neck > head > jaw / hood        trunk + head + hood-tip + lower hood lip
      chest > upperarm_L/R > forearm > hand                           2-bone IK arms (the game's gloved hands are drawn at the wrist)
      pelvis > robe_F1>F2, robe_B1>B2, robe_L1>L2, robe_R1>R2         four hanging robe chains for secondary motion
  * skin weights: height bands along the spine, distance to the arm chains for the sleeves, angular sectors for the robe chains.
usage: python3 tools/build-ghost-dealer.py
"""
import json, struct, os, base64, io, sys
import numpy as np
from PIL import Image
HERE = os.path.dirname(os.path.abspath(__file__)); SRC = os.path.join(HERE, 'ghost', 'ghost.glb'); TEXDIR = os.path.join(HERE, 'ghost')
MODELS = os.path.join(HERE, '..', 'data', 'models.js')
HEIGHT = 3.77; MAXV = 40000

d = open(SRC, 'rb').read(); o = 12; J = BIN = None
while o < len(d):
    cl, ct = struct.unpack('<II', d[o:o + 8])
    if ct == 0x4E4F534A: J = json.loads(d[o + 8:o + 8 + cl])
    elif ct == 0x004E4942: BIN = d[o + 8:o + 8 + cl]
    o += 8 + cl
def acc(i):
    a = J['accessors'][i]; bv = J['bufferViews'][a['bufferView']]
    c = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3}[a['type']]; dt = {5126: '<f4', 5123: '<u2', 5125: '<u4'}[a['componentType']]
    a0 = np.frombuffer(BIN, dtype=dt, count=a['count'] * c, offset=bv.get('byteOffset', 0) + a.get('byteOffset', 0))
    return a0.reshape(-1, c) if c > 1 else a0
pr = J['meshes'][0]['primitives'][0]
P = acc(pr['attributes']['POSITION']).astype(float); Nn = acc(pr['attributes']['NORMAL']).astype(float); UV = acc(pr['attributes']['TEXCOORD_0']).astype(float); I = acc(pr['indices']).astype(np.int64).reshape(-1, 3)
bv = J['bufferViews'][J['images'][0]['bufferView']]; tex = Image.open(io.BytesIO(BIN[bv.get('byteOffset', 0):bv.get('byteOffset', 0) + bv['byteLength']])).convert('RGB')
T = np.asarray(tex, float) / 255; th, tw = T.shape[:2]
col = T[np.clip(((1 - (UV[:, 1] % 1)) * 0 + (UV[:, 1] % 1)) * (th - 1), 0, th - 1).astype(int), np.clip((UV[:, 0] % 1) * (tw - 1), 0, tw - 1).astype(int)]
col = np.clip((col ** 0.62) * 1.25, 0, 1)          # the texture is almost black: lift it so he still reads in the dim room

# ---------------------------------------------------------------- frame: Y up, feet on 0, height 3.77, facing +Z
k = HEIGHT / (P[:, 1].max() - P[:, 1].min()); P = np.c_[P[:, 0] * k, (P[:, 1] - P[:, 1].min()) * k, P[:, 2] * k]
print('scale %.3f bounds %s %s' % (k, P.min(0).round(2), P.max(0).round(2)))

# ---------------------------------------------------------------- decimate (grid clustering), pick a cell size that fits MAXV
def cluster(cell):
    key = np.floor(P / cell).astype(np.int64); key -= key.min(0); dims = key.max(0) + 1
    flat = (key[:, 0] * dims[1] + key[:, 1]) * dims[2] + key[:, 2]; u, inv = np.unique(flat, return_inverse=True); return u, inv
lo, hi = 0.005, 0.2
for _ in range(14):
    mid = (lo + hi) / 2; u, inv = cluster(mid)
    if len(u) > MAXV: lo = mid
    else: hi = mid
u, inv = cluster(hi); nc = len(u); cnt = np.bincount(inv, minlength=nc).astype(float)[:, None]
def avg(X): out = np.zeros((nc, X.shape[1])); np.add.at(out, inv, X); return out / cnt
CP = avg(P); CN = avg(Nn); CN /= np.linalg.norm(CN, axis=1, keepdims=True) + 1e-9; CC = avg(col)
tri = inv[I]; ok = (tri[:, 0] != tri[:, 1]) & (tri[:, 1] != tri[:, 2]) & (tri[:, 0] != tri[:, 2]); tri = tri[ok]
srt = np.sort(tri, axis=1); _, first = np.unique(srt, axis=0, return_index=True); tri = tri[np.sort(first)]
used = np.unique(tri); rm = -np.ones(nc, int); rm[used] = np.arange(len(used)); CP, CN, CC, tri = CP[used], CN[used], CC[used], rm[tri]
print('cell %.4f -> %d verts, %d tris (from %d / %d)' % (hi, len(CP), len(tri), len(P), len(I)))

# ---------------------------------------------------------------- skeleton (rest positions in model space)
B = [  # name, parent, rest position
    ('root', -1, (0, 0, 0)), ('pelvis', 0, (0, 1.20, -0.10)), ('spine', 1, (0, 1.65, -0.10)), ('chest', 2, (0, 2.10, -0.20)), ('neck', 3, (0, 2.55, -0.15)),
    ('head', 4, (0, 2.85, -0.02)), ('jaw', 5, (0, 3.10, 0.10)), ('hood', 5, (0, 3.45, 0.14)),
    ('upperarm_L', 3, (0.62, 2.12, -0.15)), ('forearm_L', 8, (0.86, 1.62, 0.05)), ('hand_L', 9, (0.76, 1.28, 0.40)),
    ('upperarm_R', 3, (-0.62, 2.12, -0.15)), ('forearm_R', 11, (-0.86, 1.62, 0.05)), ('hand_R', 12, (-0.76, 1.28, 0.40)),
    ('robe_F1', 1, (0, 1.00, 0.30)), ('robe_F2', 14, (0, 0.55, 0.38)), ('robe_B1', 1, (0, 1.00, -0.60)), ('robe_B2', 16, (0, 0.55, -0.70)),
    ('robe_L1', 1, (0.75, 1.00, -0.10)), ('robe_L2', 18, (0.85, 0.55, -0.10)), ('robe_R1', 1, (-0.75, 1.00, -0.10)), ('robe_R2', 20, (-0.85, 0.55, -0.10)),
]
nb = len(B); idx = {b[0]: i for i, b in enumerate(B)}; rest = np.array([b[2] for b in B], float)
assert nb <= 32

def sstep(a, b, x): t = np.clip((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t)
def seg_dist(Pn, a, b):
    a = np.array(a); b = np.array(b); ab = b - a; t = np.clip(((Pn - a) @ ab) / (ab @ ab), 0, 1); return np.linalg.norm(Pn - (a + t[:, None] * ab), axis=1)
Wt = np.zeros((len(CP), nb)); x, y, z = CP[:, 0], CP[:, 1], CP[:, 2]
# core: soft height bands along the spine
core = np.zeros((len(CP), 6))   # pelvis, spine, chest, neck, head, root
cy = [1.20, 1.65, 2.10, 2.55, 2.95]; names = ['pelvis', 'spine', 'chest', 'neck', 'head']
for i, c in enumerate(cy):
    lo_c = cy[i - 1] if i else -9; hi_c = cy[i + 1] if i < len(cy) - 1 else 99
    up = sstep(lo_c, c, y) if i else np.ones_like(y); dn = 1 - sstep(c, hi_c, y) if i < len(cy) - 1 else np.ones_like(y)
    core[:, i] = up * dn
core /= core.sum(1, keepdims=True) + 1e-9
# robe: below the pelvis the cloth hangs; angular sectors around the body axis choose the chain
rb = sstep(1.25, 0.55, y)                               # 0 at pelvis height -> 1 near the hem
ang = np.arctan2(x, z + 0.1)                            # 0 = front (+z), +pi/2 = +x (L side)
sect = np.stack([np.cos(ang) ** 2 * (np.cos(ang) > 0), np.cos(ang - np.pi) ** 2 * (np.cos(ang - np.pi) > 0),
                 np.cos(ang - np.pi / 2) ** 2 * (np.cos(ang - np.pi / 2) > 0), np.cos(ang + np.pi / 2) ** 2 * (np.cos(ang + np.pi / 2) > 0)], 1)
sect /= sect.sum(1, keepdims=True) + 1e-9
seg2 = sstep(0.95, 0.6, y)                              # upper segment -> lower segment of each chain
# arms: sleeves = vertices close to an arm chain and out to the side
armw = {}
for s, sg in (('L', 1), ('R', -1)):
    ch = [rest[idx['upperarm_' + s]], rest[idx['forearm_' + s]], rest[idx['hand_' + s]], rest[idx['hand_' + s]] + np.array([0.0, -0.45, 0.25])]
    d1 = seg_dist(CP, ch[0], ch[1]); d2 = seg_dist(CP, ch[1], ch[2]); d3 = seg_dist(CP, ch[2], ch[3]); dm = np.minimum(np.minimum(d1, d2), d3)
    side = sstep(0.38, 0.62, x * sg); a = np.exp(-(dm / 0.34) ** 2) * side * (y > 1.0) * (y < 2.5)
    # which of upper / fore / hand: nearest segment, with the hand taking the tail
    near = np.stack([d1, d2, d3], 1); wsel = np.exp(-(near / 0.18) ** 2); wsel /= wsel.sum(1, keepdims=True) + 1e-9
    armw[s] = (a, wsel)
a_tot = np.maximum(armw['L'][0], armw['R'][0])
base = np.zeros((len(CP), nb))
for i, n in enumerate(names): base[:, idx[n]] = core[:, i] * (1 - rb) * (1 - a_tot)
# hood tip + jaw lip: inside the head band
hoodw = sstep(3.15, 3.6, y) * (1 - a_tot); base[:, idx['hood']] = base[:, idx['head']] * hoodw; base[:, idx['head']] *= (1 - hoodw)
jawm = sstep(2.75, 3.0, y) * (1 - sstep(3.05, 3.3, y)) * sstep(0.0, 0.25, z) * (1 - sstep(0.25, 0.5, np.abs(x))); base[:, idx['jaw']] = base[:, idx['head']] * jawm * 0.7; base[:, idx['head']] *= (1 - jawm * 0.7)
# robe chains
for ci, c in enumerate(['F', 'B', 'L', 'R']):
    w = rb * sect[:, ci] * (1 - a_tot)
    base[:, idx['robe_%s1' % c]] += w * (1 - seg2); base[:, idx['robe_%s2' % c]] += w * seg2
    base[:, idx['pelvis']] += 0                     # (the pelvis share of the hem is what remains of core * (1-rb))
base[:, idx['pelvis']] += core.sum(1) * 0 + (rb * (1 - sect.sum(1)) * (1 - a_tot))
for s in ('L', 'R'):
    a, wsel = armw[s]
    for k2, n in enumerate(['upperarm_', 'forearm_', 'hand_']):
        pass
    base[:, idx['upperarm_' + s]] += a * wsel[:, 0]; base[:, idx['forearm_' + s]] += a * wsel[:, 1]; base[:, idx['hand_' + s]] += a * wsel[:, 2]
# the share of the arm zone not taken by the arm goes to the chest / spine (soft attachment)
rem = np.clip(1 - base.sum(1), 0, 1); base[:, idx['chest']] += rem * (y > 1.9); base[:, idx['spine']] += rem * (y <= 1.9)
base /= base.sum(1, keepdims=True) + 1e-9
top = np.argsort(-base, axis=1)[:, :4]; Wk = np.take_along_axis(base, top, 1); Wk /= Wk.sum(1, keepdims=True) + 1e-9
Wb = np.round(Wk * 255).astype(int); Wb[:, 0] += 255 - Wb.sum(1); Wb = np.clip(Wb, 0, 255)

# ---------------------------------------------------------------- meta (face hollow measured on the model)
hs = (np.abs(x) < 0.3) & (y > 3.15) & (y < 3.6)
zf = np.percentile(z[hs], 92); print('face hollow front z %.2f' % zf)
EYE_Y = 3.38; EX = 0.17; EZ = float(zf) - 0.12
meta = dict(rig=dict(bones=[dict(n=b[0], p=b[1], t=[round(float(v), 4) for v in b[2]]) for b in B]), height=HEIGHT, head=dict(c=[0, 3.2, 0.1], r=0.62),
            eyeL=[-EX, EYE_Y, EZ], eyeR=[EX, EYE_Y, EZ], mouth=[0, 3.0, float(zf)], bbox=dict(lo=[float(P[:, 0].max()), 0, float(P[:, 2].min())], hi=[float(P[:, 0].min()), HEIGHT, float(P[:, 2].max())]), fingerLen=0.145)
b64 = lambda a: base64.b64encode(a.tobytes()).decode()
mesh = dict(groups=[dict(name='body', start=0, count=int(len(tri) * 3))], nv=int(len(CP)), p=b64(CP.astype('<f4')), n=b64(np.round(CN * 127).astype(np.int8)),
            c=b64(np.round(CC * 255).astype(np.uint8)), i=b64(tri.astype('<u2').flatten()), j=b64(top.astype(np.uint8)), w=b64(Wb.astype(np.uint8)), meta=meta)

# ---------------------------------------------------------------- write into data/models.js (old dealer removed)
js = open(MODELS, encoding='utf-8').read(); a = js.index('G.MODELS=') + len('G.MODELS='); b = js.rindex(';})(')
M = json.loads(js[a:b]); M['dealer'] = mesh
head = js[:js.index('(function(G){')]
open(MODELS, 'w', encoding='utf-8').write('/* generated by tools/build-models.js (table, gun) + tools/build-ghost-dealer.py (dealer = the supplied ghost) — do not edit */\n(function(G){G.MODELS=' + json.dumps(M, separators=(',', ':')) + js[b:])
print('models.js keys', list(M), '%.2f MB' % (os.path.getsize(MODELS) / 1e6))
