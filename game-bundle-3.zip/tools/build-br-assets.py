#!/usr/bin/env python3
"""build-br-assets.py — converts the supplied 'shotgun with hands' FBX (tools/br/source) into data/br-assets.js.

What it does (everything is derived from the FBX itself, nothing is re-modelled):
  * gun parts   : the original meshes (receiver, barrel/tube parts, stock, forearm/pump, bolt carrier), original UVs/normals
  * both hands  : the two original hand meshes. The file carries NO skin weights (the FBX has only a Null-node armature), so the
                  20-bone skeleton (original bone names/hierarchy/proportions of Armature_005) is fitted to each hand mesh and the
                  skin weights are computed (finger segmentation by geodesic merge-tree, see tools/br/handfit.py)
  * textures    : the original PNGs embedded in the FBX, embedded byte-identical (as data: URIs so WebGL can use them from file://)
Frames: everything is expressed in the game's gun frame (+X muzzle, +Y up, +Z gun-right) with the bore axis on Y=Z=0, scaled so the
gun is 3.81 units long (the length of the previous gun, so the rest of the game keeps working). Hands are stored in their own wrist
frame (+Z from the wrist into the hand, +Y palm normal) together with the file-exact placement of that frame on the gun.
usage: python3 tools/build-br-assets.py
"""
import sys, os, json, base64, collections
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, 'br'))
from fbxscene import load, geometry, nm
import handfit as HF

SRC = os.path.join(HERE, 'br', 'source', 'shotgun_with_hands2.fbx')
TEXDIR = os.path.join(HERE, 'br', 'textures')
OUT = os.path.join(HERE, '..', 'data', 'br-assets.js')
GUN_LEN = 3.81

S = load(SRC); byid = S.byid; idx = {nm(byid[i]): i for i in S.models}
gp = idx['shotgun parent_003']; Ginv = np.linalg.inv(S.world[gp])

def raw_geo(name):
    i = idx[name]; g = [byid[a] for a, k, _ in S.links[i] if k == 'Geometry'][0]; return i, geometry(g)

def gun_space_verts(name):
    i, (V, polys, N, UV, MA) = raw_geo(name)
    return (Ginv @ S.world[i] @ np.c_[V, np.ones(len(V))].T).T[:, :3]

PARTS = ['meshes[0]-0', 'meshes[0]-1', 'meshes[0]-2', 'shotgun parent_004', 'shotgun-forearm_003', 'shotgun_bolt carrier_003']
allp = np.concatenate([gun_space_verts(p) for p in PARTS])
y0, y1 = allp[:, 1].min(), allp[:, 1].max()
s = GUN_LEN / (y1 - y0); ycen = (y0 + y1) / 2
# bore axis: the upper tube's muzzle ring (barrel) at the front end of 'shotgun parent_004'
P4 = gun_space_verts('shotgun parent_004'); ring = P4[(P4[:, 1] > y1 - 0.15) & (P4[:, 2] > 0.05)]
zbore = (ring[:, 2].min() + ring[:, 2].max()) / 2; xbore = (ring[:, 0].min() + ring[:, 0].max()) / 2
print('gun: length(file)=%.3f scale=%.5f ycen=%.3f bore(x,z)=(%.3f,%.3f)' % (y1 - y0, s, ycen, xbore, zbore))
# file gun-parent space (x side, y muzzle, z up) -> game gun frame (x muzzle, y up, z side)
P3 = np.array([[0, 1, 0], [0, 0, 1], [1, 0, 0]], float) * s
T0 = -np.array([ycen * s, zbore * s, xbore * s])
C = np.eye(4); C[:3, :3] = P3; C[:3, 3] = T0; C = C @ Ginv          # world(file) -> game gun frame

def corners(name, key_tol=(1e-3, 1e-4)):
    """per-corner unique vertices in the game gun frame. returns dict(pos, nrm, uv, tri, vid)"""
    i, (V, polys, N, UV, MA) = raw_geo(name); W = C @ S.world[i]; R = W[:3, :3] / s
    Vg = (W @ np.c_[V, np.ones(len(V))].T).T[:, :3]
    pos, nrm, uv, vid, tri = [], [], [], [], []; seen = {}; ci = 0
    def get(layer, c, comp):
        mp, rf, d, ix = layer
        if mp == 'ByPolygonVertex':
            k = ix[c] if (rf == 'IndexToDirect' and ix is not None) else c
        else: raise RuntimeError('mapping ' + mp)
        return d[k * comp:(k + 1) * comp]
    for poly in polys:
        ids = []
        for v in poly:
            n = get(N, ci, 3); n = R @ n; n = n / (np.linalg.norm(n) + 1e-12); u = get(UV, ci, 2); ci += 1
            key = (v, tuple(np.round(n, 3)), tuple(np.round(u, 4)))
            if key not in seen:
                seen[key] = len(pos); pos.append(Vg[v]); nrm.append(n); uv.append(u); vid.append(v)
            ids.append(seen[key])
        for k in range(1, len(ids) - 1): tri.append((ids[0], ids[k], ids[k + 1]))
    return dict(pos=np.array(pos), nrm=np.array(nrm), uv=np.array(uv), tri=np.array(tri, int), vid=np.array(vid, int), raw=(V, polys))

def r(a, n): return np.round(np.asarray(a, float), n).tolist()
def rf(a, n): return np.round(np.asarray(a, float), n).flatten().tolist()      # flat x,y,z,x,y,z... (what the GL mesh upload expects)

# ---------------------------------------------------------------- gun meshes
MATKEY = {'metal24': 'metal', 'metal24 painted': 'paint', 'wood worn': 'wood', 'dealer hand_left': 'skin'}
def mat_of(name):
    i = idx[name]; m = [nm(byid[a]) for a, k, _ in S.links[i] if k == 'Material'][0]; return MATKEY[m]

def pack(parts, order):
    """merge parts into one vertex/index buffer, index ranges grouped by material in `order`"""
    P, Nn, U = [], [], []; groups = []; idxs = []; base = 0; data = {}
    for p in parts: data[p] = corners(p)
    out_idx = []
    for mk in order:
        start = sum(len(g) for g in out_idx)
        cnt = 0
        for p in parts:
            if mat_of(p) != mk: continue
            d = data[p]; off = len(P); P += d['pos'].tolist(); Nn += d['nrm'].tolist(); U += d['uv'].tolist()
            out_idx.append((d['tri'] + off).flatten().tolist()); cnt += d['tri'].size
        if cnt: groups.append([mk, start, cnt])
    flat = [i for g in out_idx for i in g]
    return dict(p=rf(np.array(P), 4), n=rf(np.array(Nn), 3), t=rf(np.array(U), 4), i=flat, g=groups)

body = pack(['meshes[0]-0', 'meshes[0]-1', 'meshes[0]-2', 'shotgun parent_004'], ['metal', 'wood', 'paint'])
pump = pack(['shotgun-forearm_003', 'shotgun_bolt carrier_003'], ['wood', 'paint'])
bp = np.array(body['p']).reshape(-1, 3); pp = np.array(pump['p']).reshape(-1, 3)
print('body verts %d tris %d groups %s | pump verts %d tris %d groups %s' % (len(bp), len(body['i']) // 3, body['g'], len(pp), len(pump['i']) // 3, pump['g']))
allg = np.concatenate([bp, pp])
muzzle_x = allg[:, 0].max(); butt_x = allg[:, 0].min()
print('game-frame bounds min %s max %s' % (np.round(allg.min(0), 3), np.round(allg.max(0), 3)))
# shell socket (Null) -> game frame
sock = idx['shotgun_pos shell_003']; eject = (C @ np.r_[S.world[sock][:3, 3], 1])[:3]
fore = idx['shotgun-forearm_003']
print('forearm x range (game) %.3f..%.3f ; receiver max x %.3f' % (pp[:, 0].min(), pp[:, 0].max(), np.array(corners('meshes[0]-2')['pos'])[:, 0].max()))

# ---------------------------------------------------------------- hands
BONE_ORDER = ['wrist', 'thumb1', 'thumb2', 'thumb3', 'index0', 'middle0', 'ring0', 'pinky0', 'index1', 'index2', 'index3', 'middle1', 'middle2', 'middle3', 'ring1', 'ring2', 'ring3', 'pinky1', 'pinky2', 'pinky3']
assert [HF.ROLE2BONE[b] for b in BONE_ORDER] == HF.ARM_NAMES, 'bone order must follow the original Bone, Bone_001 ... Bone_019 order'
PARENT = {'wrist': None, 'thumb1': 'wrist', 'thumb2': 'thumb1', 'thumb3': 'thumb2'}
for f in HF.FINGERS: PARENT[f + '0'] = 'wrist'; PARENT[f + '1'] = f + '0'; PARENT[f + '2'] = f + '1'; PARENT[f + '3'] = f + '2'

def smooth_weights(W, nb, iters=2, lam=0.5):
    for _ in range(iters):
        Wn = W.copy()
        for v in range(len(W)):
            if not nb[v]: continue
            avg = np.mean([W[u] for u in nb[v]], axis=0); Wn[v] = (1 - lam) * W[v] + lam * avg
        W = Wn
    for v in range(len(W)):
        k = np.argsort(-W[v])[4:]; W[v, k] = 0; W[v] /= W[v].sum()
    return W

def build_hand(name, tag):
    c = corners(name); i = idx[name]; V, polys = c['raw']
    T = np.array(polys); assert T.shape[1] == 3
    Vw, Tw, remap = HF.weld(V, T)
    rig = HF.rig_hand(Vw, Tw); sk = HF.build_skeleton(rig)
    bones = [b for b in BONE_ORDER]; col = {b: k for k, b in enumerate(sk['bones'])}
    W = np.zeros((len(Vw), len(bones)))
    for k, b in enumerate(bones): W[:, k] = sk['weights'][:, col[b]]
    W = smooth_weights(W, rig['nb'])
    # hand-local (file) -> game gun frame
    Hg = C @ S.world[i]; Rg = Hg[:3, :3] / s
    def pt(p): return (Hg @ np.r_[p, 1])[:3]
    def dr(d): v = Rg @ np.asarray(d, float); return v / (np.linalg.norm(v) + 1e-12)
    fwd = dr(sk['fwd']); pn = dr(sk['pn']); pn = pn - (pn @ fwd) * fwd; pn /= np.linalg.norm(pn); xw = np.cross(pn, fwd)
    E = np.stack([xw, pn, fwd], 1)       # columns: wrist-frame axes in the game gun frame
    o = pt(sk['wc'])
    def to_w(p): return E.T @ (np.asarray(p, float) - o)
    def dir_w(d): return E.T @ dr(d)
    # vertices (corners) in the wrist frame
    pos_w = np.array([to_w(p) for p in c['pos']]); nrm_w = np.array([E.T @ n for n in c['nrm']])
    # weights per corner
    jn = np.zeros((len(c['vid']), 4), int); wt = np.zeros((len(c['vid']), 4))
    for k, v in enumerate(c['vid']):
        ww = W[remap[v]]; top = np.argsort(-ww)[:4]; jn[k] = top; wt[k] = ww[top] / ww[top].sum()
    # bones in the wrist frame (head/tail) + radius estimate
    J = {b: to_w(pt(sk['J'][b])) for b in bones}; Tl = {b: to_w(pt(sk['tail'][b])) for b in bones}
    wpos = np.array([to_w(pt(p)) for p in Vw]); rad = {}
    for k, b in enumerate(bones):
        sel = np.where(W[:, k] > 0.5)[0]
        if len(sel):
            d, _ = HF.point_seg(wpos[sel], J[b], Tl[b]); rad[b] = float(np.median(d))
        else: rad[b] = 0.05
    axes = {f: dir_w(sk['axis'][f]) for f in sk['axis']}
    # wrist radius (cuff) from the cap vertices
    cap = np.array([to_w(pt(Vw[v])) for v in rig['cv']]); wr = float(np.mean(np.linalg.norm(cap[:, :2], axis=1)))
    thumb_side = float(np.sign(np.mean([J['thumb2'][0]])))
    frame = np.concatenate([xw, pn, fwd, o])          # gun-frame placement of the wrist frame (3 axes + origin)
    print('%s: corners %d tris %d | wrist origin %s fwd %s palmN %s | cuff radius %.3f | thumb side x=%+d' % (tag, len(pos_w), len(c['tri']), np.round(o, 3), np.round(fwd, 3), np.round(pn, 3), wr, thumb_side))
    return dict(p=rf(pos_w, 4), n=rf(nrm_w, 3), t=rf(c['uv'], 4), i=c['tri'].flatten().tolist(), j=jn.flatten().tolist(), w=np.round(wt, 3).flatten().tolist(),
                frame=r(frame, 5), cuff=round(wr, 4),
                bones=[dict(n=HF.ROLE2BONE[b], r=b, p=(bones.index(PARENT[b]) if PARENT[b] else -1), h=r(J[b], 4), t=r(Tl[b], 4), rad=round(rad[b], 4)) for b in bones],
                axes={f: r(axes[f], 4) for f in axes}, ang={b: round(float(sk['ang'][b]), 4) for b in sk['ang']}, palmN=[0, 1, 0],
                side=thumb_side, mat=mat_of(name))

handR = build_hand('dealer hand_shotgun right', 'R'); handL = build_hand('dealer hand shotgun_left', 'L')

# ---------------------------------------------------------------- textures (byte-identical PNGs from the FBX)
def datauri(fn):
    b = open(os.path.join(TEXDIR, fn), 'rb').read(); return 'data:image/png;base64,' + base64.b64encode(b).decode()
# the FBX also carries tangent-space normal maps (metal, metal painted, wood); they are measured to be almost flat (mean |n-up| < 0.03) and the
# renderer does not do normal mapping, so they are NOT shipped in the game data (the source PNGs stay in tools/br/textures/).
TEX = {'metal': datauri('metal_diffuse.png'), 'paint': datauri('metal_painted_diffuse.png'), 'wood': datauri('wood_diffuse.png'), 'skin': datauri('skin_diffuse.png')}

meta = dict(len=GUN_LEN, scale=s, muzzle=[muzzle_x, 0, 0], butt=[butt_x, 0, 0], eject=r(eject, 4), pumpTravel=0.46,
            bounds=[r(allg.min(0), 4), r(allg.max(0), 4)], armature=dict(names=HF.ARM_NAMES, roles=BONE_ORDER))
BR = dict(v=5, meta=meta, body=body, pump=pump, hands=dict(R=handR, L=handL), tex=TEX)
js = '/* generated by tools/build-br-assets.py from the supplied "shotgun with hands" FBX — do not edit */\n(function(G){G.BR=' + json.dumps(BR, separators=(',', ':')) + ';})(typeof window!==\'undefined\'?window:globalThis);\n'
open(OUT, 'w').write(js)
print('wrote %s (%.2f MB)' % (os.path.relpath(OUT), len(js) / 1e6))
