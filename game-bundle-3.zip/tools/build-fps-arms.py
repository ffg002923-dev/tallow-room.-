#!/usr/bin/env python3
"""build-fps-arms.py — converts the supplied first-person-arms FBX (tools/fps/source/fpsarms.fbx) into data/fps-arms.js.

Unlike the old shotgun FBX (no skin weights, skeleton had to be fitted), this file carries a REAL skeleton and REAL skin weights
(24 bones per arm: arm, elbow, wrist, palm, thumb1-4, point/middle/ring/pink 1-4). Nothing is fitted or re-modelled:
  * mesh, normals, UVs, skin weights are the file's own (bind pose = Wn @ V, see notes below)
  * the 24 file bones are mapped onto the game's 20-role rig (wrist, thumb1-3, index0..pinky0 (rigid metacarpals), index1-3 ... pinky1-3):
        wrist <- arm + elbow + wrist + palm (rigid)      indexN <- pointN   middleN <- middleN   ringN <- ringN   pinkyN <- pinkN   (N=1..3, tip bone 4 merged into 3)
  * the hand is baked into the same "grip pose" convention as the previous hands (mesh + bones are stored posed at hand.ang, hands.js bends
    relative to it) using the previous hands' joint angles, so the gun sockets / grip solver / hand states keep working;
    then the baked hand is rigidly (+ uniform scale) aligned to the previous hand's key points, so the old gun placement (`frame`) still fits.
  * the forearm is kept for a short length behind the wrist and closed with a cap.
Output replaces BR.hands and BR.tex.skin at load time (loaded after data/br-assets.js).
usage: python3 tools/build-fps-arms.py
"""
import sys, os, json, base64, io, subprocess
import numpy as np
from PIL import Image
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, 'br'))
from fbxscene import load, geometry, nm

SRC = os.path.join(HERE, 'fps', 'source', 'fpsarms.fbx'); TEXD = os.path.join(HERE, 'fps', 'textures')
OUT = os.path.join(HERE, '..', 'data', 'fps-arms.js')
OLD = os.path.join(HERE, '..', 'data', 'br-assets.js')
TEXSIZE = 1024
CAPSULE_K = 0.72
CUT_BACK = 0.30         # forearm kept behind the wrist, in game units (hand length ~0.75)

S = load(SRC); byid = S.byid; idx = {nm(byid[i]): i for i in S.models}
mi = idx['armsmesh']; geo = [byid[a] for a, k, _ in S.links[mi] if k == 'Geometry'][0]
V0, polys, NL, UVL, MA = geometry(geo)
Wn = S.world[mi]
clusters = {}
for o in byid.values():
    if o.name == 'Deformer' and o.props[2] == 'Cluster':
        ms = [a for a, k, _ in S.links[o.props[0]] if k == 'Model']; b = nm(byid[ms[0]])
        ix = o.first('Indexes'); wt = o.first('Weights')
        clusters[b] = dict(tl=np.array(o.first('TransformLink').props[0]).reshape(4, 4).T,
                           ix=np.array(ix.props[0], int) if ix else np.zeros(0, int), w=np.array(wt.props[0], float) if wt else np.zeros(0))
# bind pose: vertices = Wn @ V (verified: cluster means sit on their bones), bones = TransformLink translations
Vb = (Wn @ np.c_[V0, np.ones(len(V0))].T).T[:, :3]; Rn = Wn[:3, :3] / np.cbrt(abs(np.linalg.det(Wn[:3, :3])))
BIND = {b: c['tl'][:3, 3].copy() for b, c in clusters.items()}

ROLES = ['wrist', 'thumb1', 'thumb2', 'thumb3', 'index0', 'middle0', 'ring0', 'pinky0', 'index1', 'index2', 'index3', 'middle1', 'middle2', 'middle3',
         'ring1', 'ring2', 'ring3', 'pinky1', 'pinky2', 'pinky3']
PAR = {'wrist': None, 'thumb1': 'wrist', 'thumb2': 'thumb1', 'thumb3': 'thumb2'}
FINGERS = ['index', 'middle', 'ring', 'pinky']; FILE = {'index': 'point', 'middle': 'middle', 'ring': 'ring', 'pinky': 'pink'}
for f in FINGERS:
    PAR[f + '0'] = 'wrist'; PAR[f + '1'] = f + '0'; PAR[f + '2'] = f + '1'; PAR[f + '3'] = f + '2'
OLDNAMES = ['Bone'] + ['Bone_%03d' % i for i in range(1, 20)]

def role_of(side, bone):
    """file bone name -> game role (None = ignore). side 'L'/'R'"""
    if not bone.startswith(side + '_'): return None
    b = bone[2:]
    if b in ('arm', 'elbow', 'wrist', 'palm'): return 'wrist'
    if b.startswith('thumb'): return 'thumb' + str(min(int(b[5]), 3))
    for f in FINGERS:
        if b.startswith(FILE[f]): return f + str(min(int(b[len(FILE[f])]), 3))
    return None

def unit(v): v = np.asarray(v, float); return v / (np.linalg.norm(v) + 1e-12)
def rot(a, ang):
    a = unit(a); c, s, t = np.cos(ang), np.sin(ang), 1 - np.cos(ang); x, y, z = a
    return np.array([[c + x * x * t, x * y * t - z * s, x * z * t + y * s], [y * x * t + z * s, c + y * y * t, y * z * t - x * s], [z * x * t - y * s, z * y * t + x * s, c + z * z * t]])

# ------------------------------------------------------------------ old hands (target convention + gun-socket key points)
def load_old():
    js = open(OLD).read(); a = js.index('G.BR=') + 5; b = js.rindex(';})(typeof window')
    return json.loads(js[a:b])
OLDBR = load_old(); OH = OLDBR['hands']
_ch = lambda h: sum(np.linalg.norm(np.array(b['t']) - np.array(b['h'])) for b in h['bones'] if b['r'] in ('wrist', 'middle0', 'middle1', 'middle2', 'middle3'))
SCALE_MEAN = (_ch(OH['R']) + _ch(OH['L'])) / 2        # both new hands share one scale (the old fitted skeletons differ by ~15%)

def corners_all():
    """per-corner unique vertices (pos in bind space, normal, uv, original vertex id) + triangles"""
    def get(layer, c, comp):
        mp, rf, d, ix = layer; k = ix[c] if (rf == 'IndexToDirect' and ix is not None) else c
        return d[k * comp:(k + 1) * comp]
    pos, nrm, uv, vid, tri = [], [], [], [], []; seen = {}; ci = 0
    for poly in polys:
        ids = []
        for v in poly:
            n = Rn @ get(NL, ci, 3); n = n / (np.linalg.norm(n) + 1e-12); u = get(UVL, ci, 2); ci += 1
            key = (v, tuple(np.round(n, 3)), tuple(np.round(u, 4)))
            if key not in seen: seen[key] = len(pos); pos.append(Vb[v]); nrm.append(n); uv.append(u); vid.append(v)
            ids.append(seen[key])
        for k in range(1, len(ids) - 1): tri.append((ids[0], ids[k], ids[k + 1]))
    return np.array(pos), np.array(nrm), np.array(uv), np.array(vid), np.array(tri, int)
CP, CN, CUV, CV, CT = corners_all()

def build_hand(side):
    # ---- weights per corner on the game roles
    col = {r: k for k, r in enumerate(ROLES)}; Wv = np.zeros((len(V0), len(ROLES)))
    for b, c in clusters.items():
        r = role_of(side, b)
        if r is None: continue
        Wv[c['ix'], col[r]] += c['w']
    tot = Wv.sum(1); mine = tot > 0.5
    # ---- frame from the file's bind skeleton
    g = lambda n: BIND[side + '_' + n]
    wrist = g('wrist'); palm = g('palm'); mcp = {f: g(FILE[f] + '1') for f in FINGERS}
    fwd = unit(np.mean([mcp[f] for f in FINGERS], 0) - wrist)
    lat = unit(mcp['index'] - mcp['pinky']); pn = unit(np.cross(fwd, lat))
    # curl direction of the bind fingers must be towards the palm normal; flip otherwise
    curl = np.mean([(g(FILE[f] + '4') - mcp[f]) - ((g(FILE[f] + '4') - mcp[f]) @ fwd) * fwd for f in FINGERS], 0)
    if curl @ pn < 0: pn = -pn
    pn = unit(pn - (pn @ fwd) * fwd); xw = unit(np.cross(pn, fwd))
    thumb_side = float(np.sign((g('thumb2') - wrist) @ xw))
    E = np.stack([xw, pn, fwd], 1)           # columns = wrist frame axes in file space
    print('%s: thumb side %+d  palmN(file) %s  fwd %s' % (side, thumb_side, np.round(pn, 2), np.round(fwd, 2)))
    # ---- bones (file bind) in the wrist frame, un-scaled
    def P(n): return E.T @ (g(n) - wrist)
    H, T = {}, {}
    H['wrist'] = P('wrist'); T['wrist'] = P('palm')
    base = P('palm')
    for r in ROLES:
        if r == 'wrist': continue
        if r.startswith('thumb'):
            n = int(r[5]); H[r] = P('thumb%d' % n); T[r] = P('thumb%d' % (n + 1))
        elif r.endswith('0'):
            f = r[:-1]; H[r] = base.copy(); T[r] = P(FILE[f] + '1')
        else:
            f, n = r[:-1], int(r[-1]); H[r] = P(FILE[f] + str(n)); T[r] = P(FILE[f] + str(n + 1))
    # thumb1 here is CMC->MCP, the old rig thumb1 head = hand base: keep the file's own thumb1 origin
    VP = (E.T @ (CP - wrist).T).T; NP = (E.T @ CN.T).T
    # ---- scale: file hand length -> game hand length (wrist head to middle fingertip, previous hand = 1:1 with the gun)
    oh = OH['R' if side == 'R' else 'L']; ob = {b['r']: b for b in oh['bones']}
    chain = ['wrist', 'middle0', 'middle1', 'middle2', 'middle3']      # pose independent length: sum of the bone lengths along the middle finger
    old_len = sum(np.linalg.norm(np.array(ob[r]['t']) - np.array(ob[r]['h'])) for r in chain)
    new_len = sum(np.linalg.norm(T[r] - H[r]) for r in chain); sc = SCALE_MEAN / new_len; old_len = SCALE_MEAN
    print('   hand length old %.3f new %.2f -> scale %.4f' % (old_len, new_len, sc))
    VP *= sc; H = {k: v * sc for k, v in H.items()}; T = {k: v * sc for k, v in T.items()}

    # ---- bake to the old grip pose: bend each finger chain about a constant axis so that absolute joint angles == old ang
    ang_old = oh['ang']; axes = {}; fingd = {}
    for f in FINGERS:
        d = unit(T[f + '3'] - H[f + '1']); axes[f] = unit(np.cross(d, [0, 1, 0])); axes[f] = unit(axes[f] - (axes[f] @ d) * d)
    thumb_d = unit(T['thumb3'] - H['thumb2']); axes['thumb'] = unit(np.cross(thumb_d, [0, 1, 0])); axes['thumb'] = unit(axes['thumb'] - (axes['thumb'] @ thumb_d) * thumb_d)
    def signed(a, b, ax): a = unit(a); b = unit(b); return float(np.arctan2(np.cross(a, b) @ ax, a @ b))
    bind_ang = {}
    for f in FINGERS:
        ax = axes[f]; ds = [T[f + '0'] - H[f + '0'], T[f + '1'] - H[f + '1'], T[f + '2'] - H[f + '2'], T[f + '3'] - H[f + '3']]
        for n in (1, 2, 3): bind_ang[f + str(n)] = signed(ds[n - 1], ds[n], ax)
    ax = axes['thumb']; td = [T['thumb1'] - H['thumb1'], T['thumb2'] - H['thumb2'], T['thumb3'] - H['thumb3']]
    bind_ang['thumb2'] = signed(td[0], td[1], ax); bind_ang['thumb3'] = signed(td[1], td[2], ax)
    # joints in order, rotation = target - bind; thumb1 stays rigid
    S4 = {r: (np.eye(3), np.zeros(3)) for r in ROLES}      # (R, t) skinning transform of each bone
    def local(r, th):
        f = r[:-1] if r[:-1] in FINGERS else 'thumb'; Pj = H[r]; R = rot(axes[f], th); return R, Pj - R @ Pj
    for r in ROLES:
        p = PAR[r]; Rp, tp = S4[p] if p else (np.eye(3), np.zeros(3))
        if r in bind_ang:
            th = ang_old.get(r, 0.0) - bind_ang[r]; Rl, tl = local(r, th)
            S4[r] = (Rp @ Rl, Rp @ tl + tp)
        else: S4[r] = (Rp, tp)
    # skinned (baked) vertices
    keep_w = Wv.copy(); keep_w[~mine] = 0
    cw = keep_w[CV]; cw = cw / np.maximum(cw.sum(1, keepdims=True), 1e-9)
    PV = np.zeros_like(VP); PN = np.zeros_like(NP)
    for k, r in enumerate(ROLES):
        Rk, tk = S4[r]; w = cw[:, k:k + 1]
        if not w.any(): continue
        PV += w * (VP @ Rk.T + tk); PN += w * (NP @ Rk.T)
    PN = PN / (np.linalg.norm(PN, axis=1, keepdims=True) + 1e-12)
    Hp = {r: S4[r][0] @ H[r] + S4[r][1] for r in ROLES}; Tp = {r: S4[r][0] @ T[r] + S4[r][1] for r in ROLES}
    # axes after baking: finger axes unchanged (planar chain about one axis), thumb chain is rigid-free so unchanged too
    # ---- rigid alignment onto the old hand's key points (keeps the old gun frame valid)
    keys_new, keys_old = [], []
    for r in ['wrist', 'thumb1', 'thumb2', 'thumb3'] + [f + str(n) for f in FINGERS for n in (1, 2, 3)]:
        keys_new.append(Hp[r]); keys_old.append(np.array(ob[r]['h'])); keys_new.append(Tp[r]); keys_old.append(np.array(ob[r]['t']))
    A = np.array(keys_new); B = np.array(keys_old); ca, cb = A.mean(0), B.mean(0)
    Hm = (A - ca).T @ (B - cb); U, _, Vt = np.linalg.svd(Hm); d = np.sign(np.linalg.det(Vt.T @ U.T)); Rr = Vt.T @ np.diag([1, 1, d]) @ U.T; tr = cb - Rr @ ca
    fit = np.sqrt(np.mean(np.sum(((A @ Rr.T + tr) - B) ** 2, 1)))
    print('   rigid fit rms to old key points: %.4f (hand length %.2f)' % (fit, old_len))
    al = lambda X: X @ Rr.T + tr; ald = lambda X: X @ Rr.T
    PV = al(PV); PN = ald(PN)
    Hp = {r: al(Hp[r]) for r in ROLES}; Tp = {r: al(Tp[r]) for r in ROLES}
    axes = {k: unit(Rr @ v) for k, v in axes.items()}

    # ---- keep the hand + a short forearm; cap the cut
    zcut = Hp['wrist'][2] - CUT_BACK
    vz = np.zeros(len(V0)); vsel = np.zeros(len(V0), bool); vsel[CV] = True
    ok_corner = (mine[CV]) & (PV[:, 2] > zcut)
    tri = CT[ok_corner[CT].all(1)]
    # boundary loop (edges used once) -> cap fan
    from collections import Counter
    E_ = Counter()
    for a, b, c in tri:
        for u, v in ((a, b), (b, c), (c, a)): E_[(min(u, v), max(u, v))] += 1
    used = np.unique(tri)
    remap = -np.ones(len(PV), int); remap[used] = np.arange(len(used))
    pos = PV[used]; nrm = PN[used]; uv = CUV[used]; jn = cw[used]; vidu = CV[used]
    tri = remap[tri]
    # ---- v7.8 helper bones: a half-angle 'blend' bone at the proximal and middle joint of every finger and at the thumb MCP (9 extra bones, 29 of 32 joints).
    # Vertices around a joint hand part of the parent/child weight to the helper, which bends half as much: the knuckle rolls instead of creasing.
    HELP = [f + str(n) for f in FINGERS for n in (1, 2)] + ['thumb2']
    hcol = np.zeros((len(jn), len(HELP)))
    for hi, r in enumerate(HELP):
        kk = ROLES.index(r); pp = ROLES.index(PAR[r]); dirv = unit(Tp[r] - Hp[r]); L = np.linalg.norm(Tp[r] - Hp[r]); z = 0.45 * min(L, np.linalg.norm(Tp[PAR[r]] - Hp[PAR[r]]) if PAR[r] != 'wrist' else L)
        sdist = (pos - Hp[r]) @ dirv; hw = 0.85 * np.clip(1 - np.abs(sdist) / max(z, 1e-6), 0, 1); has = jn[:, kk] + jn[:, pp]; hw = np.where(has > 0.3, hw, 0)
        moved = hw * has; jn[:, kk] *= (1 - hw); jn[:, pp] *= (1 - hw); hcol[:, hi] = moved
    jn = np.hstack([jn, hcol]); print('   helper bones: %d (weight moved on %d vertices)' % (len(HELP), int((hcol.sum(1) > 0.05).sum())))
    # cap: boundary vertices lying near the cut plane
    bset = sorted({u for (u, v), n in Counter({(min(remap[a], remap[b]), max(remap[a], remap[b])): 0 for a, b, c in CT[ok_corner[CT].all(1)]}).items()} | set())
    Eb = Counter()
    for a, b, c in tri:
        for u, v in ((a, b), (b, c), (c, a)): Eb[(u, v)] += 1
    bnd = [(u, v) for (u, v) in Eb if Eb.get((v, u), 0) == 0]
    ring = {u for u, v in bnd} | {v for u, v in bnd}
    ring = [u for u in ring if pos[u][2] < zcut + 0.06]
    extra_p, extra_n, extra_t, extra_w = [], [], [], []
    if ring:
        cen = pos[ring].mean(0); base_i = len(pos); extra_p.append(cen); extra_n.append([0, 0, -1.0]); extra_t.append(uv[ring[0]]); w0 = jn[ring].mean(0); extra_w.append(w0)
        ringset = set(ring)
        for u, v in bnd:
            if u in ringset and v in ringset: tri = np.vstack([tri, [base_i, v, u]])
    if extra_p:
        pos = np.vstack([pos, extra_p]); nrm = np.vstack([nrm, extra_n]); uv = np.vstack([uv, extra_t]); jn = np.vstack([jn, extra_w])
    # top-4 weights per corner
    J = np.zeros((len(pos), 4), int); Wt = np.zeros((len(pos), 4))
    for k in range(len(pos)):
        top = np.argsort(-jn[k])[:4]; J[k] = top; Wt[k] = jn[k][top] / max(jn[k][top].sum(), 1e-9)
    # radius estimate per bone (median distance of its dominant vertices to the bone segment)
    def seg_d(Pn, a, b):
        ab = b - a; t = np.clip(((Pn - a) @ ab) / max(ab @ ab, 1e-12), 0, 1); return np.linalg.norm(Pn - (a + t[:, None] * ab), axis=1)
    dom = jn[:, :len(ROLES)].argmax(1); rad = {}
    for k, r in enumerate(ROLES):
        sel = np.where((dom == k) & (jn[np.arange(len(jn)), dom] > 0.5))[0]
        rad[r] = float(np.median(seg_d(pos[sel], Hp[r], Tp[r]))) if len(sel) else 0.05
        if r[-1] in '123' and not r.startswith('thumb1'): rad[r] *= CAPSULE_K     # collision capsule slightly inside the skin (soft glove/finger pads)
    cuffr = float(np.mean(np.linalg.norm((pos[np.array(ring)] - pos[ring].mean(0))[:, :2], axis=1))) if ring else oh['cuff']
    wp = {r: Hp[r] for r in ROLES}
    print('   verts %d tris %d (forearm cut at z=%.3f, cap ring %d verts, cuff r=%.3f)' % (len(pos), len(tri), zcut, len(ring), cuffr))
    r4 = lambda a: np.round(np.asarray(a, float), 4)
    return dict(p=r4(pos).flatten().tolist(), n=np.round(nrm, 3).flatten().tolist(), t=np.round(uv, 4).flatten().tolist(), i=tri.flatten().tolist(),
                j=J.flatten().tolist(), w=np.round(Wt, 3).flatten().tolist(), frame=oh['frame'], cuff=round(cuffr, 4),
                bones=[dict(n=OLDNAMES[k], r=r, p=(ROLES.index(PAR[r]) if PAR[r] else -1), h=r4(Hp[r]).tolist(), t=r4(Tp[r]).tolist(), rad=round(rad[r], 4)) for k, r in enumerate(ROLES)],
                axes={f: r4(axes[f]).tolist() for f in axes}, helpers=HELP, ang={r: round(float(ang_old[r]), 4) for r in ang_old}, palmN=[0, 1, 0], side=oh['side'], mat='skin')

hands = {'R': build_hand('R'), 'L': build_hand('L')}

# ------------------------------------------------------------------ texture: colour x ambient occlusion baked into one 1024 JPEG (the renderer has no normal/roughness maps)
col = Image.open(os.path.join(TEXD, 'armColor.png')).convert('RGB'); ao = Image.open(os.path.join(TEXD, 'armAO.png')).convert('L')
col = col.resize((TEXSIZE, TEXSIZE), Image.LANCZOS); ao = ao.resize((TEXSIZE, TEXSIZE), Image.LANCZOS)
c = np.asarray(col, float) / 255; a = np.asarray(ao, float)[..., None] / 255
img = Image.fromarray(np.clip(c * (0.55 + 0.45 * a) * 255, 0, 255).astype(np.uint8)); buf = io.BytesIO(); img.save(buf, 'JPEG', quality=88)
tex = 'data:image/jpeg;base64,' + base64.b64encode(buf.getvalue()).decode()
js = ('/* generated by tools/build-fps-arms.py from the supplied first-person-arms FBX (real skeleton + skin weights) — do not edit.\n'
      '   Replaces BR.hands and the skin texture of data/br-assets.js. Delete this file / its <script> tag to get the previous hands back. */\n'
      '(function(G){var B=G.BR;if(!B)return;B.hands=' + json.dumps(hands, separators=(',', ':')) + ';B.tex.skin="' + tex + '";B.fpsArms=true;})(typeof window!==\'undefined\'?window:globalThis);\n')
open(OUT, 'w').write(js); print('wrote %s (%.2f MB)' % (os.path.relpath(OUT), len(js) / 1e6))
