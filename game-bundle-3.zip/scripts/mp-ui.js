/* mp-ui.js — PLAY WITH FRIENDS: connect / create / join a room, lobby, and the online match screen (2-4 players, free-for-all).
   The server owns the match; this screen only sends intents (shoot / use item / emote) and renders the masked state the server sends.
   It needs a running server (see server/README.md). */
(function (G) {
  'use strict';
  const U = G.U, D = G.GameData, Save = G.Save, UI = G.UI;
  const $ = (id) => document.getElementById(id), T = () => G.Turns;
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const M = { net: null, lobby: null, view: null, you: null, log: [], names: {}, sel: null, itemSel: null, dl: 0 };
  const URLKEY = 'tallow.mpurl', NAMEKEY = 'tallow.mpname';
  const ls = { get: (k) => { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* ignore */ } } };

  Object.assign(D.strings.en, { 'mp.title': 'PLAY WITH FRIENDS', 'mp.server': 'Server address', 'mp.serverHint': 'e.g. my-game.onrender.com (leave empty when the game is served by the server itself)', 'mp.name': 'Your name', 'mp.connect': 'CONNECT', 'mp.create': 'CREATE ROOM', 'mp.join': 'JOIN', 'mp.code': 'ROOM CODE',
    'mp.ready': 'READY', 'mp.notReady': 'NOT READY', 'mp.start': 'START MATCH', 'mp.leave': 'LEAVE', 'mp.waiting': 'Waiting for players (2–4)…', 'mp.host': 'HOST', 'mp.connecting': 'Connecting…', 'mp.failed': 'Could not reach the server. Check the address and that the server is running.', 'mp.yourTurn': 'YOUR TURN', 'mp.turnOf': "{n}'s turn", 'mp.shootSelf': 'Shoot yourself', 'mp.shoot': 'Shoot {n}', 'mp.eliminated': 'ELIMINATED', 'mp.winner': '{n} wins the match!', 'mp.round': 'Round {n}', 'mp.reconnecting': 'Reconnecting…', 'mp.back': 'Back to menu', 'mp.live': 'LIVE SHELLS', 'mp.blank': 'BLANK SHELLS', 'mp.pickTarget': 'Pick a target for {i}', 'mp.shield': 'shield', 'mp.cuffed': 'cuffed', 'mp.charged': 'charged', 'mp.limit': 'Online mode uses 18 items and the standard weapon.' });
  Object.assign(D.strings.ar, { 'mp.title': 'العب مع الأصدقاء', 'mp.server': 'عنوان الخادم', 'mp.serverHint': 'مثال: my-game.onrender.com (اتركه فارغاً إذا كانت اللعبة تُقدَّم من الخادم نفسه)', 'mp.name': 'اسمك', 'mp.connect': 'اتصال', 'mp.create': 'إنشاء غرفة', 'mp.join': 'انضمام', 'mp.code': 'رمز الغرفة',
    'mp.ready': 'جاهز', 'mp.notReady': 'غير جاهز', 'mp.start': 'ابدأ المباراة', 'mp.leave': 'خروج', 'mp.waiting': 'بانتظار اللاعبين (2–4)…', 'mp.host': 'المضيف', 'mp.connecting': 'جارٍ الاتصال…', 'mp.failed': 'تعذّر الوصول إلى الخادم. تأكد من العنوان ومن أن الخادم يعمل.', 'mp.yourTurn': 'دورك', 'mp.turnOf': 'دور {n}', 'mp.shootSelf': 'أطلق على نفسك', 'mp.shoot': 'أطلق على {n}', 'mp.eliminated': 'خرج', 'mp.winner': '{n} يفوز بالمباراة!', 'mp.round': 'الجولة {n}', 'mp.reconnecting': 'إعادة الاتصال…', 'mp.back': 'العودة للقائمة', 'mp.live': 'LIVE SHELLS', 'mp.blank': 'BLANK SHELLS', 'mp.pickTarget': 'اختر هدفاً لـ {i}', 'mp.shield': 'درع', 'mp.cuffed': 'مقيّد', 'mp.charged': 'مشحون', 'mp.limit': 'اللعب الجماعي يستخدم 18 أداة والسلاح القياسي.' });
  const t = (k, o) => { let s = U.t(k); if (o) for (const x in o) s = s.replace('{' + x + '}', o[x]); return s; };
  const iname = (id) => U.t('item.' + id + '.name');

  /* -------------------------------------------------- screens */
  function root() {
    let r = $('mMP'); if (r) return r;
    r = el('div', 'modal hidden', '<div class="card wide mpcard"><header class="sh-head"><h2 id="mpTitle"></h2><button class="ibtn" id="mpClose" aria-label="Close"><i data-ic="close"></i></button></header><div id="mpBody" class="mpbody"></div></div>');
    r.id = 'mMP'; r.setAttribute('role', 'dialog'); r.setAttribute('aria-modal', 'true'); $('app').appendChild(r);
    $('mpClose').onclick = () => { M.leave(); UI.close('mMP'); }; UI.hydrateIcons(r); return r;
  }
  M.open = function () { root(); $('mpTitle').textContent = t('mp.title'); M.showConnect(); UI.closeAll(); UI.open('mMP'); };
  M.showConnect = function (msg) {
    const b = $('mpBody'); b.innerHTML = '';
    b.appendChild(el('label', 'fld', '<span>' + t('mp.server') + '</span><input id="mpUrl" type="text" autocomplete="off" autocapitalize="off" spellcheck="false" value="' + esc(ls.get(URLKEY)) + '"><small>' + t('mp.serverHint') + '</small>'));
    b.appendChild(el('label', 'fld', '<span>' + t('mp.name') + '</span><input id="mpName" type="text" maxlength="14" value="' + esc(ls.get(NAMEKEY) || 'Player' + ((Math.random() * 900 + 100) | 0)) + '">'));
    b.appendChild(el('label', 'fld', '<span>' + t('mp.code') + '</span><input id="mpCode" type="text" maxlength="6" autocapitalize="characters" style="text-transform:uppercase" placeholder="K7M2Q">'));
    const row = el('div', 'cact'); const bc = el('button', 'abtn primary', t('mp.create')), bj = el('button', 'abtn', t('mp.join')); row.append(bc, bj); b.appendChild(row);
    b.appendChild(el('p', 'cmsg' + (msg ? ' bad' : ''), esc(msg || t('mp.limit')))).id = 'mpMsg';
    bc.onclick = () => M.go('create'); bj.onclick = () => M.go('join');
  };
  M.go = async function (mode) {
    const url = $('mpUrl').value.trim(), name = ($('mpName').value.trim() || 'Player').slice(0, 14), code = $('mpCode').value.trim().toUpperCase();
    ls.set(URLKEY, url); ls.set(NAMEKEY, name); $('mpMsg').className = 'cmsg'; $('mpMsg').textContent = t('mp.connecting');
    try {
      if (M.net) M.net.close();
      const net = M.net = new G.NetClient({ url: url || undefined }); M.wire(net);
      await net.connect();
      const r = mode === 'create' ? await net.createRoom(name, {}, (T().meta.selected || {}).weapon) : await net.joinRoom(code, name, (T().meta.selected || {}).weapon);
      M.you = r && (r.you || r.id) || null;
    } catch (e) { M.showConnect(e && e.message === 'connect_failed' ? t('mp.failed') : (e && (e.message || e.code)) || t('mp.failed')); }
  };
  M.wire = function (net) {
    net.on('lobby', (l) => { M.lobby = l; if (!M.view || l.phase !== 'playing') M.showLobby(); });
    net.on('match', (m) => { M.names = {}; for (const p of m.players) M.names[p.seat] = p.name; M.me = (net.you && net.you.seat) || (m.state && m.state.you); M.view = m.state; M.log = []; M.showMatch(); });
    net.on('matchEvents', (b) => {
      M.dl = b.dl || 0;
      for (const e of b.events) {
        M.logEvent(e);
        if (e.t === 'shot') { M.slapOffer = (e.self && e.type === 'e' && !e.blocked && e.dmg > 0 && e.hp > 0) ? { victim: e.who, until: Date.now() + 6000 } : null; if (M.slapOffer) setTimeout(() => { if (M.slapOffer && Date.now() >= M.slapOffer.until) { M.slapOffer = null; M.showMatch(); } }, 6100); }
        else if (e.t === 'slap') { M.slapOffer = null; M.slapFx(e.from, e.to); }
        else if (e.t === 'roundStart' || e.t === 'turn' || e.t === 'item') M.slapOffer = null;
      }
      net.sync();
    });
    net.on('state', (s) => { M.view = s.state; M.dl = s.dl || M.dl; if (s.state) M.showMatch(); });
    net.on('results', (r) => { M.results = r; M.showMatch(); });
    net.on('emote', (e) => M.emote(e.seat, e.id));
    net.on('status', (s) => { const o = $('mpConn'); if (o) o.textContent = s === 'reconnecting' ? t('mp.reconnecting') : ''; });
    net.on('closed', () => { M.view = null; M.showConnect(t('mp.failed')); const mg = $('mpGame'); if (mg) mg.remove(); UI.open('mMP'); });
    net.on('error', (e) => { const m = $('mpMsg'); if (m) { m.className = 'cmsg bad'; m.textContent = e.message || e.code; } });
  };
  M.leave = function () { try { if (M.net) { M.net.leave(); M.net.close(); } } catch (e) { /* ignore */ } M.net = null; M.view = null; const mg = $('mpGame'); if (mg) mg.remove(); };

  M.showLobby = function () {
    const l = M.lobby, b = $('mpBody'); if (!l || !b || $('mpGame')) return; b.innerHTML = '';
    b.appendChild(el('div', 'roomcode', '<small>' + t('mp.code') + '</small><b>' + esc(l.room) + '</b>'));
    const list = el('ul', 'plist');
    for (const p of l.players) list.appendChild(el('li', p.connected ? '' : 'off', '<span>' + esc(p.name) + (p.host ? ' <em>' + t('mp.host') + '</em>' : '') + '</span><span class="' + (p.ready ? 'rdy' : '') + '">' + (p.ready ? '✓' : '…') + '</span><small>' + (p.ping != null ? Math.round(p.ping) + ' ms' : '') + '</small>'));
    b.appendChild(list); b.appendChild(el('p', 'cmsg', t('mp.waiting')));
    const me = l.players.find((p) => M.net && p.id === (M.net.you && (M.net.you.id || M.net.you))) || l.players.find((p) => p.host === false && false);
    const row = el('div', 'cact'), amHost = me ? me.host : false;
    if (!amHost) { const r = el('button', 'abtn primary', me && me.ready ? t('mp.notReady') : t('mp.ready')); r.onclick = () => M.net.setReady(!(me && me.ready)).catch(() => {}); row.appendChild(r); }
    else { const s = el('button', 'abtn primary', t('mp.start')); s.disabled = l.players.length < 2; s.onclick = () => M.net.startMatch().catch((e) => { $('mpMsg') && 0; UI.toast(String(e.message || e.code || e), 'bad'); }); row.appendChild(s); }
    const lv = el('button', 'abtn', t('mp.leave')); lv.onclick = () => { M.leave(); M.showConnect(); }; row.appendChild(lv); b.appendChild(row);
  };

  /* -------------------------------------------------- match */
  M.logEvent = function (e) {
    const n = (s) => esc(M.names[s] || s); let s = '';
    switch (e.t) {
      case 'roundStart': s = t('mp.round', { n: e.round }); break;
      case 'shot': s = n(e.who) + (e.self ? ' → ' + n(e.who) : ' → ' + n(e.target)) + ': ' + (e.type === 'e' ? 'LIVE SHELL' + (e.blocked ? ' (blocked)' : ' −' + e.dmg) : 'BLANK SHELL'); break;
      case 'item': s = n(e.who) + ' · ' + iname(e.id); break;
      case 'death': s = n(e.who) + ' — ' + t('mp.eliminated'); break;
      case 'reload': s = 'Reload: ' + e.e + ' LIVE / ' + e.a + ' BLANK'; break;
      case 'skip': s = n(e.who) + ' (cuffed) skips'; break;
      case 'roundEnd': s = e.winner ? n(e.winner) + ' wins the round' : 'Round drawn'; break;
      case 'matchEnd': s = t('mp.winner', { n: e.winner ? M.names[e.winner] || e.winner : '—' }); break;
      case 'forfeit': s = n(e.who) + ' left'; break;
      default: return;
    }
    M.log.push(s); if (M.log.length > 40) M.log.shift();
    if (G.Show && G.Show.subtitle) { /* subtitles belong to the dealer scene; online log is shown in-panel */ }
  };
  M.showMatch = function () {
    const v = M.view; if (!v) return; UI.close('mMP');
    let g = $('mpGame'); if (!g) { g = el('div', 'mpgame'); g.id = 'mpGame'; $('app').appendChild(g); }
    const me = v.you, mine = v.players[me], myTurn = v.turn === me && v.phase === 'play' && mine && mine.alive;
    let h = '<div class="mphead"><b>' + t('mp.round', { n: v.round }) + '</b><span class="mpshells"><i class="pip ember"></i> ' + v.pub.e + ' ' + t('mp.live') + ' · <i class="pip ash"></i> ' + v.pub.a + ' ' + t('mp.blank') + '</span><span id="mpConn"></span><button class="tbtn" id="mpQuit">' + t('mp.leave') + '</button></div><div class="mpseats">';
    for (const s of v.seats) {
      const p = v.players[s], turn = v.turn === s;
      h += '<div class="mpseat' + (turn ? ' turn' : '') + (p.alive ? '' : ' dead') + (s === me ? ' me' : '') + '" data-seat="' + s + '"><div class="nm">' + esc(M.names[s] || s) + (s === me ? ' •' : '') + ' <small>' + (v.roundWins[s] || 0) + '★</small></div><div class="hp">' + '♥'.repeat(p.hp) + '<span class="lost">' + '♥'.repeat(Math.max(0, p.max - p.hp)) + '</span></div><div class="flags">' +
        (p.shield ? '<em>' + t('mp.shield') + '</em>' : '') + (p.cuffed ? '<em>' + t('mp.cuffed') + '</em>' : '') + (p.charged ? '<em>' + t('mp.charged') + '</em>' : '') + (p.alive ? '' : '<em>' + t('mp.eliminated') + '</em>') + '</div><div class="its">';
      p.items.forEach((id, i) => { if (id) h += '<button class="it" data-s="' + s + '" data-i="' + i + '" ' + (s === me && myTurn ? '' : 'disabled') + ' title="' + esc(iname(id)) + '">' + (G.Art && G.Art.icon ? '<img alt="' + esc(iname(id)) + '" src="' + G.Art.icon(id, 40) + '">' : esc(iname(id))) + '</button>'; });
      h += '</div><div class="bub" id="bub_' + s + '"></div></div>';
    }
    h += '</div>';
    if (v.phase === 'over' || (M.results && v.phase === 'over')) { const w = v.winner; h += '<div class="mpover"><h2>' + (w ? t('mp.winner', { n: esc(M.names[w] || w) }) : '—') + '</h2><button class="abtn primary" id="mpDone">' + t('mp.back') + '</button></div>'; }
    else {
      h += '<div class="mpbar"><div class="turnlbl">' + (myTurn ? '<b class="mine">' + t('mp.yourTurn') + '</b>' : t('mp.turnOf', { n: esc(M.names[v.turn] || v.turn) })) + '</div><div class="acts">';
      if (myTurn) { h += '<button class="abtn" data-shoot="' + me + '">' + t('mp.shootSelf') + '</button>'; for (const s of v.seats) if (s !== me && v.players[s].alive) h += '<button class="abtn primary" data-shoot="' + s + '">' + t('mp.shoot', { n: esc(M.names[s] || s) }) + '</button>'; }
      if (M.slapOffer && M.slapOffer.victim !== me && Date.now() < M.slapOffer.until && mine && mine.alive) h += '<button class="abtn slapbtn" id="mpSlap">👋 ' + U.t('slap.btn') + '</button>';
      h += '</div><div class="emotes"><button class="tbtn emotebtn" id="mpEmoteBtn">✋ ' + U.t('emote.btn') + '</div></div>';
      if (M.itemSel) h += '<div class="mppick"><b>' + t('mp.pickTarget', { i: esc(iname(M.itemSel.id)) }) + '</b>' + v.seats.filter((s) => s !== me && v.players[s].alive).map((s) => '<button class="abtn" data-tgt="' + s + '">' + esc(M.names[s] || s) + '</button>').join('') + '</div>';
    }
    h += '<div class="mplog">' + M.log.slice(-5).map((x) => '<div>' + x + '</div>').join('') + '</div>';
    g.innerHTML = h;
    $('mpQuit').onclick = () => { M.leave(); UI.open('mMP'); M.showConnect(); };
    const done = $('mpDone'); if (done) done.onclick = () => { M.leave(); UI.closeAll(); UI.showMenu(); };
    g.querySelectorAll('[data-shoot]').forEach((b) => (b.onclick = () => M.send({ type: 'shoot', target: b.dataset.shoot })));
    g.querySelectorAll('.it:not([disabled])').forEach((b) => (b.onclick = () => {
      const idx = +b.dataset.i, id = v.players[me].items[idx];
      if (['handcuffs', 'lighter', 'knife'].includes(id)) { M.itemSel = { idx, id }; M.showMatch(); } else M.send({ type: 'item', idx });
    }));
    g.querySelectorAll('[data-tgt]').forEach((b) => (b.onclick = () => { const it = M.itemSel; M.itemSel = null; M.send({ type: 'item', idx: it.idx, target: b.dataset.tgt }); }));
    const sb = $('mpSlap'); if (sb) sb.onclick = () => { M.slapOffer = null; sb.disabled = true; M.net.slap(); };
    const eb = $('mpEmoteBtn'); if (eb) eb.onclick = () => G.Emotes.toggle((id) => { M.net.emote(id); M.emote(me, id); if (G.Progress) G.Progress.emote(id); });
    if (v.phase === 'over' && !M.counted) { M.counted = true; const m = T().meta; if (G.Progress) G.Progress.onMatch({ players: v.seats.length, win: v.winner === me, sec: 0 }, m); }
    if (v.phase !== 'over') M.counted = false;
  };
  M.send = function (a) { M.itemSel = null; if (!M.net) return; M.net.act(a).catch((e) => UI.toast(String(e.reason || e.message || 'rejected'), 'bad')); };
  M.slapFx = function (from, to) {
    const b = $('bub_' + to), g = $('mpGame'); M.log.push('👋 ' + esc(M.names[from] || from) + ' → ' + esc(M.names[to] || to) + ' · ' + U.t('slap.btn'));
    if (b) { b.textContent = '💥 ' + U.t('slap.btn'); b.classList.add('on'); setTimeout(() => b && b.classList.remove('on'), 1800); }
    const seat = g && g.querySelector('[data-seat="' + to + '"]'); if (seat) { seat.classList.add('slapped'); setTimeout(() => seat.classList.remove('slapped'), 700); }
    if (G.AudioMgr && G.AudioMgr.sfx) try { G.AudioMgr.sfx('slap', { vol: 0.9 }); } catch (e) { /* ignore */ }
  };
  M.emote = function (seat, id) { const b = $('bub_' + seat); if (!b) return; b.textContent = (G.Emotes ? G.Emotes.icon(id) + ' ' : '') + (U.t('emote.' + id) || id); b.classList.add('on'); setTimeout(() => b && b.classList.remove('on'), 2200); };

  G.MPUI = M;
})(window);
