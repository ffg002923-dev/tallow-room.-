/* dealer-ai.js — decision logic only (v6). Reads *resolved* game state (never animation state).
   The Dealer knows: public shell counts, what HE has learned (his peeks can be FALSE after Black Mirror / Whisper Box), and both inventories.
   Every one of the 50 items has a scoring rule; difficulty controls how often the clever play is used. */
(function (G) {
  'use strict';
  const U = G.U, D = G.GameData, E = G.Engine, R = U.Rand;
  const AI = {};

  AI.scoreItem = function (st, who, id, c) {
    const me = c.me, op = c.op, pe = c.pe, p = c.pEmber, n = c.total;
    const bad = ['curse', 'lockOn', 'forcedOn', 'hexLeft', 'confuse'].some((k) => me.fx[k]) || me.cuffed;
    switch (id) {
      case 'cigarette': return 9;
      case 'medicine': return me.hp <= me.max - 2 && me.hp > 1 ? 5 : 0;
      case 'magnifier': case 'periscope': case 'stethoscope': return pe === null && n > 1 ? 7 : 1;
      case 'tally_bell': return pe === null && n > 2 ? 4 : 0;
      case 'ledger': return pe === null ? 4 : 0;
      case 'truth_candle': return pe === null ? 2 : 0;
      case 'ouija': return me.hp > 2 && n > 2 ? 4 : 0;
      case 'confessor_ear': return 1;
      case 'handcuffs': return p >= 0.5 || pe === 'e' ? 7 : 2;
      case 'battery': return !me.charged && (pe === 'e' || p >= 0.5) ? 6 : 1;
      case 'heavy_slug': return pe === 'e' || p >= 0.55 ? 5 : 1;
      case 'twin_barrel': return pe === 'e' ? 6 : 0;
      case 'can': return pe === null && p > 0.34 && p < 0.67 && n > 1 ? 4 : 0;
      case 'lighter': return 5;
      case 'rope': return 5;
      case 'acid_vial': return 5;
      case 'swap_hands': return 2;
      case 'scrambler': return pe === 'e' && me.hp <= 2 ? 5 : 1;
      case 'coin': return 3;
      case 'knife': return op.hp > 1 ? 4 : 0;
      case 'blank': return pe === 'e' && me.hp <= 2 ? 7 : 0;
      case 'spray': return op.charged ? 8 : 2;
      case 'black_mirror': return 3; case 'shadow_puppet': return 2; case 'whisper_box': return op.fx && !op.fx.mirror ? 4 : 1;
      case 'pocket_watch': return pe === 'e' || p > 0.6 ? 6 : 2;
      case 'pass_token': return me.hp <= 1 && p > 0.6 && pe !== 'a' ? 3 : 0;
      case 'loaded_die': return 2;
      case 'hook_chain': return 3; case 'spinning_top': return 2;
      case 'rust_lock': return op.items.filter(Boolean).length >= 2 ? 4 : 1;
      case 'cursed_needle': return 3;
      case 'hex_doll': return op.items.filter(Boolean).length >= 2 ? 4 : 1;
      case 'wax_shield': case 'tin_plate': case 'locket': case 'phoenix_ash': return me.hp <= 2 ? 5 : 2;
      case 'bandage': return 5;
      case 'salt': return bad ? 9 : 0;
      case 'pale_tonic': return 3;
      case 'gift_box': return 4;
      case 'wax_purse': return 0;
      case 'shell_swap': return pe === 'e' ? 3 : 0;
      case 'rotary_crank': return pe === 'e' && me.hp <= 2 ? 5 : 1;
      case 'spare_round': return me.hp <= 2 ? 4 : 1;
      case 'hot_round': return op.hp <= 1 ? 3 : 0;
      case 'rewind_locket': return st.lastShell === 'e' ? 3 : 0;
      case 'scales': return me.hp < op.hp ? 6 : 0;
      default: return 1;
    }
  };

  AI.decide = function (st, who) {
    who = who || 'd';
    const df = D.difficulties[st.diff], s = df.skill;
    const me = st[who], op = st[E.opp(who)], info = E.infoFor(st, who);
    const rnd = () => R.next(st);
    const pe = info.peek, total = info.total;
    const pEmber = pe ? (pe === 'e' ? 1 : 0) : (total ? info.ember / total : 0);
    const ctx = { me, op, pe, pEmber, total };

    if (rnd() < 0.35 + 0.65 * s) {   // weaker difficulties sometimes skip the clever play entirely
      let best = -1, bs = 0;
      me.items.forEach((it, i) => {
        if (!it || !E.canUse(st, who, i).ok) return;
        const sc = AI.scoreItem(st, who, it.id, ctx) + rnd() * 1.2;
        if (sc > bs) { bs = sc; best = i; }
      });
      if (best >= 0 && bs >= 3 - s) return { type: 'item', idx: best };
    }

    let target;
    if (pe === 'e') target = 'opp';
    else if (pe === 'a') target = 'self';
    else if (pEmber === 0) target = 'self';
    else if (pEmber === 1) target = 'opp';
    else target = pEmber >= 0.5 ? 'opp' : 'self';
    if (!pe && rnd() > 0.5 + 0.5 * s) target = rnd() < 0.5 ? 'opp' : 'self';
    if (me.fx.forcedOn) target = 'self';
    return { type: 'shoot', target };
  };

  G.DealerAI = AI;
  if (typeof module !== 'undefined' && module.exports) module.exports = AI;
})(typeof window !== 'undefined' ? window : globalThis);
