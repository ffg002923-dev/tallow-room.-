/* ui-v6.js — the redesigned main menu (live 3D room behind it) and the collection / shop screens
   (Characters, Weapons, Items, Shop). Everything reads the catalogue (data/content.js) and goes through Economy for buying / selecting,
   so ownership is saved once and can never be bought twice. */
(function (G) {
  'use strict';
  const U = G.U, D = G.GameData, Eco = G.Economy, Save = G.Save, UI = G.UI;
  const $ = (id) => document.getElementById(id), T = () => G.Turns;
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const V = { tab: 'dealer', shopCat: 'all', sel: null, mode: 'collection' };
  const ar = () => U.lang === 'ar';
  const meta = () => T().meta;
  const nm = (kind, id) => U.t(kind + '.' + id), ds = (kind, id) => U.t(kind + '.' + id + '.d');
  const dealerDesc = (id) => U.t('dealer.' + id + '.t');
  const RAR = { common: '#b9b2a4', rare: '#4aa3ff', epic: '#b46cff', legendary: '#ffc23a' };
  const rarityName = (r) => U.t('rarity.' + r);

  /* ---------------------------------------------------------------- strings */
  const S = {
    en: { 'v6.play': 'PLAY', 'v6.friends': 'PLAY WITH FRIENDS', 'v6.chars': 'CHARACTERS', 'v6.weapons': 'WEAPONS', 'v6.items': 'ITEMS', 'v6.shop': 'SHOP', 'v6.ach': 'ACHIEVEMENTS', 'v6.stats': 'STATISTICS', 'v6.settings': 'SETTINGS',
      'v6.continue': 'CONTINUE', 'v6.buy': 'BUY', 'v6.owned': 'OWNED', 'v6.select': 'SELECT', 'v6.selected': 'SELECTED', 'v6.locked': 'LOCKED', 'v6.free': 'FREE', 'v6.wax': 'Wax',
      'v6.all': 'All', 'v6.rare': 'Rare', 'v6.new': 'New', 'v6.mine': 'Owned', 'v6.notEnough': 'Not enough Wax — you need {n} more.', 'v6.bought': 'Purchased!', 'v6.nothing': 'Nothing here yet.',
      'v6.power': 'Power', 'v6.control': 'Control', 'v6.risk': 'Risk', 'v6.utility': 'Utility', 'v6.drag': 'Drag to rotate', 'v6.catalog': 'Items', 'v6.cat': 'Category', 'v6.uses': 'Uses',
      'v6.mpSoon': 'Online play needs the multiplayer server (see server/README.md).', 'v6.style': 'Style', 'v6.voice': 'Voice',
      'cat.detect': 'Detect', 'cat.heal': 'Heal', 'cat.attack': 'Attack', 'cat.control': 'Control', 'cat.defense': 'Defense', 'cat.strategy': 'Strategy', 'cat.chaos': 'Chaos', 'cat.utility': 'Utility', 'cat.curse': 'Curse', 'cat.support': 'Support',
      'rarity.common': 'Common', 'rarity.rare': 'Rare', 'rarity.epic': 'Epic', 'rarity.legendary': 'Legendary' },
    ar: { 'v6.play': 'العب', 'v6.friends': 'العب مع الأصدقاء', 'v6.chars': 'الشخصيات', 'v6.weapons': 'الأسلحة', 'v6.items': 'الأدوات', 'v6.shop': 'المتجر', 'v6.ach': 'الإنجازات', 'v6.stats': 'الإحصائيات', 'v6.settings': 'الإعدادات',
      'v6.continue': 'متابعة', 'v6.buy': 'شراء', 'v6.owned': 'مملوك', 'v6.select': 'اختيار', 'v6.selected': 'مختار', 'v6.locked': 'مقفل', 'v6.free': 'مجاني', 'v6.wax': 'شمع',
      'v6.all': 'الكل', 'v6.rare': 'نادر', 'v6.new': 'جديد', 'v6.mine': 'ممتلكاتي', 'v6.notEnough': 'الشمع لا يكفي — ينقصك {n}.', 'v6.bought': 'تم الشراء!', 'v6.nothing': 'لا شيء هنا بعد.',
      'v6.power': 'القوة', 'v6.control': 'التحكم', 'v6.risk': 'المخاطرة', 'v6.utility': 'الفائدة', 'v6.drag': 'اسحب للتدوير', 'v6.catalog': 'الأدوات', 'v6.cat': 'الفئة', 'v6.uses': 'الاستخدامات',
      'v6.mpSoon': 'اللعب عبر الإنترنت يحتاج خادم اللعب الجماعي (راجع server/README.md).', 'v6.style': 'الأسلوب', 'v6.voice': 'الصوت',
      'cat.detect': 'كشف', 'cat.heal': 'علاج', 'cat.attack': 'هجوم', 'cat.control': 'تحكم', 'cat.defense': 'دفاع', 'cat.strategy': 'استراتيجية', 'cat.chaos': 'فوضى', 'cat.utility': 'منفعة', 'cat.curse': 'لعنة', 'cat.support': 'دعم',
      'rarity.common': 'عادي', 'rarity.rare': 'نادر', 'rarity.epic': 'ملحمي', 'rarity.legendary': 'أسطوري' },
  };
  Object.assign(D.strings.en, S.en); Object.assign(D.strings.ar, S.ar);

  /* ---------------------------------------------------------------- main menu */
  const MENU = [
    ['continue', 'v6.continue', 'play', 'primary'], ['play', 'v6.play', 'play', 'primary'], ['friends', 'v6.friends', 'users'],
    ['chars', 'v6.chars', 'skull'], ['weapons', 'v6.weapons', 'weapon'], ['items', 'v6.items', 'inventory'], ['shop', 'v6.shop', 'coin'],
    ['ach', 'v6.ach', 'trophy'], ['stats', 'v6.stats', 'stats'], ['settings', 'v6.settings', 'settings'],
  ];
  V.buildMenu = function () {
    const menu = $('menu'); if ($('menuV6')) return;
    const root = el('div', 'v6menu'); root.id = 'menuV6';
    root.innerHTML = '<div class="v6left"><div class="v6title"><span class="t1">THE</span><span class="t2">TALLOW</span><span class="t3">ROOM</span><span class="v6wax" id="v6coins"></span></div><nav class="v6nav" id="v6nav"></nav></div>' +
      '<div class="v6foot"><button class="tbtn" id="v6full"></button><button class="tbtn" id="v6lang"></button></div>';
    menu.appendChild(root);
    // atmosphere: the two faces from the supplied texture (MENU ONLY, never in the play room), drifting dust, breathing light
    const fx = el('div', 'v6fx', '<img class="face grin" alt="" src="assets/ui/face-grin.png"><img class="face sph" alt="" src="assets/ui/face-sphere.png"><canvas id="v6dust"></canvas><div class="v6flick"></div>');
    menu.insertBefore(fx, root); V.startDust();
    const nav = $('v6nav');
    for (const [id, key, ic, cls] of MENU) {
      const b = el('button', 'v6btn ' + (cls || ''), '<i data-ic="' + ic + '"></i><span data-i18n="' + key + '"></span>'); b.id = 'v6_' + id; b.dataset.id = id; nav.appendChild(b);
      b.addEventListener('click', () => { if (G.AudioMgr) G.AudioMgr.unlock(); V.menuAction(id); });
    }
    $('v6full').addEventListener('click', () => $('mFull').click());
    $('v6lang').addEventListener('click', () => { const s = T().settings; s.lang = s.lang === 'ar' ? 'en' : 'ar'; G.Main.applySettings(s); Save.saveSettings(s); V.refreshMenu(); });
    UI.hydrateIcons(root);
  };
  V.startDust = function () {
    const cv = $('v6dust'); if (!cv) return; const c = cv.getContext('2d'); let W = 0, H = 0; const P = [];
    const size = () => { W = cv.width = cv.clientWidth >> 1; H = cv.height = cv.clientHeight >> 1; }; size(); window.addEventListener('resize', size);
    for (let i = 0; i < 46; i++) P.push({ x: Math.random(), y: Math.random(), r: 0.6 + Math.random() * 1.8, vx: (Math.random() - 0.5) * 0.004, vy: -0.002 - Math.random() * 0.004, a: 0.15 + Math.random() * 0.4, ph: Math.random() * 6 });
    let last = 0; const loop = (t) => {
      requestAnimationFrame(loop); if (document.documentElement.classList.contains('ingame') || $('menu').classList.contains('hidden')) return;
      if (t - last < 40) return; last = t; c.clearRect(0, 0, W, H);   // ~25 fps is plenty for slow dust
      for (const p of P) { p.x += p.vx + Math.sin(t / 3000 + p.ph) * 0.0006; p.y += p.vy; if (p.y < -0.02) { p.y = 1.02; p.x = Math.random(); } c.fillStyle = 'rgba(255,170,110,' + (p.a * (0.6 + 0.4 * Math.sin(t / 900 + p.ph))) + ')'; c.beginPath(); c.arc(p.x * W, p.y * H, p.r, 0, 6.283); c.fill(); }
    }; requestAnimationFrame(loop);
  };
  V.refreshMenu = function () {
    if (!$('menuV6')) return;
    document.querySelectorAll('#menuV6 [data-i18n]').forEach((n) => { n.textContent = U.t(n.dataset.i18n); });
    $('v6_continue').style.display = Save.hasRun() ? '' : 'none';
    $('v6_play').classList.toggle('primary', !Save.hasRun());
    $('v6coins').textContent = (meta().coins | 0) + ' ' + U.t('v6.wax');
    $('v6full').textContent = U.t('menu.fullscreen'); $('v6lang').textContent = ar() ? 'English' : 'العربية';
    $('menuV6').classList.toggle('compact', true);
  };
  V.menuAction = function (id) {
    const MA = G.MenuArt;
    switch (id) {
      case 'continue': if (MA) MA.stopMusic(450); T().continueGame(); break;
      case 'play': UI.openDiff(); break;
      case 'friends': if (G.MPUI) G.MPUI.open(); else UI.toast(U.t('v6.mpSoon'), 'info'); break;
      case 'chars': V.open('dealer'); break;
      case 'weapons': V.open('weapon'); break;
      case 'items': V.open('item'); break;
      case 'shop': V.open('shop'); break;
      case 'ach': UI.openAch(); break;
      case 'stats': UI.openStats(); break;
      case 'settings': UI.openSettings('menu'); break;
    }
  };

  /* ---------------------------------------------------------------- collection / shop screen */
  const icon = (kind, id, size) => {
    if (kind === 'item' && G.Art && G.Art.icon) { try { return '<img alt="" width="' + size + '" height="' + size + '" src="' + G.Art.icon(id, size) + '">'; } catch (e) { /* fall through */ } }
    const glyph = kind === 'dealer' ? '☠' : kind === 'weapon' ? '⌖' : '◆';
    return '<span class="glyph">' + glyph + '</span>';
  };
  const kindOf = (tab) => (tab === 'shop' ? V.shopKind : tab);
  V.shopKind = 'dealer';
  const ids = (kind) => (kind === 'item' ? D.itemOrder : kind === 'weapon' ? D.weaponOrder : D.dealerOrder);

  V.entries = function () {
    const m = meta(); let list = [];
    if (V.tab === 'shop') {
      const cat = V.shopCat; const kinds = V.shopKind === 'all' ? ['dealer', 'weapon', 'item'] : [V.shopKind];
      for (const k of kinds) for (const id of ids(k)) {
        const owned = Eco.owned(m, k, id), d = Eco.def(k, id), free = !!d.free;
        if (free) continue;
        if (cat === 'rare' && !['epic', 'legendary', 'rare'].includes(d.rarity)) continue;
        if (cat === 'new' && !Eco.newest(k).includes(id)) continue;
        if (cat === 'mine' && !owned) continue;
        list.push({ kind: k, id });
      }
    } else { for (const id of ids(V.tab)) list.push({ kind: V.tab, id }); }
    return list;
  };

  V.open = function (tab) {
    const mm = $('menuV6'); if (mm) mm.style.visibility = 'hidden';
    V.tab = tab; if (tab === 'shop') { V.shopCat = 'all'; V.shopKind = 'dealer'; }
    V.sel = null; V.build(); UI.closeAll(); UI.open('mColl');
  };
  V.build = function () {
    const m = meta(), root = $('mColl'); if (!root) return;
    $('collCoins').textContent = (m.coins | 0) + ' ' + U.t('v6.wax');
    $('collTitle').textContent = U.t(V.tab === 'shop' ? 'v6.shop' : V.tab === 'dealer' ? 'v6.chars' : V.tab === 'weapon' ? 'v6.weapons' : 'v6.items');
    // top tabs
    const tabs = $('collTabs'); tabs.innerHTML = '';
    const tabDefs = [['dealer', 'v6.chars'], ['weapon', 'v6.weapons'], ['item', 'v6.items'], ['shop', 'v6.shop']];
    for (const [t, k] of tabDefs) { const b = el('button', 'chip' + (V.tab === t ? ' on' : ''), U.t(k)); b.onclick = () => { V.tab = t; V.sel = null; if (t === 'shop') { V.shopCat = 'all'; } V.build(); }; tabs.appendChild(b); }
    // sub filters (shop)
    const sub = $('collSub'); sub.innerHTML = '';
    if (V.tab === 'shop') {
      for (const [k, key] of [['dealer', 'v6.chars'], ['weapon', 'v6.weapons'], ['item', 'v6.items'], ['all', 'v6.all']]) { const b = el('button', 'chip sm' + (V.shopKind === k ? ' on' : ''), U.t(key)); b.onclick = () => { V.shopKind = k; V.sel = null; V.build(); }; sub.appendChild(b); }
      sub.appendChild(el('span', 'sep'));
      for (const [k, key] of [['all', 'v6.all'], ['rare', 'v6.rare'], ['new', 'v6.new'], ['mine', 'v6.mine']]) { const b = el('button', 'chip sm' + (V.shopCat === k ? ' on' : ''), U.t(key)); b.onclick = () => { V.shopCat = k; V.sel = null; V.build(); }; sub.appendChild(b); }
    }
    const list = V.entries(), grid = $('collGrid'); grid.innerHTML = '';
    if (!V.sel || !list.some((e) => e.kind === V.sel.kind && e.id === V.sel.id)) V.sel = list[0] || null;
    if (!list.length) grid.appendChild(el('p', 'empty', U.t('v6.nothing')));
    for (const e of list) {
      const d = Eco.def(e.kind, e.id), owned = Eco.owned(m, e.kind, e.id), selKey = e.kind === 'dealer' || e.kind === 'weapon' ? m.selected[e.kind] : null;
      const c = el('button', 'ccard' + (V.sel && V.sel.id === e.id && V.sel.kind === e.kind ? ' on' : '') + (owned ? '' : ' locked'));
      c.style.setProperty('--rc', RAR[d.rarity] || RAR.common);
      c.innerHTML = '<div class="cimg">' + icon(e.kind, e.id, 64) + '</div><b>' + nm(e.kind, e.id) + '</b><small>' +
        (selKey === e.id ? U.t('v6.selected') : owned ? U.t('v6.owned') : (d.price | 0) + ' ' + U.t('v6.wax')) + '</small>';
      c.onclick = () => { V.sel = e; V.build(); };
      grid.appendChild(c);
    }
    V.detail();
  };
  V.detail = function () {
    const box = $('collDetail'), m = meta(); box.innerHTML = ''; const e = V.sel; if (!e) return;
    const d = Eco.def(e.kind, e.id), owned = Eco.owned(m, e.kind, e.id);
    const prev = el('div', 'cprev'); prev.id = 'collPrev';
    if (e.kind === 'item') prev.innerHTML = icon('item', e.id, 128);
    else prev.appendChild(el('canvas', 'pcan')); // 3D preview canvas (filled by V.preview when available)
    box.appendChild(prev);
    const info = el('div', 'cinfo');
    info.appendChild(el('h3', '', nm(e.kind, e.id)));
    info.appendChild(el('div', 'rar', '<span style="color:' + (RAR[d.rarity] || RAR.common) + '">' + rarityName(d.rarity) + '</span>' + (e.kind === 'item' ? ' · ' + U.t('cat.' + d.cat) : '')));
    info.appendChild(el('p', '', e.kind === 'dealer' ? dealerDesc(e.id) : ds(e.kind, e.id)));
    if (e.kind === 'weapon' && d.stats) { const st = el('div', 'stbars'); for (const k of ['power', 'control', 'risk', 'utility']) st.appendChild(el('div', 'stb', '<span>' + U.t('v6.' + k) + '</span><i><u style="width:' + (d.stats[k] * 20) + '%"></u></i>')); info.appendChild(st); }
    if (e.kind === 'item') info.appendChild(el('small', '', U.t('v6.uses') + ': ' + d.uses));
    const act = el('div', 'cact');
    const msg = el('div', 'cmsg'); msg.id = 'collMsg';
    if (!owned) {
      const b = el('button', 'abtn primary', '<i data-ic="coin"></i><span>' + U.t('v6.buy') + ' · ' + d.price + '</span>');
      b.onclick = () => V.buy(e);
      act.appendChild(b);
    } else if (e.kind === 'dealer' || e.kind === 'weapon') {
      const cur = m.selected[e.kind] === e.id;
      const b = el('button', 'abtn' + (cur ? '' : ' primary'), '<span>' + U.t(cur ? 'v6.selected' : 'v6.select') + '</span>'); b.disabled = cur;
      b.onclick = () => { const r = Eco.select(m, e.kind, e.id); if (r.ok) { Save.saveMeta(m); V.build(); if (e.kind === 'dealer' && V.applyDealer) V.applyDealer(); } };
      act.appendChild(b);
    } else act.appendChild(el('span', 'ownedtag', U.t('v6.owned')));
    info.appendChild(act); info.appendChild(msg); box.appendChild(info);
    UI.hydrateIcons(box);
    if (V.preview) V.preview(e, prev);
  };
  /* 3D preview: the real dealer in the room behind the (translucent) screen wears the selected look; dragging turns him */
  V.preview = function (e, prev) {
    const L = G.DealerLooks, card = document.querySelector('.collcard');
    if (card) { card.classList.toggle('pv3d', e.kind === 'dealer'); $('mColl').classList.toggle('pv3d', e.kind === 'dealer'); }
    if (e.kind !== 'dealer') { if (L) { L.override = null; L.yaw = 0; } return; }
    L.override = e.id; L.yaw = 0; prev.innerHTML = '<span class="pvhint">' + U.t('v6.drag') + '</span>';
    let x0 = null, y0 = L.yaw;
    prev.onpointerdown = (ev) => { x0 = ev.clientX; y0 = L.yaw; try { prev.setPointerCapture(ev.pointerId); } catch (err) { /* ignore */ } };
    prev.onpointermove = (ev) => { if (x0 === null) return; L.yaw = Math.max(-1.3, Math.min(1.3, y0 + (ev.clientX - x0) / 120)); };
    prev.onpointerup = prev.onpointercancel = () => { x0 = null; };
  };
  V.endPreview = function () { const L = G.DealerLooks; if (L) { L.override = null; L.yaw = 0; } };
  V.buy = function (e) {
    const m = meta(), r = Eco.buy(m, e.kind, e.id), msg = $('collMsg');
    if (!r.ok) { if (msg) { msg.textContent = r.reason === 'poor' ? U.t('v6.notEnough').replace('{n}', r.missing) : U.t('v6.locked'); msg.className = 'cmsg bad'; } if (G.AudioMgr && G.AudioMgr.sfx) G.AudioMgr.sfx('ui_deny'); return; }
    if (G.Progress) { G.Progress.check(m); }
    Save.saveMeta(m); if (G.AudioMgr && G.AudioMgr.sfx) G.AudioMgr.sfx('ui_buy');
    V.build(); const msg2 = $('collMsg'); if (msg2) { msg2.textContent = U.t('v6.bought'); msg2.className = 'cmsg good'; }
  };

  const COLL_HTML = '<div class="card wide collcard"><header class="sh-head"><h2 id="collTitle"></h2><div class="coins" id="collCoins"></div><button class="ibtn" data-close data-aria="ui.close" aria-label="Close"><i data-ic="close"></i></button></header>' +
    '<div id="collTabs" class="chips"></div><div id="collSub" class="chips subchips"></div><div class="collbody"><div id="collGrid" class="collgrid"></div><div id="collDetail" class="colldetail"></div></div></div>';
  V.init = function () {
    if (!$('mColl')) { const m = el('div', 'modal hidden', COLL_HTML); m.id = 'mColl'; m.setAttribute('role', 'dialog'); m.setAttribute('aria-modal', 'true'); $('app').appendChild(m); m.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => { UI.close('mColl'); V.endPreview(); })); UI.hydrateIcons(m); }
    const uc = UI.close; UI.close = function (id) { if (id === 'mColl') { V.endPreview(); const mm = $('menuV6'); if (mm) mm.style.visibility = ''; } return uc.apply(this, arguments); };
    V.buildMenu(); V.refreshMenu();
    const sm = UI.showMenu; UI.showMenu = function () { sm.apply(this, arguments); if (G.Renderer) { G.Renderer.menuCover = false; G.Renderer.scene.menuOff = V.off(); } V.refreshMenu(); };
    V.off = () => (ar() ? -1 : 1);
    const al = UI.applyLang; UI.applyLang = function () { al.apply(this, arguments); if (G.Renderer && G.Renderer.scene.mode === 'menu') G.Renderer.scene.menuOff = V.off(); V.refreshMenu(); if (!$('mColl').classList.contains('hidden')) V.build(); };
    if (G.Renderer) G.Renderer.menuCover = false;
    document.documentElement.classList.add('v6');
  };
  V.coinsChanged = function () { V.refreshMenu(); };
  G.UIv6 = V;
})(window);
