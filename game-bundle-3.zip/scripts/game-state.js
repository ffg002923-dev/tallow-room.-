/* game-state.js — AUTHORITATIVE rules engine (v6). Pure data in, events out. No rendering, no audio, no timing.
   Shell codes: 'e' = LIVE SHELL, 'a' = BLANK SHELL (internal codes kept for save compatibility).
   v6: 50 items with real effects, weapon hooks, per-player knowledge map, status effects (st[who].fx). */
(function (G) {
  'use strict';
  const U = G.U, D = G.GameData, R = U.Rand;
  const E = {};
  E.SLOTS = D.config.slots;
  const opp = (w) => (w === 'p' ? 'd' : 'p');
  E.opp = opp;
  const MAXCH = 12;

  const blank = (max) => ({ hp: max, max, items: new Array(E.SLOTS).fill(null), cuffed: false, charged: false, fx: {} });
  const firstEmpty = (arr) => arr.findIndex((x) => !x);
  const hooks = (st, who) => (who === 'p' && st.weapon && D.weapons && D.weapons[st.weapon] ? D.weapons[st.weapon].hooks : {});
  const rar = (id) => (D.rarity && D.items[id] ? D.rarity[D.items[id].rarity] || 0 : 0);
  const poolOf = (st) => (st.pool && st.pool.length ? st.pool : D.itemOrder);
  const BAD = ['curse', 'lock', 'lockOn', 'forced', 'forcedOn', 'hex', 'hexLeft', 'confuse'];

  E.newGame = function (diff, seed, bonus, opts) {
    opts = opts || {};
    if (!D.difficulties[diff]) diff = 'normal';
    return {
      v: 2, r: (seed === undefined ? (Date.now() & 0x7fffffff) : seed) | 0, diff, bonus: (bonus || []).filter((id) => D.items[id]).slice(0, 2),
      weapon: (D.weapons && D.weapons[opts.weapon]) ? opts.weapon : 'caster', pool: opts.pool && opts.pool.length ? opts.pool.filter((id) => D.items[id]) : null,
      round: 0, phase: 'between', turn: 'p', p: blank(3), d: blank(3),
      chamber: [], loaded: { e: 0, a: 0 }, pub: { e: 0, a: 0 }, peek: { who: null, type: null }, know: { p: [], d: [] }, lastShell: null,
      stats: { dmgTaken: 0, itemsUsed: 0, usedIds: {}, shotsSelf: 0, ashStreak: 0, bestStreak: 0, roundsWon: 0, roundItems: 0, roundDmg: 0, liveHits: 0, leech: 0, vesper: 0, liveStreak: 0, passUsed: 0, cb: 0 }
    };
  };

  /* ---- knowledge: what each side believes about shells (index from the front of the chamber). Entries may be FALSE (Whisper Box / Black Mirror). */
  function sync(st) {
    const a = st.know.p.find((x) => x.i === 0), b = st.know.d.find((x) => x.i === 0);
    st.peek = a && b ? { who: 'both', type: a.type } : a ? { who: 'p', type: a.type } : b ? { who: 'd', type: b.type } : { who: null, type: null };
  }
  function learn(st, who, i, type, fake) { st.know[who] = st.know[who].filter((x) => x.i !== i).concat([{ i, type, fake: !!fake }]); sync(st); }
  function forget(st, who) { if (who) st.know[who] = []; else st.know = { p: [], d: [] }; sync(st); }
  function shiftKnow(st) { for (const w of ['p', 'd']) st.know[w] = st.know[w].map((x) => ({ i: x.i - 1, type: x.type, fake: x.fake })).filter((x) => x.i >= 0); sync(st); }
  E.knownNext = (st, who) => { const k = st.know[who].find((x) => x.i === 0); return k ? k.type : null; };
  /* a reveal made by `viewer`; a Black Mirror held by the opponent flips it once */
  function reveal(st, viewer, i, type) {
    const o = st[opp(viewer)];
    if (o.fx.mirror > 0) { o.fx.mirror--; type = type === 'e' ? 'a' : 'e'; learn(st, viewer, i, type, true); return { type, fake: true }; }
    learn(st, viewer, i, type, false); return { type, fake: false };
  }

  E.startRound = function (st) {
    const cfg = D.config, df = D.difficulties[st.diff];
    st.round++;
    const base = cfg.hpByRound[st.round - 1];
    st.p = blank(base + df.playerHp); st.d = blank(base + df.dealerHp);
    st.phase = 'play'; st.turn = 'p'; st.lastShell = null; st.stats.leech = 0; st.stats.vesper = 0; st.stats.liveHits = 0; st.stats.liveStreak = 0; st.stats.passUsed = 0; st.stats.cb = 0;
    st.stats.roundItems = 0; st.stats.roundDmg = 0;
    const h = hooks(st, 'p');
    if (h.shieldStart) st.p.fx.shield = 1;
    if (h.chargeStart) st.p.charged = true;
    const ev = [{ t: 'roundStart', round: st.round, pmax: st.p.max, dmax: st.d.max }];
    E.reload(st, ev);
    if (st.round === 1 && st.bonus && st.bonus.length) {
      const rl = ev.find((x) => x.t === 'reload');
      for (const id of st.bonus) { const slot = firstEmpty(st.p.items); if (slot < 0) break; st.p.items[slot] = { id, uses: D.items[id].uses }; rl.added.push({ who: 'p', slot, id }); }
      st.bonus = [];
    }
    return ev;
  };

  E.reload = function (st, ev) {
    const cfg = D.config, ri = Math.max(0, st.round - 1), df = D.difficulties[st.diff], h = hooks(st, 'p');
    const n = R.int(st, cfg.chamberMin[ri], cfg.chamberMax[ri]);
    let e = Math.round(n * (0.4 + R.next(st) * 0.2)) + (h.liveBias || 0);
    e = U.clamp(e, 1, n - 1);
    const a = n - e, ch = [];
    for (let i = 0; i < e; i++) ch.push('e');
    for (let i = 0; i < a; i++) ch.push('a');
    R.shuffle(st, ch);
    st.chamber = ch; st.loaded = { e, a }; st.pub = { e, a }; st.lastShell = null; forget(st);
    const added = [], pool = D.itemWeights(poolOf(st));
    for (const who of ['p', 'd']) {
      const cnt = cfg.itemsPerReload[ri] + (who === 'd' ? df.dealerItems : 0) + (who === 'p' ? (h.extraItems || 0) : 0);
      for (let i = 0; i < cnt; i++) {
        const slot = firstEmpty(st[who].items); if (slot < 0) break;
        const id = R.weighted(st, pool);
        st[who].items[slot] = { id, uses: D.items[id].uses }; added.push({ who, slot, id });
      }
    }
    if (h.peekStart) learn(st, 'p', 0, ch[0], false);
    ev.push({ t: 'reload', e, a, total: n, added, peek: h.peekStart ? ch[0] : null });
  };

  E.canUse = function (st, who, idx) {
    const me = st[who], op = st[opp(who)], it = me.items[idx];
    if (!it) return { ok: false, reason: 'toast.slotEmpty' };
    if (me.fx.lockOn) return { ok: false, reason: 'toast.locked' };
    const id = it.id, n = st.chamber.length, NO = { ok: false, reason: 'toast.noEffect' }, YES = { ok: true };
    const others = (o, skip) => o.items.some((x, i) => x && i !== skip);
    switch (id) {
      case 'cigarette': return me.hp >= me.max ? { ok: false, reason: 'toast.pulseFull' } : YES;
      case 'handcuffs': return op.cuffed ? { ok: false, reason: 'toast.cuffed' } : YES;
      case 'battery': return me.charged ? { ok: false, reason: 'toast.charged' } : YES;
      case 'lighter': return !op.items.some((x) => x) ? { ok: false, reason: 'toast.noTargets' } : YES;
      case 'knife': return op.hp <= 1 ? { ok: false, reason: 'toast.noKnife' } : YES;
      case 'blank': return (!n || st.chamber[0] === 'a') ? { ok: false, reason: 'toast.noSpray' } : YES;
      case 'spray': return !(op.charged || st.know[opp(who)].length) ? { ok: false, reason: 'toast.noSpray' } : YES;
      case 'rope': return (!op.items.some((x) => x) || me.items.every((x, i) => x && i !== idx)) ? { ok: false, reason: 'toast.noSteal' } : YES;
      case 'periscope': case 'stethoscope': return n >= 2 ? YES : NO;
      case 'tally_bell': case 'truth_candle': case 'whisper_box': return n >= 1 ? YES : NO;
      case 'ledger': return st.chamber.includes('e') ? YES : NO;
      case 'black_mirror': return me.fx.mirror ? NO : YES;
      case 'shadow_puppet': return me.fx.veil ? NO : YES;
      case 'pocket_watch': return me.fx.extra ? NO : YES;
      case 'hook_chain': return (op.fx.forced || op.fx.forcedOn) ? NO : YES;
      case 'spinning_top': return op.fx.confuse ? NO : YES;
      case 'rust_lock': return (op.fx.lock || op.fx.lockOn) ? NO : YES;
      case 'acid_vial': return op.items.some((x) => x) ? YES : { ok: false, reason: 'toast.noTargets' };
      case 'cursed_needle': return op.fx.curse ? NO : YES;
      case 'hex_doll': return op.fx.hex ? NO : YES;
      case 'wax_shield': return me.fx.shield ? NO : YES;
      case 'tin_plate': return me.fx.plate ? NO : YES;
      case 'bandage': return me.hp >= me.max ? { ok: false, reason: 'toast.pulseFull' } : YES;
      case 'salt': return (BAD.some((k) => me.fx[k]) || me.cuffed) ? YES : { ok: false, reason: 'toast.nothingToClean' };
      case 'phoenix_ash': return me.fx.phoenix ? NO : YES;
      case 'locket': return me.fx.locket ? NO : YES;
      case 'gift_box': return me.items.some((x, i) => !x || i === idx) ? YES : { ok: false, reason: 'toast.noSteal' };
      case 'wax_purse': return me.fx.purse ? NO : YES;
      case 'heavy_slug': return me.fx.slug ? NO : YES;
      case 'twin_barrel': return (n >= 2 && !me.fx.twin) ? YES : NO;
      case 'shell_swap': case 'rotary_crank': return n >= 2 ? YES : NO;
      case 'spare_round': case 'hot_round': return n < MAXCH ? YES : NO;
      case 'swap_hands': return (others(me, idx) && others(op, -1)) ? YES : { ok: false, reason: 'toast.noSteal' };
      case 'rewind_locket': return (st.lastShell && n < MAXCH) ? YES : NO;
      case 'ouija': return (me.hp > 1 && n >= 2) ? YES : NO;
      case 'scales': return me.hp !== op.hp ? YES : NO;
      default: return YES;
    }
  };

  /* damage pipeline: shield -> plate -> locket -> hp -> phoenix. `nonfatal` damage never kills. */
  function dealDamage(st, shooter, vid, dmg, o) {
    o = o || {};
    const v = st[vid], fx = v.fx, info = { dmg: 0, blocked: 0, reflected: 0, saved: false };
    if (dmg <= 0) return info;
    if (!o.pierce && fx.shield > 0) { fx.shield--; info.blocked = dmg; return info; }
    if (!o.pierce && fx.plate > 0) { fx.plate--; dmg = Math.max(0, dmg - 1); info.blocked = 1; if (!dmg) return info; }
    if (!o.nonfatal && fx.locket > 0 && shooter && shooter !== vid) {
      fx.locket--; info.reflected = 1; info.blocked = dmg; const s = st[shooter]; s.hp = Math.max(1, s.hp - 1); return info;
    }
    const before = v.hp;
    v.hp = Math.max(o.nonfatal ? 1 : 0, v.hp - dmg);
    if (v.hp <= 0 && fx.phoenix > 0) { fx.phoenix--; v.hp = Math.min(v.max, 2); info.saved = true; }
    info.dmg = before - v.hp;
    if (vid === 'p') { st.stats.dmgTaken += Math.max(0, info.dmg); st.stats.roundDmg += Math.max(0, info.dmg); }
    return info;
  }

  const FX = {
    cuff(st, who) { st[opp(who)].cuffed = true; return { k: 'cuff' }; },
    heal(st, who) { const me = st[who], b = me.hp; me.hp = Math.min(me.max, me.hp + 1); return { k: 'heal', amt: me.hp - b, hp: me.hp }; },
    scramble(st) { R.shuffle(st, st.chamber); forget(st); return { k: 'scramble' }; },
    peek(st, who) { const r = reveal(st, who, 0, st.chamber[0]); return { k: 'peek', type: r.type, fake: r.fake }; }
  };
  const hurtMe = (st, who, n) => { st[who].hp = Math.max(1, st[who].hp - n); if (who === 'p') { st.stats.dmgTaken += n; st.stats.roundDmg += n; } };

  function useItem(st, who, idx, ev) {
    const oid = opp(who), me = st[who], op = st[oid];
    const it = me.items[idx], id = it.id, n = st.chamber.length;
    const e = { t: 'item', who, idx, id, consumed: true, fx: null, usesLeft: 0 };
    if (who === 'p') { st.stats.itemsUsed++; st.stats.roundItems++; st.stats.usedIds[id] = 1; }
    // Hex Doll: whoever carries the hex pays 1 pulse (never fatal) for each of their next 2 items
    if (me.fx.hexLeft > 0 && me.hp > 1) { me.fx.hexLeft--; hurtMe(st, who, 1); e.hexTax = true; if (me.fx.hexLeft <= 0) delete me.fx.hex; }
    switch (id) {
      case 'magnifier': e.fx = FX.peek(st, who); break;
      case 'handcuffs': e.fx = FX.cuff(st, who); break;
      case 'cigarette': e.fx = FX.heal(st, who); break;
      case 'battery': me.charged = true; e.fx = { k: 'charge' }; break;
      case 'medicine': {
        const good = R.next(st) < 0.5, b = me.hp;
        if (good) me.hp = Math.min(me.max, me.hp + 2); else if (me.hp > 1) me.hp -= 1;
        e.fx = { k: 'pills', good, amt: me.hp - b, hp: me.hp }; break;
      }
      case 'can': {
        const type = st.chamber.shift(); st.pub[type]--; st.lastShell = type; shiftKnow(st);
        e.fx = { k: 'eject', type, empty: st.chamber.length === 0 }; break;
      }
      case 'lighter': {
        const targets = []; op.items.forEach((x, i) => { if (x) targets.push(i); });
        const ti = R.pick(st, targets);
        e.fx = { k: 'burn', slot: ti, id: op.items[ti].id, target: oid }; op.items[ti] = null;
        it.uses--; e.consumed = it.uses <= 0; e.usesLeft = it.uses; break;
      }
      case 'scrambler': e.fx = FX.scramble(st); break;
      case 'knife': op.hp -= 1; e.fx = { k: 'stab', target: oid, hp: op.hp }; if (oid === 'p') { st.stats.dmgTaken++; st.stats.roundDmg++; } break;
      case 'blank': {
        const old = st.chamber[0]; st.chamber[0] = 'a'; st.pub[old]--; st.pub.a++;
        for (const w of ['p', 'd']) st.know[w] = st.know[w].map((x) => (x.i === 0 ? { i: 0, type: 'a', fake: x.fake } : x)); sync(st);
        e.fx = { k: 'blank', was: old }; break;
      }
      case 'spray': op.charged = false; forget(st, oid); e.fx = { k: 'spray', target: oid }; break;
      case 'rope': {
        const from = []; op.items.forEach((x, i) => { if (x) from.push(i); });
        let to = me.items.findIndex((x, i) => !x && i !== idx); if (to < 0) to = idx;
        const fi = R.pick(st, from), stolen = op.items[fi]; op.items[fi] = null;
        e.fx = { k: 'steal', id: stolen.id, from: fi, to, target: oid }; e.stolen = stolen; break;
      }
      case 'coin': {
        const opts = ['peek']; if (!op.cuffed) opts.push('cuff'); if (me.hp < me.max) opts.push('heal'); if (n > 1) opts.push('scramble');
        const kind = R.pick(st, opts); e.fx = { k: 'coin', inner: FX[kind](st, who) }; break;
      }
      /* ---- v6 items ---- */
      case 'periscope': { const r = reveal(st, who, n - 1, st.chamber[n - 1]); e.fx = { k: id, slot: n - 1, type: r.type, fake: r.fake, viewer: who }; break; }
      case 'stethoscope': { const r = reveal(st, who, 1, st.chamber[1]); e.fx = { k: id, slot: 1, type: r.type, fake: r.fake, viewer: who }; break; }
      case 'tally_bell': e.fx = { k: id, count: st.chamber.slice(0, 3).filter((x) => x === 'e').length, of: Math.min(3, n), viewer: who }; break;
      case 'truth_candle': learn(st, 'p', 0, st.chamber[0], false); learn(st, 'd', 0, st.chamber[0], false); e.fx = { k: id, type: st.chamber[0] }; break;
      case 'ledger': { const pos = st.chamber.indexOf('e'); learn(st, who, pos, 'e', false); e.fx = { k: id, pos, viewer: who }; break; }
      case 'confessor_ear': { const k = st.know[oid].find((x) => x.i === 0); e.fx = { k: id, knows: k ? k.type : null, viewer: who }; break; }
      case 'black_mirror': me.fx.mirror = 1; e.fx = { k: id }; break;
      case 'whisper_box': { const fake = st.chamber[0] === 'e' ? 'a' : 'e'; learn(st, oid, 0, fake, true); e.fx = { k: id, type: fake, target: oid }; break; }
      case 'shadow_puppet': me.fx.veil = 1; e.fx = { k: id }; break;
      case 'pocket_watch': me.fx.extra = 1; e.fx = { k: id }; break;
      case 'pass_token': e.fx = { k: id }; st.stats.passUsed++; break;
      case 'loaded_die': {
        const roll = R.int(st, 1, 6); let inner;
        if (roll <= 2) inner = { k: 'lose' }; else if (roll <= 4) inner = FX.peek(st, who); else if (roll === 5) inner = FX.heal(st, who); else { me.fx.extra = 1; inner = { k: 'again' }; }
        e.fx = { k: id, roll, inner }; break;
      }
      case 'hook_chain': op.fx.forced = 1; e.fx = { k: id, target: oid }; break;
      case 'spinning_top': op.fx.confuse = 1; e.fx = { k: id, target: oid }; break;
      case 'rust_lock': op.fx.lock = 1; e.fx = { k: id, target: oid }; break;
      case 'acid_vial': {
        let best = -1, bi = -1; op.items.forEach((x, i) => { if (x) { const sc = rar(x.id) * 10 + R.next(st); if (sc > best) { best = sc; bi = i; } } });
        e.fx = { k: id, slot: bi, id: op.items[bi].id, target: oid }; op.items[bi] = null; break;
      }
      case 'cursed_needle': op.fx.curse = 1; e.fx = { k: id, target: oid }; break;
      case 'hex_doll': op.fx.hex = 1; op.fx.hexLeft = 2; e.fx = { k: id, target: oid }; break;
      case 'wax_shield': me.fx.shield = 1; e.fx = { k: id }; break;
      case 'tin_plate': me.fx.plate = 2; e.fx = { k: id }; break;
      case 'bandage': { const b = me.hp; me.hp = Math.min(me.max, me.hp + 1); me.fx.regen = 1; e.fx = { k: id, amt: me.hp - b, hp: me.hp }; break; }
      case 'salt': { for (const k of BAD) delete me.fx[k]; me.cuffed = false; e.fx = { k: id }; break; }
      case 'phoenix_ash': me.fx.phoenix = 1; e.fx = { k: id }; break;
      case 'locket': me.fx.locket = 1; e.fx = { k: id }; break;
      case 'pale_tonic': { me.max += 1; me.hp = Math.min(me.max, me.hp + 1); e.fx = { k: id, hp: me.hp, max: me.max }; break; }
      case 'gift_box': {
        const added = [], pool = D.itemWeights(poolOf(st));
        for (let i = 0; i < 2; i++) { const slot = me.items.findIndex((x, k) => !x && k !== idx); if (slot < 0) break; const nid = R.weighted(st, pool); me.items[slot] = { id: nid, uses: D.items[nid].uses }; added.push({ who, slot, id: nid }); }
        e.fx = { k: id, added }; break;
      }
      case 'wax_purse': me.fx.purse = 1; e.fx = { k: id }; break;
      case 'heavy_slug': me.fx.slug = 1; e.fx = { k: id }; break;
      case 'twin_barrel': me.fx.twin = 1; e.fx = { k: id }; break;
      case 'shell_swap': { const a = st.chamber[0]; st.chamber[0] = st.chamber[n - 1]; st.chamber[n - 1] = a; forget(st); e.fx = { k: id }; break; }
      case 'rotary_crank': st.chamber.push(st.chamber.shift()); forget(st); e.fx = { k: id }; break;
      case 'spare_round': case 'hot_round': {
        const t = id === 'spare_round' ? 'a' : 'e', pos = R.int(st, 0, n); st.chamber.splice(pos, 0, t); st.pub[t]++; st.loaded[t]++; forget(st); e.fx = { k: id, type: t }; break;
      }
      case 'swap_hands': {
        const mine = [], theirs = []; me.items.forEach((x, i) => { if (x && i !== idx) mine.push(i); }); op.items.forEach((x, i) => { if (x) theirs.push(i); });
        const a = R.pick(st, mine), b = R.pick(st, theirs), t = me.items[a]; me.items[a] = op.items[b]; op.items[b] = t;
        e.fx = { k: id, mine: a, theirs: b, gain: me.items[a].id, lose: op.items[b].id, target: oid }; break;
      }
      case 'rewind_locket': {
        const t = st.lastShell; st.chamber.unshift(t); st.pub[t]++; st.lastShell = null;
        for (const w of ['p', 'd']) st.know[w] = st.know[w].map((x) => ({ i: x.i + 1, type: x.type, fake: x.fake }));
        learn(st, who, 0, t, false); e.fx = { k: id, type: t, viewer: who }; break;
      }
      case 'ouija': { hurtMe(st, who, 1); st.chamber.forEach((t, i) => learn(st, who, i, t, false)); e.fx = { k: id, order: st.chamber.slice(), hp: me.hp, viewer: who }; break; }
      case 'scales': {
        const total = me.hp + op.hp, mine = Math.min(me.max, Math.ceil(total / 2)), theirs = Math.max(1, Math.min(op.max, total - mine));
        me.hp = mine; op.hp = theirs; e.fx = { k: id, p: st.p.hp, d: st.d.hp }; break;
      }
      default: e.fx = { k: id };
    }
    if (e.consumed) me.items[idx] = null;
    if (e.stolen) { me.items[e.fx.to] = e.stolen; delete e.stolen; }
    ev.push(e);
    if (id === 'can' && e.fx.empty) E.reload(st, ev);
    if (id === 'pass_token' || (id === 'loaded_die' && e.fx.roll <= 2)) endTurn(st, who, ev);
  }

  /* hand the turn over; pending statuses become active when their owner's turn starts, and end when it ends */
  function setTurn(st, next, ev) {
    const prev = st.turn;
    if (next !== prev) {
      const p = st[prev]; p.fx.lockOn = 0; p.fx.forcedOn = 0;
      const n = st[next];
      if (n.fx.lock) { n.fx.lockOn = 1; n.fx.lock = 0; }
      if (n.fx.forced) { n.fx.forcedOn = 1; n.fx.forced = 0; }
      if (n.fx.regen > 0) { n.fx.regen--; const b = n.hp; n.hp = Math.min(n.max, n.hp + 1); if (n.hp > b) ev.push({ t: 'regen', who: next, hp: n.hp }); }
    }
    st.turn = next;
  }
  function endTurn(st, who, ev) {
    let next = opp(who);
    if (st[next].cuffed) { st[next].cuffed = false; ev.push({ t: 'skip', who: next }); next = who; }
    setTurn(st, next, ev); ev.push({ t: 'turn', who: st.turn });
  }

  function shoot(st, who, target, ev) {
    const me = st[who], h = hooks(st, who);
    if (me.fx.confuse > 0) { me.fx.confuse = 0; if (R.next(st) < 0.5) target = target === 'self' ? 'opp' : 'self'; }
    const count = me.fx.twin ? Math.min(2, st.chamber.length) : 1;
    const victimId = target === 'self' ? who : opp(who), victim = st[victimId];
    const shells = []; let type = null, anyLive = false; const info = { dmg: 0, blocked: 0, reflected: 0, saved: false };
    for (let k = 0; k < count; k++) {
      const t = st.chamber.shift(); st.pub[t]--; st.lastShell = t; shiftKnow(st); shells.push(t); if (type === null || t === 'e') type = t;
      if (t === 'e') {
        anyLive = true;
        let dmg = (h.dmg || 1) + (me.charged ? 1 : 0) + (me.fx.slug ? 1 : 0);
        if (target === 'opp' && h.crit) { st.stats.liveHits++; if (st.stats.liveHits % h.crit === 0) dmg += 1; }
        const r = dealDamage(st, who, victimId, dmg, { pierce: !!h.pierce });
        info.dmg += r.dmg; info.blocked += r.blocked; info.reflected += r.reflected; info.saved = info.saved || r.saved;
        if (victim.hp <= 0) break;
      }
    }
    const charged = me.charged;
    me.charged = false; me.fx.slug = 0; me.fx.twin = 0; me.fx.forcedOn = 0;
    const e = { t: 'shot', who, target, victim: victimId, type, shells, dmg: info.dmg, hp: victim.hp, charged, keep: false, empty: st.chamber.length === 0, blocked: info.blocked, reflected: info.reflected, saved: info.saved };
    if (!anyLive && me.fx.curse > 0) { me.fx.curse = 0; hurtMe(st, who, 1); e.cursed = true; }
    if (who === 'p' && target === 'self') {
      st.stats.shotsSelf++;
      if (type === 'a') { st.stats.ashStreak++; st.stats.bestStreak = Math.max(st.stats.bestStreak, st.stats.ashStreak); } else st.stats.ashStreak = 0;
    }
    if (who === 'p' && target === 'opp' && anyLive) st.stats.liveStreak = info.dmg > 0 ? st.stats.liveStreak + 1 : 0;
    if (anyLive && info.dmg > 0 && target === 'opp' && h.lifesteal && !st.stats.leech && me.hp < me.max) { st.stats.leech = 1; me.hp++; e.heal = 1; }
    ev.push(e);
    if (victim.hp <= 0) {
      const winner = opp(victimId);
      ev.push({ t: 'death', who: victimId }); forget(st);
      if (winner === 'p') { st.stats.roundsWon++; st.phase = st.round >= D.config.rounds ? 'won' : 'between'; } else st.phase = 'lost';
      ev.push({ t: 'roundEnd', winner, phase: st.phase, round: st.round, hpLeft: st.p.hp, dhp: st.d.hp, dmax: st.d.max, pmax: st.p.max, items: st.stats.roundItems, dmg: st.stats.roundDmg, purse: !!st.p.fx.purse, passUsed: st.stats.passUsed, finisher: who === 'p' });
      return;
    }
    let keep = false;
    if (target === 'self' && !anyLive) {
      keep = true;
      if (h.selfBlankHeal && !st.stats.vesper && me.hp < me.max) { st.stats.vesper = 1; me.hp++; e.heal = 1; }
    }
    if (!keep && target === 'opp' && me.fx.extra > 0) { me.fx.extra--; keep = true; e.extraTurn = true; }
    if (!anyLive && target === 'opp' && h.stunBlank && !st[opp(who)].cuffed && R.next(st) < h.stunBlank) { st[opp(who)].cuffed = true; e.stun = true; }
    e.keep = keep;
    if (keep) setTurn(st, who, ev);
    else { let next = opp(who); if (st[next].cuffed) { st[next].cuffed = false; ev.push({ t: 'skip', who: next }); next = who; } setTurn(st, next, ev); }
    if (st.chamber.length === 0) E.reload(st, ev);
    ev.push({ t: 'turn', who: st.turn });
    if (who === 'p' && !keep) me.fx.veil = 0;
  }

  E.apply = function (st, who, action) {
    const ev = [];
    if (st.phase !== 'play') return { ok: false, reason: 'phase', ev };
    if (st.turn !== who) return { ok: false, reason: 'toast.notTurn', ev };
    if (!action) return { ok: false, reason: 'badAction', ev };
    if (action.type === 'item') {
      const c = E.canUse(st, who, action.idx);
      if (!c.ok) return { ok: false, reason: c.reason, ev };
      useItem(st, who, action.idx, ev);
    } else if (action.type === 'shoot' && (action.target === 'self' || action.target === 'opp')) {
      if (!st.chamber.length) return { ok: false, reason: 'empty', ev };
      if (action.target === 'opp' && st[who].fx.forcedOn) return { ok: false, reason: 'toast.forced', ev };
      shoot(st, who, action.target, ev);
    } else return { ok: false, reason: 'badAction', ev };
    return { ok: true, ev };
  };

  /* What `who` is allowed to know (public counts + own knowledge, which may be false). Used by the Dealer AI. */
  E.infoFor = function (st, who) {
    return { ember: st.pub.e, ash: st.pub.a, total: st.chamber.length, peek: E.knownNext(st, who), know: (st.know[who] || []).slice() };
  };

  /* old saves (v1) are repaired here */
  E.normalize = function (st) {
    st.v = 2; st.know = st.know || { p: [], d: [] }; st.know.p = st.know.p || []; st.know.d = st.know.d || [];
    st.weapon = (D.weapons && D.weapons[st.weapon]) ? st.weapon : 'caster'; st.pool = Array.isArray(st.pool) ? st.pool.filter((id) => D.items[id]) : null;
    for (const w of ['p', 'd']) st[w].fx = st[w].fx && typeof st[w].fx === 'object' ? st[w].fx : {};
    for (const k of ['liveHits', 'liveStreak', 'leech', 'vesper', 'passUsed', 'cb']) st.stats[k] = st.stats[k] | 0;
    if (st.peek && st.peek.who && st.peek.who !== 'both' && !st.know[st.peek.who].length && st.peek.type) st.know[st.peek.who] = [{ i: 0, type: st.peek.type, fake: false }];
    sync(st); return st;
  };

  E.validate = function (st) {
    try {
      if (!st || (st.v !== 1 && st.v !== 2) || typeof st.r !== 'number') return false;
      if (!D.difficulties[st.diff]) return false;
      if (!['p', 'd'].includes(st.turn) || !['play', 'between', 'won', 'lost'].includes(st.phase)) return false;
      if (!(st.round >= 0 && st.round <= D.config.rounds)) return false;
      for (const w of ['p', 'd']) {
        const s = st[w];
        if (!s || !(s.hp >= 0 && s.hp <= s.max && s.max <= 14) || !Array.isArray(s.items) || s.items.length !== E.SLOTS) return false;
        for (const it of s.items) if (it && (!D.items[it.id] || !(it.uses >= 1 && it.uses <= 5))) return false;
      }
      if (!Array.isArray(st.chamber) || st.chamber.length > MAXCH + 2 || st.chamber.some((c) => c !== 'e' && c !== 'a')) return false;
      if (st.phase === 'play' && st.chamber.length === 0) return false;
      if (!st.pub || !st.stats) return false;
      return true;
    } catch (e) { return false; }
  };

  G.Engine = E;
  if (typeof module !== 'undefined' && module.exports) module.exports = E;
})(typeof window !== 'undefined' ? window : globalThis);
