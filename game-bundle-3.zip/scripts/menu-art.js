/* menu-art.js — the image-based main menu: hot-spots over the artwork's six buttons, a canvas of falling shotgun shells,
   and the menu song (assets/menu-music.mp3, taken from the supplied video). Pressing Continue stops the song and starts the game. */
(function (G) {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const MA = { music: null, wantMusic: true, playing: false, fx: null, running: false };

  /* ------------------------------------------------------------ music (HTMLAudio: works from file:// and in a WebView) */
  function vol() { const A = G.AudioMgr; return Math.max(0, Math.min(1, (A ? A.vol.music * A.vol.master : 0.7) * 1.15)); }
  function ensureAudio() {
    if (MA.music) return MA.music;
    const a = new Audio('assets/menu-music.mp3'); a.loop = true; a.preload = 'auto'; a.volume = 0; MA.music = a; return a;
  }
  let fadeT = 0;
  function fadeTo(v, ms, done) {
    const a = MA.music; if (!a) return; clearInterval(fadeT); const v0 = a.volume, t0 = performance.now();
    fadeT = setInterval(() => { const k = Math.min(1, (performance.now() - t0) / ms); a.volume = Math.max(0, Math.min(1, v0 + (v - v0) * k)); if (k >= 1) { clearInterval(fadeT); if (done) done(); } }, 40);
  }
  MA.playMusic = function () {
    if (!MA.wantMusic) return; const a = ensureAudio(); if (G.AudioMgr) { G.AudioMgr.menuMusic = true; G.AudioMgr.applyVolumes(); }
    const p = a.play(); const ok = () => { MA.playing = true; $('martHint').classList.add('hidden'); fadeTo(vol(), 1200); };
    if (p && p.then) p.then(ok).catch(() => { MA.playing = false; if (!$('menu').classList.contains('hidden')) $('martHint').classList.remove('hidden'); }); else ok();
  };
  MA.stopMusic = function (ms) {
    if (G.AudioMgr) { G.AudioMgr.menuMusic = false; G.AudioMgr.applyVolumes(); }
    $('martHint').classList.add('hidden'); const a = MA.music; if (!a || !MA.playing) return; MA.playing = false;
    fadeTo(0, ms === undefined ? 500 : ms, () => { a.pause(); a.currentTime = 0; });
  };
  MA.refreshVolume = function () { if (MA.music && MA.playing) MA.music.volume = vol(); };
  document.addEventListener('visibilitychange', () => { const a = MA.music; if (!a) return; if (document.hidden) a.pause(); else if (MA.playing) a.play().catch(() => {}); });

  /* ------------------------------------------------------------ falling shells */
  function sprite(w, h, blur, hue) { // one shotgun shell drawn once into an offscreen canvas
    const pad = Math.ceil(blur * 3) + 2, c = document.createElement('canvas'); c.width = w + pad * 2; c.height = h + pad * 2; const x = c.getContext('2d');
    if (blur) x.filter = 'blur(' + blur + 'px)'; x.translate(pad, pad);
    const bodyH = h * 0.7, r = w * 0.18;
    let g = x.createLinearGradient(0, 0, w, 0); g.addColorStop(0, '#3a0408'); g.addColorStop(0.3, hue || '#c2202a'); g.addColorStop(0.55, '#e0414a'); g.addColorStop(1, '#4a0508');
    x.fillStyle = g; x.beginPath(); x.moveTo(r, 0); x.lineTo(w - r, 0); x.quadraticCurveTo(w, 0, w, r); x.lineTo(w, bodyH); x.lineTo(0, bodyH); x.lineTo(0, r); x.quadraticCurveTo(0, 0, r, 0); x.fill();
    g = x.createLinearGradient(0, 0, w, 0); g.addColorStop(0, '#6b4a14'); g.addColorStop(0.3, '#d9b04a'); g.addColorStop(0.5, '#fff1b0'); g.addColorStop(0.75, '#b8892c'); g.addColorStop(1, '#5a3d0f');
    x.fillStyle = g; x.fillRect(0, bodyH, w, h - bodyH); x.fillStyle = 'rgba(0,0,0,0.35)'; x.fillRect(0, bodyH, w, h * 0.04); x.fillStyle = 'rgba(255,240,200,0.55)'; x.fillRect(w * 0.1, h - h * 0.07, w * 0.8, h * 0.035);
    x.fillStyle = 'rgba(255,255,255,0.22)'; x.fillRect(w * 0.14, h * 0.05, w * 0.12, bodyH * 0.8);   // glossy highlight
    return { c, pad, w, h };
  }
  function startFx() {
    const cv = $('martFx'); if (!cv || MA.running) return; MA.running = true; const ctx = cv.getContext('2d');
    const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    const sp = [sprite(20, 54, 0, '#b81c26'), sprite(20, 54, 0, '#d02a33'), sprite(28, 76, 2.5, '#c2202a'), sprite(40, 108, 5, '#c2202a')], N = reduce ? 8 : 22;
    let W = 0, H = 0, dpr = 1;
    const size = () => { dpr = Math.min(window.devicePixelRatio || 1, 1.5); const w = cv.clientWidth, h = cv.clientHeight; if (w && (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr))) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); } W = cv.width; H = cv.height; };
    const rnd = (a, b) => a + Math.random() * (b - a);
    const mk = (first) => { const d = Math.random(); // depth 0 (far, small) .. 1 (near, big, blurred)
      const k = d < 0.45 ? 0 : d < 0.75 ? 1 : d < 0.93 ? 2 : 3, s = [0.55, 0.8, 0.9, 0.95][k] * rnd(0.85, 1.15);
      return { k, s: s * (H / 520), x: (Math.random() < 0.5 ? rnd(0, 0.33) : rnd(0.67, 1)) * W, y: first ? rnd(-H * 0.2, H) : rnd(-H * 0.3, -20), vy: rnd(0.35, 0.6) * H * (0.5 + d), vx: rnd(-0.008, 0.008) * W, rot: rnd(0, 6.28), vr: rnd(-3, 3), floor: H * (0.8 + 0.15 * d), bounce: 0, life: 0, state: 0, a: 1 }; };
    const P = []; const spark = []; const fog = []; size(); for (let i = 0; i < N; i++) P.push(mk(true));
    for (let i = 0; i < 7; i++) fog.push({ x: rnd(0, 1), y: rnd(0.78, 1), r: rnd(0.18, 0.34), v: rnd(0.004, 0.012) * (Math.random() < 0.5 ? -1 : 1), a: rnd(0.05, 0.12) });
    const dust = []; for (let i = 0; i < (reduce ? 10 : 40); i++) dust.push({ x: Math.random(), y: Math.random(), v: rnd(0.01, 0.04), s: rnd(0.6, 2), tw: rnd(0, 6.28) });
    let last = performance.now();
    function loop(now) {
      if ($('menu').classList.contains('hidden')) { MA.running = false; return; }
      requestAnimationFrame(loop); const dt = Math.min(0.05, (now - last) / 1000); last = now; size(); ctx.clearRect(0, 0, W, H);
      const t = now / 1000;
      // drifting fog banks near the floor
      ctx.globalCompositeOperation = 'screen';
      for (const f of fog) { f.x += f.v * dt; if (f.x > 1.3) f.x = -0.3; if (f.x < -0.3) f.x = 1.3; const g = ctx.createRadialGradient(f.x * W, f.y * H, 0, f.x * W, f.y * H, f.r * W); g.addColorStop(0, 'rgba(150,120,120,' + f.a * (0.8 + 0.2 * Math.sin(t * 0.7 + f.x * 9)) + ')'); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = g; ctx.fillRect(f.x * W - f.r * W, f.y * H - f.r * W, f.r * W * 2, f.r * W * 2); }
      // embers / dust
      for (const d of dust) { d.y -= d.v * dt; d.x += Math.sin(t * 0.6 + d.tw) * 0.002; if (d.y < -0.02) { d.y = 1.02; d.x = Math.random(); } const a = 0.25 + 0.25 * Math.sin(t * 2 + d.tw); ctx.fillStyle = 'rgba(255,90,60,' + a + ')'; ctx.fillRect(d.x * W, d.y * H, d.s * dpr, d.s * dpr); }
      ctx.globalCompositeOperation = 'source-over';
      // shells
      for (const p of P) {
        if (p.state === 0) {
          p.y += p.vy * dt; p.x += p.vx * dt; p.rot += p.vr * dt;
          if (p.y >= p.floor) { // lands on the wet floor: one bounce, sparks, then fades
            if (p.bounce < 1) { p.bounce++; p.vy = -p.vy * 0.32; p.vr *= 0.5; p.y = p.floor; for (let i = 0; i < 5; i++) spark.push({ x: p.x, y: p.floor, vx: rnd(-0.12, 0.12) * W, vy: rnd(-0.18, -0.04) * H, l: 0.5, c: p.k }); }
            else { p.state = 1; p.vy = 0; }
          }
        } else { p.life += dt; p.a = Math.max(0, 1 - p.life * 0.7); if (p.a <= 0) { Object.assign(p, mk(false)); continue; } }
        if (p.state === 0 && p.bounce === 1) p.vy += H * 1.6 * dt;
        const sc = sp[p.k]; ctx.save(); ctx.globalAlpha = p.a * (p.k === 3 ? 0.85 : 1); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
        if (p.state === 1) { ctx.scale(1, 0.55); }
        ctx.scale(p.s, p.s); ctx.drawImage(sc.c, -sc.w / 2 - sc.pad, -sc.h / 2 - sc.pad); ctx.restore();
        if (p.state === 1) { ctx.save(); ctx.globalAlpha = p.a * 0.25; ctx.translate(p.x, p.floor + sc.h * p.s * 0.55); ctx.scale(p.s, -p.s * 0.4); ctx.rotate(p.rot); ctx.drawImage(sc.c, -sc.w / 2 - sc.pad, -sc.h / 2 - sc.pad); ctx.restore(); }   // reflection
      }
      ctx.globalCompositeOperation = 'lighter';
      for (let i = spark.length - 1; i >= 0; i--) { const s = spark[i]; s.l -= dt; if (s.l <= 0) { spark.splice(i, 1); continue; } s.vy += H * 1.5 * dt; s.x += s.vx * dt; s.y += s.vy * dt; ctx.fillStyle = 'rgba(255,' + (150 + s.c * 20) + ',90,' + (s.l * 1.4) + ')'; ctx.fillRect(s.x, s.y, 2 * dpr, 2 * dpr); }
      ctx.globalCompositeOperation = 'source-over';
    }
    requestAnimationFrame(loop);
  }
  MA.show = function () { startFx(); MA.playMusic(); };

  /* ------------------------------------------------------------ wiring */
  MA.wire = function () {
    const UI = G.UI, T = () => G.Turns, Save = G.SaveMgr || G.Save;
    const on = (id, fn) => { const e = $(id); if (e) e.addEventListener('click', (ev) => { if (G.AudioMgr) G.AudioMgr.unlock(); fn(ev); }); };
    on('hContinue', () => {
      MA.stopMusic(450);   // the song stops, the game begins
      if (Save.hasRun()) T().continueGame(); else UI.startNew((T().meta && T().meta.lastDiff) || 'normal');
    });
    on('hSettings', () => $('mSettings').click()); on('hShop', () => $('bShop').click()); on('hArchive', () => $('bArchive').click()); on('hAch', () => $('bAch').click()); on('hLeave', () => $('bLeave').click());
    on('hNew', () => $('mNew').click()); on('hCred', () => $('bCredits').click()); on('hFull', () => $('mFull').click());
    on('hSound', () => { MA.wantMusic = !MA.wantMusic; $('hSound').style.opacity = MA.wantMusic ? 1 : 0.55; { const i = $('hSound').querySelector('[data-ic]'); if (i && G.UI && G.UI.hydrateIcons) { i.dataset.ic = MA.wantMusic ? 'sound' : 'mute'; G.UI.hydrateIcons($('hSound')); } } if (MA.wantMusic) MA.playMusic(); else MA.stopMusic(300); });
    // browsers only allow sound after a gesture: the first touch/click/key starts the song
    const first = () => { if (!$('menu').classList.contains('hidden') && MA.wantMusic && !MA.playing) MA.playMusic(); };
    ['pointerdown', 'keydown', 'touchstart'].forEach((ev) => document.addEventListener(ev, first, { passive: true }));
    // the menu is the only screen with the song: showing it starts it, leaving it stops it
    const sm = UI.showMenu, sg = UI.showGame;
    UI.showMenu = function () { sm.apply(this, arguments); G.Renderer && (G.Renderer.menuCover = true); MA.show(); };
    UI.showGame = function () { MA.stopMusic(450); G.Renderer && (G.Renderer.menuCover = false); return sg.apply(this, arguments); };
    G.Renderer && (G.Renderer.menuCover = true);
    MA.show();
  };
  G.MenuArt = MA;
})(window);
