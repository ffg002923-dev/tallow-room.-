/* gameplay.js — the presentation director ("Show"). It NARRATES events produced by the authoritative rules engine:
   it never decides outcomes. Each sequence is an async function; every await is cancellable (token) so a restart can
   never leave a half-finished sequence mutating the scene. After each narrated chunk the HUD view is re-synced from
   the real game state, so a missed/skipped animation event can never leave the display wrong. */
(function (G) {
  'use strict';
  const U = G.U, D = G.GameData, AD = G.AnimData, Anim = G.Anim, R = G.Renderer, Au = G.AudioMgr, Art = G.Art, Phys = G.Physics, E = G.Engine;
  const CANCEL = { cancelled: true };
  const Sc = R.scene;
  const Show = {
    CANCEL, token: 0, timers: [], tweens: [], handlers: {}, view: null, aimWho: null, aimed: null, waiting: false, idleT: 0, st: null, settings: null, flags: {}
  };
  const A = (w) => (w === 'p' ? Anim.player : Anim.dealer);
  const rel = (p) => ({ x: p.x - 640, y: p.y, s: p.s });

  /* ---------------------------------------------------------------- core: time, cancellation, wrappers */
  Show.cancelled = (e) => e === CANCEL;
  Show.reset = function () {
    Show.token++; Show.timers.length = 0; Show.tweens.length = 0; Show.handlers = {}; Show.aimed = null; Show.aimWho = null; Show.waiting = false;
    Sc.gunHolder = 'table'; Sc.held.p = null; Sc.held.d = null; Sc.lens = null; Sc.selected = null; Sc.flashObj = null;
    Sc.flash = 0; Sc.hurt = 0; Sc.fade = 0; Sc.redWash = 0; Sc.blackout = 0; Sc.doorLight = 0; Sc.lampBase = 1; Sc.lowPulse = 0; Sc.charge = 0; Sc.dread = 0; Sc.tvGlitch = 0;
    Sc.cuffs.p = Sc.cuffs.d = false; R.shakeAmp = 0; Sc.cine.k = 0; Sc.cine.p = 0;
    Phys.clear(); Anim.resetAll(); Anim.gun.setIdle('gun_table_idle'); Anim.player.ambient.on = true; Anim.dealer.ambient.on = true;
  };
  Show.update = function (dt) {
    for (let i = Show.timers.length - 1; i >= 0; i--) { const t = Show.timers[i]; t.t -= dt; if (t.t <= 0) { Show.timers.splice(i, 1); t.res(); } }
    for (let i = Show.tweens.length - 1; i >= 0; i--) {
      const w = Show.tweens[i]; w.t += dt; const k = U.clamp(w.t / w.d, 0, 1), e = (U.ease[w.e] || U.ease.inout)(k);
      w.o[w.k] = w.a + (w.b - w.a) * e; if (k >= 1) { Show.tweens.splice(i, 1); w.res(); }
    }
    if (Show.waiting && !G.Turns.busy) { Show.idleT -= dt; if (Show.idleT <= 0) { Show.say('idle', null, Math.random() < 0.5 ? 'whisper' : 'murmur'); Show.idleT = 16 + Math.random() * 14; } }
  };
  const wrap = (p) => { const tk = Show.token; return p.then((v) => { if (tk !== Show.token) throw CANCEL; return v; }); };
  Show.sleep = (s) => wrap(new Promise((res) => { Show.timers.push({ t: Math.max(0.001, s), res }); }));
  Show.play = (who, clip, o) => wrap(Anim.actors[who === 'p' ? 'player' : who === 'd' ? 'dealer' : who].play(clip, o));
  Show.tween = (o, k, b, d, e) => wrap(new Promise((res) => { Show.tweens.push({ o, k, a: o[k], b, d: Math.max(0.01, d), t: 0, e: e || 'inout', res }); }));
  const reduced = () => !!(Show.settings && Show.settings.reduced);

  /* ---------------------------------------------------------------- audio / event hooks from the animation controller */
  Anim.onSfx = function (actor, name, vol) { Au.sfx(name, { vol: vol === undefined ? 1 : vol, pan: actor === 'dealer' ? 0 : 0 }); };
  Anim.onEvent = function (actor, name, clip) {
    const h = Show.handlers[name]; if (h && !(h.actor && h.actor !== actor)) { if (h.once) delete Show.handlers[name]; h.fn(clip); }
    switch (name) {
      case 'laugh_start': Au.speak('', 'laugh'); if (Show.settings && Show.settings.subtitles && Math.random() < 0.6) G.UI && G.UI.subtitle('Hah... hahah.', 1.4); break;
      case 'rage_slam': Show.rageSlam(); break;
      case 'rage_roar': Au.speak('', 'rage'); break;
      case 'glitch_start': Sc.tvGlitch = 1; Show.tween(Sc, 'tvGlitch', 0, 0.8).catch(() => {}); R.flicker(0.35); break;
      case 'chamber_glint': R.sparks(R.muzzlePos().x - 120, R.muzzlePos().y, 3, { speed: 40, size: 6, life: 0.4, g: 0 }); break;
      case 'inspect_started': break;
      default: break;
    }
  };

  /* ---------------------------------------------------------------- dealer dialogue */
  /* v7.6: no line repeats back to back (per category), and each category has its own performance (mood) unless the caller passes one */
  const MOOD_OF = { round1: 'excited', round2: 'excited', round3: 'excited', greet: 'boom', win: 'boom', lose: 'rage', dealerFireYou: 'boom', dealerFireSelf: 'boom', dealerHitYou: 'excited', dealerHitSelf: 'boom', dealerAsh: 'boom', playerSelfAsh: 'boom', playerHitDealer: 'rage', slapBack: 'rage' };
  Show.lastLine = {};
  Show.say = function (cat, params, mood) {
    try {
      const arr = (D.lines.en && D.lines.en[cat]) || [], n = arr.length; let r = Math.random();
      if (n > 1) { let i = Math.floor(r * n) % n; const last = Show.lastLine[cat]; if (i === last) i = (i + 1 + Math.floor(Math.random() * (n - 1))) % n; Show.lastLine[cat] = i; r = (i + 0.5) / n; }
      const text = U.line(cat, params, undefined, r); if (!text) return 0;
      const m = mood || MOOD_OF[cat] || 'normal';
      const dur = Au.speak(text, m);
      Anim.dealer.play(AD.speak(dur, m === 'whisper'));
      const sl = Show.settings && Show.settings.subLang;
      if (G.UI) G.UI.subtitle(sl && sl !== 'auto' ? U.line(cat, params, sl, r) : text, dur + 0.4, m, sl && sl !== 'auto' ? sl : null);
      return dur;
    } catch (e) { return 0; }
  };
  Show.face = (name) => Anim.dealer.play('face_' + name);
  const hapt = (ms) => { try { if (Show.settings && Show.settings.haptics && navigator.vibrate) navigator.vibrate(ms); } catch (e) { /* ignore */ } };

  /* ---------------------------------------------------------------- view model (what the HUD shows) */
  Show.syncView = function (st) {
    const v = Show.view || (Show.view = {});
    v.pHp = st.p.hp; v.pMax = st.p.max; v.dHp = st.d.hp; v.dMax = st.d.max; v.round = st.round; v.turn = st.phase === 'play' ? st.turn : null;
    v.pubE = st.pub.e; v.pubA = st.pub.a; v.peek = st.peek.who === 'p' ? st.peek.type : null; v.charged = { p: st.p.charged, d: st.d.charged };
    v.cuffed = { p: st.p.cuffed, d: st.d.cuffed }; v.total = st.chamber.length; v.diff = st.diff;
    Sc.cuffs.p = st.p.cuffed; Sc.cuffs.d = st.d.cuffed; Sc.charge = (st.p.charged || st.d.charged) ? 1 : 0;
    Sc.lowPulse = st.phase === 'play' && st.p.hp === 1 ? 1 : 0;
    const frac = st.pub.e / Math.max(1, st.pub.e + st.pub.a);
    Au.setTension(st.phase === 'play' ? U.clamp(0.15 + 0.35 * (1 - st.p.hp / st.p.max) + 0.35 * frac + (st.p.hp === 1 ? 0.2 : 0), 0, 1) : 0.1);
    Anim.tension = Au.tensionNow = st.phase === 'play' ? 0.4 + 0.5 * (1 - st.p.hp / st.p.max) : 0;
    // items on the table follow the real inventory
    for (const who of ['p', 'd']) for (let i = 0; i < 6; i++) {
      const real = st[who].items[i], shown = Sc.items[who][i];
      if (!real && shown && !shown.hidden) Sc.items[who][i] = null;
      else if (real && !shown) R.setItem(who, i, real.id, real.uses, false);
      else if (real && shown) shown.uses = real.uses;
    }
    if (G.UI) G.UI.refreshHud();
  };

  /* ---------------------------------------------------------------- scene setup */
  Show.menuScene = function () {
    Show.reset(); Sc.mode = 'menu'; R.clearItems();
    const ids = D.itemOrder.slice(); const r = (n) => ids[(n * 7 + 3) % ids.length];
    [[0, 'magnifier'], [2, 'cigarette'], [4, 'lighter']].forEach(([i, id]) => R.setItem('p', i, id, 1, false));
    [[1, 'handcuffs'], [3, 'can'], [5, 'medicine']].forEach(([i, id]) => R.setItem('d', i, id, 1, false));
    Au.setTension(0.12); Au.setMusicMode('menu');
  };
  Show.restoreScene = function (st) {
    Show.reset(); Sc.mode = 'game'; R.clearItems();
    Show.syncView(st);
  };

  /* ---------------------------------------------------------------- gun custody (hands follow the gun: never detached mid-air) */
  const GRIP = { x: -62, y: 522 }, FORE = { x: 80, y: 520 };
  function detachHands(who) {
    const w = R.handWrist[who]; if (!w) return; const p = A(who).p;
    p.lx = w.lx; p.ly = w.ly; p.lr = w.lr; p.rx = w.rx; p.ry = w.ry; p.rr = w.rr;
    for (const k of ['c', 'i', 't']) { p['l' + k] = 0.85; p['r' + k] = 0.9; }
    p.ls = p.rs = who === 'p' ? 1.05 : 0.92;
  }
  Show.gunIdle = function (kind) { const m = Show.settings && Show.settings.gunHold; return 'gun_idle_' + kind + '_' + (m === 'subtle' || m === 'natural' ? m : 'locked'); };
  /* The clip the gun actor falls back to whenever nothing else drives it. It is the pose that is being held right now, so a finished aim / fire / recoil clip can never let the
     gun drift back to the lying-on-the-table pose while somebody still holds it (that drift was what swung the weapon around after a shot and when the Dealer aimed). */
  Show.setGunIdle = function (kind) { Anim.gun.setIdle(kind ? Show.gunIdle(kind) : 'gun_table_idle'); };
  Show.holdKind = function (who, target) { return who === 'p' ? (target === 'self' ? 'self' : 'dealer') : (target === 'self' ? 'dself' : 'dplayer'); };
  Show.takeGun = async function (who) {
    if (Sc.gunHolder === who) return;
    Anim.player.ambient.on = false; Anim.dealer.ambient.on = false;
    const hs = who === 'p' ? 1.05 : 0.9;
    const reach = AD.moveHands('reach_gun_' + who, who === 'p' ? 0.7 : 0.9, { l: { x: FORE.x, y: FORE.y, r: who === 'p' ? 0.1 : 0.05, c: 0.25, i: 0.25, t: 0.3, s: hs }, r: { x: GRIP.x, y: GRIP.y, r: who === 'p' ? 0.1 : 0.05, c: 0.25, i: 0.25, t: 0.3, s: hs } }, { sfx: [{ t: 0.1, name: 'cloth', vol: 0.5 }] });
    await Show.play(who, reach);
    await Show.play(who, AD.moveHands('grab_gun_' + who, 0.3, { l: { c: 0.9, i: 0.9, t: 0.85 }, r: { c: 0.9, i: 0.9, t: 0.9 } }, { ease: 'in', sfx: [{ t: 0.12, name: 'gun_pickup', vol: 0.9 }] }));
    Sc.gunHolder = who; Show.setGunIdle(who === 'p' ? 'held' : 'dtake');
    await Show.play('gun', who === 'p' ? 'gun_enter' : 'gun_dealer_take');
    Anim.gun.play(Show.gunIdle(who === 'p' ? 'held' : 'dtake'));
  };
  Show.putGun = async function (who) {
    if (Sc.gunHolder !== who) return;
    Show.aimed = null; Show.aimWho = null; Show.setGunIdle(null);
    await Show.play('gun', 'gun_return', { force: true });
    detachHands(who); Sc.gunHolder = 'table';
    Au.sfx('place', { vol: 0.9 });
    const rest = who === 'p' ? 'hand_rest' : 'd_rest_hands';
    await Show.play(who, AD.moveHands('release_gun_' + who, 0.5, { l: { c: 0.3, i: 0.3, t: 0.3 }, r: { c: 0.3, i: 0.3, t: 0.3 } }, { ease: 'out' }));
    Anim.gun.play('gun_table_idle', { force: true });
    Anim.actors[who === 'p' ? 'player' : 'dealer'].play(rest);
    Anim.player.ambient.on = true; Anim.dealer.ambient.on = true;
  };
  Show.aimGun = async function (who, target) {
    const clip = who === 'p' ? (target === 'self' ? 'gun_raise_self' : 'gun_raise_dealer') : (target === 'self' ? 'gun_dealer_aim_self' : 'gun_dealer_aim_player');
    Show.aimed = target; Show.aimWho = who;
    Sc.dread = target === 'self' || who === 'd' ? 1 : 0.5;
    if (who === 'p') Anim.dealer.play(target === 'self' ? 'face_amusement' : 'face_suspicion');
    else Anim.dealer.play(target === 'self' ? 'face_smile' : 'face_stare');
    const kind = Show.holdKind(who, target); Show.setGunIdle(kind);
    await Show.play('gun', clip, { force: true });
    Anim.player.play('hand_tremble'); // loop, interruptible: nervous trembling while aimed
    Anim.gun.play(Show.gunIdle(kind));      // keep the aimed pose (the Dealer's aim used to fall back to the table pose here)
  };
  Show.lowerGun = async function () {
    if (Sc.gunHolder !== 'p') return;
    Sc.dread = 0; Show.setGunIdle('held');
    await Show.play('gun', 'gun_lower', { force: true });
    await Show.putGun('p');
  };
  Show.inspectGun = async function () {
    Anim.player.ambient.on = false;
    await Show.takeGun('p');
    Anim.gun.play('gun_inspect', { force: true }); Au.sfx('metal_clink', { vol: 0.6 });
    await Show.sleep(1.9);
    await Show.putGun('p');
  };

  /* ---------------------------------------------------------------- shooting */
  Show.shot = async function (ev) {
    const who = ev.who, target = ev.target, isP = who === 'p';
    Anim.player.ambient.on = false; Anim.dealer.ambient.on = false;
    if (Sc.gunHolder !== who) await Show.takeGun(who);
    if (Show.aimed !== target || Show.aimWho !== who) await Show.aimGun(who, target);
    if (!isP) {
      Show.say(target === 'self' ? 'dealerFireSelf' : 'dealerFireYou');
      Au.setTension(1); Au.sfx('heartbeat', { vol: 0.7 }); R.flicker(0.4);
      await Show.sleep(reduced() ? 0.5 : 0.9 + Math.random() * 0.8);
      if (Math.random() < 0.5) Anim.player.play('hand_hesitate', { force: true });
    } else { Au.sfx('heartbeat', { vol: 0.5 }); await Show.sleep(0.25); }
    // --- the shot itself (outcome is already decided by the engine: ev.type / ev.dmg)
    const mz = R.muzzlePos(), ember = ev.type === 'e';
    Anim.gun.play('gun_fire', { force: true });
    if (isP) Anim.player.play('hand_fire', { force: true });
    if (ember) {
      Au.sfx('gun_fire', { vol: 1, minGap: 0.1 }); Au.buzzSpike(1.2);
      R.muzzle(mz.x, mz.y, mz.ang, true); R.shake(ev.charged ? 1.6 : 1); R.punchZoom(1); R.flash(ev.charged ? '190,220,255' : '255,190,120', ev.charged ? 0.8 : 0.5); R.flicker(0.35);
      R.smoke(mz.x, mz.y, 8, { size: 22, life: 3, alpha: 0.55, vy: -26 }); R.sparks(mz.x, mz.y, 12, { dir: mz.ang, spread: 0.9, speed: 380 });
      hapt([30, 40, 30]);
    } else {
      Au.sfx('gun_dry', { vol: 1, minGap: 0.1 }); R.smoke(mz.x, mz.y, 3, { size: 14, life: 2, alpha: 0.35, vy: -20 }); R.shake(0.15);
    }
    // eject the spent shell onto the table (cosmetic physics)
    const br = R.gunPoint(70, -10), sgn = isP ? 1 : -1;
    Phys.spawn(ember ? 'shell_e' : 'shell_a', br.x - 640, U.clamp(br.y, 440, 650), 70, sgn * (90 + Math.random() * 90), (isP ? 1 : -1) * 40, 380, Math.random() * 6, (Math.random() - 0.5) * 24);
    Show.view.pub = Show.view.pub || {}; if (ember) Show.view.pubE = Math.max(0, Show.view.pubE - 1); else Show.view.pubA = Math.max(0, Show.view.pubA - 1);
    if (G.UI) G.UI.refreshHud();
    // --- victim reaction
    const victimIsP = ev.victim === 'p';
    if (ember) {
      Au.sfx('impact_hit', { vol: 1, delay: 0.02 });
      if (G.Stage3D && G.Stage3D.bloodAt) G.Stage3D.bloodAt(victimIsP ? 'p' : 'd', 8);
      if (victimIsP) { Sc.hurt = 1; R.flash('200,0,12', 0.45); R.shake(1.4); hapt([80, 50, 120]); Anim.player.play('hand_startle'); G.UI && G.UI.toast(U.t('toast.hurt', { n: ev.dmg }), 'bad'); Show.view.pHp = ev.hp; }
      else {
        Anim.dealer.play('d_hit_react', { force: true }); R.sparks(640, 235, 18, { speed: 300, size: 10 }); R.chips(640, 235, 16, '#e8dfca'); R.flash('255,150,80', 0.3); Show.view.dHp = ev.hp; G.UI && G.UI.toast(U.t('toast.hurt', { n: ev.dmg }), 'good');
      }
      if (G.UI) G.UI.refreshHud();
    }
    // --- dialogue (voice only; subtitles follow)
    await Show.sleep(0.35);
    if (isP) {
      if (target === 'opp') Show.say(ember ? 'playerHitDealer' : 'playerAshDealer');
      else Show.say(ember ? 'playerSelfHit' : 'playerSelfAsh');
      if (!ember && target === 'self') { Anim.dealer.play('face_confusion'); Anim.player.play('hand_hesitate'); }
    } else {
      if (target === 'opp') Show.say(ember ? 'dealerHitYou' : 'dealerAsh');
      else Show.say(ember ? 'dealerHitSelf' : 'dealerAsh');
      Anim.dealer.play(ember && target === 'self' ? 'face_frustration' : (ember ? 'face_amusement' : 'face_disappointment'));
    }
    await Show.sleep(ember ? 0.9 : 0.6);
    Anim.gun.play('gun_recoil', { force: true });
    await Show.sleep(0.3);
    if (ev.dmg && ev.hp <= 0) return; // death sequence follows; gun stays where it is
    await Show.putGun(who);
    if (!isP) Anim.dealer.play('face_neutral');
    Anim.player.ambient.on = true; Anim.dealer.ambient.on = true;
    // SLAP / SLAP BACK: only after a survived LIVE self-shot (never a blank, never fatal)
    const liveSelf = ember && target === 'self' && ev.dmg > 0 && ev.hp > 0;
    if (liveSelf && G.Slap) { try { if (isP) await G.Slap.back(); else await G.Slap.offer(3500); } catch (e) { /* a cosmetic failure must never stall the game */ } }
  };

  /* ---------------------------------------------------------------- items */
  function applyEffectVisual(ev, fx, who) {
    const mine = who === 'p', pos = mine ? (R.heldPos || { x: 700, y: 400 }) : (R.heldPosD || { x: 700, y: 330 });
    switch (fx.k) {
      case 'peek':
        if (mine) { Sc.lens = { t: 0, type: fx.type, out: false }; Au.sfx('shell_reveal', { vol: 0.8 }); Show.view.peek = fx.type; G.UI && G.UI.toast(U.t(fx.type === 'e' ? 'hud.peekEmber' : 'hud.peekAsh'), fx.type === 'e' ? 'bad' : 'good'); }
        else Anim.dealer.play('face_smile');
        break;
      case 'cuff': Sc.cuffs[who === 'p' ? 'd' : 'p'] = true; Au.sfx('cuff_close', { vol: 1 }); R.flash('200,200,210', 0.12); G.UI && G.UI.toast(U.t(mine ? 'toast.cuffedD' : 'toast.cuffedP'), mine ? 'good' : 'bad'); if (mine) Show.face('suspicion'); break;
      case 'heal': (mine ? (Show.view.pHp = fx.hp) : (Show.view.dHp = fx.hp)); R.smoke(pos.x, pos.y - 20, 5, { size: 14, life: 2.2, alpha: 0.35 }); if (mine) G.UI && G.UI.toast(U.t('toast.heal', { n: fx.amt }), 'good'); R.flash('255,180,120', 0.08); break;
      case 'charge': Sc.charge = 1; R.flash('190,220,255', 0.3); Au.buzzSpike(1); R.shake(0.3); G.UI && G.UI.toast(U.t('toast.charge'), 'good'); break;
      case 'pills': (mine ? (Show.view.pHp = fx.hp) : (Show.view.dHp = fx.hp)); R.flash(fx.good ? '170,255,170' : '255,40,40', 0.22); if (mine) G.UI && G.UI.toast(fx.good ? U.t('toast.heal', { n: fx.amt }) : U.t('toast.hurt', { n: -fx.amt }), fx.good ? 'good' : 'bad'); if (!fx.good && mine) { Sc.hurt = 0.5; hapt(60); } break;
      case 'eject': {
        const gp = R.gunPoint(60, -12); Phys.spawn(fx.type === 'e' ? 'shell_e' : 'shell_a', gp.x - 640, gp.y, 60, (mine ? 1 : -1) * 120, -60, 360, 0, 14);
        if (fx.type === 'e') Show.view.pubE = Math.max(0, Show.view.pubE - 1); else Show.view.pubA = Math.max(0, Show.view.pubA - 1);
        Au.sfx('shell_drop', { vol: 0.9 }); if (mine) G.UI && G.UI.toast(U.t('toast.eject', { s: U.t(fx.type === 'e' ? 'toast.ember' : 'toast.ash') }), fx.type === 'e' ? 'bad' : 'good'); else G.UI && G.UI.toast(U.t('toast.eject', { s: U.t(fx.type === 'e' ? 'toast.ember' : 'toast.ash') }), 'info');
        break;
      }
      case 'burn': {
        const tgt = Sc.items[fx.target][fx.slot]; if (tgt) { tgt.burn = 0.01; setTimeout(() => {}, 0); }
        Au.sfx('burn', { vol: 0.8 }); G.UI && G.UI.toast(U.t('toast.burn'), mine ? 'good' : 'bad');
        const w = R.slotWorld(fx.target, fx.slot); R.burnFx(w.x, w.y);
        if (!mine) Show.say('burnt');
        break;
      }
      case 'scramble': Sc.tvGlitch = 1; Show.tween(Sc, 'tvGlitch', 0, 1.0).catch(() => {}); R.flash('160,255,200', 0.14); R.shake(0.4); Show.view.peek = null; G.UI && G.UI.toast(U.t('toast.scramble'), 'info'); break;
      case 'stab': {
        const toP = fx.target === 'p'; if (toP) { Show.view.pHp = fx.hp; Sc.hurt = 0.7; hapt(80); R.shake(0.5); } else { Show.view.dHp = fx.hp; R.chips(640, 235, 10, '#a3141b'); Anim.dealer.play('d_hit_react', { force: true }); }
        if (G.Stage3D && G.Stage3D.bloodAt) G.Stage3D.bloodAt(toP ? 'p' : 'd', 5);
        R.flash('255,40,40', 0.25); G.UI && G.UI.toast(U.t(toP ? 'toast.stabP' : 'toast.stabD'), toP ? 'bad' : 'good'); break;
      }
      case 'blank': {
        Show.view.pubA += 1; Show.view.pubE = Math.max(0, Show.view.pubE - (fx.was === 'e' ? 1 : 0)); if (fx.was === 'a') Show.view.pubA -= 1;
        R.sparks(pos.x, pos.y, 8, { speed: 120, size: 6, life: 0.5 }); R.flash('200,180,230', 0.12); G.UI && G.UI.toast(U.t('toast.blankMade'), 'info'); break;
      }
      case 'spray': {
        R.smoke(pos.x + 40, pos.y - 30, 10, { size: 22, life: 2.6, alpha: 0.35, vy: -20 }); Sc.charge = fx.target === 'p' ? Sc.charge : (fx.target === 'd' ? Sc.charge : Sc.charge);
        Au.sfx('zap', { vol: 0.25 }); R.flash('220,200,240', 0.1); Show.view.peek = (fx.target === 'p') ? Show.view.peek : null; G.UI && G.UI.toast(U.t('toast.sprayed'), 'info'); break;
      }
      case 'steal': {
        const src = Sc.items[fx.target], from = src[fx.from]; src[fx.from] = null;
        R.setItem(who, fx.to, fx.id, 1, true); Au.sfx('place', { vol: 0.7 }); G.UI && G.UI.toast(U.t('toast.stolen'), mine ? 'good' : 'bad'); break;
      }
      case 'coin': applyEffectVisual(ev, fx.inner, who); break;
      default: {   // v6 items: generic but readable feedback (flash by category, sound, named toast); state is already resolved by the engine
        const def = D.items[ev.id], cat = def ? def.cat : 'utility';
        const col = { detect: '120,200,255', heal: '150,255,170', attack: '255,70,50', control: '200,200,215', defense: '210,190,120', strategy: '190,160,255', chaos: '255,170,60', utility: '220,220,220', curse: '150,40,170', support: '255,230,150' }[cat] || '220,220,220';
        R.flash(col, 0.16); R.sparks(pos.x, pos.y, 6, { speed: 90, size: 5, life: 0.5 });
        Au.sfx(cat === 'attack' ? 'zap' : cat === 'heal' ? 'pickup' : cat === 'curse' ? 'burn' : 'place', { vol: 0.6 });
        if (typeof fx.hp === 'number' && fx.target !== 'p' && fx.target !== 'd') { if (mine) Show.view.pHp = fx.hp; else Show.view.dHp = fx.hp; }
        if (G.UI) G.UI.toast(U.t('item.' + ev.id + '.name') + ' — ' + U.t('item.' + ev.id + '.d'), mine ? 'good' : 'info');
        break;
      }
    }
    if (G.UI) G.UI.refreshHud();
  }

  Show.item = async function (ev) {
    const who = ev.who, actor = who === 'p' ? 'player' : 'dealer', isP = who === 'p', id = ev.id;
    Anim.player.ambient.on = false; Anim.dealer.ambient.on = false;
    const slot = rel(R.slotWorld(who, ev.idx)), entry = Sc.items[who][ev.idx];
    if (!isP) { Show.face('suspicion'); await Show.sleep(0.25); }
    const hs = isP ? 1.05 : 0.85;
    // 1. reach for the item
    const dist = Math.hypot(slot.x - (isP ? 250 : 150), slot.y - (isP ? 652 : 452)), rt = U.clamp(0.35 + dist / 700, 0.45, 0.9);
    await Show.play(who, AD.moveHands('reach_slot', rt, { r: { x: slot.x, y: slot.y + (isP ? 16 : 26), r: 0.05, c: 0.1, i: 0.1, t: 0.15, s: hs } }, { sfx: [{ t: 0.1, name: 'cloth', vol: 0.5 }] }));
    // 2. grab: item attaches to the right-hand anchor and leaves the table slot
    await Show.play(who, AD.moveHands('grab_item', 0.28, { r: { c: 0.9, i: 0.9, t: 0.8 } }, { ease: 'in', sfx: [{ t: 0.12, name: 'pickup', vol: 0.9 }] }));
    if (entry) entry.hidden = true; Sc.held[who] = { kind: 'item', id };
    const anc = AD.anchors[who];
    await Show.play(who, AD.moveHands('to_hold', 0.55, { r: { x: anc.hold.x, y: anc.hold.y, s: anc.hold.s, r: anc.hold.r, c: 0.85, i: 0.85, t: 0.75 } }));
    if (!isP && Math.random() < 0.7) Show.say('dealerItem');
    // 3. the item-specific use animation; effects land at its 'effect' event
    let applied = false;
    const target = ev.fx && ev.fx.k === 'burn' ? rel(R.slotWorld(ev.fx.target, ev.fx.slot)) : null;
    const clip = AD.itemUse(id, who, target ? { x: target.x, y: target.y - 10, s: target.s } : null);
    const doFx = () => { if (applied) return; applied = true; applyEffectVisual(ev, ev.fx, who); };
    Show.handlers.effect = { fn: doFx, once: true };
    Show.handlers.smoke = { fn: () => { const hp = isP ? { x: 640, y: 640 } : { x: 646, y: 300 }; R.smoke(hp.x, hp.y, 5, { size: 14, life: 2.6, alpha: 0.4, vy: -34 }); } };
    Show.handlers.smoke_light = { fn: () => { const p = isP ? (R.heldPos || { x: 700, y: 440 }) : (R.heldPosD || { x: 700, y: 330 }); R.sparks(p.x - 20, p.y, 5, { dir: -1.57, spread: 1, speed: 80, g: 0, size: 6, life: 0.4 }); } };
    Show.handlers.fizz = { fn: () => { const p = isP ? (R.heldPos || { x: 700, y: 440 }) : (R.heldPosD || { x: 700, y: 330 }); R.fizz(p.x, p.y - 20, 14); } };
    Show.handlers.insert = { fn: () => { Sc.charge = 1; Sc.flash = Math.max(Sc.flash, 0.1); } };
    Show.handlers.zoom_off = { fn: () => { if (Sc.lens) { Sc.lens.out = true; Sc.lens.outAt = Sc.lens.t; } } };
    Show.handlers.flame_on = { fn: () => { R.flash('255,170,90', 0.1); } };
    Show.handlers.rattle = { fn: () => { Au.sfx('pill_rattle', { vol: 0.3 }); } };
    await Show.play(who, clip, { force: false });
    doFx();
    Show.handlers = {};
    if (Sc.lens) { await Show.sleep(0.25); Sc.lens = null; }
    // 4. consumption / return
    Sc.held[who] = null; const hpos = isP ? (R.heldPos || { x: 700, y: 440 }) : (R.heldPosD || { x: 700, y: 330 });
    if (ev.consumed) {
      if (!(ev.fx && ev.fx.k === 'steal' && ev.fx.to === ev.idx)) Sc.items[who][ev.idx] = null;
      const hx = hpos.x - 640, hy = hpos.y;
      switch (id) {
        case 'cigarette': Phys.spawn('butt', hx, U.clamp(hy + 80, 440, 650), 80, 40, 20, 100, 0, 3); break;
        case 'can': Phys.spawn('can', hx, U.clamp(hy + 60, 440, 650), 90, isP ? 330 : -330, isP ? -40 : 60, 260, 0, 12); Au.sfx('can_crush', { vol: 0.5 }); break;
        case 'medicine': Phys.spawn('bottle', hx, U.clamp(hy + 60, 440, 650), 90, isP ? -290 : 290, 30, 260, 0, 9); break;
        case 'coin': Phys.spawn('coin', hx, U.clamp(hy + 80, 440, 640), 130, 20, 30, 460, 0, 24, { life: 3 }); break;
        case 'handcuffs': case 'magnifier': case 'scrambler': case 'lighter': case 'knife': case 'spray': case 'rope': case 'blank': Au.sfx('place', { vol: 0.6 }); break;
        default: break;
      }
    } else { // lighter (1 charge left): carried back to its slot
      await Show.play(who, AD.moveHands('return_slot', 0.55, { r: { x: slot.x, y: slot.y + (isP ? 6 : 14), r: 0.05, s: hs } }, {}));
      if (entry) entry.hidden = false; Au.sfx('place', { vol: 0.7 });
    }
    await Show.play(who, AD.moveHands('open_hand', 0.3, { r: { c: 0.15, i: 0.15, t: 0.2 } }, { ease: 'out' }));
    Anim.actors[actor].play(isP ? 'hand_rest' : 'd_rest_hands');
    if (isP) { if (Math.random() < 0.5) Show.say('playerItem'); }
    if (!isP && ev.fx && ev.fx.k === 'cuff') Anim.dealer.play('face_neutral');
    Show.face('neutral');
    Anim.player.ambient.on = true; Anim.dealer.ambient.on = true;
  };

  Show.inspectItem = async function (idx, stSnapshot) {
    const entry = Sc.items.p[idx]; if (!entry) return;
    Anim.player.ambient.on = false;
    const slot = rel(R.slotWorld('p', idx)), anc = AD.anchors.p;
    await Show.play('p', AD.moveHands('reach_slot', 0.55, { r: { x: slot.x, y: slot.y + 16, r: 0.05, c: 0.1, i: 0.1, t: 0.15, s: 1.05 } }, { sfx: [{ t: 0.1, name: 'cloth', vol: 0.5 }] }));
    await Show.play('p', 'hand_grab'); entry.hidden = true; Sc.held.p = { kind: 'item', id: entry.id };
    await Show.play('p', AD.moveHands('to_hold', 0.5, { r: { x: anc.hold.x, y: anc.hold.y, s: anc.hold.s, r: anc.hold.r, c: 0.85, i: 0.85, t: 0.75 } }));
    await Show.play('p', 'hand_inspect');
    await Show.play('p', AD.moveHands('return_slot', 0.55, { r: { x: slot.x, y: slot.y + 6, r: 0.05, s: 1.05 } }));
    entry.hidden = false; Sc.held.p = null; Au.sfx('place', { vol: 0.7 });
    await Show.play('p', AD.moveHands('open_hand', 0.3, { r: { c: 0.15, i: 0.15, t: 0.2 } }, { ease: 'out' }));
    Anim.player.play('hand_rest'); Anim.player.ambient.on = true;
  };

  /* ---------------------------------------------------------------- rounds, reloads, skips, endings */
  Show.roundStart = async function (ev, st) {
    Sc.mode = 'game'; R.clearItems(); Phys.clear(); Show.aimed = null;
    Sc.lampBase = 1; Sc.redWash = 0; Sc.fade = 0; Sc.doorLight = 0; Sc.blackout = 0;
    Show.syncView(st);
    Show.view.pHp = ev.pmax; Show.view.dHp = ev.dmax; Show.view.pubE = 0; Show.view.pubA = 0;
    if (G.UI) { G.UI.refreshHud(); G.UI.banner(U.t('banner.round', { n: ev.round }), ''); }
    Au.stinger('round'); Au.setTension(0.2);
    Anim.dealer.play('d_round_transition');
    Show.say('round' + ev.round);
    await Show.sleep(reduced() ? 1.2 : 2.2);
  };
  Show.reload = async function (ev, st, first) {
    Anim.player.ambient.on = false; Anim.dealer.ambient.on = false;
    // v7.6 CINEMATIC: the camera glides out of the player's view down to the table for the whole drop (shells, then every item) and glides back before the Dealer loads the Caster
    const cine = (first || ev.added.length > 0) && !reduced(); const nop = () => {};
    if (cine) { Sc.cine.mode = 'table'; Sc.cine.p = 0; Au.sfx('whoosh', { vol: 0.5 }); Show.tween(Sc.cine, 'p', 0.2, 1.6, 'out').catch(nop); await Show.tween(Sc.cine, 'k', 1, 1.6, 'inout'); }
    // lay the shells out on the table (visual order is shuffled; the real order stays secret)
    const arr = []; for (let i = 0; i < ev.e; i++) arr.push('shell_e'); for (let i = 0; i < ev.a; i++) arr.push('shell_a');
    for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [arr[i], arr[j]] = [arr[j], arr[i]]; }
    const bodies = [], span = 50;
    arr.forEach((k, i) => { const x = (i - (arr.length - 1) / 2) * span; bodies.push(Phys.spawn(k, x, 452, 200 + i * 30, 0, 0, 0, Math.PI / 2, 0)); });      // one straight row, all squared up, clear of the gun and of both item rows
    if (G.UI) G.UI.banner(U.t('banner.load', { e: ev.e, a: ev.a }), 'sub');
    Show.say('load', { e: ev.e, a: ev.a });
    Show.view.pubE = 0; Show.view.pubA = 0;
    await Show.sleep(cine ? 1.3 : 1.6);
    // deal items
    const LAND = { medicine: 'item_land_glass', can: 'item_land_can', spray: 'item_land_can', magnifier: 'item_land_metal', handcuffs: 'item_land_metal', battery: 'item_land_metal', lighter: 'item_land_metal', scrambler: 'item_land_metal', coin: 'item_land_metal', knife: 'item_land_metal', cigarette: 'item_land_soft', blank: 'item_land_soft', rope: 'item_land_soft' };
    R.onItemLand = (who, it, speed, first) => {      // every bounce makes the sound of the item's own material, scaled by how hard it hit; the first one also thuds through the camera and puffs dust
      const hit = Math.min(1, (speed || 800) / 1100), q = first === false ? 0.55 : 1;
      Au.sfx(LAND[it.id] || 'item_land', { vol: (cine ? 0.85 : 0.6) * (0.25 + 0.75 * hit) * q, minGap: cine ? 0.02 : 0.05 }); if (first !== false) Au.sfx('table_tap', { vol: 0.35 * hit, minGap: 0.03 });
      if (cine && first !== false) { try { const w = R.slotWorld(who, Sc.items[who].indexOf(it)); R.smoke(w.x, w.y - 6, 2, { size: 10, life: 0.9, alpha: 0.18, vy: -10 }); } catch (e) { /* ignore */ } }
    };
    if (cine) {
      const step = 0.46; Show.tween(Sc.cine, 'p', 1, step * ev.added.length + 1.6, 'inout').catch(nop);
      for (let k = 0; k < ev.added.length; k++) {      // the Dealer puts them down ONE BY ONE: a reach, then the item drops and the sound lands with it
        const a = ev.added[k]; await Show.sleep(0.2);      // the Dealer holds still; only the items move
        R.setItem(a.who, a.slot, a.id, D.items[a.id].uses, true); Sc.items[a.who][a.slot].delay = 0; Au.sfx('place', { vol: 0.4, minGap: 0.05 }); await Show.sleep(step - 0.2);
      }
      await Show.sleep(1.0);        // the last item settles while the camera is still low on the table
      Show.tween(Sc.cine, 'p', 1, 0.2).catch(nop); await Show.tween(Sc.cine, 'k', 0, 1.3, 'inout');      // back to the player's view; no pause before play continues
    } else {
      ev.added.forEach((a, k) => { R.setItem(a.who, a.slot, a.id, D.items[a.id].uses, true); Sc.items[a.who][a.slot].delay = 0.12 + k * 0.16; });
      await Show.sleep(0.4 + ev.added.length * 0.16 + 0.5);
    }
    // the Dealer loads the Caster
    await Show.takeGun('d');
    Anim.gun.play('gun_reload', { force: true }); Show.setGunIdle(null);      // the reload ends in the base pose, which is where the gun stays until it is put down
    const n = bodies.length; let k = 0;
    for (const b of bodies) { await Show.sleep(0.7 / n + 0.05); b.dying = true; Au.sfx('gun_load_shell', { vol: 0.6, minGap: 0.04 }); k++; Show.view.pubE = ev.e * (k / n) | 0; Show.view.pubA = ev.a * (k / n) | 0; if (G.UI) G.UI.refreshHud(); }
    await Show.sleep(1.5);
    Show.view.pubE = ev.e; Show.view.pubA = ev.a; if (G.UI) G.UI.refreshHud();
    await Show.putGun('d');
    Show.syncView(st);
    Anim.player.ambient.on = true; Anim.dealer.ambient.on = true;
  };
  Show.skip = async function (who, st) {
    if (G.UI) G.UI.toast(U.t(who === 'd' ? 'toast.skipD' : 'toast.cuffedP'), who === 'd' ? 'good' : 'bad');
    Au.sfx('cuff_open', { vol: 0.8 });
    if (who === 'd') { Anim.dealer.play('d_shake_head'); Show.face('frustration'); Show.say('cuffed'); } else { Anim.player.play('hand_frustrate'); }
    await Show.sleep(1.4);
    Sc.cuffs[who] = false; Show.face('neutral');
  };

  /* the impact of the Dealer's fists on the table: everything that can move, moves — and nothing leaves the table (physics + item hops are clamped by the table limits) */
  Show.rageSlam = function () {
    R.shake(3); R.punchZoom(1.6); R.flash('255,70,30', 0.32); R.flicker(1); Au.sfx('impact_hit', { vol: 0.8 });
    for (const who of ['p', 'd']) Sc.items[who].forEach((it, slot) => { if (!it) return; it.landed = true; const sx = Math.abs(R.slotWorld(who, slot).x - R.CX); R.knock(it, 0.75 + Math.random() * 0.25, sx / 1500 + (who === 'p' ? 0.04 : 0)); });       // the shock travels outwards from the fists: nearer items jump first; each lands with its own material sound
    for (const b of Phys.bodies) { b.vz = (b.vz || 0) + 240 + Math.random() * 160; b.vx = (b.vx || 0) + (Math.random() - 0.5) * 220; }                    // shells jump and roll
    try { for (let i = 0; i < 6; i++) { const w = R.slotWorld(i % 2 ? 'p' : 'd', i); R.smoke(w.x, w.y - 4, 3, { size: 16, life: 1.7, alpha: 0.3, vy: -18 }); } R.smoke(640, 440, 8, { size: 26, life: 2, alpha: 0.28, vy: -26 }); } catch (e) { /* ignore */ }
    hapt([140, 40, 220]);
  };
  Show.death = async function (who, st) {
    Anim.player.ambient.on = false; Anim.dealer.ambient.on = false; Sc.dread = 0; Sc.lowPulse = 0;
    if (who === 'd') {
      // v7.6 the Dealer's RAGE (replaces the old collapse): freeze + glare (red eyes) > hands rise > hold > SLAM (table, camera, room, items, sound) > roar > settle
      const nop = () => {}, cin = !reduced();
      Au.setTension(0); Au.sfx('rage_rumble', { vol: 0.9 });
      if (cin) document.body.classList.add('cine');      // the HUD steps aside for the whole scene
      if (cin) { Sc.cine.mode = 'dealer'; Sc.cine.p = 0; Show.tween(Sc.cine, 'k', 0.9, 1.3, 'inout').catch(nop); Show.tween(Sc.cine, 'p', 1, 6.4, 'inout').catch(nop); }
      Anim.dealer.play('d_rage_stare', { force: true }); Show.face('anger'); Show.tween(Sc, 'lampBase', 0.8, 1.0).catch(nop); R.flicker(0.5);
      await Show.sleep(1.05);
      Anim.dealer.play('d_rage_raise', { force: true }); Show.tween(Sc, 'redWash', 0.14, 1.3).catch(nop);
      await Show.sleep(1.3);
      Anim.dealer.play('d_rage_hold', { force: true }); await Show.sleep(0.34);
      Anim.dealer.play('d_rage_slam', { force: true });         // the clip's own 'rage_slam' event (0.12 s in) fires the impact: Show.rageSlam()
      await Show.sleep(0.3); Au.stinger('win'); Sc.tvGlitch = 1; Show.tween(Sc, 'tvGlitch', 0, 1.6).catch(nop);
      for (let k = 0; k < 4; k++) { R.shake(1.7 - k * 0.38); await Show.sleep(0.26); }      // aftershocks
      Anim.dealer.play('d_rage_roar', { force: true }); await Show.sleep(1.3); Show.say('lose', null, 'rage');
      await Show.sleep(1.5);
      Anim.dealer.play('d_rage_end', { force: true }); Show.face('neutral'); Show.tween(Sc, 'redWash', 0, 1.6).catch(nop); Show.tween(Sc, 'lampBase', 1, 1.4).catch(nop);
      Anim.player.play('hand_victory', { force: true });
      if (cin) { await Show.tween(Sc.cine, 'k', 0, 1.4, 'inout'); document.body.classList.remove('cine'); } else await Show.sleep(1.2);
    } else {
      Au.stinger('lose'); Au.setTension(0);
      Anim.player.play('hand_defeat', { force: true }); Anim.dealer.play('d_victory', { force: true });
      Show.tween(Sc, 'redWash', 1, 2.4); Show.say('win', null, 'murmur');
      await Show.sleep(1.6); Au.speak('', 'laugh');
      await Show.tween(Sc, 'fade', 0.85, 1.6);
    }
  };
  Show.victoryEnding = async function () {
    Au.setTension(0);
    Anim.dealer.play('d_end', { force: true });
    Show.tween(Sc, 'lampBase', 0.18, 2.5); Show.tween(Sc, 'doorLight', 1, 3);
    await Show.sleep(1.5); Au.sfx('whoosh', { vol: 0.5 });
    await Show.sleep(2.0);
  };

  /* ---------------------------------------------------------------- narrate an event list, then resync from truth */
  Show.narrate = async function (evs, st) {
    for (const ev of evs) {
      switch (ev.t) {
        case 'roundStart': await Show.roundStart(ev, st); break;
        case 'reload': await Show.reload(ev, st); break;
        case 'item': await Show.item(ev); break;
        case 'shot': await Show.shot(ev); break;
        case 'skip': await Show.skip(ev.who, st); break;
        case 'death': await Show.death(ev.who, st); break;
        case 'turn': if (Show.view) Show.view.turn = ev.who; if (G.UI) G.UI.refreshHud(); break;
        default: break;
      }
    }
    Show.syncView(st);
  };

  /* ---------------------------------------------------------------- hotspots for the input manager */
  Show.hotspots = function (inputOn, touch) {
    const out = [], st = Show.st; if (!inputOn || !st) return out;
    const k = touch || 1.2;
    for (let i = 0; i < 6; i++) { const e = Sc.items.p[i]; if (e && !e.hidden) { const w = R.slotWorld('p', i); out.push({ kind: 'slot', idx: i, x: w.x, y: w.y, r: 54 * k }); } }
    out.push({ kind: 'dealer', x: 640, y: 230, r: 130 });
    if (Sc.gunHolder === 'table') out.push({ kind: 'gun', x: 640 + Art.GUN_BASE.x + 110, y: Art.GUN_BASE.y, r: 120 });
    return out;
  };

  G.Show = Show;
})(typeof window !== 'undefined' ? window : globalThis);
