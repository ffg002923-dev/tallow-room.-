/* ui-extra.js — v4 interface layer on top of ui-controller.js:
   icon hydration, the redesigned settings sheet (tabs, sliders, toggles, dropdowns, accent swatches, weapon preview),
   the achievements page + unlock pop-ups, the statistics page, and the visual preferences (UI scale, HUD opacity, brightness, accent, FPS meter). */
(function (G) {
  'use strict';
  const U = G.U, D = G.GameData, Save = G.Save, Au = G.AudioMgr, Ic = G.Icons, P = G.Progress, UI = G.UI;
  const $ = (id) => document.getElementById(id), T = () => G.Turns;
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const label = (k) => (k && k.indexOf('.') > 0 ? U.t(k) : k);

  UI.hydrateIcons = function (root) {
    (root || document).querySelectorAll('[data-ic]').forEach((n) => { if (n.dataset.icDone === n.dataset.ic) return; n.innerHTML = Ic.svg(n.dataset.ic); n.classList.add('gi'); n.dataset.icDone = n.dataset.ic; });
  };

  /* ================================================================== settings */
  const FMT = { pct: (v) => Math.round(v * 100) + '%', x: (v) => '×' + v.toFixed(2), px: (v) => (v > 0 ? '+' : '') + Math.round(v) + 'px', sc: (v) => '×' + v.toFixed(2) };
  const R_ = (key, label, mn, mx, fmt, step, extra) => Object.assign({ key, type: 'range', label, rng: [mn, mx], fmt: fmt || 'pct', step: step || 0.01 }, extra || {});
  const TABS = [
    { id: 'general', icon: 'general', label: 'set.tab.general', groups: [
      { k: 'set.grpLang', rows: [
        { key: 'lang', type: 'seg', label: 'set.language', opts: [['en', 'English'], ['ar', 'العربية']] },
        { key: 'subtitles', type: 'tog', label: 'set.subtitles' },
        { key: 'subLang', type: 'sel', label: 'set.subLang', opts: [['auto', 'set.subAuto'], ['en', 'English'], ['ar', 'العربية']] }] },
      { k: 'set.grpHelp', rows: [
        { type: 'btn', label: 'set.replayTut', icon: 'help', act: 'tutorial' }, { type: 'btn', label: 'set.openStats', icon: 'stats', act: 'stats' }, { type: 'btn', label: 'set.openAch', icon: 'trophy', act: 'ach' }] }] },
    { id: 'audio', icon: 'sound', label: 'set.tab.audio', groups: [
      { k: 'set.grpVolume', rows: [R_('master', 'set.master', 0, 1), R_('music', 'set.music', 0, 1), R_('ambience', 'set.ambience', 0, 1), R_('sfx', 'set.sfx', 0, 1), R_('voice', 'set.voice', 0, 1)] }] },
    { id: 'video', icon: 'video', label: 'set.tab.video', groups: [
      { k: 'set.grpRender', rows: [
        { key: 'three', type: 'tog', label: 'set.three' },
        { key: 'quality', type: 'seg', label: 'set.quality', opts: [['low', 'set.low'], ['medium', 'set.medium'], ['high', 'set.high']] },
        R_('res', 'set.res', 0.5, 1), { key: 'fps', type: 'seg', label: 'set.fps', opts: [[30, 'set.fps30'], [60, 'set.fps60']] }] },
      { k: 'set.grpLook', rows: [R_('brightness', 'set.brightness', 0.7, 1.3), { key: 'vignette', type: 'tog', label: 'set.vignette' }, { key: 'effects', type: 'tog', label: 'set.effects' }, R_('shake', 'set.shake', 0, 1),
        { type: 'btn', label: 'set.fullscreen', icon: 'fullscreen', act: 'fullscreen' }] }] },
    { id: 'controls', icon: 'controls', label: 'set.tab.controls', groups: [
      { k: 'set.grpTouch', rows: [R_('touch', 'set.touch', 0.8, 1.8, 'x'), R_('sens', 'set.sens', 0.3, 2, 'x'), { key: 'invertY', type: 'tog', label: 'set.invertY' }, { key: 'haptics', type: 'tog', label: 'set.haptics' },
        { type: 'note', label: 'set.lookHint' }] }] },
    { id: 'weapon', icon: 'weapon', label: 'set.tab.weapon', groups: [
      { k: 'set.grpHold', rows: [{ key: 'gunHold', type: 'seg', label: 'set.gunHold', desc: 'set.gunHold.d', opts: [['locked', 'set.locked'], ['subtle', 'set.subtle'], ['natural', 'set.natural']] }, R_('camSway', 'set.camSway', 0, 1)] },
      { k: 'set.grpCross', rows: [{ key: 'crosshair', type: 'sel', label: 'set.crosshair', opts: [['off', 'set.xoff'], ['dot', 'set.xdot'], ['cross', 'set.xcross'], ['ring', 'set.xring']] }, R_('xhairSize', 'set.xhairSize', 0.6, 1.8, 'sc'), R_('xhairAlpha', 'set.xhairAlpha', 0.3, 1)] },
      { k: 'set.grpPos', rows: [{ type: 'preview' }, R_('gunX', 'set.gunX', -40, 40, 'px', 1, { desc: 'set.gunPos.d' }), R_('gunY', 'set.gunY', -40, 40, 'px', 1), R_('gunScale', 'set.gunScale', 0.9, 1.15, 'sc', 0.01)] }] },
    { id: 'interface', icon: 'interface', label: 'set.tab.interface', groups: [
      { k: 'set.grpHud', rows: [R_('uiScale', 'set.uiScale', 0.85, 1.2), R_('hudAlpha', 'set.hudAlpha', 0.45, 1), { key: 'hudLabels', type: 'tog', label: 'set.hudLabels' },
        { key: 'hudSide', type: 'seg', label: 'set.hudSide', opts: [['left', 'set.left'], ['right', 'set.right']] }, { key: 'showFps', type: 'tog', label: 'set.showFps' }] },
      { k: 'set.grpTheme', rows: [{ key: 'accent', type: 'swatch', label: 'set.accent', desc: 'set.accent.d' }] }] },
    { id: 'access', icon: 'access', label: 'set.tab.access', groups: [
      { k: 'set.grpReadable', rows: [{ key: 'textSize', type: 'seg', label: 'set.textSize', opts: [[0, 'set.small'], [1, 'set.medium'], [2, 'set.large']] }, { key: 'contrast', type: 'tog', label: 'set.contrast' }] },
      { k: 'set.grpMotion', rows: [{ key: 'reduced', type: 'tog', label: 'set.reduced' }, R_('shake', 'set.shake', 0, 1), R_('camSway', 'set.camSway', 0, 1)] }] }
  ];
  UI.SETTINGS_TABS = TABS;
  UI.settingsTab = 'general';

  function tabKeys(tab) { const ks = []; for (const g of tab.groups) for (const r of g.rows) if (r.key && r.key !== 'lang') ks.push(r.key); return ks; }

  function weaponPreview(s) {
    const gx = 71.25 + s.gunX * 0.125, gy = 58.6 + s.gunY * 0.125, cx = 80, cy = 44, deg = Math.atan2(cy - gy, cx - gx) * 180 / Math.PI, sc = s.gunScale, r = s.xhairSize;
    let ch = '';
    if (s.crosshair === 'dot') ch = '<circle cx="' + cx + '" cy="' + cy + '" r="' + (1.6 * r).toFixed(2) + '" fill="#ffe3c8"/>';
    else if (s.crosshair === 'ring') ch = '<circle cx="' + cx + '" cy="' + cy + '" r="' + (4.5 * r).toFixed(2) + '" fill="none" stroke="#ffe3c8" stroke-width="1"/>';
    else if (s.crosshair === 'cross') { const a = 1.6 * r, b = 4.6 * r; ch = '<path d="M' + (cx - b) + ' ' + cy + 'H' + (cx - a) + 'M' + (cx + a) + ' ' + cy + 'H' + (cx + b) + 'M' + cx + ' ' + (cy - b) + 'V' + (cy - a) + 'M' + cx + ' ' + (cy + a) + 'V' + (cy + b) + '" stroke="#ffe3c8" stroke-width="1" stroke-linecap="round"/>'; }
    return '<svg class="wprev" viewBox="0 0 160 90" role="img" aria-label="' + U.t('set.preview') + '"><rect width="160" height="90" fill="#0b0405"/><ellipse cx="80" cy="90" rx="74" ry="9" fill="#1d0b0d"/>' +
      '<path d="M50 90Q54 52 80 48Q106 52 110 90Z" fill="#221012"/><circle cx="80" cy="32" r="13" fill="#2a1416"/><circle cx="76" cy="33" r="2" fill="#000"/><circle cx="84" cy="33" r="2" fill="#000"/>' +
      '<line x1="' + gx.toFixed(1) + '" y1="' + gy.toFixed(1) + '" x2="' + cx + '" y2="' + cy + '" stroke="#ff5030" stroke-opacity=".5" stroke-dasharray="2 2" stroke-width=".8"/>' +
      '<g transform="translate(' + gx.toFixed(1) + ' ' + gy.toFixed(1) + ') rotate(' + deg.toFixed(1) + ') scale(' + sc + ')"><rect x="-9" y="-1.2" width="9" height="5.4" rx="1.2" fill="#3a2a22"/><rect x="0" y="-2" width="26" height="3.2" rx="1.2" fill="#8b7a66"/><rect x="4" y="1.2" width="11" height="2.4" rx="1" fill="#5a4636"/></g>' +
      '<g opacity="' + s.xhairAlpha.toFixed(2) + '">' + ch + '</g></svg>';
  }
  UI.updatePreview = function () { const h = $('setBody') && $('setBody').querySelector('.wprevbox'); if (h) h.innerHTML = weaponPreview(T().settings); };

  UI.buildSettings = function () {
    const s = T().settings, body = $('setBody'), tabsEl = $('setTabs'); body.innerHTML = ''; tabsEl.innerHTML = '';
    if (!TABS.some((t) => t.id === UI.settingsTab)) UI.settingsTab = 'general';
    for (const t of TABS) {
      const b = el('button', t.id === UI.settingsTab ? 'on' : '', '<i class="gi">' + Ic.svg(t.icon) + '</i><span>' + U.t(t.label) + '</span>');
      b.setAttribute('role', 'tab'); b.setAttribute('aria-selected', t.id === UI.settingsTab ? 'true' : 'false'); b.setAttribute('aria-label', U.t(t.label)); b.title = U.t(t.label);
      b.onclick = () => { if (UI.settingsTab === t.id) return; UI.settingsTab = t.id; UI.buildSettings(); }; tabsEl.appendChild(b);
    }
    const tab = TABS.find((t) => t.id === UI.settingsTab);
    $('setReset').title = U.t('set.resetTab'); $('setReset').setAttribute('aria-label', U.t('set.resetTab'));
    for (const g of tab.groups) {
      body.appendChild(el('div', 'sgroup', U.t(g.k)));
      for (const r of g.rows) body.appendChild(buildRow(r, s));
    }
    body.scrollTop = 0;
  };

  function buildRow(r, s) {
    const row = el('div', 'srow'), lab = el('label'); const key = r.key;
    if (r.type === 'note') { row.className = 'srow note full'; row.textContent = U.t(r.label); return row; }
    if (r.type === 'preview') { row.className = 'srow full'; const h = el('div', 'wprevbox', weaponPreview(s)); row.appendChild(h); return row; }
    lab.textContent = U.t(r.label); if (r.desc) lab.appendChild(el('small', '', U.t(r.desc))); row.appendChild(lab);
    let ctl;
    if (r.type === 'btn') {
      ctl = el('button', 'abtn', '<i class="gi">' + Ic.svg(r.icon) + '</i>'); lab.textContent = ''; row.className = 'srow full'; row.removeChild(lab);
      ctl.appendChild(document.createTextNode(U.t(r.label)));
      ctl.onclick = () => {
        if (r.act === 'fullscreen') { try { const d = document; if (!d.fullscreenElement) (d.documentElement.requestFullscreen || d.documentElement.webkitRequestFullscreen).call(d.documentElement); else (d.exitFullscreen || d.webkitExitFullscreen).call(d); } catch (e) { /* ignore */ } }
        else if (r.act === 'stats') { UI.close('mSet'); UI.openStats(); }
        else if (r.act === 'ach') { UI.close('mSet'); UI.openAch(); }
        else if (r.act === 'tutorial') { UI.close('mSet'); UI.showTutorial(() => { if (UI.settingsFrom === 'pause') UI.open('mPause'); }); }
      };
    } else if (r.type === 'range') {
      const [mn, mx] = r.rng, f = FMT[r.fmt]; ctl = el('div', 'rng'); const inp = el('input'); inp.type = 'range'; inp.min = mn; inp.max = mx; inp.step = r.step; inp.value = s[key]; inp.id = 'set_' + key + (UI.settingsTab === 'access' ? '_a' : ''); lab.htmlFor = inp.id;
      inp.setAttribute('aria-valuetext', f(s[key])); const val = el('span', 'val', f(s[key]));
      const paint = () => { inp.style.setProperty('--v', ((inp.value - mn) / (mx - mn) * 100) + '%'); val.textContent = f(parseFloat(inp.value)); inp.setAttribute('aria-valuetext', val.textContent); }; paint();
      inp.oninput = () => { paint(); UI.setSetting(key, parseFloat(inp.value), true); };
      inp.onchange = () => { UI.flushSettings(); Au.sfx('tick', { vol: 0.8 }); if (key === 'sfx') Au.sfx('metal_clink', { vol: 0.8 }); if (key === 'voice') Au.speak('Test', 'normal'); if (key === 'shake') G.Renderer.shake(1); };
      ctl.appendChild(inp); ctl.appendChild(val);
    } else if (r.type === 'tog') {
      ctl = el('button', 'tog'); ctl.setAttribute('role', 'switch'); ctl.setAttribute('aria-checked', s[key] ? 'true' : 'false'); ctl.setAttribute('aria-label', U.t(r.label)); ctl.style.justifySelf = 'end';
      ctl.onclick = () => { const v = ctl.getAttribute('aria-checked') !== 'true'; ctl.setAttribute('aria-checked', v ? 'true' : 'false'); UI.setSetting(key, v); Au.sfx('tick', { vol: 0.7 }); if (key === 'haptics' && v) { try { navigator.vibrate && navigator.vibrate(30); } catch (e) { /* ignore */ } } };
    } else if (r.type === 'sel') {
      ctl = el('select', 'sel'); ctl.setAttribute('aria-label', U.t(r.label));
      r.opts.forEach(([v, lk], i) => { const o = el('option'); o.value = String(i); o.textContent = label(lk); if (s[key] === v) o.selected = true; ctl.appendChild(o); });
      ctl.onchange = () => { UI.setSetting(key, r.opts[parseInt(ctl.value, 10)][0]); Au.sfx('tick', { vol: 0.7 }); };
    } else if (r.type === 'swatch') {
      ctl = el('div', 'swatches'); ctl.setAttribute('role', 'radiogroup'); ctl.setAttribute('aria-label', U.t(r.label));
      for (const id of D.accents) {
        const open = P.accentUnlocked(id), c = D.accentColors[id][0], b = el('button', 'sw' + (open ? '' : ' locked')); b.style.setProperty('--c', c); b.setAttribute('role', 'radio');
        b.setAttribute('aria-checked', s.accent === id && open ? 'true' : 'false'); const nm = U.t('accent.' + id); b.setAttribute('aria-label', open ? nm : U.t('set.locked.tip', { n: U.t('ach.' + D.accentUnlock[id]) })); b.title = b.getAttribute('aria-label');
        if (!open) b.innerHTML = '<i class="gi">' + Ic.svg('lock') + '</i>';
        b.onclick = () => { if (!open) { UI.toast(U.t('set.locked.tip', { n: U.t('ach.' + D.accentUnlock[id]) }), 'info'); Au.sfx('ui_back', { vol: 0.6 }); return; } UI.setSetting('accent', id); ctl.querySelectorAll('.sw').forEach((x) => x.setAttribute('aria-checked', 'false')); b.setAttribute('aria-checked', 'true'); };
        ctl.appendChild(b);
      }
    } else {
      ctl = el('div', 'seg'); ctl.setAttribute('role', 'radiogroup'); ctl.setAttribute('aria-label', U.t(r.label));
      for (const [val, lk] of r.opts) {
        const b = el('button', s[key] === val ? 'on' : ''); b.textContent = label(lk); b.setAttribute('role', 'radio'); b.setAttribute('aria-checked', s[key] === val ? 'true' : 'false');
        b.onclick = () => { UI.setSetting(key, val); ctl.querySelectorAll('button').forEach((x) => { x.className = ''; x.setAttribute('aria-checked', 'false'); }); b.className = 'on'; b.setAttribute('aria-checked', 'true'); }; ctl.appendChild(b);
      }
    }
    row.appendChild(ctl); return row;
  }

  /* settings are applied immediately; while a slider is being dragged the save is debounced and the apply is coalesced to one per frame */
  UI.setSetting = function (key, val, live) {
    const t = T(); t.settings[key] = val; t.settings = Save.sanitizeSettings(t.settings);
    if (live) {
      clearTimeout(UI._saveT); UI._saveT = setTimeout(() => UI.flushSettings(), 400);
      if (!UI._applyRaf) UI._applyRaf = requestAnimationFrame(() => { UI._applyRaf = 0; G.Main.applySettings(T().settings); });
    } else { UI.flushSettings(); G.Main.applySettings(t.settings); }
    if (key === 'lang') { UI.applyLang(); UI.buildSettings(); }
    if (/^(gunX|gunY|gunScale|crosshair|xhairSize|xhairAlpha)$/.test(key)) UI.updatePreview();
  };
  UI.flushSettings = function () { clearTimeout(UI._saveT); Save.saveSettings(T().settings); };
  UI.openSettings = function (from) {
    UI.settingsFrom = from || 'menu'; UI.buildSettings(); UI.open('mSet');
    $('setBack').onclick = () => { UI.flushSettings(); UI.close('mSet'); if (UI.settingsFrom === 'pause') UI.open('mPause'); };
    $('setReset').onclick = () => {
      const tab = TABS.find((x) => x.id === UI.settingsTab), d = Save.defaultSettings(), t = T(); for (const k of tabKeys(tab)) t.settings[k] = d[k];
      t.settings = Save.sanitizeSettings(t.settings); UI.flushSettings(); G.Main.applySettings(t.settings); UI.buildSettings(); UI.toast(U.t('set.resetDone'), 'info');
    };
  };

  /* ================================================================== visual preferences */
  UI.applyVisual = function (s) {
    const h = document.documentElement, st = h.style, m = T() && T().meta;
    st.setProperty('--ui', String(s.uiScale)); st.setProperty('--hudA', String(s.hudAlpha));
    h.dataset.labels = s.hudLabels ? '1' : '0'; h.dataset.side = s.hudSide; h.dataset.contrast = s.contrast ? '1' : '0';
    const acc = m && P.accentUnlocked(s.accent, m) ? s.accent : 'ember', c = D.accentColors[acc];
    st.setProperty('--ember', c[0]); st.setProperty('--blood', c[1]); st.setProperty('--blood2', c[2]); h.dataset.accent = acc;
    const b = $('bright');
    if (b) { b.style.display = s.brightness === 1 ? 'none' : 'block'; if (s.brightness < 1) { b.style.background = '#000'; b.style.mixBlendMode = 'normal'; b.style.opacity = ((1 - s.brightness) * 1.1).toFixed(3); } else if (s.brightness > 1) { b.style.background = '#fff'; b.style.mixBlendMode = 'soft-light'; b.style.opacity = Math.min(1, (s.brightness - 1) * 2.2).toFixed(3); } else b.style.opacity = '0'; }
    const f = $('fps'); if (f) f.classList.toggle('hidden', !s.showFps);
  };
  let fAcc = 0, fN = 0;
  UI.fpsTick = function (dt) {
    const s = T().settings; if (!s || !s.showFps) return; fAcc += dt; fN++;
    if (fAcc >= 0.5) { const f = $('fps'); if (f) f.textContent = Math.round(fN / fAcc) + ' ' + U.t('hud.fps') + (G.Renderer.auto < 0.99 ? ' · ' + Math.round(G.Renderer.auto * 100) + '%' : ''); fAcc = 0; fN = 0; }
  };

  /* ================================================================== achievements */
  const TIERS = ['b', 'c', 'a', 'l'];
  UI.achFilter = 'all';
  const fmtStat = (def, v) => (def.stat === 'playSec' ? P.fmtTime(v) : String(Math.floor(v)));
  UI.buildAch = function () {
    const m = T().meta, sum = P.summary(m), list = $('achList'), chips = $('achTabs'); list.innerHTML = ''; chips.innerHTML = '';
    $('achPct').textContent = sum.pct + '%'; $('achBar').style.width = sum.pct + '%'; $('achSum').textContent = U.t('ach.completion', { a: sum.done, b: sum.total, p: sum.pct });
    const mk = (id, text, n, tier) => { const b = el('button', 'chip' + (UI.achFilter === id ? ' on' : ''), (tier ? '<i style="--tier:var(--t' + tier + ')"></i>' : '') + '<span>' + text + '</span><span class="n">' + n + '</span>'); b.setAttribute('role', 'tab'); b.setAttribute('aria-selected', UI.achFilter === id ? 'true' : 'false'); b.onclick = () => { UI.achFilter = id; UI.buildAch(); }; chips.appendChild(b); };
    mk('all', U.t('ach.all'), sum.done + '/' + sum.total); for (const t of TIERS) mk(t, U.t('ach.tier.' + t), sum.by[t][0] + '/' + sum.by[t][1], t);
    const defs = D.achDefs.filter((d) => UI.achFilter === 'all' || d.tier === UI.achFilter).sort((a, b) => TIERS.indexOf(a.tier) - TIERS.indexOf(b.tier));
    for (const def of defs) {
      const pr = P.progress(def, m), fresh = P.fresh && P.fresh.has(def.id);
      const d = el('div', 'ach t-' + def.tier + (pr.done ? ' done' : '') + (fresh ? ' fresh' : ''));
      const rw = '<span class="rw">' + (def.accent ? '<i class="dot" style="--c:' + D.accentColors[def.accent][0] + '"></i>' : '') + U.t('ach.reward', { n: def.coins }) + '</span>';
      d.innerHTML = '<div class="ai"><i class="gi">' + Ic.svg(def.icon) + '</i></div><div class="nm"><b>' + U.t('ach.' + def.id) + '</b></div>' + rw +
        '<div class="ds">' + U.t('ach.' + def.id + '.d') + (def.accent ? ' · ' + U.t('ach.accentReward', { n: U.t('accent.' + def.accent) }) : '') + '</div>' +
        '<div class="pr"><div class="bar"><i style="width:' + (pr.done ? 100 : pr.v / pr.goal * 100) + '%"></i></div><em>' + (pr.done ? '<i class="gi">' + Ic.svg('check') + '</i>' + U.t('ach.done') : fmtStat(def, pr.v) + ' / ' + fmtStat(def, pr.goal)) + '</em></div>';
      d.setAttribute('role', 'group'); d.setAttribute('aria-label', U.t('ach.' + def.id) + ', ' + (pr.done ? U.t('ach.done') : pr.pct + '%'));
      list.appendChild(d);
    }
  };
  UI.openAch = function () { UI.achFilter = 'all'; UI.buildAch(); UI.open('mAch'); const l = $('achList'); if (l) l.scrollTop = 0; };
  const baseClose = UI.close;
  UI.close = function (id) { baseClose(id); if (id === 'mAch' && P.fresh) P.fresh.clear(); };   // the "new" highlight is dropped once the page has been seen

  /* unlock pop-up: one at a time, sound + screen-reader announcement */
  const popQ = []; let popOn = false;
  UI.achPop = function (def) { popQ.push(def); if (!popOn) pump(); };
  function pump() {
    const def = popQ.shift(); if (!def) { popOn = false; return; } popOn = true;
    const box = $('achPop'); if (!box) { popOn = false; return; }
    const e = el('div', 'apop t-' + def.tier, '<div class="ai"><i class="gi">' + Ic.svg(def.icon) + '</i></div><div><small>' + U.t('ach.unlockedLbl') + '</small><b>' + U.t('ach.' + def.id) + '</b><span>' + U.t('ach.reward', { n: def.coins }) + (def.accent ? ' · ' + U.t('ach.accentReward', { n: U.t('accent.' + def.accent) }) : '') + '</span></div>');
    box.appendChild(e); try { Au.sfx('toast', { vol: 0.9 }); Au.sfx('coin_catch', { vol: 0.5 }); } catch (err) { /* ignore */ }
    try { G.Access.announce(U.t('ach.unlockedLbl') + ': ' + U.t('ach.' + def.id)); } catch (err) { /* ignore */ }
    if (UI.applyVisual && T().settings) UI.applyVisual(T().settings);   // an accent reward may just have become available
    if (!T().settings || !T().settings.haptics) { /* no vibration */ } else { try { navigator.vibrate && navigator.vibrate([20, 40, 20]); } catch (err) { /* ignore */ } }
    setTimeout(() => { e.classList.add('out'); setTimeout(() => { e.remove(); pump(); }, 420); }, 3600);
  }

  /* ================================================================== statistics */
  UI.openStats = function () {
    const m = T().meta, s = m.stats, body = $('statsBody'), sum = P.summary(m); body.innerHTML = '';
    const rate = (a, b) => (b > 0 ? Math.round(a / b * 100) + '%' : '—');
    const tile = (v, l) => '<div class="tile"><b>' + v + '</b><span>' + l + '</span></div>';
    body.appendChild(el('div', 'tiles', tile(rate(s.wins, s.games), U.t('stat.winrate')) + tile(s.games, U.t('stat.games')) + tile(P.fmtTime(s.playSec), U.t('stat.playSec')) + tile(m.coins || 0, U.t('shop.title'))));
    const item = (k, v) => '<div class="stitem"><span>' + U.t('stat.' + k) + '</span><b>' + v + '</b></div>';
    const sec = (title, html) => { body.appendChild(el('div', 'stsec', U.t(title))); body.appendChild(el('div', 'stgrid', html)); };
    sec('stats.secRuns', item('wins', s.wins) + item('losses', s.losses) + item('rounds', s.rounds) + item('perfect', s.perfect) + item('nightmareWins', s.nightmareWins) + item('thread', s.thread));
    sec('stats.secCombat', item('shots', s.shots) + item('hits', s.hits) + item('accuracy', rate(s.hits, s.shots - s.selfShots)) + item('selfShots', s.selfShots) + item('ashSelf', s.ashSelf) + item('bestStreak', s.bestStreak) +
      item('dmgDealt', s.dmgDealt) + item('dmgTaken', s.dmgTaken) + item('charged', s.charged) + item('ash3', s.ash3));
    sec('stats.secItems', item('itemsUsed', s.itemsUsed) + item('cuffs', s.cuffs) + item('bare', s.bare) + item('bought', s.bought) + item('earned', s.earned) + '<div class="stitem"><span>' + U.t('arch.title') + '</span><b>' + Object.keys(m.discovered).length + '/' + D.itemOrder.length + '</b></div>');
    body.appendChild(el('div', 'stsec', U.t('stats.secAch') + ' · ' + U.t('stats.completion', { a: sum.done, b: sum.total, p: sum.pct })));
    body.appendChild(el('div', 'tierbars', TIERS.map((t) => '<div class="tierbar" style="--tier:var(--t' + t + ')"><div class="l"><span>' + U.t('ach.tier.' + t) + '</span><span>' + sum.by[t][0] + '/' + sum.by[t][1] + '</span></div><div class="bar"><i style="width:' + (sum.by[t][0] / sum.by[t][1] * 100) + '%"></i></div></div>').join('')));
    UI.open('mStats'); body.scrollTop = 0;
  };

  /* ================================================================== wiring */
  const baseInit = UI.init;
  UI.init = function () {
    baseInit(); UI.hydrateIcons(); P.onUnlock = (def) => UI.achPop(def);
    $('hStats').onclick = () => UI.openStats();
    const full = $('mFull'); const hf = $('hFull'); if (hf && full) hf.onclick = () => full.click();
  };
  const baseLang = UI.applyLang;
  UI.applyLang = function () { baseLang(); UI.hydrateIcons(); };
  /* the HUD badge shows how many items you hold */
  const baseHud = UI.refreshHud;
  UI.refreshHud = function () { baseHud(); const st = T() && T().st, b = $('invCount'); if (b && st) b.textContent = st.p.items.filter(Boolean).length || ''; };
})(typeof window !== 'undefined' ? window : globalThis);
