/* slap.js — SLAP (player slaps the Dealer after the Dealer survives a LIVE self-shot) and SLAP BACK (the Dealer slaps the player after a survived LIVE self-shot).
   Never offered for a blank shell, a blocked shot or a fatal shot. The slap is a pure show: it changes no HP, so the engine and the online server stay authoritative.
   Online, the server (mp-engine M.slap) validates the same rule; see scripts/mp-ui.js for that button. */
(function (G) {
  'use strict';
  const U = G.U, D = G.GameData;
  const S = { open: false, busy: false, used: 0 };
  Object.assign(D.strings.en, { 'slap.btn': 'SLAP' }); Object.assign(D.strings.ar, { 'slap.btn': 'اصفع الموزع' });
  const add = (k, en, ar) => { D.lines.en[k] = en; D.lines.ar[k] = ar; };
  add('slapped_shock', ['...You struck me?', 'Ah! My face...'], ['...ضربتني؟', 'آه! وجهي...']);
  add('slapped_angry', ['That will cost you.', 'Hmph. Remember that.'], ['سيكلفك هذا غاليا.', 'همم. تذكر ذلك.']);
  add('slapped_laugh', ['Hah! Again, if you dare.', 'Ha... ha... lovely.'], ['ها! أعدها إن تجرأت.', 'ها... ها... رائع.']);
  add('slapped_hold', ['Please... not the face.', 'It hurts... it truly hurts.'], ['أرجوك... ليس الوجه.', 'يؤلم... يؤلم حقا.']);
  add('slapped_threat', ['I will remember this hand.', 'Quiet now. Very quiet.'], ['سأتذكر هذه اليد.', 'اهدأ الآن. هدوءا تاما.']);
  add('slapped_shout', ['HOW DARE YOU!', 'ENOUGH!'], ['كيف تجرؤ!', 'كفى!']);
  add('slapBack', ['Careless. Wake up.', 'Pull yourself together.', 'That is for your foolishness.'], ['إهمال. استيقظ.', 'تماسك.', 'هذا جزاء حماقتك.']);
  const $ = (id) => document.getElementById(id);
  const dem = () => { const id = G.DealerLooks ? G.DealerLooks.id() : 'ghost'; return { id, d: (D.dealers[id] || {}).demeanor || { aggr: 0.5, humor: 0.3, patience: 0.5 } }; };
  /* personality -> reaction; each dealer reacts in the way his demeanour says */
  S.kind = function () {
    const { d } = dem();
    if (d.humor >= 0.6) return 'laugh';
    if (d.aggr >= 0.75 && d.patience < 0.5) return 'shout';
    if (d.aggr >= 0.65) return 'threat';
    if (d.aggr >= 0.45) return 'angry';
    if (d.patience >= 0.85) return 'hold';
    return 'shock';
  };
  const sleep = (s) => G.Show.sleep(s);
  S.btn = function () {
    let b = $('slapBtn');
    if (!b) { b = document.createElement('button'); b.id = 'slapBtn'; b.className = 'hidden'; ($('app') || document.body).appendChild(b); }
    b.innerHTML = '👋 ' + U.t('slap.btn'); return b;
  };
  /* resolves true if the player slapped */
  S.offer = function (ms) {
    if (S.busy) return Promise.resolve(false);
    return new Promise((res) => {
      const b = S.btn(); S.open = true; b.classList.remove('hidden');
      const done = (v) => { if (!S.open) return; S.open = false; b.classList.add('hidden'); b.onclick = null; clearTimeout(t); res(v); };
      const t = setTimeout(() => done(false), ms || 3500);
      b.onclick = () => done(true);
    }).then(async (hit) => { if (hit) await S.perform(); return hit; });
  };
  S.perform = async function () {
    const Sh = G.Show, A = G.Anim, R = G.Renderer, Au = G.AudioMgr, kind = S.kind(); S.busy = true;
    try {
      A.player.ambient.on = false; A.dealer.ambient.on = false;
      A.player.play('hand_slap', { force: true });
      await sleep(0.4);                                        // contact frame
      R.shake(1); R.flash('255,200,160', 0.35); R.punchZoom(0.6);
      R.chips(640, 235, 10, '#e8dfca'); R.sparks(640, 235, 8, { speed: 220, size: 8 });
      A.dealer.play('d_slap_' + kind, { force: true });
      if (G.Progress && G.Progress.slap) G.Progress.slap();
      S.used++;
      await sleep(0.55);
      Sh.say('slapped_' + kind, null, 'normal');
      await sleep(1.5);
    } finally { A.player.ambient.on = true; A.dealer.ambient.on = true; S.busy = false; }
  };
  /* the Dealer slaps the player; chance follows his temper */
  S.back = async function () {
    const { d } = dem(); if (S.busy) return false;
    if (Math.random() > Math.min(0.75, 0.25 + d.aggr * 0.5)) return false;
    const Sh = G.Show, A = G.Anim, R = G.Renderer; S.busy = true;
    try {
      A.dealer.ambient.on = false; A.player.ambient.on = false;
      A.dealer.play('d_slap_swing', { force: true });
      await sleep(0.45);
      R.slapKick(Math.random() < 0.5 ? 1 : -1); R.shake(0.9); R.flash('255,190,150', 0.4);
      A.player.play('hand_startle', { force: true });
      Sh.say('slapBack');
      await sleep(1.3);
    } finally { A.dealer.ambient.on = true; A.player.ambient.on = true; S.busy = false; }
    return true;
  };
  G.Slap = S;
})(window);
