/* economy.js — Wax (coins), the shop and ownership. Pure functions over the saved meta object, so they are fully testable in Node.
   Rules enforced here: enough Wax, no double purchase, free items are always owned, only owned things can be selected/used. */
(function (G) {
  'use strict';
  const D = G.GameData;
  const Eco = {};
  const KINDS = { item: ['items', 'items'], weapon: ['weapons', 'weapons'], dealer: ['dealers', 'dealers'] };
  const table = (kind) => (kind === 'item' ? D.items : kind === 'weapon' ? D.weapons : D.dealers);

  Eco.kinds = Object.keys(KINDS);
  Eco.def = (kind, id) => (table(kind) || {})[id] || null;
  Eco.price = (kind, id) => { const d = Eco.def(kind, id); return d ? d.price | 0 : 0; };
  Eco.owned = (m, kind, id) => { const d = Eco.def(kind, id); return !!d && (d.free || !!(m.owned[KINDS[kind][0]] && m.owned[KINDS[kind][0]][id])); };
  Eco.list = (m, kind) => Object.keys(table(kind)).filter((id) => Eco.owned(m, kind, id));
  /* items that can be dealt in a game: the free ten + everything the player has bought (both sides draw from the same pool) */
  Eco.itemPool = (m) => D.itemOrder.filter((id) => Eco.owned(m, 'item', id));
  Eco.canBuy = function (m, kind, id) {
    const d = Eco.def(kind, id); if (!d) return { ok: false, reason: 'unknown' };
    if (Eco.owned(m, kind, id)) return { ok: false, reason: 'owned' };
    if ((m.coins | 0) < d.price) return { ok: false, reason: 'poor', missing: d.price - (m.coins | 0) };
    return { ok: true };
  };
  Eco.buy = function (m, kind, id) {
    const c = Eco.canBuy(m, kind, id); if (!c.ok) return c;
    const d = Eco.def(kind, id);
    m.coins -= d.price; m.owned[KINDS[kind][0]][id] = 1; m.stats.bought++; m.log.push({ kind, id, price: d.price, t: Date.now() }); if (m.log.length > 30) m.log.shift();
    return { ok: true, price: d.price, coins: m.coins };
  };
  Eco.select = function (m, kind, id) {
    if (kind !== 'dealer' && kind !== 'weapon') return { ok: false, reason: 'kind' };
    if (!Eco.owned(m, kind, id)) return { ok: false, reason: 'locked' };
    m.selected[kind] = id; return { ok: true };
  };
  Eco.newest = (kind) => Object.keys(table(kind)).slice(-6);
  Eco.rare = (kind) => Object.keys(table(kind)).filter((id) => ['epic', 'legendary'].includes(table(kind)[id].rarity));
  G.Economy = Eco;
  if (typeof module !== 'undefined' && module.exports) module.exports = Eco;
})(typeof window !== 'undefined' ? window : globalThis);
