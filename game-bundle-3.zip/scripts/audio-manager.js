/* audio-manager.js — fully synthesised audio (Web Audio API). No audio files are shipped:
   every sound effect, the ambience bed, the generative music and the Dealer's voice are generated at runtime.
   Buses: master -> compressor -> out;  music / ambience / sfx / voice -> master. Reverb send for guns & voice. */
(function (G) {
  'use strict';
  const U = G.U;
  const A = { SFX: {}, ready: false, unlocked: false, paused: false, vol: { master: 0.8, music: 0.6, ambience: 0.7, sfx: 0.9, voice: 0.9 }, stats: { played: 0, dropped: 0, throttled: 0 } };
  const mv = () => (G.AudioMgr && G.AudioMgr.menuMusic ? 0 : (G.AudioMgr ? G.AudioMgr.vol.music : 0.7) * 0.7);   // the generative music is silent while the menu song plays
  let ctx = null, bus = {}, noiseBuf = null, verbIn = null, lastPlayed = {}, live = 0;

  /* ------------------------------------------------------------ synth kit (works on any BaseAudioContext) */
  function makeNoise(c) {
    const len = c.sampleRate * 2, b = c.createBuffer(1, len, c.sampleRate), d = b.getChannelData(0);
    let seed = 12345;
    for (let i = 0; i < len; i++) { seed = (seed * 1664525 + 1013904223) | 0; d[i] = ((seed >>> 8) / 8388608) - 1; }
    return b;
  }
  function Kit(c, dest, nbuf, verb) {
    const k = { c, dest, verb };
    k.tone = function (type, f0, f1, t, dur, vol, o) {
      o = o || {}; f0 = Math.min(f0, 18000); f1 = Math.min(f1, 18000);
      const os = c.createOscillator(), g = c.createGain();
      os.type = type; os.frequency.setValueAtTime(f0, t);
      if (f1 && f1 !== f0) os.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + dur);
      if (o.detune) os.detune.value = o.detune;
      const a = o.a || 0.004;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t + a);
      g.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(a + 0.01, dur));
      os.connect(g);
      let n = g;
      if (o.f) { const fl = c.createBiquadFilter(); fl.type = o.ft || 'lowpass'; fl.frequency.value = o.f; fl.Q.value = o.q || 0.7; g.connect(fl); n = fl; }
      n.connect(o.dest || dest);
      if (o.verb && verb) { const s = c.createGain(); s.gain.value = o.verb; n.connect(s); s.connect(verb); }
      os.start(t); os.stop(t + dur + 0.05);
      return os;
    };
    k.noise = function (t, dur, vol, o) {
      o = o || {};
      const s = c.createBufferSource(); s.buffer = nbuf;
      if (o.rate) s.playbackRate.value = o.rate;
      const g = c.createGain();
      const a = o.a || 0.004;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t + a);
      if (o.hold) g.gain.setValueAtTime(Math.max(0.0002, vol), t + o.hold);
      g.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(a + 0.01, dur));
      const fl = c.createBiquadFilter(); fl.type = o.ft || 'bandpass'; fl.Q.value = o.q || 0.8;
      fl.frequency.setValueAtTime(o.f0 || 2000, t);
      if (o.f1) fl.frequency.exponentialRampToValueAtTime(Math.max(20, o.f1), t + dur);
      s.connect(fl); fl.connect(g); g.connect(o.dest || dest);
      if (o.verb && verb) { const v = c.createGain(); v.gain.value = o.verb; g.connect(v); v.connect(verb); }
      s.start(t, Math.random() * 1.4, Math.min(1.9, dur + 0.05));
      return s;
    };
    k.click = (t, vol, f) => k.tone('square', f || 1800, (f || 1800) * 0.5, t, 0.012, vol, { a: 0.001, f: 4000 });
    k.thump = (t, vol, f, dur) => { k.tone('sine', f || 90, (f || 90) * 0.45, t, dur || 0.16, vol, { a: 0.002 }); k.noise(t, 0.05, vol * 0.5, { ft: 'lowpass', f0: 500, q: 0.5 }); };
    k.ring = (f, t, dur, vol, o) => { // metallic partials
      [1, 2.76, 5.4, 8.9].forEach((m, i) => k.tone('sine', f * m, f * m * 0.995, t, dur / (1 + i * 0.7), vol / (1 + i * 1.3), Object.assign({ a: 0.001 }, o || {})));
    };
    return k;
  }

  /* ------------------------------------------------------------ sound effects table (name -> synth) */
  const S = A.SFX;
  S.ui_click = (k, t, v) => { k.click(t, 0.22 * v, 1500); k.tone('sine', 520, 420, t, 0.06, 0.12 * v, { a: 0.002 }); };
  S.ui_back = (k, t, v) => { k.click(t, 0.2 * v, 900); k.tone('sine', 380, 260, t, 0.08, 0.12 * v, { a: 0.002 }); };
  S.toast = (k, t, v) => { k.tone('sine', 740, 740, t, 0.18, 0.08 * v, { a: 0.01, verb: 0.3 }); k.tone('sine', 988, 988, t + 0.06, 0.2, 0.06 * v, { a: 0.01, verb: 0.3 }); };
  S.tick = (k, t, v) => k.click(t, 0.15 * v, 2600);
  S.stab = (k, t, v) => { k.noise(t, 0.12, 0.3 * v, { ft: 'bandpass', f0: 900, f1: 300, q: 1, a: 0.001 }); k.thump(t, 0.4 * v, 120, 0.12); k.tone('sawtooth', 300, 90, t, 0.18, 0.1 * v, { a: 0.002, f: 900 }); };
  S.blade_swish = (k, t, v) => k.noise(t, 0.22, 0.18 * v, { ft: 'bandpass', f0: 700, f1: 3200, q: 1.2, a: 0.06 });
  S.blank_click = (k, t, v) => { k.click(t, 0.3 * v, 1400); k.tone('triangle', 420, 260, t, 0.1, 0.12 * v, { a: 0.002 }); };
  S.spray_hiss = (k, t, v) => { k.noise(t, 1.1, 0.2 * v, { ft: 'highpass', f0: 3500, f1: 6500, q: 0.6, a: 0.05, verb: 0.3 }); k.click(t, 0.25 * v, 1100); };
  S.rope_whip = (k, t, v) => { k.noise(t, 0.3, 0.16 * v, { ft: 'bandpass', f0: 500, f1: 1800, q: 0.7, a: 0.1 }); k.noise(t + 0.28, 0.08, 0.2 * v, { ft: 'lowpass', f0: 1800, f1: 400, q: 0.5, a: 0.001 }); };
  S.cloth = (k, t, v) => k.noise(t, 0.28, 0.1 * v, { ft: 'bandpass', f0: 1100, f1: 500, q: 0.4, a: 0.06 });
  S.table_tap = (k, t, v) => { k.tone('sine', 220, 120, t, 0.07, 0.35 * v, { a: 0.001 }); k.noise(t, 0.03, 0.12 * v, { ft: 'bandpass', f0: 1500, q: 1 }); };
  S.table_thud = (k, t, v) => { k.thump(t, 0.6 * v, 70, 0.3); k.noise(t, 0.12, 0.2 * v, { ft: 'lowpass', f0: 700, q: 0.4 }); };
  // v7.6: per-material landing sounds for the round-start item drop, and the Dealer's rage (slam / rumble / debris)
  S.item_land_glass = (k, t, v) => { k.thump(t, 0.35 * v, 90, 0.12); k.tone('sine', 2600, 2450, t, 0.2, 0.17 * v, { a: 0.001 }); k.tone('sine', 3900, 3600, t + 0.012, 0.14, 0.09 * v, { a: 0.001 }); k.noise(t, 0.05, 0.12 * v, { ft: 'highpass', f0: 3000, q: 0.8 }); };
  S.item_land_metal = (k, t, v) => { k.thump(t, 0.4 * v, 110, 0.1); k.tone('square', 1400, 1300, t, 0.09, 0.09 * v, { a: 0.001 }); k.tone('sine', 2100, 2040, t, 0.26, 0.12 * v, { a: 0.001 }); k.noise(t, 0.04, 0.15 * v, { ft: 'bandpass', f0: 3500, q: 2 }); };
  S.item_land_soft = (k, t, v) => { k.thump(t, 0.45 * v, 75, 0.14); k.noise(t, 0.08, 0.12 * v, { ft: 'lowpass', f0: 900, q: 0.5 }); };
  S.item_land_can = (k, t, v) => { k.thump(t, 0.4 * v, 95, 0.12); k.tone('sine', 820, 560, t, 0.16, 0.14 * v, { a: 0.001 }); k.tone('sine', 1650, 1100, t + 0.01, 0.1, 0.07 * v, { a: 0.001 }); k.noise(t, 0.05, 0.1 * v, { ft: 'bandpass', f0: 2600, q: 1.5 }); };
  S.rage_rumble = (k, t, v) => { k.tone('sawtooth', 34, 72, t, 1.7, 0.45 * v, { a: 1.2 }); k.tone('sine', 52, 46, t, 1.7, 0.4 * v, { a: 1.0 }); k.noise(t, 1.7, 0.22 * v, { ft: 'lowpass', f0: 260, f1: 900, q: 0.6, a: 1.1 }); };
  S.rage_slam = (k, t, v) => {
    k.thump(t, 1.0 * v, 46, 0.6); k.thump(t + 0.015, 0.85 * v, 78, 0.35); k.tone('sawtooth', 95, 38, t, 0.8, 0.32 * v, { a: 0.002 });
    k.noise(t, 0.5, 0.5 * v, { ft: 'lowpass', f0: 1800, f1: 200, q: 0.6, a: 0.001, verb: 0.7 }); k.noise(t, 0.05, 0.55 * v, { ft: 'bandpass', f0: 2400, q: 1.5, a: 0.0005 });          // wood crack
    k.noise(t + 0.08, 1.1, 0.18 * v, { ft: 'bandpass', f0: 320, f1: 110, q: 0.8, a: 0.01, verb: 1 });                                                                               // room boom + tail
    for (let i = 0; i < 8; i++) k.tone('sine', 650 + ((i * 397) % 1700), 480, t + 0.12 + i * 0.055, 0.06, 0.07 * v, { a: 0.001 });                                                    // things rattling on the table
  };
  S.pickup = (k, t, v) => { k.noise(t, 0.12, 0.14 * v, { ft: 'bandpass', f0: 2200, f1: 900, q: 1 }); k.tone('sine', 300, 360, t, 0.06, 0.1 * v); };
  S.place = (k, t, v) => { k.tone('sine', 190, 110, t, 0.09, 0.28 * v, { a: 0.001 }); k.noise(t, 0.04, 0.1 * v, { ft: 'bandpass', f0: 1800, q: 1 }); };
  S.bounce_small = (k, t, v) => { for (let i = 0; i < 3; i++) k.tone('triangle', 1300 - i * 180, 900 - i * 120, t + i * 0.07 * (1 + i * 0.4), 0.05, 0.12 * v / (1 + i), { a: 0.001 }); };
  S.item_land = (k, t, v) => { k.thump(t, 0.28 * v, 130, 0.1); k.ring(1900, t, 0.08, 0.05 * v); };
  S.slap = (k, t, v) => { k.noise(t, 0.09, 0.55 * v, { ft: 'highpass', f0: 1800, f1: 900, q: 0.6, a: 0.001, verb: 0.15 }); k.thump(t, 0.5 * v, 150, 0.12); k.noise(t + 0.02, 0.22, 0.12 * v, { ft: 'bandpass', f0: 2400, f1: 700, q: 0.5, a: 0.002, verb: 0.35 }); };
  S.whoosh = (k, t, v) => k.noise(t, 0.5, 0.2 * v, { ft: 'bandpass', f0: 300, f1: 2600, q: 0.7, a: 0.2, verb: 0.2 });
  S.creak = (k, t, v) => { k.tone('sawtooth', 150, 190, t, 0.28, 0.05 * v, { a: 0.1, f: 600, q: 6 }); k.tone('sawtooth', 190, 120, t + 0.28, 0.27, 0.04 * v, { a: 0.02, f: 600, q: 6 }); };
  S.metal_clink = (k, t, v) => k.ring(2300 + Math.random() * 400, t, 0.25, 0.14 * v, { verb: 0.2 });
  S.glass_tink = (k, t, v) => { k.ring(3400, t, 0.4, 0.12 * v, { verb: 0.3 }); k.tone('sine', 5200, 5200, t, 0.3, 0.04 * v, { a: 0.001 }); };
  S.lens_hum = (k, t, v) => { k.tone('sine', 220, 330, t, 1.2, 0.1 * v, { a: 0.3, verb: 0.4 }); k.tone('sine', 223, 335, t, 1.2, 0.08 * v, { a: 0.3 }); k.noise(t, 1.2, 0.04 * v, { ft: 'bandpass', f0: 3000, q: 8, a: 0.4 }); };
  S.cuff_open = (k, t, v) => { for (let i = 0; i < 5; i++) k.click(t + i * 0.045, 0.2 * v, 1400 + i * 120); k.ring(1900, t + 0.2, 0.2, 0.08 * v); };
  S.cuff_close = (k, t, v) => { for (let i = 0; i < 4; i++) k.click(t + i * 0.035, 0.22 * v, 1500 + i * 150); k.ring(1200, t + 0.15, 0.4, 0.2 * v, { verb: 0.25 }); k.thump(t + 0.15, 0.2 * v, 120, 0.1); };
  S.cig_light = (k, t, v) => { k.noise(t, 0.6, 0.12 * v, { ft: 'highpass', f0: 3000, q: 0.5, a: 0.02 }); k.noise(t + 0.1, 0.9, 0.05 * v, { ft: 'bandpass', f0: 5000, q: 2 }); };
  S.lighter_open = (k, t, v) => { k.click(t, 0.3 * v, 1100); k.ring(2600, t + 0.01, 0.35, 0.12 * v, { verb: 0.2 }); };
  S.lighter_flick = (k, t, v) => { k.noise(t, 0.07, 0.3 * v, { ft: 'highpass', f0: 2500, q: 0.7, a: 0.001 }); k.click(t, 0.3 * v, 2500); k.noise(t + 0.05, 0.12, 0.12 * v, { ft: 'bandpass', f0: 1500, q: 1 }); };
  S.lighter_close = (k, t, v) => { k.click(t, 0.3 * v, 800); k.ring(2200, t, 0.2, 0.1 * v); };
  S.flame_whoosh = (k, t, v) => k.noise(t, 0.35, 0.14 * v, { ft: 'bandpass', f0: 500, f1: 1200, q: 0.5, a: 0.04 });
  S.puff = (k, t, v) => k.noise(t, 0.25, 0.1 * v, { ft: 'lowpass', f0: 1800, f1: 400, q: 0.5, a: 0.01 });
  S.burn = (k, t, v) => { k.noise(t, 1.1, 0.2 * v, { ft: 'bandpass', f0: 3500, f1: 1200, q: 0.8, a: 0.05 }); for (let i = 0; i < 12; i++) k.click(t + Math.random() * 1.0, 0.08 * v, 1800 + Math.random() * 2000); };
  S.smoke_exhale = (k, t, v) => k.noise(t, 1.4, 0.14 * v, { ft: 'bandpass', f0: 1800, f1: 700, q: 0.4, a: 0.35, verb: 0.2 });
  S.battery_insert = (k, t, v) => { k.click(t, 0.3 * v, 900); k.thump(t + 0.02, 0.35 * v, 150, 0.1); k.ring(1500, t + 0.04, 0.3, 0.12 * v); k.tone('sine', 2200, 2200, t + 0.1, 0.07, 0.06 * v); };
  S.zap = (k, t, v) => { k.noise(t, 0.3, 0.24 * v, { ft: 'highpass', f0: 2500, f1: 7000, q: 1, a: 0.001, verb: 0.2 }); k.tone('sawtooth', 1800, 120, t, 0.22, 0.12 * v, { a: 0.002, f: 3000 }); for (let i = 0; i < 6; i++) k.click(t + i * 0.03, 0.14 * v, 2000 + Math.random() * 2500); };
  S.pill_rattle = (k, t, v) => { for (let i = 0; i < 9; i++) k.tone('triangle', 2500 + Math.random() * 1500, 1800, t + i * 0.055 + Math.random() * 0.02, 0.03, 0.09 * v, { a: 0.001 }); };
  S.bottle_open = (k, t, v) => { k.tone('square', 500, 380, t, 0.05, 0.12 * v, { a: 0.001, f: 1500 }); k.noise(t, 0.12, 0.1 * v, { ft: 'bandpass', f0: 1200, q: 1 }); k.thump(t + 0.06, 0.15 * v, 260, 0.08); };
  S.gulp = (k, t, v) => { k.tone('sine', 140, 90, t, 0.14, 0.2 * v, { a: 0.02 }); k.tone('sine', 120, 70, t + 0.2, 0.14, 0.18 * v, { a: 0.02 }); k.noise(t, 0.35, 0.05 * v, { ft: 'lowpass', f0: 900, q: 0.5 }); };
  S.can_open = (k, t, v) => { k.click(t, 0.3 * v, 1800); k.noise(t + 0.03, 0.5, 0.22 * v, { ft: 'highpass', f0: 4000, f1: 2500, q: 0.7, a: 0.005 }); k.ring(1700, t, 0.12, 0.06 * v); };
  S.can_fizz = (k, t, v) => k.noise(t, 1.0, 0.09 * v, { ft: 'highpass', f0: 5500, q: 0.5, a: 0.05 });
  S.can_crush = (k, t, v) => { for (let i = 0; i < 6; i++) k.tone('square', 600 + Math.random() * 1400, 300, t + i * 0.035, 0.05, 0.1 * v, { a: 0.001, f: 3000 }); k.noise(t, 0.3, 0.2 * v, { ft: 'bandpass', f0: 1800, q: 0.6 }); };
  S.device_beep = (k, t, v) => { k.tone('square', 1320, 1320, t, 0.09, 0.07 * v, { a: 0.003, f: 2800 }); k.tone('square', 1760, 1760, t + 0.12, 0.09, 0.07 * v, { a: 0.003, f: 2800 }); };
  S.device_dial = (k, t, v) => { for (let i = 0; i < 12; i++) k.click(t + i * 0.045, 0.14 * v, 1000 + i * 90); };
  S.glitch = (k, t, v) => { for (let i = 0; i < 7; i++) k.tone('square', 200 + Math.random() * 3000, 100 + Math.random() * 500, t + i * 0.04, 0.05, 0.08 * v, { a: 0.001, f: 4000 }); k.noise(t, 0.3, 0.14 * v, { ft: 'bandpass', f0: 4000, f1: 800, q: 3, a: 0.001 }); };
  S.coin_flip = (k, t, v) => { k.ring(3200, t, 0.9, 0.1 * v, { verb: 0.25 }); k.tone('sine', 3180, 3260, t, 0.9, 0.03 * v, { a: 0.02 }); k.noise(t, 0.08, 0.05 * v, { ft: 'highpass', f0: 3000 }); };
  S.coin_catch = (k, t, v) => { k.ring(2600, t, 0.3, 0.1 * v); k.click(t, 0.2 * v, 1600); };
  S.gun_pickup = (k, t, v) => { k.thump(t, 0.3 * v, 110, 0.12); k.noise(t, 0.2, 0.1 * v, { ft: 'bandpass', f0: 900, q: 1 }); k.ring(800, t + 0.02, 0.25, 0.05 * v); };
  S.gun_cock = (k, t, v) => { k.click(t, 0.4 * v, 700); k.thump(t + 0.01, 0.4 * v, 140, 0.08); k.ring(1100, t + 0.02, 0.35, 0.12 * v, { verb: 0.3 }); k.click(t + 0.14, 0.45 * v, 1000); k.thump(t + 0.15, 0.3 * v, 100, 0.1); };
  S.gun_breech_open = (k, t, v) => { k.click(t, 0.3 * v, 600); k.ring(700, t + 0.02, 0.4, 0.12 * v, { verb: 0.3 }); k.noise(t, 0.2, 0.08 * v, { ft: 'bandpass', f0: 700, q: 2 }); };
  S.gun_breech_close = (k, t, v) => { k.thump(t, 0.4 * v, 120, 0.1); k.click(t, 0.4 * v, 900); k.ring(900, t + 0.01, 0.4, 0.14 * v, { verb: 0.3 }); };
  S.gun_load_shell = (k, t, v) => { k.click(t, 0.25 * v, 1400); k.tone('triangle', 900, 600, t, 0.05, 0.14 * v); k.thump(t + 0.04, 0.12 * v, 200, 0.06); };
  S.gun_fire = (k, t, v) => {
    k.noise(t, 0.09, 0.6 * v, { ft: 'lowpass', f0: 9000, f1: 1500, q: 0.5, a: 0.001 });
    k.noise(t, 0.6, 0.35 * v, { ft: 'lowpass', f0: 3000, f1: 200, q: 0.5, a: 0.002, verb: 0.9 });
    k.tone('sine', 150, 28, t, 0.55, 0.55 * v, { a: 0.001 });
    k.tone('sawtooth', 380, 60, t, 0.12, 0.25 * v, { a: 0.001, f: 1800 });
    k.noise(t + 0.08, 1.6, 0.2 * v, { ft: 'lowpass', f0: 900, f1: 120, q: 0.4, a: 0.1, verb: 1.0 });
    k.ring(3000, t + 0.12, 0.3, 0.05 * v, { verb: 0.6 });
  };
  S.gun_dry = (k, t, v) => { k.click(t, 0.4 * v, 800); k.thump(t, 0.3 * v, 100, 0.1); k.noise(t + 0.02, 0.25, 0.14 * v, { ft: 'lowpass', f0: 1200, f1: 300, q: 0.5, a: 0.01, verb: 0.3 }); };
  S.shell_drop = (k, t, v) => { for (let i = 0; i < 3; i++) k.tone('triangle', 2200 - i * 300, 1500 - i * 200, t + i * 0.09 * (1 + i * 0.3), 0.06, 0.16 * v / (1 + i * 0.5), { a: 0.001 }); k.thump(t, 0.1 * v, 200, 0.05); };
  S.shell_reveal = (k, t, v) => { k.ring(1400, t, 0.35, 0.1 * v, { verb: 0.3 }); k.tone('sine', 220, 110, t, 0.4, 0.1 * v, { a: 0.02 }); };
  S.impact_hit = (k, t, v) => { k.thump(t, 0.8 * v, 80, 0.35); k.noise(t, 0.3, 0.3 * v, { ft: 'lowpass', f0: 2200, f1: 300, q: 0.5, a: 0.001, verb: 0.4 }); k.tone('sawtooth', 220, 50, t, 0.3, 0.15 * v, { f: 600, a: 0.002 }); };
  S.heartbeat = (k, t, v) => { k.thump(t, 0.7 * v, 62, 0.18); k.thump(t + 0.26, 0.5 * v, 55, 0.18); };
  S.round_start = (k, t, v) => { k.tone('sine', 55, 55, t, 2.4, 0.4 * v, { a: 0.9, verb: 0.5 }); k.tone('sawtooth', 110, 112, t, 2.4, 0.07 * v, { a: 1.0, f: 400, verb: 0.5 }); k.noise(t, 2.2, 0.14 * v, { ft: 'bandpass', f0: 200, f1: 1600, q: 0.6, a: 1.2, verb: 0.5 }); k.thump(t + 2.2, 0.7 * v, 50, 0.5); };
  S.stinger = (k, t, v) => { k.tone('sawtooth', 70, 66, t, 1.6, 0.18 * v, { a: 0.01, f: 500, verb: 0.7 }); k.ring(466, t, 1.6, 0.14 * v, { verb: 0.8 }); k.ring(493, t, 1.6, 0.1 * v, { verb: 0.8 }); k.thump(t, 0.5 * v, 55, 0.5); };
  S.win_sting = (k, t, v) => { [196, 247, 294, 392].forEach((f, i) => k.tone('sine', f, f, t + i * 0.22, 2.2, 0.1 * v, { a: 0.05, verb: 0.8 })); k.tone('sine', 98, 98, t, 3, 0.2 * v, { a: 0.2, verb: 0.5 }); };
  S.lose_sting = (k, t, v) => { [147, 139, 131, 98].forEach((f, i) => k.tone('sawtooth', f, f * 0.97, t + i * 0.35, 2.2, 0.07 * v, { a: 0.1, f: 500, verb: 0.9 })); k.thump(t + 1.2, 0.8 * v, 45, 0.9); k.noise(t, 3, 0.1 * v, { ft: 'lowpass', f0: 600, f1: 80, q: 0.5, a: 0.3, verb: 0.8 }); };

  A.requiredSfx = Object.keys(S);

  /* ------------------------------------------------------------ context & buses */
  function impulse(c, secs) {
    const len = Math.floor(c.sampleRate * secs), b = c.createBuffer(2, len, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d = b.getChannelData(ch); let s = 777 + ch * 91; for (let i = 0; i < len; i++) { s = (s * 1664525 + 1013904223) | 0; d[i] = (((s >>> 8) / 8388608) - 1) * Math.pow(1 - i / len, 2.6); } }
    return b;
  }
  A.init = function () {
    if (ctx) return true;
    const AC = G.AudioContext || G.webkitAudioContext;
    if (!AC) return false;
    try {
      ctx = new AC({ latencyHint: 'balanced' });
      noiseBuf = makeNoise(ctx);
      const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 5; comp.attack.value = 0.004; comp.release.value = 0.2;
      const master = ctx.createGain(); master.connect(comp); comp.connect(ctx.destination);
      bus.master = master; bus.comp = comp;
      for (const n of ['music', 'ambience', 'sfx', 'voice']) { const g = ctx.createGain(); g.connect(master); bus[n] = g; }
      const conv = ctx.createConvolver(); conv.buffer = impulse(ctx, 1.4);
      const vg = ctx.createGain(); vg.gain.value = 0.55; verbIn = ctx.createGain(); verbIn.connect(conv); conv.connect(vg);
      vg.connect(bus.sfx);
      const vgm = ctx.createGain(); vgm.gain.value = 0.7; conv.connect(vgm); vgm.connect(bus.music); // light shared tail for music
      bus.duck = ctx.createGain(); bus.duck.connect(master);
      A.applyVolumes();
      A.ready = true;
    } catch (e) { console.warn('[audio] init failed', e); ctx = null; return false; }
    return true;
  };
  A.unlock = function () {
    if (!A.init()) return;
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    if (!A.unlocked) { A.unlocked = true; startAmbience(); startMusic(); setTimeout(A.bakeAll, 1500); }
  };
  A.applyVolumes = function () {
    if (!ctx) return;
    const t = ctx.currentTime, V = A.vol, set = (n, v) => { try { bus[n].gain.cancelScheduledValues(t); bus[n].gain.setTargetAtTime(v, t, 0.05); } catch (e) { /* ignore */ } };
    set('master', V.master); set('music', mv()); set('ambience', V.ambience * (A.paused || A.menuMusic ? 0.3 : 1)); if (G.MenuArt) G.MenuArt.refreshVolume(); set('sfx', V.sfx); set('voice', V.voice);
  };
  A.applySettings = function (s) {
    A.vol.master = s.master; A.vol.music = s.music; A.vol.ambience = s.ambience; A.vol.sfx = s.sfx; A.vol.voice = s.voice;
    A.applyVolumes();
  };
  A.setPaused = function (p) {
    A.paused = p; A.applyVolumes();
    if (ctx) { if (p && A.unlocked) { try { bus.music.gain.setTargetAtTime(0.0001, ctx.currentTime, 0.1); } catch (e) { /* ignore */ } } }
  };
  A.suspend = function () { if (ctx && ctx.state === 'running') ctx.suspend().catch(() => {}); };
  A.resume = function () { if (ctx && A.unlocked && ctx.state === 'suspended') ctx.resume().catch(() => {}); };

  /* ------------------------------------------------------------ playback */
  A.sfx = function (name, o) {
    o = o || {};
    A.stats.played++;
    if (!ctx || !A.unlocked || ctx.state !== 'running') { A.stats.dropped++; return false; }
    const fn = S[name];
    if (!fn) { if (!A._warned) A._warned = {}; if (!A._warned[name]) { A._warned[name] = 1; console.warn('[audio] missing sfx', name); } A.stats.dropped++; return false; }
    const now = ctx.currentTime;
    if (lastPlayed[name] !== undefined && now - lastPlayed[name] < (o.minGap || 0.035)) { A.stats.throttled++; return false; } // duplicate guard
    lastPlayed[name] = now;
    if (live > 24) { A.stats.dropped++; return false; } // polyphony cap
    live++; setTimeout(() => { live--; }, 700);
    let dest = bus.sfx;
    if (o.pan !== undefined && ctx.createStereoPanner) { const p = ctx.createStereoPanner(); p.pan.value = U.clamp(o.pan, -1, 1); p.connect(bus.sfx); dest = p; }
    const baked = bakedSfx[name];
    if (baked) { A.stats.baked = (A.stats.baked || 0) + 1; playBuffer(baked, dest, now + (o.delay || 0), o.vol === undefined ? 1 : o.vol); return true; }
    bake(name);   // first use: play live once while the buffer renders in the background
    const k = Kit(ctx, dest, noiseBuf, verbIn);
    try { fn(k, now + (o.delay || 0), (o.vol === undefined ? 1 : o.vol)); } catch (e) { console.warn('[audio] sfx error', name, e); return false; }
    return true;
  };

  /* Render one sfx offline (for the in-browser audio self-test). Returns {peak, rms, dur}. */
  A.renderTest = async function (name) {
    const OC = G.OfflineAudioContext || G.webkitOfflineAudioContext;
    const oc = new OC(1, 44100 * 4, 44100);
    const nb = makeNoise(oc);
    const out = oc.createGain(); out.connect(oc.destination);
    const conv = oc.createConvolver(); conv.buffer = impulse(oc, 1.5); const vin = oc.createGain(); vin.connect(conv); conv.connect(out);
    S[name](Kit(oc, out, nb, vin), 0.02, 1);
    const buf = await oc.startRendering(); const d = buf.getChannelData(0);
    let peak = 0, sum = 0, last = 0;
    for (let i = 0; i < d.length; i++) { const a = Math.abs(d[i]); if (a > peak) peak = a; sum += d[i] * d[i]; if (a > 0.003) last = i; }
    return { name, peak, rms: Math.sqrt(sum / d.length), dur: last / 44100 };
  };

  /* ------------------------------------------------------------ baked (pre-rendered) sounds */
  const bakedSfx = {}, baking = {}, voiceCache = new Map(); let bakeQ = [], baker = 0;
  const OC = () => G.OfflineAudioContext || G.webkitOfflineAudioContext;
  function playBuffer(buf, dest, t, vol) {
    const src = ctx.createBufferSource(); src.buffer = buf; const g = ctx.createGain(); g.gain.value = vol; src.connect(g); g.connect(dest); src.start(Math.max(t, ctx.currentTime)); return src;
  }
  function trim(buf, c) { // cut trailing silence so cached buffers stay small
    const d = buf.getChannelData(0); let last = 0; for (let i = d.length - 1; i >= 0; i--) if (Math.abs(d[i]) > 0.0015) { last = i; break; }
    const n = Math.min(d.length, last + 2048), out = c.createBuffer(1, Math.max(1, n), buf.sampleRate); out.getChannelData(0).set(d.subarray(0, n)); return out;
  }
  async function renderBuf(secs, build) {
    const Ctor = OC(); if (!Ctor || !ctx) return null; const sr = 44100, oc = new Ctor(1, Math.ceil(sr * secs), sr), nb = makeNoise(oc);
    const out = oc.createGain(); out.connect(oc.destination); const conv = oc.createConvolver(); conv.buffer = impulse(oc, 1.2); const vin = oc.createGain(); vin.connect(conv); conv.connect(out);
    build(oc, out, nb, vin); return trim(await oc.startRendering(), ctx);
  }
  function bake(name) {
    if (bakedSfx[name] || baking[name] || !S[name] || !OC()) return; baking[name] = 1; bakeQ.push(name); if (!baker) baker = setTimeout(pump, 30);
  }
  function pump() { // one sound at a time, never during a busy moment
    baker = 0; const n = bakeQ.shift(); if (!n) return;
    renderBuf(4, (oc, out, nb, vin) => S[n](Kit(oc, out, nb, vin), 0.01, 1)).then((b) => { if (b) bakedSfx[n] = b; }).catch(() => {}).then(() => { if (bakeQ.length) baker = setTimeout(pump, 40); });
  }
  A.bakeAll = function () { if (!ctx) return; for (const n of Object.keys(S)) bake(n); };
  A.stats.baked = 0; A.bakedCount = () => Object.keys(bakedSfx).length; A.voiceCached = () => voiceCache.size;

  /* ------------------------------------------------------------ ambience bed */
  const amb = { nodes: [], next: 0, t: 0, buzz: null };
  function startAmbience() {
    const c = ctx, out = bus.ambience;
    const mk = (type, f, vol, filt) => { const o = c.createOscillator(), g = c.createGain(); o.type = type; o.frequency.value = f; g.gain.value = vol; o.connect(g); if (filt) { const fl = c.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = filt; g.connect(fl); fl.connect(out); } else g.connect(out); o.start(); return { o, g }; };
    amb.nodes.push(mk('sine', 48, 0.16), mk('sine', 96.4, 0.07), mk('sawtooth', 50.2, 0.03, 220)); // industrial hum
    const buzz = mk('sawtooth', 100, 0.012, 1400); amb.buzz = buzz; amb.nodes.push(buzz);   // mains buzz
    const lfo = c.createOscillator(), lg = c.createGain(); lfo.frequency.value = 0.07; lg.gain.value = 0.03; lfo.connect(lg); lg.connect(amb.nodes[0].g.gain); lfo.start();
    const room = c.createBufferSource(); room.buffer = noiseBuf; room.loop = true;
    const rf = c.createBiquadFilter(); rf.type = 'lowpass'; rf.frequency.value = 380; const rg = c.createGain(); rg.gain.value = 0.05; room.connect(rf); rf.connect(rg); rg.connect(out); room.start(); // room tone
  }
  A.buzzSpike = function (amt) { if (!ctx || !amb.buzz) return; const t = ctx.currentTime, g = amb.buzz.g.gain; g.cancelScheduledValues(t); g.setValueAtTime(0.012, t); g.linearRampToValueAtTime(0.012 + 0.06 * (amt || 1), t + 0.02); g.linearRampToValueAtTime(0.012, t + 0.25); };

  /* ------------------------------------------------------------ generative music */
  const mus = { tension: 0.2, next: 0, drone: null, pulse: null, mode: 'menu', beat: 0 };
  const SCALE = [0, 1, 3, 5, 7, 8, 10]; // phrygian — sparse unsettling notes
  function startMusic() {
    const c = ctx, out = bus.music;
    const pad = (f, vol) => { const o = c.createOscillator(), o2 = c.createOscillator(), g = c.createGain(), fl = c.createBiquadFilter(); o.type = 'sawtooth'; o2.type = 'sawtooth'; o.frequency.value = f; o2.frequency.value = f * 1.004; fl.type = 'lowpass'; fl.frequency.value = 260; fl.Q.value = 2; g.gain.value = vol; o.connect(fl); o2.connect(fl); fl.connect(g); g.connect(out); o.start(); o2.start();
      const l = c.createOscillator(), lg = c.createGain(); l.frequency.value = 0.05 + Math.random() * 0.05; lg.gain.value = 120; l.connect(lg); lg.connect(fl.frequency); l.start(); return { g, fl }; };
    mus.drone = [pad(36.7, 0.1), pad(55, 0.06), pad(73.4, 0.03)];
    mus.high = (function () { const o = c.createOscillator(), g = c.createGain(); o.type = 'sine'; o.frequency.value = 622; g.gain.value = 0; o.connect(g); g.connect(out); o.start(); const l = c.createOscillator(), lg = c.createGain(); l.frequency.value = 0.13; lg.gain.value = 6; l.connect(lg); lg.connect(o.frequency); l.start(); return g; })();
    mus.t = 0;
  }
  A.setTension = function (x) { mus.tension = U.clamp(x, 0, 1); };
  A.setMusicMode = function (m) { mus.mode = m; };
  A.stinger = function (kind) { A.sfx(kind === 'win' ? 'win_sting' : kind === 'lose' ? 'lose_sting' : kind === 'round' ? 'round_start' : 'stinger'); };

  /* per-frame (game-time) update: sparse notes, tension pulse, ambience events */
  A.update = function (dt) {
    if (!ctx || !A.unlocked || A.paused || ctx.state !== 'running') return;
    const t = ctx.currentTime;
    mus.t += dt; amb.t += dt;
    try {
      const tn = mus.tension;
      mus.drone[1].g.gain.setTargetAtTime(0.03 + tn * 0.1, t, 0.8);
      mus.drone[2].g.gain.setTargetAtTime(0.01 + tn * 0.06, t, 0.8);
      mus.drone[0].fl.frequency.setTargetAtTime(220 + tn * 320, t, 1.5);
      mus.high.gain.setTargetAtTime(Math.max(0, tn - 0.55) * 0.05, t, 1.2);
      bus.music.gain.setTargetAtTime(mv(), t, 0.3);
    } catch (e) { /* ignore */ }
    if (mus.t > mus.next) { // sparse note with long reverb tail, then silence
      const k = Kit(ctx, bus.music, noiseBuf, verbIn);
      const deg = SCALE[Math.floor(Math.random() * SCALE.length)], f = 146.8 * Math.pow(2, (deg + (Math.random() < 0.3 ? 12 : 0)) / 12);
      k.tone('sine', f, f, t, 4.5, 0.06, { a: 0.6, verb: 1.4 }); k.tone('sine', f * 2.005, f * 2.005, t, 3, 0.015, { a: 0.4, verb: 1.2 });
      mus.next = mus.t + 6 + Math.random() * 12 * (1.4 - mus.tension) + (Math.random() < 0.25 ? 10 : 0); // carefully timed silences
    }
    mus.beat -= dt;
    if (mus.tension > 0.45 && mus.beat <= 0) { A.sfx('heartbeat', { vol: 0.25 + mus.tension * 0.35, minGap: 0.2 }); mus.beat = 1.25 - mus.tension * 0.55; }
    if (amb.t > amb.next) { // metallic creaks, distant impacts, electrical blips, distant machinery
      const r = Math.random(), k = Kit(ctx, bus.ambience, noiseBuf, verbIn);
      if (r < 0.35) A.sfx('creak', { vol: 0.4, pan: Math.random() * 2 - 1 });
      else if (r < 0.6) { k.thump(t, 0.18, 52 + Math.random() * 20, 0.5); k.noise(t, 0.6, 0.05, { ft: 'lowpass', f0: 400, q: 0.5, verb: 1.2 }); }
      else if (r < 0.8) A.buzzSpike(0.6);
      else { k.tone('square', 62, 58, t, 1.6, 0.012, { a: 0.4, f: 300 }); k.noise(t, 1.6, 0.025, { ft: 'bandpass', f0: 500, q: 3, a: 0.5 }); }
      amb.next = amb.t + 5 + Math.random() * 14;
    }
  };

  /* ------------------------------------------------------------ Dealer voice (formant synthesis, v7.6: deep / hoarse / performed)
     There are no recorded voice files and no speech engine in this build, so the Dealer is a synthesised voice: a big-vocal-tract growl (low glottal pulse + sub-octave,
     lowered formants, vocal fry, aspiration noise, drive) with a different PERFORMANCE per mood:
       normal/boom  deep menacing statement (falling contour)        excited  hyped, faster, rising phrase ends, harder drive      whisper  breathy low whisper
       murmur       slow low mutter                                  laugh    evil laugh (ha-ha-ha burst train that decays into a chuckle)
       rage         roar / scream (pitch climbs then tears), heavy clipping, wide open vowel                      glitch   broken voice
     Everything goes through a slap-back echo + the room reverb. Same line + mood always renders the same performance (seeded), so it is cached. */
  const VOWELS = [[700, 1100], [500, 1700], [300, 2300], [450, 800], [320, 800], [600, 1000]];
  function lineSeed(text) { let h = 2166136261; for (let i = 0; i < text.length; i++) { h ^= text.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  const MOODS = { normal: { f: 66, rng: 14, spd: 1, rough: 0.55, drive: 14, fs: 0.8, vol: 1 }, boom: { f: 62, rng: 12, spd: 1.05, rough: 0.6, drive: 16, fs: 0.78, vol: 1.05 }, excited: { f: 84, rng: 26, spd: 0.82, rough: 0.8, drive: 22, fs: 0.86, vol: 1.15 },
    murmur: { f: 52, rng: 8, spd: 1.2, rough: 0.5, drive: 10, fs: 0.74, vol: 0.7 }, whisper: { f: 0, rng: 0, spd: 1.2, rough: 0, drive: 4, fs: 1, vol: 0.8 }, glitch: { f: 70, rng: 22, spd: 1, rough: 0.9, drive: 40, fs: 0.9, vol: 0.9 },
    rage: { f: 118, rng: 70, spd: 0.8, rough: 1, drive: 34, fs: 0.95, vol: 1.3 }, laugh: { f: 100, rng: 20, spd: 1, rough: 0.7, drive: 16, fs: 0.85, vol: 1.1 } };
  A.voiceDuration = function (text, mood) {
    const n = Math.max(1, text.replace(/[^\p{L}\p{N}]/gu, '').length), M = MOODS[mood] || MOODS.normal;
    if (mood === 'laugh') return 2.1;
    if (mood === 'rage' && !text) return 2.3;
    return U.clamp(n * (mood === 'whisper' ? 0.085 : 0.07) * M.spd + 0.45 + (/^(ha|هاها)/i.test(text.trim()) ? 1.5 : 0), 0.9, 5.4);
  };
  /* returns duration in seconds. mood: normal|boom|excited|whisper|laugh|murmur|rage|glitch */
  A.speak = function (text, mood) {
    mood = MOODS[mood] ? mood : 'normal';
    const dur = A.voiceDuration(text, mood);
    if (!ctx || !A.unlocked || ctx.state !== 'running') return dur;
    try { const tt = ctx.currentTime; bus.music.gain.setTargetAtTime(mv() * 0.4, tt, 0.05); setTimeout(() => { if (ctx) bus.music.gain.setTargetAtTime(mv(), ctx.currentTime, 0.4); }, dur * 1000 + 300); } catch (e) { /* ignore */ }
    const key = mood + '|' + text, hit = voiceCache.get(key);
    if (hit) { playBuffer(hit, bus.voice, ctx.currentTime + 0.03, 1); return dur; }
    if (!OC()) { buildVoice(ctx, bus.voice, verbIn, noiseBuf, text, mood, dur, ctx.currentTime + 0.03); return dur; }
    renderBuf(dur + 2.2, (oc, out, nb, vin) => buildVoice(oc, out, vin, nb, text, mood, dur, 0.03)).then((b) => { if (!b) return; voiceCache.set(key, b); if (voiceCache.size > 48) voiceCache.delete(voiceCache.keys().next().value); if (ctx) playBuffer(b, bus.voice, ctx.currentTime + 0.01, 1); }).catch(() => {});
    return dur;
  };
  function buildVoice(c, dest, vsend, nb, text, mood, dur, t0) {
    const M = MOODS[mood] || MOODS.normal; let h = lineSeed(text + mood); const rnd = () => { h = (Math.imul(h, 1664525) + 1013904223) >>> 0; return h / 4294967296; };
    const out = c.createGain(); out.gain.value = M.vol;
    const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = mood === 'whisper' ? 5200 : mood === 'rage' ? 4200 : 2900; out.connect(lp);
    const chest = c.createBiquadFilter(); chest.type = 'peaking'; chest.frequency.value = 140; chest.gain.value = mood === 'whisper' ? 2 : 7; chest.Q.value = 0.9; lp.connect(chest);       // chest resonance: the deep body of the voice
    const shaper = c.createWaveShaper(); const curve = new Float32Array(512);
    for (let i = 0; i < 512; i++) { const x = i / 256 - 1; curve[i] = Math.tanh(x * M.drive * 0.18) * 0.9 + (mood === 'glitch' ? Math.sin(x * 12) * 0.2 : 0) + (mood === 'rage' ? Math.sin(x * 5) * 0.08 : 0); }
    shaper.curve = curve; chest.connect(shaper);
    const dry = c.createGain(); dry.gain.value = 0.92; shaper.connect(dry); dry.connect(dest);
    const send = c.createGain(); send.gain.value = mood === 'whisper' ? 0.5 : 0.75; shaper.connect(send); send.connect(vsend);                    // room reverb
    const dl = c.createDelay(0.6), fb = c.createGain(), dlo = c.createBiquadFilter(), eg = c.createGain();                                           // slap-back echo
    dl.delayTime.value = mood === 'rage' ? 0.23 : 0.17; fb.gain.value = mood === 'rage' ? 0.42 : 0.26; dlo.type = 'lowpass'; dlo.frequency.value = 1800; eg.gain.value = mood === 'rage' ? 0.42 : 0.28;
    shaper.connect(dl); dl.connect(dlo); dlo.connect(fb); fb.connect(dl); dlo.connect(eg); eg.connect(dest); eg.connect(vsend);
    const kit = Kit(c, out, nb, null), base = M.f ? M.f * (0.94 + rnd() * 0.12) : 0;
    const laughBurst = (t0b) => {      // evil laugh: HA-ha-ha-ha... decaying into a chuckle
      let t = t0b, n = 6 + Math.floor(rnd() * 3), gap = 0.15;
      for (let i = 0; i < n; i++) {
        const top = (118 - i * 5) * (0.95 + rnd() * 0.1), d = i === 0 ? 0.2 : 0.12 - i * 0.004; voiced(c, out, t, d, top, top * 0.62, VOWELS[0], (i === 0 ? 0.8 : 0.62 - i * 0.04) * M.vol, rnd, { rough: 0.8, fs: 0.85, hard: i === 0 });
        kit.noise(t, 0.09, 0.07, { ft: 'bandpass', f0: 1500, q: 0.9, dest: out }); t += gap; gap *= i < 3 ? 0.97 : 1.1;
      }
      voiced(c, out, t + 0.05, 0.4, 82, 55, VOWELS[3], 0.45, rnd, { rough: 1, fs: 0.8 }); return t + 0.45;
    };
    if (mood === 'laugh') { laughBurst(t0 + 0.05); return dur; }
    if (mood === 'rage' && !text) {      // roar: climbing scream that tears, with a sub-octave and torn-breath noise
      voiced(c, out, t0 + 0.02, 1.55, 105, 210, VOWELS[0], 1.0, rnd, { rough: 1, fs: 1, hard: true, scream: true });
      voiced(c, out, t0 + 1.4, 0.8, 190, 70, VOWELS[3], 0.85, rnd, { rough: 1, fs: 0.9, scream: true });
      kit.noise(t0, 1.9, 0.18, { ft: 'bandpass', f0: 1100, q: 0.6, dest: out }); kit.thump(t0, 0.5, 48, 0.8); return dur;
    }
    const sentences = text.split(/(?<=[.!?…؟])\s+/), laughFirst = /^(ha|هاها)/i.test(text.trim()); let t = t0 + 0.05;
    if (laughFirst) t = laughBurst(t) + 0.12;
    const bodyText = laughFirst ? text.replace(/^[^\s]*\s*/, '') : text, parts = (laughFirst ? [bodyText] : sentences);
    const totalChars = Math.max(1, parts.join('').replace(/[^\p{L}\p{N}]/gu, '').length), perChar = Math.max(0.03, (dur - 0.45 - (t - t0 - 0.05)) / totalChars);
    let pitch = base;
    for (const sent of parts) {
      const q = /[?؟]\s*$/.test(sent), ex = /!\s*$/.test(sent) || mood === 'excited', words = sent.replace(/[^\p{L}\p{N}\s]/gu, ' ').trim().split(/\s+/).filter(Boolean), nw = words.length;
      words.forEach((w, wi) => {
        const syl = Math.max(1, Math.round(w.length / 2.6)), pos = (wi + 1) / nw, stress = (wi === 0 && ex) || rnd() < 0.18;
        for (let s2 = 0; s2 < syl; s2++) {
          const v = VOWELS[Math.floor(rnd() * VOWELS.length)], d = Math.max(0.07, perChar * (w.length / syl) * 0.9 * M.spd);
          // phrase contour: statements fall, questions rise at the end, excitement climbs; stressed syllables jump
          const contour = q ? (pos > 0.7 ? 1 + (pos - 0.7) * 0.9 : 1) : mood === 'excited' ? 1 + pos * 0.22 : 1 - pos * 0.16;
          pitch = U.clamp(pitch * 0.55 + base * contour * 0.45 + (rnd() - 0.5) * M.rng * (stress ? 1.6 : 0.8) + (stress ? M.rng * 0.35 : 0), Math.max(40, base * 0.7), base * 1.7 + 20);
          if (mood === 'whisper') {
            const nz = c.createBufferSource(); nz.buffer = nb; const g = c.createGain(), f1 = c.createBiquadFilter(), f2 = c.createBiquadFilter();
            f1.type = f2.type = 'bandpass'; f1.frequency.value = v[0] * 2.2; f2.frequency.value = v[1] * 1.6; f1.Q.value = f2.Q.value = 5;
            g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.55, t + 0.03); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
            nz.connect(f1); nz.connect(f2); f1.connect(g); f2.connect(g); g.connect(out); nz.start(t, rnd() * 1.4, d + 0.05);
            const rum = c.createOscillator(), rg = c.createGain(); rum.type = 'sine'; rum.frequency.value = 55 + rnd() * 8; rg.gain.setValueAtTime(0.0001, t); rg.gain.exponentialRampToValueAtTime(0.12, t + 0.05); rg.gain.exponentialRampToValueAtTime(0.0001, t + d); rum.connect(rg); rg.connect(out); rum.start(t); rum.stop(t + d + 0.05);
          } else voiced(c, out, t, d, pitch * (1.04 - s2 * 0.03), pitch * (0.9 + rnd() * 0.15) * (stress ? 1.08 : 1) * (ex && s2 === syl - 1 && pos > 0.8 ? 1.15 : 1), v, (stress ? 0.62 : 0.5) * (mood === 'murmur' ? 0.7 : 1), rnd, { rough: M.rough, fs: M.fs, hard: stress && ex });
          t += d + 0.012;
        }
        t += 0.02 + (rnd() < 0.2 ? 0.1 + rnd() * 0.14 : 0);
      });
      t += 0.18 + rnd() * 0.12;          // breath between sentences
    }
    if (mood !== 'whisper') kit.noise(t0 - 0.02, 0.2, 0.06, { ft: 'bandpass', f0: 1000, q: 0.7, dest: out });     // intake breath
    return dur;
  };
  function voiced(c, out, t, d, f0, f1, vow, vol, rnd, o) {
    o = o || {}; const rough = o.rough === undefined ? 0.5 : o.rough, fs = o.fs || 0.8;
    const g = c.createGain(), att = Math.min(o.hard ? 0.012 : 0.03, d * 0.3); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + att); g.gain.setValueAtTime(vol, t + d * 0.7); g.gain.exponentialRampToValueAtTime(0.0001, t + d); g.connect(out);
    const f1b = c.createBiquadFilter(), f2b = c.createBiquadFilter(), f3 = c.createBiquadFilter();
    f1b.type = f2b.type = f3.type = 'bandpass'; f1b.frequency.value = vow[0] * fs; f2b.frequency.value = vow[1] * fs * 0.9; f3.frequency.value = 2400 * fs; f1b.Q.value = o.scream ? 3 : 6; f2b.Q.value = o.scream ? 3 : 7; f3.Q.value = 4;
    [[f1b, 1], [f2b, 0.7], [f3, 0.28]].forEach(([f, gain]) => { const m = c.createGain(); m.gain.value = gain; f.connect(m); m.connect(g); });
    // glottal pulse train + sub-octave + a detuned square for body
    for (const [mult, type, amp, det] of [[1, 'sawtooth', 0.8, 0], [0.5, 'sawtooth', 0.8, 9], [0.25, 'triangle', 0.35 * rough + 0.1, 0], [1.006, 'square', 0.3, -7]]) {
      const o2 = c.createOscillator(), og = c.createGain(); o2.type = type; o2.detune.value = det;
      o2.frequency.setValueAtTime(f0 * mult, t); o2.frequency.exponentialRampToValueAtTime(Math.max(30, f1 * mult), t + d);
      const vib = c.createOscillator(), vg = c.createGain(); vib.frequency.value = 5 + rnd() * 3; vg.gain.value = f0 * 0.012 * mult; vib.connect(vg); vg.connect(o2.frequency); vib.start(t); vib.stop(t + d + 0.05);
      if (rough > 0.3) {      // jitter + vocal fry: pitch wobble and a fast gain flutter = the hoarse, cracked grain
        const jt = c.createOscillator(), jg = c.createGain(); jt.type = 'sawtooth'; jt.frequency.value = 23 + rnd() * 20; jg.gain.value = f0 * 0.03 * rough * mult; jt.connect(jg); jg.connect(o2.frequency); jt.start(t); jt.stop(t + d + 0.05);
      }
      og.gain.value = amp; if (rough > 0.3) { const fl = c.createOscillator(), fg = c.createGain(); fl.frequency.value = 38 + rnd() * 30; fg.gain.value = amp * 0.45 * rough; fl.connect(fg); fg.connect(og.gain); fl.start(t); fl.stop(t + d + 0.05); }
      o2.connect(og); og.connect(f1b); og.connect(f2b); og.connect(f3); o2.start(t); o2.stop(t + d + 0.05);
    }
    if (rough > 0.3) {        // aspiration / rasp noise through the formants
      const nz = c.createBufferSource(), ng = c.createGain(); nz.buffer = c.createBuffer(1, Math.max(8, Math.ceil(c.sampleRate * (d + 0.1))), c.sampleRate); const dd = nz.buffer.getChannelData(0); for (let i = 0; i < dd.length; i++) dd[i] = rnd() * 2 - 1;
      ng.gain.value = 0.16 * rough * (o.scream ? 2 : 1); nz.connect(ng); ng.connect(f1b); ng.connect(f2b); nz.start(t); nz.stop(t + d + 0.05);
    }
  }

  G.AudioMgr = A;
  if (typeof module !== 'undefined' && module.exports) module.exports = A;
})(typeof window !== 'undefined' ? window : globalThis);
