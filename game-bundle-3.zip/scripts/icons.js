/* icons.js — one small inline-SVG icon set (24x24, stroke = currentColor) used by every button, tab and achievement.
   Original line drawings. Everything is plain markup, so icons recolour with CSS and cost nothing at runtime. */
(function (G) {
  'use strict';
  const gear = (() => { let t = ''; for (let k = 0; k < 8; k++) t += '<path d="M12 2.6v2.6" transform="rotate(' + k * 45 + ' 12 12)"/>'; return '<circle cx="12" cy="12" r="5.4"/><circle cx="12" cy="12" r="1.9"/>' + t; })();
  const sq4 = '<rect x="4" y="4" width="6.5" height="6.5" rx="1.4"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.4"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.4"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.4"/>';
  const target = '<circle cx="12" cy="12" r="6.5"/><path d="M12 2.5v4M12 17.5v4M2.5 12h4M17.5 12h4"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/>';
  const bag = '<path d="M5 8h14l-1 12H6z"/><path d="M9 8V6.5a3 3 0 0 1 6 0V8"/>';
  const bolt = '<path d="M13.5 2.5L5.5 13.5H11l-1 8 8-11h-5.5z" fill="currentColor"/>';
  const skull = '<path d="M12 3a8 8 0 0 0-5 14v3h10v-3a8 8 0 0 0-5-14z"/><circle cx="9" cy="12" r="1.6" fill="currentColor"/><circle cx="15" cy="12" r="1.6" fill="currentColor"/><path d="M10.5 20v-2M13.5 20v-2"/>';
  const star = '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>';
  const I = {
    aimDealer: target, aimSelf: '<circle cx="12" cy="8" r="3.6"/><path d="M5 21c0-4.2 3-6.6 7-6.6s7 2.4 7 6.6"/>',
    fire: '<path d="M12 2.5c3.6 3.6 5.6 6.6 5.6 10a5.6 5.6 0 0 1-11.2 0c0-1.9.8-3.3 1.9-4.4.2 1.4.9 2.2 1.8 2.5C10 7.4 10.6 5 12 2.5z" fill="currentColor"/>',
    lower: '<path d="M12 4v11M7 10.5l5 5 5-5M5 20h14"/>', inventory: sq4, inspect: '<circle cx="10.5" cy="10.5" r="6"/><path d="M15 15l6 6"/>',
    pause: '<rect x="6.5" y="5" width="3.6" height="14" rx="1" fill="currentColor"/><rect x="13.9" y="5" width="3.6" height="14" rx="1" fill="currentColor"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.6 9.6a2.6 2.6 0 1 1 3.6 2.4c-.8.4-1.2.9-1.2 1.9M12 17.3v.1"/>', settings: gear,
    shop: bag, archive: '<path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3z"/><path d="M5 17a3 3 0 0 1 3-3h11"/>',
    trophy: '<path d="M8 4h8v6a4 4 0 0 1-8 0zM8 6H4.5c0 3 1.5 4.5 3.5 4.5M16 6h3.5c0 3-1.5 4.5-3.5 4.5M12 14v4M8.5 21h7M9.5 18h5"/>',
    stats: '<path d="M5 20v-9M12 20V4M19 20v-6"/>', credits: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.1"/>',
    leave: '<path d="M12 3v8"/><path d="M6.3 6.8a8 8 0 1 0 11.4 0"/>', fullscreen: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
    sound: '<path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"/>', mute: '<path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4z"/><path d="M16 9.5l5 5M21 9.5l-5 5"/>',
    plus: '<path d="M12 5v14M5 12h14"/>', play: '<path d="M8 5l11 7-11 7z" fill="currentColor"/>', back: '<path d="M15 5l-7 7 7 7"/>', close: '<path d="M6 6l12 12M18 6L6 18"/>',
    reset: '<path d="M4 12a8 8 0 1 0 2.6-5.9"/><path d="M4 4v5h5"/>',
    general: '<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
    video: '<rect x="3" y="5" width="18" height="12" rx="2"/><path d="M8 21h8M12 17v4"/>',
    controls: '<path d="M7 8h10a4 4 0 0 1 4 4v1.5a3 3 0 0 1-5.4 1.8L15 14H9l-.6 1.3A3 3 0 0 1 3 13.5V12a4 4 0 0 1 4-4z"/><path d="M8 10.2v2.6M6.7 11.5h2.6"/>',
    weapon: '<path d="M2.5 10.5h12.5l1.6-1.8h4.9v3.6h-6.3L14 15.5h-3.2l-.7-2.2H2.5z"/><path d="M6 13.3v3.4"/>',
    interface: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M9 9v11"/>',
    access: '<circle cx="12" cy="5" r="2"/><path d="M5 9h14M12 9v5l-3 6M12 14l3 6"/>',
    candle: '<path d="M12 2c2.6 3 2.6 5 0 6.2-2.6-1.2-2.6-3.2 0-6.2z"/><rect x="9" y="10" width="6" height="11" rx="1.5"/>', bolt,
    eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>', bag,
    heart: '<path d="M12 20s-8-4.8-8-10.2A4.3 4.3 0 0 1 12 7a4.3 4.3 0 0 1 8 2.8C20 15.2 12 20 12 20z"/>', target,
    door: '<path d="M6 21V4h9l3 2v15M4 21h16"/><circle cx="13" cy="13" r=".9" fill="currentColor"/>',
    hand: '<path d="M8 12V6a1.5 1.5 0 0 1 3 0v5M11 11V4.5a1.5 1.5 0 0 1 3 0V11M14 11V6a1.5 1.5 0 0 1 3 0v8c0 4-2.5 7-6 7-3 0-4.5-2-6-5l-1.5-3a1.5 1.5 0 0 1 2.6-1.4L8 14"/>',
    thread: '<path d="M2 12h5l2-6 3 12 2.5-9 1.5 3H22"/>', grid: sq4, star, gear,
    cloud: '<path d="M7 18a4 4 0 0 1-.5-8A5.5 5.5 0 0 1 17 8.5a4.8 4.8 0 0 1 .5 9.5z"/>', shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
    fist: '<path d="M6 11V8a2 2 0 0 1 4 0 2 2 0 0 1 4 0 2 2 0 0 1 4 0v6a6 6 0 0 1-6 6h-1a5 5 0 0 1-5-5z"/>',
    chain: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
    users: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.6 2.7-6 6-6s6 2.4 6 6"/><circle cx="17" cy="9" r="2.4"/><path d="M16 14.2c3 0 5 2 5 5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', coin: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5v9M9.6 10.2h3.6a1.6 1.6 0 0 1 0 3.2h-2.6a1.6 1.6 0 0 0 0 3.2h3.8"/>',
    skull, crown: '<path d="M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5z"/>', lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>', check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>'
  };
  const Icons = {
    has: (n) => !!I[n],
    svg(n, cls) { return '<svg class="ic' + (cls ? ' ' + cls : '') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + (I[n] || '') + '</svg>'; },
    names: () => Object.keys(I)
  };
  G.Icons = Icons;
  if (typeof module !== 'undefined' && module.exports) module.exports = Icons;
})(typeof window !== 'undefined' ? window : globalThis);
