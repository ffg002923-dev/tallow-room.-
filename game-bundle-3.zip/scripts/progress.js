/* progress.js — lifetime statistics, achievements (84) and challenges (daily + special).
   Every achievement is a pure function of the saved statistics / collections (meta.stats, meta.used, meta.owned ...), so the progress bars always match
   what the game really recorded. Stats are fed from the same event stream that drives the narration (no second source of truth). */
(function (G) {
  'use strict';
  const D = G.GameData, Save = G.Save;
  const P = { flags: { ash3: false }, acc: 0, dirty: false, popQueue: [], fresh: new Set() };
  const meta = () => (G.Turns && G.Turns.meta) || null;
  const MAXC = 999999;
  const cnt = (o) => Object.keys(o || {}).length;

  P.def = (id) => D.achDefs.find((a) => a.id === id);
  P.value = function (def, m) {
    switch (def.stat) {
      case 'discovered': return cnt(m.discovered);
      case 'achCount': { let n = 0; for (const a of D.achDefs) if (a.id !== def.id && m.ach[a.id]) n++; return n; }
      case 'itemDistinct': return cnt(m.used);
      case 'itemsOwned': return cnt(m.owned && m.owned.items);
      case 'dealersOwned': return cnt(m.owned && m.owned.dealers);
      case 'dealersBeaten': return cnt(m.dealerWins);
      case 'weaponsOwned': return Math.max(0, cnt(m.owned && m.owned.weapons) - 1);
      case 'weaponsWon': return cnt(m.weaponWins);
      case 'emoteDistinct': return cnt(m.emoteUsed);
      default: return (m.stats && m.stats[def.stat]) || 0;
    }
  };
  P.progress = function (def, m) {
    m = m || meta(); const v = P.value(def, m), goal = def.goal, done = !!m.ach[def.id];
    return { v: Math.min(v, goal), raw: v, goal, pct: done ? 100 : Math.min(99, Math.floor(v / goal * 100)), done };
  };
  P.summary = function (m) {
    m = m || meta(); const by = { b: [0, 0], c: [0, 0], a: [0, 0], l: [0, 0] }; let done = 0;
    for (const a of D.achDefs) { by[a.tier][1]++; if (m.ach[a.id]) { by[a.tier][0]++; done++; } }
    return { done, total: D.achDefs.length, pct: Math.round(done / D.achDefs.length * 100), by };
  };
  P.accentUnlocked = function (id, m) { m = m || meta(); const a = D.accentUnlock[id]; return id === 'ember' || !a || !!(m && m.ach[a]); };

  P.unlock = function (id, m) {
    m = m || meta(); const def = P.def(id); if (!m || !def || m.ach[id]) return false;
    m.ach[id] = 1; m.coins = Math.min(MAXC, (m.coins || 0) + def.coins); m.stats.earned = Math.min(1e8, (m.stats.earned || 0) + def.coins);
    P.dirty = true; P.popQueue.push(id); P.fresh.add(id);
    if (P.onUnlock) { try { P.onUnlock(def); } catch (e) { /* UI problems must never break gameplay */ } }
    return true;
  };
  P.check = function (m) {
    m = m || meta(); if (!m) return [];
    const got = [];
    for (let pass = 0; pass < 8; pass++) {
      let any = false;
      for (const def of D.achDefs) if (!m.ach[def.id] && P.value(def, m) >= def.goal) { if (P.unlock(def.id, m)) { got.push(def.id); any = true; } }
      const before = m.stats.challenges; P.checkChallenges(m); if (m.stats.challenges !== before) any = true;
      if (!any) break;
    }
    if (got.length || P.dirty) { P.dirty = false; if (m === meta()) P.save(); }
    return got;
  };
  P.save = function () { const m = meta(); if (m) Save.saveMeta(m); };

  /* ---------------- challenges ---------------- */
  const today = () => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
  const hash = (s) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return h >>> 0; };
  P.statOf = function (m, key) { if (key.startsWith('cat:')) return (m.cats && m.cats[key.slice(4)]) || 0; return (m.stats && m.stats[key]) || 0; };
  /* picks 3 daily challenges deterministically from the date (same for everybody on the same day) */
  P.rollDaily = function (m, date) {
    date = date || today(); if (m.daily.date === date && m.daily.ids.length === 3) return m.daily;
    const pool = D.challengePool.slice(), ids = []; let h = hash('tallow-' + date);
    while (ids.length < 3 && pool.length) { const i = h % pool.length; ids.push(pool.splice(i, 1)[0].id); h = hash(String(h) + date); }
    m.daily = { date, ids, base: {}, done: {} };
    for (const id of ids) m.daily.base[id] = P.statOf(m, D.challengePool.find((c) => c.id === id).stat);
    return m.daily;
  };
  P.challengeInfo = function (m) {
    P.rollDaily(m); const out = [];
    for (const id of m.daily.ids) { const c = D.challengePool.find((x) => x.id === id), v = P.statOf(m, c.stat) - (m.daily.base[id] || 0); out.push({ id, kind: 'daily', goal: c.goal, v: Math.min(c.goal, Math.max(0, v)), coins: c.coins, done: !!m.daily.done[id] }); }
    for (const c of D.specialChallenges) { if (m.special.base[c.id] === undefined) m.special.base[c.id] = 0; const v = P.statOf(m, c.stat) - m.special.base[c.id]; out.push({ id: c.id, kind: 'special', goal: c.goal, v: Math.min(c.goal, Math.max(0, v)), coins: c.coins, done: !!m.special.done[c.id] }); }
    return out;
  };
  P.checkChallenges = function (m) {
    if (!m || !m.daily) return;
    for (const c of P.challengeInfo(m)) {
      if (c.done || c.v < c.goal) continue;
      (c.kind === 'daily' ? m.daily.done : m.special.done)[c.id] = 1;
      m.coins = Math.min(MAXC, m.coins + c.coins); m.stats.earned = Math.min(1e8, m.stats.earned + c.coins); m.stats.challenges++; P.dirty = true;
      if (P.onChallenge) { try { P.onChallenge(c); } catch (e) { /* ignore */ } }
    }
  };

  /* events -> statistics (the player's actions, plus what happens to the player) */
  P.track = function (evs, st, m) {
    m = m || meta(); if (!m || !evs) return;
    const s = m.stats;
    for (const e of evs) {
      if (e.t === 'shot') {
        const anyLive = (e.shells || [e.type]).includes('e');
        if (e.who === 'p') {
          s.shots++;
          if (e.target === 'self') { s.selfShots++; if (!anyLive) s.ashSelf++; else s.liveSelf++; }
          else { if (e.dmg > 0) { s.hits++; s.dmgDealt += e.dmg; if (e.charged) s.charged++; } else if (!anyLive) s.blankDealer++; }
        }
        if (e.victim === 'p' && e.dmg > 0) s.dmgTaken += e.dmg;
        if (e.victim === 'p' && e.saved) s.phoenixSaves++;
        if (e.victim === 'p' && e.reflected) s.reflects++;
      } else if (e.t === 'item' && e.who === 'p') {
        s.itemsUsed++; if (e.id === 'handcuffs') s.cuffs++;
        m.used[e.id] = (m.used[e.id] || 0) + 1;
        const cat = D.items[e.id] && D.items[e.id].cat; if (cat) m.cats[cat] = (m.cats[cat] || 0) + 1;
      }
    }
    if (st && st.stats) { s.bestStreak = Math.max(s.bestStreak || 0, st.stats.bestStreak || 0); s.liveStreak = Math.max(s.liveStreak || 0, st.stats.liveStreak || 0); if (st.p && st.d && st.p.hp === 1 && st.d.hp >= 3) st.stats.cb = 1; }
    P.dirty = true; P.check(m);
  };
  P.newGame = function () { P.flags.ash3 = false; };
  P.onRoundEnd = function (st, re, m) {
    m = m || meta(); const s = m.stats;
    if (re.winner === 'p') {
      if (re.hpLeft === 1) s.thread++;
      if (re.items === 0) s.bare++;
      if (st.stats.bestStreak >= 3 && !P.flags.ash3) { P.flags.ash3 = true; s.ash3++; }
      if (re.finisher) s.finishers++;
      if (re.passUsed > 0) s.passWins++;
      if (st.stats.cb) s.comebacks++;
    } else if (st.phase === 'lost') s.losses++;
    st.stats.cb = 0;
    P.check(m);
  };
  /* sec = seconds since the game started (for the speed achievement) */
  P.onWin = function (st, m, sec) {
    m = m || meta(); const s = m.stats;
    if (st.stats.dmgTaken === 0) s.perfect++;
    if (st.diff === 'nightmare') { s.nightmareWins++; if (st.stats.dmgTaken === 0) s.nmPerfect++; }
    if (st.diff === 'hard' || st.diff === 'nightmare') s.hardWins++;
    if (sec && sec < 300) s.speedWins++;
    const dl = (m.selected && m.selected.dealer) || 'ghost', wp = st.weapon || 'caster';
    m.dealerWins[dl] = (m.dealerWins[dl] || 0) + 1; m.weaponWins[wp] = (m.weaponWins[wp] || 0) + 1;
    m.matches.push({ t: Date.now(), mode: 'sp', win: true, diff: st.diff, dealer: dl, weapon: wp, sec: sec | 0 }); if (m.matches.length > 20) m.matches.shift();
    P.check(m);
  };
  P.onLoss = function (st, m, sec) {
    m = m || meta(); m.matches.push({ t: Date.now(), mode: 'sp', win: false, diff: st.diff, dealer: (m.selected && m.selected.dealer) || '', weapon: st.weapon || 'caster', sec: sec | 0 }); if (m.matches.length > 20) m.matches.shift(); P.dirty = true;
  };
  P.onMatch = function (info, m) { // multiplayer result: {players, win}
    m = m || meta(); const s = m.stats; s.mpGames++; if (info.win) s.mpWins++; if (info.players >= 4) s.mp4++;
    m.matches.push({ t: Date.now(), mode: 'mp', win: !!info.win, diff: '', dealer: '', weapon: '', sec: info.sec | 0 }); if (m.matches.length > 20) m.matches.shift();
    P.check(m);
  };
  P.emote = function (id, m) { m = m || meta(); if (!m || !D.emotes.includes(id)) return; m.stats.emotes++; m.emoteUsed[id] = (m.emoteUsed[id] || 0) + 1; P.dirty = true; P.check(m); };
  P.addWax = function (n, m) { m = m || meta(); m.coins = Math.min(MAXC, (m.coins || 0) + n); m.stats.earned = Math.min(1e8, (m.stats.earned || 0) + n); P.check(m); };
  P.bought = function (m) { m = m || meta(); m.stats.bought++; P.check(m); };
  P.tick = function (dt) {
    const m = meta(); if (!m) return;
    P.acc += dt; if (P.acc < 1) return;
    m.stats.playSec += Math.floor(P.acc); P.acc -= Math.floor(P.acc); P.dirty = true;
    P.check(m);
    P.sinceSave = (P.sinceSave || 0) + 1; if (P.sinceSave >= 20) { P.sinceSave = 0; P.save(); }
  };
  P.fmtTime = function (sec) { sec = Math.floor(sec || 0); const h = Math.floor(sec / 3600), mi = Math.floor(sec % 3600 / 60); return h ? h + 'h ' + mi + 'm' : mi + 'm ' + (sec % 60) + 's'; };

  G.Progress = P;
  if (typeof module !== 'undefined' && module.exports) module.exports = P;
})(typeof window !== 'undefined' ? window : globalThis);
