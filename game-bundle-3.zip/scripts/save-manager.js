/* save-manager.js — settings, meta-progress (achievements, endings, archive) and run snapshots.
   Uses localStorage with full error handling; falls back to in-memory if storage is blocked.
   Limitations: localStorage is per-origin/per-browser, can be cleared by the user or by private-mode
   browsing, and is not synced between devices. No personal data is stored. */
(function (G) {
  'use strict';
  const U = G.U, D = G.GameData;
  const KEY = { settings: 'tallow.settings.v2', settingsOld: 'tallow.settings.v1', meta: 'tallow.meta.v2', metaBak: 'tallow.meta.v2.bak', metaOld: 'tallow.meta.v1', run: 'tallow.run.v1' };
  const S = { mem: {}, corruptFlag: false };

  let ls = null;
  try { ls = G.localStorage; const k = '__tallow_probe'; ls.setItem(k, '1'); ls.removeItem(k); } catch (e) { ls = null; }
  S.available = !!ls;

  S.read = function (key) {
    let raw = null;
    try { raw = ls ? ls.getItem(key) : (S.mem[key] === undefined ? null : S.mem[key]); } catch (e) { raw = S.mem[key] === undefined ? null : S.mem[key]; }
    if (raw === null) return null;
    try { return JSON.parse(raw); } catch (e) { S.corruptFlag = true; S.remove(key); return null; }
  };
  S.write = function (key, obj) {
    let s;
    try { s = JSON.stringify(obj); } catch (e) { return false; }
    S.mem[key] = s;
    try { if (ls) ls.setItem(key, s); return !!ls; } catch (e) { return false; }
  };
  S.remove = function (key) { delete S.mem[key]; try { if (ls) ls.removeItem(key); } catch (e) { /* ignore */ } };

  /* ---------- settings ---------- */
  S.defaultSettings = function () {
    const nav = G.navigator || {};
    const weak = (nav.hardwareConcurrency && nav.hardwareConcurrency <= 4) || (nav.deviceMemory && nav.deviceMemory <= 2);
    let reduced = false;
    try { reduced = !!(G.matchMedia && G.matchMedia('(prefers-reduced-motion: reduce)').matches); } catch (e) { /* ignore */ }
    return {
      master: 0.8, music: 0.6, ambience: 0.7, sfx: 0.9, voice: 0.9,
      quality: weak ? 'low' : 'medium', sens: 1, res: 1, three: true, subLang: 'auto', fps: 60, shake: 1, effects: true, subtitles: true,
      textSize: 1, lang: (nav.language || 'en').toLowerCase().startsWith('ar') ? 'ar' : 'en',
      reduced, haptics: true, touch: 1.2,
      gunHold: 'locked', camSway: 0.3, crosshair: 'dot', xhairSize: 1, xhairAlpha: 0.85, gunX: 0, gunY: 0, gunScale: 1,
      uiScale: 1, hudAlpha: 1, hudLabels: true, hudSide: 'right', invertY: false, showFps: false, brightness: 1, vignette: true, contrast: false, accent: 'ember'
    };
  };
  const range = (v, a, b, d) => (typeof v === 'number' && isFinite(v) ? U.clamp(v, a, b) : d);
  S.sanitizeSettings = function (raw) {
    const d = S.defaultSettings();
    if (!raw || typeof raw !== 'object') return d;
    return {
      master: range(raw.master, 0, 1, d.master), music: range(raw.music, 0, 1, d.music), ambience: range(raw.ambience, 0, 1, d.ambience),
      sfx: range(raw.sfx, 0, 1, d.sfx), voice: range(raw.voice, 0, 1, d.voice),
      quality: ['low', 'medium', 'high'].includes(raw.quality) ? raw.quality : d.quality,
      fps: raw.fps === 30 ? 30 : 60, shake: range(raw.shake, 0, 1, d.shake),
      effects: typeof raw.effects === 'boolean' ? raw.effects : d.effects,
      subtitles: typeof raw.subtitles === 'boolean' ? raw.subtitles : d.subtitles,
      textSize: [0, 1, 2].includes(raw.textSize) ? raw.textSize : d.textSize,
      lang: raw.lang === 'ar' ? 'ar' : 'en',
      reduced: typeof raw.reduced === 'boolean' ? raw.reduced : d.reduced,
      haptics: typeof raw.haptics === 'boolean' ? raw.haptics : d.haptics,
      touch: range(raw.touch, 0.8, 1.8, d.touch), sens: range(raw.sens, 0.3, 2, d.sens), res: range(raw.res, 0.5, 1, d.res),
      three: typeof raw.three === 'boolean' ? raw.three : d.three, subLang: ['auto', 'en', 'ar'].includes(raw.subLang) ? raw.subLang : d.subLang,
      gunHold: ['locked', 'subtle', 'natural'].includes(raw.gunHold) ? raw.gunHold : d.gunHold, camSway: range(raw.camSway, 0, 1, d.camSway),
      crosshair: ['off', 'dot', 'cross', 'ring'].includes(raw.crosshair) ? raw.crosshair : d.crosshair, xhairSize: range(raw.xhairSize, 0.6, 1.8, d.xhairSize), xhairAlpha: range(raw.xhairAlpha, 0.3, 1, d.xhairAlpha),
      gunX: range(raw.gunX, -40, 40, 0), gunY: range(raw.gunY, -40, 40, 0), gunScale: range(raw.gunScale, 0.9, 1.15, 1),
      uiScale: range(raw.uiScale, 0.85, 1.2, 1), hudAlpha: range(raw.hudAlpha, 0.45, 1, 1), hudLabels: typeof raw.hudLabels === 'boolean' ? raw.hudLabels : d.hudLabels,
      hudSide: raw.hudSide === 'left' ? 'left' : 'right', invertY: typeof raw.invertY === 'boolean' ? raw.invertY : d.invertY, showFps: typeof raw.showFps === 'boolean' ? raw.showFps : d.showFps, brightness: range(raw.brightness, 0.7, 1.3, 1),
      vignette: typeof raw.vignette === 'boolean' ? raw.vignette : d.vignette, contrast: typeof raw.contrast === 'boolean' ? raw.contrast : d.contrast, accent: (D.accents || ['ember']).includes(raw.accent) ? raw.accent : 'ember'
    };
  };
  S.loadSettings = function () { return S.sanitizeSettings(S.read(KEY.settings) || S.read(KEY.settingsOld)); };
  S.saveSettings = function (s) { return S.write(KEY.settings, s); };

  /* ---------- meta progress ---------- */
  S.STAT_KEYS = ['games', 'wins', 'rounds', 'losses', 'shots', 'selfShots', 'ashSelf', 'hits', 'dmgDealt', 'dmgTaken', 'itemsUsed', 'bestStreak', 'playSec', 'earned', 'bought', 'perfect', 'nightmareWins', 'thread', 'bare', 'ash3', 'charged', 'cuffs',
    'blankDealer', 'liveSelf', 'finishers', 'liveStreak', 'mpGames', 'mpWins', 'mp4', 'challenges', 'emotes', 'phoenixSaves', 'reflects', 'passWins', 'nmPerfect', 'speedWins', 'comebacks', 'hardWins'];
  /* stats that are computed from collections (never stored directly) */
  S.DERIVED = ['itemDistinct', 'itemsOwned', 'dealersOwned', 'dealersBeaten', 'weaponsOwned', 'weaponsWon', 'emoteDistinct'];
  S.defaultStats = function () { const o = {}; for (const k of S.STAT_KEYS) o[k] = 0; return o; };
  S.defaultMeta = function () {
    return { ach: {}, endings: {}, discovered: {}, unlocked: { nightmare: false }, stats: S.defaultStats(), tutorial: false, lastDiff: 'normal', coins: 0, stock: {}, owned: { items: {}, weapons: {}, dealers: {} }, selected: { dealer: 'ghost', weapon: 'caster' }, used: {}, cats: {}, dealerWins: {}, weaponWins: {}, emoteUsed: {}, daily: { date: '', ids: [], base: {}, done: {} }, special: { base: {}, done: {} }, log: [], matches: [] };
  };
  S.sanitizeMeta = function (raw) {
    const d = S.defaultMeta();
    if (!raw || typeof raw !== 'object') return d;
    const pick = (o, keys) => { const r = {}; if (o && typeof o === 'object') for (const k of keys) if (o[k]) r[k] = 1; return r; };
    d.ach = pick(raw.ach, D.achievements);
    d.endings = pick(raw.endings, D.endings);
    d.discovered = pick(raw.discovered, D.itemOrder);
    d.unlocked.nightmare = !!(raw.unlocked && raw.unlocked.nightmare);
    if (raw.stats) for (const k of S.STAT_KEYS) d.stats[k] = range(raw.stats[k], 0, 1e8, 0);
    if (D.itemOrder) d.discovered = pick(raw.discovered, D.itemOrder);
    d.tutorial = !!raw.tutorial;
    d.coins = range(raw.coins, 0, 999999, 0) | 0; d.stock = {}; if (raw.stock && typeof raw.stock === 'object') for (const k of D.itemOrder) { const n = raw.stock[k] | 0; if (n > 0) d.stock[k] = Math.min(9, n); }
    d.lastDiff = D.difficulties[raw.lastDiff] ? raw.lastDiff : 'normal';
    const own = raw.owned && typeof raw.owned === 'object' ? raw.owned : {};
    for (const id of (D.itemOrder || [])) { if (D.items[id].free || (own.items && own.items[id])) d.owned.items[id] = 1; }
    for (const id of (D.weaponOrder || [])) { if (D.weapons[id].free || (own.weapons && own.weapons[id])) d.owned.weapons[id] = 1; }
    for (const id of (D.dealerOrder || [])) { if (D.dealers[id].free || (own.dealers && own.dealers[id])) d.owned.dealers[id] = 1; }
    const sel = raw.selected || {};
    d.selected.dealer = d.owned.dealers[sel.dealer] ? sel.dealer : 'ghost'; d.selected.weapon = d.owned.weapons[sel.weapon] ? sel.weapon : 'caster';
    const cnt = (src, keys, o) => { if (src && typeof src === 'object') for (const k of keys) { const n = src[k] | 0; if (n > 0) o[k] = Math.min(1e6, n); } };
    cnt(raw.used, D.itemOrder || [], d.used); cnt(raw.cats, D.itemCats || [], d.cats); cnt(raw.dealerWins, D.dealerOrder || [], d.dealerWins); cnt(raw.weaponWins, D.weaponOrder || [], d.weaponWins); cnt(raw.emoteUsed, D.emotes || [], d.emoteUsed);
    const dl = raw.daily && typeof raw.daily === 'object' ? raw.daily : {};
    d.daily.date = typeof dl.date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(dl.date) ? dl.date : '';
    const chIds = ((D.challengePool || []).map((c) => c.id)).concat((D.specialChallenges || []).map((c) => c.id));
    d.daily.ids = Array.isArray(dl.ids) ? dl.ids.filter((x) => chIds.includes(x)).slice(0, 3) : [];
    const numMap = (src, o) => { if (src && typeof src === 'object') for (const k of chIds) if (typeof src[k] === 'number' && isFinite(src[k])) o[k] = range(src[k], 0, 1e8, 0); };
    numMap(dl.base, d.daily.base); if (dl.done) for (const k of chIds) if (dl.done[k]) d.daily.done[k] = 1;
    const sp = raw.special && typeof raw.special === 'object' ? raw.special : {}; numMap(sp.base, d.special.base); if (sp.done) for (const k of chIds) if (sp.done[k]) d.special.done[k] = 1;
    if (Array.isArray(raw.log)) d.log = raw.log.filter((x) => x && typeof x.id === 'string' && typeof x.kind === 'string').slice(-30).map((x) => ({ kind: String(x.kind).slice(0, 12), id: String(x.id).slice(0, 32), price: range(x.price, 0, 99999, 0) | 0, t: range(x.t, 0, 4e12, 0) }));
    if (Array.isArray(raw.matches)) d.matches = raw.matches.slice(-20).filter((x) => x && typeof x === 'object').map((x) => ({ t: range(x.t, 0, 4e12, 0), mode: x.mode === 'mp' ? 'mp' : 'sp', win: !!x.win, diff: String(x.diff || '').slice(0, 12), dealer: String(x.dealer || '').slice(0, 24), weapon: String(x.weapon || '').slice(0, 24), sec: range(x.sec, 0, 1e6, 0) | 0 }));
    return d;
  };
  /* integrity: the payload is stored as {v, sum, data}; sum is an FNV-1a hash of the JSON text. A mismatching or unreadable payload falls back to the
     previous good copy (.bak), then to the v1 save, then to defaults — the player is told when data had to be reset. (This detects corruption, it is not anti-cheat.) */
  const fnv = (str) => { let h = 0x811c9dc5; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h.toString(16); };
  S.pack = function (obj) { const data = JSON.stringify(obj); return JSON.stringify({ v: 2, sum: fnv('tallow|' + data), data }); };
  S.unpack = function (text) {
    try { const o = JSON.parse(text); if (!o || o.v !== 2 || typeof o.data !== 'string' || o.sum !== fnv('tallow|' + o.data)) return null; return JSON.parse(o.data); } catch (e) { return null; }
  };
  const rawGet = (k) => { try { return ls ? ls.getItem(k) : (S.mem[k] === undefined ? null : S.mem[k]); } catch (e) { return S.mem[k] === undefined ? null : S.mem[k]; } };
  const rawSet = (k, v) => { S.mem[k] = v; try { if (ls) { ls.setItem(k, v); return true; } } catch (e) { /* quota or blocked */ } return false; };
  S.loadMeta = function () {
    const main = rawGet(KEY.meta);
    if (main !== null) {
      const o = S.unpack(main); if (o) return S.sanitizeMeta(o);
      S.corruptFlag = true; const bak = rawGet(KEY.metaBak); const ob = bak ? S.unpack(bak) : null; if (ob) return S.sanitizeMeta(ob);
      return S.defaultMeta();
    }
    const old = S.read(KEY.metaOld); return old ? S.sanitizeMeta(old) : S.defaultMeta();
  };
  S.saveMeta = function (m) {
    const prev = rawGet(KEY.meta); if (prev !== null && S.unpack(prev)) rawSet(KEY.metaBak, prev);
    let text; try { text = S.pack(m); } catch (e) { return false; }
    return rawSet(KEY.meta, text);
  };

  /* ---------- run snapshot (resume) ---------- */
  let pending = null, timer = null;
  S.queueRun = function (state) {
    try { pending = JSON.stringify({ v: 1, t: Date.now(), state }); } catch (e) { return; }
    if (timer) return;
    // Deferred so saving never lands inside an animation frame.
    timer = setTimeout(() => { timer = null; S.flushRun(); }, 60);
  };
  S.flushRun = function () {
    if (pending === null) return true;
    const s = pending; pending = null; S.mem[KEY.run] = s;
    try { if (ls) ls.setItem(KEY.run, s); return true; } catch (e) { return false; }
  };
  S.loadRun = function () {
    const raw = S.read(KEY.run);
    if (!raw) return null;
    if (raw.state && G.Engine.validate(raw.state)) G.Engine.normalize(raw.state);
    if (!raw.state || !G.Engine.validate(raw.state) || raw.state.phase === 'lost' || raw.state.phase === 'won') {
      S.corruptFlag = S.corruptFlag || !G.Engine.validate(raw.state);
      S.remove(KEY.run); return null;
    }
    return raw.state;
  };
  S.hasRun = function () { return !!S.loadRun(); };
  S.KEY = KEY;
  S.clearRun = function () { pending = null; S.remove(KEY.run); };

  G.Save = S;
  if (typeof module !== 'undefined' && module.exports) module.exports = S;
})(typeof window !== 'undefined' ? window : globalThis);
