/* mp-engine.js — authoritative N-player (2-4) free-for-all engine used by the multiplayer SERVER (also loadable in the browser for prediction/tests).
   Same shell vocabulary as the single-player engine (LIVE SHELL = 'e', BLANK SHELL = 'a'). Free-for-all: on your turn shoot yourself or any other living seat.
   Multiplayer item set (18 items) — the full 50-item set is single-player only (documented limitation). Deterministic from the seed. */
(function (G) {
  'use strict';
  const U = G.U, D = G.GameData, R = U.Rand;
  const M = {};
  M.ITEMS = ['magnifier', 'stethoscope', 'handcuffs', 'cigarette', 'battery', 'medicine', 'can', 'lighter', 'scrambler', 'knife', 'wax_shield', 'bandage', 'pass_token', 'heavy_slug', 'spare_round', 'hot_round', 'salt', 'periscope'];
  const NEEDS_TARGET = { handcuffs: 1, lighter: 1, knife: 1 };
  const SLOTS = 6, ROUNDS_TO_WIN = 2;

  const player = (max, weapon) => ({ hp: max, max, alive: true, items: new Array(SLOTS).fill(null), cuffed: false, charged: false, fx: {}, weapon: weapon || 'caster' });
  const alive = (st) => st.seats.filter((s) => st[s].alive);

  M.newMatch = function (seats, opts) {
    opts = opts || {}; if (!Array.isArray(seats) || seats.length < 2 || seats.length > 4) throw new Error('2-4 seats');
    const st = { v: 1, r: (opts.seed === undefined ? Date.now() & 0x7fffffff : opts.seed) | 0, seats: seats.slice(), order: seats.slice(), phase: 'between', turn: seats[0], round: 0, roundWins: {}, winner: null, chamber: [], pub: { e: 0, a: 0 }, know: {}, lastShell: null };
    for (const s of seats) { st[s] = player(3, opts.weapons && opts.weapons[s]); st.roundWins[s] = 0; st.know[s] = []; }
    return st;
  };

  M.startRound = function (st) {
    st.round++; st.phase = 'play';
    const max = st.round === 1 ? 3 : st.round === 2 ? 4 : 5;
    for (const s of st.seats) { st[s] = player(max, st[s].weapon); }
    st.order = st.seats.slice(); st.turn = st.seats[(st.round - 1) % st.seats.length];
    const ev = [{ t: 'roundStart', round: st.round, max }]; reload(st, ev); return ev;
  };

  function reload(st, ev) {
    const n = R.int(st, 5 + Math.min(3, st.seats.length - 1), 8 + st.seats.length), e = Math.max(1, Math.min(n - 1, Math.round(n * (0.4 + R.next(st) * 0.2))));
    const ch = []; for (let i = 0; i < e; i++) ch.push('e'); for (let i = 0; i < n - e; i++) ch.push('a'); R.shuffle(st, ch);
    st.chamber = ch; st.pub = { e, a: n - e }; st.lastShell = null; for (const s of st.seats) st.know[s] = [];
    const added = [];
    for (const s of alive(st)) for (let k = 0; k < 2; k++) {
      const slot = st[s].items.findIndex((x) => !x); if (slot < 0) break;
      const id = M.ITEMS[R.int(st, 0, M.ITEMS.length - 1)]; st[s].items[slot] = { id }; added.push({ who: s, slot, id });
    }
    ev.push({ t: 'reload', e, a: n - e, total: n, added });
  }

  const nextAlive = (st, from) => { const i = st.seats.indexOf(from); for (let k = 1; k <= st.seats.length; k++) { const s = st.seats[(i + k) % st.seats.length]; if (st[s].alive) return s; } return from; };
  function advance(st, who, ev) {
    let next = nextAlive(st, who);
    while (st[next].cuffed && next !== who) { st[next].cuffed = false; ev.push({ t: 'skip', who: next }); next = nextAlive(st, next); }
    st.turn = next;
    const n = st[next]; if (n.fx.regen > 0) { n.fx.regen--; if (n.hp < n.max) { n.hp++; ev.push({ t: 'regen', who: next, hp: n.hp }); } }
    ev.push({ t: 'turn', who: st.turn });
  }
  function checkRoundEnd(st, ev) {
    const left = alive(st); if (left.length > 1) return false;
    const winner = left[0] || null; if (winner) st.roundWins[winner]++;
    const champ = winner && st.roundWins[winner] >= ROUNDS_TO_WIN;
    st.phase = champ || st.round >= 3 ? 'over' : 'between';
    if (st.phase === 'over') { let best = null; for (const s of st.seats) if (best === null || st.roundWins[s] > st.roundWins[best]) best = s; st.winner = champ ? winner : best; }
    ev.push({ t: 'roundEnd', winner, roundWins: Object.assign({}, st.roundWins), phase: st.phase });
    if (st.phase === 'over') ev.push({ t: 'matchEnd', winner: st.winner, roundWins: Object.assign({}, st.roundWins) });
    return true;
  }
  const kill = (st, s, ev, by) => { st[s].alive = false; st[s].hp = 0; ev.push({ t: 'death', who: s, by: by || null }); };

  M.apply = function (st, seat, action) {
    const ev = [];
    if (st.phase !== 'play') return { ok: false, reason: 'phase', ev };
    if (st.turn !== seat || !st[seat] || !st[seat].alive) return { ok: false, reason: 'notTurn', ev };
    if (!action || typeof action !== 'object') return { ok: false, reason: 'badAction', ev };
    const me = st[seat];
    st.slap = null; // an unclaimed slap chance never survives the next action
    if (action.type === 'shoot') {
      const t = action.target; if (!st.seats.includes(t) || !st[t].alive) return { ok: false, reason: 'badTarget', ev };
      if (!st.chamber.length) return { ok: false, reason: 'empty', ev };
      const shell = st.chamber.shift(); st.pub[shell]--; st.lastShell = shell;
      for (const s of st.seats) st.know[s] = st.know[s].map((x) => ({ i: x.i - 1, type: x.type })).filter((x) => x.i >= 0);
      let dmg = 0, blocked = false;
      if (shell === 'e') {
        dmg = 1 + (me.charged ? 1 : 0) + (me.fx.slug ? 1 : 0);
        if (st[t].fx.shield > 0) { st[t].fx.shield--; blocked = true; dmg = 0; } else st[t].hp = Math.max(0, st[t].hp - dmg);
      }
      me.charged = false; me.fx.slug = 0;
      ev.push({ t: 'shot', who: seat, target: t, self: t === seat, type: shell, dmg, blocked, hp: st[t].hp, empty: st.chamber.length === 0 });
      if (st[t].hp <= 0 && st[t].alive) kill(st, t, ev, seat);
      else if (t === seat && shell === 'e' && dmg > 0) st.slap = { victim: seat, used: false, at: 0 }; // a LIVE self-shot that was survived (never a blank, never a blocked shot)
      if (checkRoundEnd(st, ev)) return { ok: true, ev };
      if (t === seat && shell === 'a') ev.push({ t: 'turn', who: seat, again: true });
      else advance(st, seat, ev);
      if (!st.chamber.length) reload(st, ev);
      return { ok: true, ev };
    }
    if (action.type === 'item') {
      const it = me.items[action.idx | 0]; if (!it) return { ok: false, reason: 'slotEmpty', ev };
      const id = it.id, e = { t: 'item', who: seat, idx: action.idx | 0, id, fx: null }; let tgt = action.target;
      if (NEEDS_TARGET[id]) { if (!st.seats.includes(tgt) || tgt === seat || !st[tgt].alive) return { ok: false, reason: 'badTarget', ev }; }
      const n = st.chamber.length;
      switch (id) {
        case 'magnifier': st.know[seat] = st.know[seat].filter((x) => x.i !== 0).concat([{ i: 0, type: st.chamber[0] }]); e.fx = { k: 'peek', type: st.chamber[0] }; break;
        case 'stethoscope': if (n < 2) return { ok: false, reason: 'noEffect', ev }; st.know[seat].push({ i: 1, type: st.chamber[1] }); e.fx = { k: 'stethoscope', slot: 1, type: st.chamber[1] }; break;
        case 'periscope': if (n < 2) return { ok: false, reason: 'noEffect', ev }; st.know[seat].push({ i: n - 1, type: st.chamber[n - 1] }); e.fx = { k: 'periscope', slot: n - 1, type: st.chamber[n - 1] }; break;
        case 'handcuffs': if (st[tgt].cuffed) return { ok: false, reason: 'cuffed', ev }; st[tgt].cuffed = true; e.fx = { k: 'cuff', target: tgt }; break;
        case 'cigarette': if (me.hp >= me.max) return { ok: false, reason: 'pulseFull', ev }; me.hp++; e.fx = { k: 'heal', hp: me.hp }; break;
        case 'bandage': if (me.hp >= me.max) return { ok: false, reason: 'pulseFull', ev }; me.hp++; me.fx.regen = 1; e.fx = { k: 'bandage', hp: me.hp }; break;
        case 'battery': if (me.charged) return { ok: false, reason: 'charged', ev }; me.charged = true; e.fx = { k: 'charge' }; break;
        case 'heavy_slug': if (me.fx.slug) return { ok: false, reason: 'noEffect', ev }; me.fx.slug = 1; e.fx = { k: 'heavy_slug' }; break;
        case 'wax_shield': if (me.fx.shield) return { ok: false, reason: 'noEffect', ev }; me.fx.shield = 1; e.fx = { k: 'wax_shield' }; break;
        case 'salt': me.cuffed = false; me.fx = Object.assign({}, { shield: me.fx.shield, slug: me.fx.slug }); e.fx = { k: 'salt' }; break;
        case 'medicine': { const good = R.next(st) < 0.5; if (good) me.hp = Math.min(me.max, me.hp + 2); else if (me.hp > 1) me.hp--; e.fx = { k: 'pills', good, hp: me.hp }; break; }
        case 'can': { if (n < 1) return { ok: false, reason: 'noEffect', ev }; const t = st.chamber.shift(); st.pub[t]--; st.lastShell = t; for (const s of st.seats) st.know[s] = st.know[s].map((x) => ({ i: x.i - 1, type: x.type })).filter((x) => x.i >= 0); e.fx = { k: 'eject', type: t }; break; }
        case 'lighter': { const tg = []; st[tgt].items.forEach((x, i) => { if (x) tg.push(i); }); if (!tg.length) return { ok: false, reason: 'noTargets', ev }; const ti = R.pick(st, tg); e.fx = { k: 'burn', slot: ti, id: st[tgt].items[ti].id, target: tgt }; st[tgt].items[ti] = null; break; }
        case 'scrambler': R.shuffle(st, st.chamber); for (const s of st.seats) st.know[s] = []; e.fx = { k: 'scramble' }; break;
        case 'knife': if (st[tgt].hp <= 1) return { ok: false, reason: 'noKnife', ev }; st[tgt].hp--; e.fx = { k: 'stab', target: tgt, hp: st[tgt].hp }; break;
        case 'spare_round': if (n >= 14) return { ok: false, reason: 'noEffect', ev }; st.chamber.splice(R.int(st, 0, n), 0, 'a'); st.pub.a++; for (const s of st.seats) st.know[s] = []; e.fx = { k: 'spare_round' }; break;
        case 'hot_round': if (n >= 14) return { ok: false, reason: 'noEffect', ev }; st.chamber.splice(R.int(st, 0, n), 0, 'e'); st.pub.e++; for (const s of st.seats) st.know[s] = []; e.fx = { k: 'hot_round' }; break;
        case 'pass_token': e.fx = { k: 'pass_token' }; break;
        default: return { ok: false, reason: 'noEffect', ev };
      }
      me.items[action.idx | 0] = null; ev.push(e);
      if (id === 'can' && !st.chamber.length) reload(st, ev);
      if (id === 'pass_token') advance(st, seat, ev);
      return { ok: true, ev };
    }
    return { ok: false, reason: 'badAction', ev };
  };

  /* SLAP (server-validated): only another living seat, only once, only right after a survived live self-shot, only inside the time window. */
  M.SLAP_MS = 6000;
  M.openSlap = function (st, nowMs) { if (st.slap && !st.slap.at) st.slap.at = nowMs; };
  M.slap = function (st, seat, nowMs) {
    const ev = [], sl = st.slap;
    if (st.phase !== 'play') return { ok: false, reason: 'phase', ev };
    if (!sl || sl.used) return { ok: false, reason: 'noSlap', ev };
    if (!st[seat] || !st[seat].alive || seat === sl.victim) return { ok: false, reason: 'notAllowed', ev };
    if (!st[sl.victim] || !st[sl.victim].alive) return { ok: false, reason: 'noSlap', ev };
    if (sl.at && nowMs - sl.at > M.SLAP_MS) { st.slap = null; return { ok: false, reason: 'tooLate', ev }; }
    sl.used = true; ev.push({ t: 'slap', from: seat, to: sl.victim });
    return { ok: true, ev };
  };

  M.forfeit = function (st, seat) {
    const ev = []; if (!st[seat] || !st[seat].alive || st.phase === 'over') return ev;
    const wasTurn = st.turn === seat; kill(st, seat, ev, null); ev.push({ t: 'forfeit', who: seat });
    if (st.phase === 'play') { if (checkRoundEnd(st, ev)) return ev; if (wasTurn) advance(st, seat, ev); }
    return ev;
  };

  /* secrets: other seats must not learn a private reveal */
  M.maskEvent = function (ev, seat) {
    if (ev.t === 'item' && ev.fx && ev.who !== seat && ['peek', 'stethoscope', 'periscope'].includes(ev.fx.k)) { const c = JSON.parse(JSON.stringify(ev)); delete c.fx.type; return c; }
    return ev;
  };
  M.viewFor = function (st, seat) {
    const players = {};
    for (const s of st.seats) { const p = st[s]; players[s] = { hp: p.hp, max: p.max, alive: p.alive, cuffed: p.cuffed, charged: p.charged, shield: !!p.fx.shield, items: p.items.map((x) => (x ? x.id : null)), weapon: p.weapon }; }
    return { seats: st.seats, you: seat, turn: st.turn, phase: st.phase, round: st.round, roundWins: Object.assign({}, st.roundWins), winner: st.winner, pub: Object.assign({}, st.pub), chamberLen: st.chamber.length, know: (st.know[seat] || []).slice(), players };
  };
  M.autoAction = function (st, seat) {
    const me = st[seat]; const foes = alive(st).filter((s) => s !== seat);
    const k = (st.know[seat] || []).find((x) => x.i === 0);
    if (k && k.type === 'a') return { type: 'shoot', target: seat };
    const target = foes.length ? foes.reduce((a, b) => (st[b].hp < st[a].hp ? b : a)) : seat;
    return { type: 'shoot', target: me.hp <= 1 && !(k && k.type === 'e') && st.pub.a > st.pub.e ? seat : target };
  };
  G.MPEngine = M;
  if (typeof module !== 'undefined' && module.exports) module.exports = M;
})(typeof window !== 'undefined' ? window : globalThis);
