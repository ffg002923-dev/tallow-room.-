/* dealer-looks.js — the game has ONE dealer now: the Ghost (supplied ghost model with its own skeleton), so there are no per-dealer tints or gear.
   This module still holds the WEAPON looks (procedural gear on the gun, one per weapon) and the id/override hooks that Stage3D, Slap and the UI read.
   weapon parts are in gun-local units (barrel along +x from -1.9 to 1.9, top of the receiver at y~0.08, z = side). colour '*hex' = glowing.
   mesh: sph (radii) | box (full size) | cyl / cone (radius, height, radius; base at the offset) | tor (ring in XZ; rx=1.57 stands it up) */
(function (G) {
  'use strict';
  const H = Math.PI / 2;
  const L = { looks: { ghost: { tint: [1, 1, 1], head: [], body: [] } }, override: null };

  /* weapon looks: parts in gun-local units (barrel along +x from -1.9 to 1.9, top of the receiver at y~0.08, z = side) */
  const X = -H;                                   // rz that lays a cylinder along +x
  L.weapons = {
    caster: [],
    pump: [['cyl', '#7a1a1a', [-0.2, -0.02, 0.1], [0.045, 0.9, 0.045], [0, 0, X]], ['cyl', '#b08a3a', [-0.2, -0.02, 0.1], [0.05, 0.05, 0.05], [0, 0, X]], ['cyl', '#7a1a1a', [-0.2, -0.02, 0.17], [0.045, 0.9, 0.045], [0, 0, X]], ['cyl', '#7a1a1a', [-0.2, -0.02, 0.24], [0.045, 0.9, 0.045], [0, 0, X]]],
    widow: [['cyl', '#15101a', [1.9, 0.03, 0], [0.085, 0.75, 0.085], [0, 0, X]], ['cyl', '#a3141b', [2.3, 0.03, 0], [0.095, 0.08, 0.095], [0, 0, X]], ['cyl', '#a3141b', [1.95, 0.03, 0], [0.095, 0.06, 0.095], [0, 0, X]]],
    penny: [['cyl', '#2a2420', [-0.3, 0.2, 0], [0.07, 1.1, 0.07], [0, 0, X]], ['cyl', '*6ad0ff', [0.8, 0.2, 0], [0.06, 0.03, 0.06], [0, 0, X]], ['box', '#4a3a2a', [-0.1, 0.12, 0], [0.12, 0.1, 0.1], [0, 0, 0]], ['box', '#4a3a2a', [0.5, 0.12, 0], [0.12, 0.1, 0.1], [0, 0, 0]]],
    mortician: [['sph', '#e8e2d2', [-1.95, -0.1, 0], [0.16, 0.18, 0.15], [0, 0, 0]], ['sph', '#0a0a0a', [-1.95, -0.08, 0.1], [0.04, 0.05, 0.03], [0, 0, 0]], ['sph', '#0a0a0a', [-1.9, -0.08, -0.1], [0.04, 0.05, 0.03], [0, 0, 0]], ['box', '#101010', [0.1, 0.09, 0], [1.6, 0.03, 0.04], [0, 0, 0]]],
    flare: [['cone', '#c66a1a', [2.1, 0.03, 0], [0.2, 0.3, 0.2], [0, 0, X]], ['cyl', '*ff7a2a', [1.92, 0.03, 0], [0.09, 0.05, 0.09], [0, 0, X]], ['sph', '*ff9a3a', [2.1, 0.03, 0], [0.12, 0.12, 0.12], [0, 0, 0]]],
    breaker: [['cone', '#9aa0a8', [1.9, -0.1, 0], [0.07, 0.8, 0.07], [0, 0, X]], ['box', '#3a3a40', [1.1, -0.1, 0], [0.22, 0.1, 0.12], [0, 0, 0]]],
    candle: [['cyl', '#efe2bd', [0.2, 0.08, 0], [0.07, 0.4, 0.07], [0, 0, 0]], ['sph', '*ffb03a', [0.2, 0.52, 0], [0.05, 0.1, 0.05], [0, 0, 0]], ['cyl', '#b08a3a', [0.2, 0.07, 0], [0.11, 0.04, 0.11], [0, 0, 0]]],
    leech: [['cyl', '*40d060', [-0.4, 0.0, 0.1], [0.05, 1.5, 0.05], [0, 0, X]], ['sph', '#2a5a30', [-0.5, 0.0, 0.12], [0.12, 0.12, 0.1], [0, 0, 0]], ['sph', '#2a5a30', [0.9, 0.0, 0.12], [0.12, 0.12, 0.1], [0, 0, 0]]],
    fang: [['cone', '#f0ead8', [1.85, 0.12, 0.1], [0.06, 0.45, 0.06], [0, 0, X]], ['cone', '#f0ead8', [1.85, 0.12, -0.1], [0.06, 0.45, 0.06], [0, 0, X]], ['tor', '*4a90ff', [0.6, 0.03, 0], [0.12, 0.12, 0.12], [0, 0, H]], ['tor', '*4a90ff', [1.0, 0.03, 0], [0.12, 0.12, 0.12], [0, 0, H]]],
    vesper: [['tor', '#d4a82a', [0.2, 0.03, 0], [0.12, 0.12, 0.12], [0, 0, H]], ['tor', '#d4a82a', [0.9, 0.03, 0], [0.12, 0.12, 0.12], [0, 0, H]], ['tor', '#d4a82a', [1.6, 0.03, 0], [0.12, 0.12, 0.12], [0, 0, H]], ['sph', '#d4a82a', [-1.95, -0.05, 0], [0.12, 0.12, 0.12], [0, 0, 0]]],
  };
  L.weaponId = () => L.weaponOverride || ((G.Turns && G.Turns.st && G.Turns.st.weapon) || (G.Turns && G.Turns.meta && G.Turns.meta.selected && G.Turns.meta.selected.weapon) || 'caster');
  L.id = () => 'ghost';
  G.DealerLooks = L;
  if (typeof module !== 'undefined' && module.exports) module.exports = L;
})(typeof window !== 'undefined' ? window : globalThis);
