/* net-client.js — multiplayer client for The Tallow Room. UMD: window.NetClient (browser) / module.exports (Node 22+).
 * No DOM access, no secrets. The reconnect token lives only in memory and (optionally) sessionStorage.
 *
 *   const net = new NetClient();                       // url defaults to ws(s)://<page host>/ws
 *   net.on('lobby', l => ...); net.on('matchEvents', ({ver, events}) => ...); net.on('state', ({ver, state}) => ...);
 *   await net.connect(); const me = await net.createRoom('Ann', {weaponMode:'own'});   // or joinRoom('K7M2Q','Bob')
 *   await net.setReady(true); await net.startMatch(); await net.act({type:'shoot', target:'s1'});
 *
 * Events: status('connecting'|'online'|'reconnecting'|'offline') · lobby · match · matchEvents · state · results ·
 *         emote · error · closed.  matchEvents arrive strictly ordered, de-duplicated by `ver`; a gap triggers `sync`. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(root);
  else root.NetClient = factory(root);
})(typeof window !== 'undefined' ? window : globalThis, function (root) {
  'use strict';
  var SESSION_KEY = 'tallow.session.v1';
  var noop = function () {};
  function median(a) { if (!a.length) return 0; var s = a.slice().sort(function (x, y) { return x - y; }); return s[s.length >> 1]; }

  /** 'host', 'https://host', 'ws://host:8080/' → 'wss://host/ws' etc. */
  function normalizeUrl(u, loc) {
    u = String(u || '').trim();
    if (!u) {
      loc = loc || root.location;
      if (!loc || !loc.host) throw new Error('NetClient: no url and no location');
      return (loc.protocol === 'https:' ? 'wss://' : 'ws://') + loc.host + '/ws';
    }
    if (/^https?:\/\//i.test(u)) u = u.replace(/^http/i, 'ws');
    else if (!/^wss?:\/\//i.test(u)) u = (/^(localhost|127\.|192\.168\.|10\.)/.test(u) ? 'ws://' : 'wss://') + u;
    var m = /^(wss?:\/\/[^\/?#]+)(\/[^?#]*)?/i.exec(u);
    if (!m) throw new Error('NetClient: bad url');
    return m[1] + (m[2] && m[2] !== '/' ? m[2] : '/ws');
  }

  function NetClient(opts) {
    opts = opts || {};
    this.opts = {
      url: opts.url || null, WebSocket: opts.WebSocket || null, storage: opts.storage,
      reconnect: opts.reconnect !== false, backoffMin: opts.backoffMin || 500, backoffMax: opts.backoffMax || 8000,
      pingMs: opts.pingMs || 5000, actTimeoutMs: opts.actTimeoutMs || 10000, reqTimeoutMs: opts.reqTimeoutMs || 10000,
    };
    this.status = 'offline';
    this.handlers = {};
    this.ws = null; this.url = null; this.wantOnline = false; this.attempt = 0; this.timer = null; this.pingTimer = null;
    this.pending = {}; this.rid = 0; this.seq = 0; this.acts = {};
    this.session = null; this.room = null; this.you = null; this.lobbyState = null;
    this.lastVer = -1; this.held = {}; this.syncing = false;
    this.rttSamples = []; this.offSamples = []; this.rtt = null; this.clockOffset = 0;
    this._firstResolve = null; this._firstReject = null;
    this._loadSession();
  }
  NetClient.normalizeUrl = normalizeUrl;
  var P = NetClient.prototype;

  // ---------- events ----------
  P.on = function (ev, fn) { (this.handlers[ev] = this.handlers[ev] || []).push(fn); var s = this; return function () { s.off(ev, fn); }; };
  P.off = function (ev, fn) { var a = this.handlers[ev]; if (a) this.handlers[ev] = a.filter(function (f) { return f !== fn; }); };
  P._emit = function (ev, data) {
    var a = this.handlers[ev]; if (!a) return;
    a.slice().forEach(function (f) { try { f(data); } catch (e) { if (typeof console !== 'undefined') console.error('NetClient handler', ev, e); } });
  };
  P._setStatus = function (s) { if (this.status !== s) { this.status = s; this._emit('status', s); } };

  // ---------- session persistence (never throws) ----------
  P._storage = function () { try { return this.opts.storage !== undefined ? this.opts.storage : (root.sessionStorage || null); } catch (e) { return null; } };
  P._loadSession = function () {
    try { var st = this._storage(), raw = st && st.getItem(SESSION_KEY); if (raw) { var s = JSON.parse(raw); if (s && s.room && s.token) this.session = s; } } catch (e) { /* ignore */ }
  };
  P._saveSession = function () {
    try { var st = this._storage(); if (st) { if (this.session) st.setItem(SESSION_KEY, JSON.stringify(this.session)); else st.removeItem(SESSION_KEY); } } catch (e) { /* ignore */ }
  };
  P.clearSession = function () { this.session = null; this.room = null; this.you = null; this._saveSession(); };

  // ---------- connection ----------
  /** resolves when the socket is open (and resumed, if a stored session exists). Rejects if the first attempt fails and there is nothing to resume. */
  P.connect = function (url) {
    var self = this;
    if (this.ws && (this.status === 'online' || this.status === 'connecting')) return Promise.resolve(this);
    this.url = normalizeUrl(url || this.opts.url);
    this.wantOnline = true; this.attempt = 0;
    var p = new Promise(function (res, rej) { self._firstResolve = res; self._firstReject = rej; });
    p.catch(noop);
    this._open();
    return p;
  };
  P._open = function () {
    var self = this, WS = this.opts.WebSocket || root.WebSocket;
    if (!WS) { this._firstFail(new Error('no WebSocket available')); return; }
    this._setStatus(this.attempt === 0 && !this.session ? 'connecting' : (this.attempt === 0 ? 'connecting' : 'reconnecting'));
    var ws;
    try { ws = new WS(this.url); } catch (e) { this._firstFail(e); return; }
    this.ws = ws; var opened = false;
    ws.onopen = function () {
      if (self.ws !== ws) return;
      opened = true; self.attempt = 0; self._setStatus('online');
      self._startPing();
      if (self.session) self._resume(); else self._firstOk();
    };
    ws.onmessage = function (e) { if (self.ws === ws) self._onMessage(e.data); };
    var closed = false;
    ws.onerror = function () { if (!opened) setTimeout(function () { ws.onclose && ws.onclose({ code: 1006 }); }, 0); }; // some runtimes never fire close after a failed connect
    ws.onclose = function (e) {
      if (self.ws !== ws || closed) return; closed = true;
      self.ws = null; self._stopPing(); self._failPending('disconnected');
      if (e && e.code === 4000) { self.wantOnline = false; self._setStatus('offline'); self._emit('closed', { reason: 'replaced' }); return; }
      if (!self.wantOnline) { self._setStatus('offline'); return; }
      if (!opened && !self.session) { self.wantOnline = false; self._setStatus('offline'); self._firstFail(new Error('connect_failed')); self._emit('closed', { reason: 'connect_failed' }); return; }
      if (!self.opts.reconnect) { self._setStatus('offline'); self._emit('closed', { reason: 'lost' }); return; }
      self._schedule();
    };
  };
  P._schedule = function () {
    var self = this;
    this._setStatus('reconnecting');
    var d = Math.min(this.opts.backoffMax, this.opts.backoffMin * Math.pow(2, this.attempt++));
    d = Math.round(d * (0.75 + Math.random() * 0.5)); // jitter ±25%
    clearTimeout(this.timer);
    this.timer = setTimeout(function () { self.timer = null; if (self.wantOnline) self._open(); }, d);
    this._emit('reconnecting', { attempt: this.attempt, delay: d });
  };
  P._firstOk = function () { var r = this._firstResolve; this._firstResolve = this._firstReject = null; if (r) r(this); };
  P._firstFail = function (e) { var r = this._firstReject; this._firstResolve = this._firstReject = null; this._setStatus('offline'); if (r) r(e); };
  P._resume = function () {
    var self = this, s = this.session;
    this._request({ t: 'resume', room: s.room, token: s.token }).then(function (m) {
      self.room = m.room; self.you = m.you; self._firstOk();
    }, function (err) { // token expired / room gone
      self.clearSession(); self.lastVer = -1; self.held = {};
      self._emit('closed', { reason: 'session_lost', code: err && err.code });
      self._firstOk();
    });
  };
  /** leave the room (if any) but keep the connection */
  P.leave = function () {
    var self = this;
    var done = function () { self.clearSession(); self.lobbyState = null; self.lastVer = -1; self.held = {}; };
    if (!this.ws || this.status !== 'online') { done(); return Promise.resolve(); }
    return this._request({ t: 'leave' }).then(done, done);
  };
  /** close the socket for good (no reconnect). Keeps the stored session unless leave() was called. */
  P.close = function () {
    this.wantOnline = false; clearTimeout(this.timer); this.timer = null; this._stopPing();
    var ws = this.ws; this.ws = null;
    if (ws) { try { ws.close(1000); } catch (e) { /* ignore */ } }
    this._failPending('closed'); this._firstFail(new Error('closed')); this._setStatus('offline');
  };

  // ---------- sending ----------
  P._tx = function (obj) {
    if (!this.ws || this.status !== 'online') return false;
    obj.v = 1;
    try { this.ws.send(JSON.stringify(obj)); return true; } catch (e) { return false; }
  };
  P._request = function (obj) {
    var self = this, id = ++this.rid;
    var p = new Promise(function (res, rej) {
      obj.rid = id;
      var t = setTimeout(function () { delete self.pending[id]; rej(Object.assign(new Error('timeout'), { code: 'timeout' })); }, self.opts.reqTimeoutMs);
      self.pending[id] = { res: res, rej: rej, t: t };
      if (!self._tx(obj)) { clearTimeout(t); delete self.pending[id]; rej(Object.assign(new Error('offline'), { code: 'offline' })); }
    });
    p.catch(noop); // callers that ignore the promise must not trigger unhandled-rejection
    return p;
  };
  P._failPending = function (code) {
    var e, k;
    for (k in this.pending) { e = this.pending[k]; clearTimeout(e.t); e.rej(Object.assign(new Error(code), { code: code })); }
    this.pending = {};
    for (k in this.acts) { e = this.acts[k]; clearTimeout(e.t); e.rej(Object.assign(new Error(code), { reason: code })); }
    this.acts = {};
  };
  P.createRoom = function (name, settings, weapon) { return this._request({ t: 'create', name: name, settings: settings, weapon: weapon }); };
  P.joinRoom = function (code, name, weapon) { return this._request({ t: 'join', room: String(code || '').trim().toUpperCase(), name: name, weapon: weapon }); };
  P.setReady = function (b) { return this._request({ t: 'ready', ready: !!b }); };
  P.setSettings = function (s) { return this._request({ t: 'settings', settings: s }); };
  P.startMatch = function () { return this._request({ t: 'start' }); };
  /** send an intent; resolves {ver} on ack, rejects with Error{reason} on rej / timeout / disconnect */
  P.act = function (action) {
    var self = this, seq = ++this.seq;
    var p = new Promise(function (res, rej) {
      var t = setTimeout(function () { delete self.acts[seq]; rej(Object.assign(new Error('timeout'), { reason: 'timeout' })); }, self.opts.actTimeoutMs);
      self.acts[seq] = { res: res, rej: rej, t: t };
      if (!self._tx({ t: 'act', seq: seq, action: action })) { clearTimeout(t); delete self.acts[seq]; rej(Object.assign(new Error('offline'), { reason: 'offline' })); }
    });
    p.catch(noop);
    return p;
  };
  P.slap = function () { return this._tx({ t: 'slap' }); };
  P.emote = function (id) { return this._tx({ t: 'emote', id: id }); };
  P.sync = function () { this.syncing = true; return this._tx({ t: 'sync' }); };

  // ---------- time sync ----------
  P._startPing = function () {
    var self = this; this._stopPing();
    var send = function () { self._tx({ t: 'ping', c: Date.now(), rtt: self.rtt === null ? undefined : Math.round(self.rtt) }); };
    send(); [150, 300, 450].forEach(function (d, i) { self._burst = (self._burst || []); self._burst.push(setTimeout(send, d)); }); // quick warm-up samples
    this.pingTimer = setInterval(send, this.opts.pingMs);
  };
  P._stopPing = function () { clearInterval(this.pingTimer); this.pingTimer = null; (this._burst || []).forEach(clearTimeout); this._burst = []; };
  /** estimated server clock (ms since epoch) */
  P.serverNow = function () { return Date.now() + this.clockOffset; };

  // ---------- incoming ----------
  P._onMessage = function (data) {
    var m; try { m = JSON.parse(data); } catch (e) { return; }
    if (!m || typeof m.t !== 'string') return;
    var h = this['_m_' + m.t];
    if (typeof h === 'function') h.call(this, m);
  };
  P._settle = function (m, ok) {
    var e = m.ref !== undefined && this.pending[m.ref];
    if (!e) return false;
    clearTimeout(e.t); delete this.pending[m.ref];
    if (ok) e.res(m); else e.rej(Object.assign(new Error(m.msg || m.code), { code: m.code }));
    return true;
  };
  P._m_joined = function (m) {
    this.room = m.room; this.you = m.you;
    this.session = { room: m.room, token: m.you.token, id: m.you.id, seat: m.you.seat }; this._saveSession();
    if (!m.resumed) { this.lastVer = -1; this.held = {}; }
    this._settle(m, true);
  };
  P._m_ok = function (m) { this._settle(m, true); };
  P._m_err = function (m) { if (!this._settle(m, false)) this._emit('error', { code: m.code, message: m.msg }); };
  P._m_lobby = function (m) { this.lobbyState = m; this._emit('lobby', m); };
  P._m_match = function (m) { this.lastVer = m.ver; this.held = {}; this.syncing = false; this._emit('match', m); this._emit('state', { ver: m.ver, state: m.state, reason: 'match', players: m.players }); };
  P._m_state = function (m) {
    this.syncing = false; this.lastVer = m.ver;
    for (var k in this.held) if (+k <= m.ver) delete this.held[k];
    this._emit('state', { ver: m.ver, state: m.state, turn: m.turn, phase: m.phase, dl: m.dl, reason: 'sync' });
    this._flush();
  };
  P._m_ev = function (m) {
    if (m.ver <= this.lastVer) return; // duplicate / already covered by a sync
    this.held[m.ver] = m; this._flush();
    if (this.held && Object.keys(this.held).length && !this.syncing) this.sync(); // gap: ask for a full masked state
  };
  P._flush = function () {
    var n;
    while ((n = this.held[this.lastVer + 1])) {
      delete this.held[this.lastVer + 1]; this.lastVer = n.ver;
      this._emit('matchEvents', { ver: n.ver, events: n.ev, turn: n.turn, phase: n.phase, dl: n.dl, auto: n.auto });
    }
  };
  P._m_results = function (m) { this._emit('results', m); };
  P._m_ack = function (m) { var e = this.acts[m.seq]; if (e) { clearTimeout(e.t); delete this.acts[m.seq]; e.res({ ver: m.ver }); } };
  P._m_rej = function (m) { var e = this.acts[m.seq]; if (e) { clearTimeout(e.t); delete this.acts[m.seq]; e.rej(Object.assign(new Error(m.reason), { reason: m.reason })); } };
  P._m_emote = function (m) { this._emit('emote', { seat: m.seat, id: m.id }); };
  P._m_pong = function (m) {
    var t = Date.now(), rtt = t - m.c;
    if (rtt < 0 || rtt > 60000) return;
    this.rttSamples.push(rtt); this.offSamples.push(m.s - (m.c + rtt / 2));
    if (this.rttSamples.length > 5) { this.rttSamples.shift(); this.offSamples.shift(); }
    this.rtt = median(this.rttSamples); this.clockOffset = median(this.offSamples);
  };

  return NetClient;
});
