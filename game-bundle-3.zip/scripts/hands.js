/* hands.js — the "smart hands" system.
   The two hand meshes, their 20-bone skeleton (original Armature_005 bone names / hierarchy / proportions) and the skin weights come
   from data/br-assets.js (built from the supplied FBX by tools/build-br-assets.py). This file adds everything that makes them behave:
     - skeleton pose evaluation (forward kinematics around the file's grip pose, per-finger independent joints, GPU palette output)
     - a grip solver (sequential joint closing until a finger capsule touches the item's proxy shape: no finger penetration)
     - a per-hand state machine with 8 explicit states and blending:
         IDLE, WEAPON, PICKUP, HOLD, RELEASE, INTERACT, RELOAD, TRANSITION
     - the file-exact placement of each hand on the shotgun (gun frame) and the free-hand wrist frame
   Pure maths, no GL calls (so it is unit-tested in Node); the GL side only needs `Hands.palette()` + the mesh built by stage3d.js. */
(function (G) {
  'use strict';
  const Hands = {};
  const sqrt = Math.sqrt, sin = Math.sin, cos = Math.cos, PI = Math.PI, abs = Math.abs;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const sstep = (t) => { t = clamp(t, 0, 1); return t * t * (3 - 2 * t); };
  const FING = ['index', 'middle', 'ring', 'pinky'];
  const GAMMA = 0.1;                        // natural residual curvature of a "straight" finger joint (rad)
  const LIMIT = { 1: 1.75, 2: 1.95, 3: 1.35 };   // max bend of the proximal / middle / distal joint (rad)
  const THUMB_LIMIT = { 2: 1.1, 3: 1.2 };

  /* ------------------------------------------------------------------ rig (static data of one hand mesh) */
  function Rig(def, key) {
    this.key = key; this.def = def; const B = def.bones; this.n = B.length;
    this.names = B.map((b) => b.n); this.roles = B.map((b) => b.r); this.par = B.map((b) => b.p);
    this.head = B.map((b) => b.h.slice()); this.tail = B.map((b) => b.t.slice()); this.rad = B.map((b) => b.rad);
    this.idx = {}; this.roles.forEach((r, i) => { this.idx[r] = i; });
    // finger id (0..3 index..pinky, 4 thumb) + joint number (1..3) per bone; -1 = rigid (wrist, metacarpals, thumb1)
    this.fing = new Int8Array(this.n).fill(-1); this.joint = new Int8Array(this.n);
    this.roles.forEach((r, i) => { const m = /^(index|middle|ring|pinky)([123])$/.exec(r); if (m) { this.fing[i] = FING.indexOf(m[1]); this.joint[i] = +m[2]; } else if (r === 'thumb2' || r === 'thumb3') { this.fing[i] = 4; this.joint[i] = +r[5]; } else if (r === 'thumb1') { this.fing[i] = 4; this.joint[i] = 1; } });
    this.axisOf = FING.map((f) => def.axes[f].slice()); this.axisOf.push(def.axes.thumb.slice());
    this.bind = new Float32Array(this.n); this.roles.forEach((r, i) => { this.bind[i] = def.ang[r] || 0; });   // bend angle of every joint in the file's grip pose
    this.side = def.side;                                                                                      // +1: thumb on +X of the wrist frame
    const f = def.frame; this.gunFromWrist = new Float32Array([f[0], f[1], f[2], 0, f[3], f[4], f[5], 0, f[6], f[7], f[8], 0, f[9], f[10], f[11], 1]);
    this.cuff = def.cuff; this.flex = []; for (let i = 0; i < this.n; i++) if (this.fing[i] >= 0 && !(this.roles[i] === 'thumb1')) this.flex.push(i);
    this.S = new Float32Array(this.n * 12);
    this._R = new Float64Array(9);
    // v7.8 helper (half-angle blend) bones: they only exist for smoother skinning, the grip solver never sees them. Palette = n joints + helpers.
    this.hk = (def.helpers || []).map((r) => this.idx[r]).filter((i) => i !== undefined); this.nTot = this.n + this.hk.length; this.SP = new Float32Array(this.nTot * 12);
  }
  /* absolute bend angles of the bind (file grip) pose, open pose and a curl mix */
  Rig.prototype.bindPose = function (out) { out = out || new Float32Array(this.n); out.set(this.bind); return out; };
  Rig.prototype.openPose = function (out) { out = out || new Float32Array(this.n); for (const i of this.flex) out[i] = GAMMA * (this.bind[i] < 0 ? -1 : 1) * 0.6; return out; };
  /* synergy curl: c[0..4] = index, middle, ring, pinky, thumb; 1 = file grip, 0 = open, >1 = tighter */
  Rig.prototype.curlPose = function (c, out) {
    out = out || new Float32Array(this.n);
    for (const i of this.flex) { const f = this.fing[i], b = this.bind[i], g = GAMMA * (b < 0 ? -1 : 1) * 0.6; out[i] = g + (c[f] === undefined ? 1 : c[f]) * (b - g); }
    return out;
  };
  /* skinning matrices (3x4 row-major per joint, in the wrist frame) for absolute joint angles th[], optional finger spread (rad). Returns this.S */
  Rig.prototype.skin = function (th, spread, out) {
    const S = out || this.S, n = this.n, R = this._R; spread = spread || 0;
    for (let k = 0; k < n; k++) {
      const p = this.par[k], o = k * 12; let r0, r1, r2, r3, r4, r5, r6, r7, r8, t0, t1, t2;
      if (p < 0) { r0 = 1; r1 = 0; r2 = 0; r3 = 0; r4 = 1; r5 = 0; r6 = 0; r7 = 0; r8 = 1; t0 = 0; t1 = 0; t2 = 0; }
      else { const q = p * 12; r0 = S[q]; r1 = S[q + 1]; r2 = S[q + 2]; t0 = S[q + 3]; r3 = S[q + 4]; r4 = S[q + 5]; r5 = S[q + 6]; t1 = S[q + 7]; r6 = S[q + 8]; r7 = S[q + 9]; r8 = S[q + 10]; t2 = S[q + 11]; }
      const f = this.fing[k]; let dl = 0, ab = 0;
      if (f >= 0 && this.roles[k] !== 'thumb1') { dl = th[k] - this.bind[k]; if (this.joint[k] === 1 && f < 4) ab = spread * this.side * (1.5 - f) / 1.5; }
      if (dl !== 0 || ab !== 0) {
        // local = T(P) * Ry(ab) * Rax(dl) * T(-P)
        const a = this.axisOf[f], P = this.head[k]; rotAxis(a, dl, R);
        let m0 = R[0], m1 = R[1], m2 = R[2], m3 = R[3], m4 = R[4], m5 = R[5], m6 = R[6], m7 = R[7], m8 = R[8];
        if (ab !== 0) { const c = cos(ab), s = sin(ab); // Ry(ab) * M
          const a0 = c * m0 + s * m6, a1 = c * m1 + s * m7, a2 = c * m2 + s * m8, b6 = -s * m0 + c * m6, b7 = -s * m1 + c * m7, b8 = -s * m2 + c * m8; m0 = a0; m1 = a1; m2 = a2; m6 = b6; m7 = b7; m8 = b8; }
        const u0 = P[0] - (m0 * P[0] + m1 * P[1] + m2 * P[2]), u1 = P[1] - (m3 * P[0] + m4 * P[1] + m5 * P[2]), u2 = P[2] - (m6 * P[0] + m7 * P[1] + m8 * P[2]);
        const n0 = r0 * m0 + r1 * m3 + r2 * m6, n1 = r0 * m1 + r1 * m4 + r2 * m7, n2 = r0 * m2 + r1 * m5 + r2 * m8, n3 = r3 * m0 + r4 * m3 + r5 * m6, n4 = r3 * m1 + r4 * m4 + r5 * m7, n5 = r3 * m2 + r4 * m5 + r5 * m8, n6 = r6 * m0 + r7 * m3 + r8 * m6, n7 = r6 * m1 + r7 * m4 + r8 * m7, n8 = r6 * m2 + r7 * m5 + r8 * m8;
        const x0 = r0 * u0 + r1 * u1 + r2 * u2 + t0, x1 = r3 * u0 + r4 * u1 + r5 * u2 + t1, x2 = r6 * u0 + r7 * u1 + r8 * u2 + t2;
        r0 = n0; r1 = n1; r2 = n2; r3 = n3; r4 = n4; r5 = n5; r6 = n6; r7 = n7; r8 = n8; t0 = x0; t1 = x1; t2 = x2;
      }
      S[o] = r0; S[o + 1] = r1; S[o + 2] = r2; S[o + 3] = t0; S[o + 4] = r3; S[o + 5] = r4; S[o + 6] = r5; S[o + 7] = t1; S[o + 8] = r6; S[o + 9] = r7; S[o + 10] = r8; S[o + 11] = t2;
    }
    return S;
  };
  /* skin palette including the helper bones: helper h sits at the pivot of joint bone hk[h] and bends HALF of that joint's angle (and half its spread) */
  Rig.prototype.skinFull = function (th, spread) {
    const S = this.skin(th, spread), SP = this.SP, R = this._R; SP.set(S); spread = spread || 0;
    for (let h = 0; h < this.hk.length; h++) {
      const k = this.hk[h], p = this.par[k], o = (this.n + h) * 12, q = p * 12, f = this.fing[k], P = this.head[k], a = this.axisOf[f];
      const r0 = S[q], r1 = S[q + 1], r2 = S[q + 2], t0 = S[q + 3], r3 = S[q + 4], r4 = S[q + 5], r5 = S[q + 6], t1 = S[q + 7], r6 = S[q + 8], r7 = S[q + 9], r8 = S[q + 10], t2 = S[q + 11];
      const dl = (th[k] - this.bind[k]) * 0.5, ab = (this.joint[k] === 1 && f < 4) ? spread * this.side * (1.5 - f) / 1.5 * 0.5 : 0;
      rotAxis(a, dl, R); let m0 = R[0], m1 = R[1], m2 = R[2], m3 = R[3], m4 = R[4], m5 = R[5], m6 = R[6], m7 = R[7], m8 = R[8];
      if (ab !== 0) { const c = cos(ab), s2 = sin(ab); const a0 = c * m0 + s2 * m6, a1 = c * m1 + s2 * m7, a2 = c * m2 + s2 * m8, b6 = -s2 * m0 + c * m6, b7 = -s2 * m1 + c * m7, b8 = -s2 * m2 + c * m8; m0 = a0; m1 = a1; m2 = a2; m6 = b6; m7 = b7; m8 = b8; }
      const u0 = P[0] - (m0 * P[0] + m1 * P[1] + m2 * P[2]), u1 = P[1] - (m3 * P[0] + m4 * P[1] + m5 * P[2]), u2 = P[2] - (m6 * P[0] + m7 * P[1] + m8 * P[2]);
      SP[o] = r0 * m0 + r1 * m3 + r2 * m6; SP[o + 1] = r0 * m1 + r1 * m4 + r2 * m7; SP[o + 2] = r0 * m2 + r1 * m5 + r2 * m8; SP[o + 3] = r0 * u0 + r1 * u1 + r2 * u2 + t0;
      SP[o + 4] = r3 * m0 + r4 * m3 + r5 * m6; SP[o + 5] = r3 * m1 + r4 * m4 + r5 * m7; SP[o + 6] = r3 * m2 + r4 * m5 + r5 * m8; SP[o + 7] = r3 * u0 + r4 * u1 + r5 * u2 + t1;
      SP[o + 8] = r6 * m0 + r7 * m3 + r8 * m6; SP[o + 9] = r6 * m1 + r7 * m4 + r8 * m7; SP[o + 10] = r6 * m2 + r7 * m5 + r8 * m8; SP[o + 11] = r6 * u0 + r7 * u1 + r8 * u2 + t2;
    }
    return SP;
  };
  function rotAxis(a, ang, R) { const c = cos(ang), s = sin(ang), t = 1 - c, x = a[0], y = a[1], z = a[2];
    R[0] = c + x * x * t; R[1] = x * y * t - z * s; R[2] = x * z * t + y * s; R[3] = y * x * t + z * s; R[4] = c + y * y * t; R[5] = y * z * t - x * s; R[6] = z * x * t - y * s; R[7] = z * y * t + x * s; R[8] = c + z * z * t; }
  const xfS = (S, k, p) => { const o = k * 12; return [S[o] * p[0] + S[o + 1] * p[1] + S[o + 2] * p[2] + S[o + 3], S[o + 4] * p[0] + S[o + 5] * p[1] + S[o + 6] * p[2] + S[o + 7], S[o + 8] * p[0] + S[o + 9] * p[1] + S[o + 10] * p[2] + S[o + 11]]; };
  /* posed head/tail of one bone (wrist frame) */
  Rig.prototype.seg = function (k, S) { S = S || this.S; return [xfS(S, k, this.head[k]), xfS(S, k, this.tail[k])]; };

  /* ------------------------------------------------------------------ proxy shapes + signed distance */
  /* {t:'cyl', c:[x,y,z], a:[ax,ay,az], r, h}  {t:'box', c, half:[x,y,z]} (axis aligned in the wrist frame)  {t:'sph', c, r} */
  function sdf(P, p) {
    let dx = p[0] - P.c[0], dy = p[1] - P.c[1], dz = p[2] - P.c[2];
    if (P.t === 'sph') return sqrt(dx * dx + dy * dy + dz * dz) - P.r;
    if (P.fr) { const l = P.fr[0], n = P.fr[1], f = P.fr[2]; const a = dx * l[0] + dy * l[1] + dz * l[2], b = dx * n[0] + dy * n[1] + dz * n[2], c = dx * f[0] + dy * f[1] + dz * f[2]; dx = a; dy = b; dz = c; }   // proxy frame: x = lateral, y = palm normal, z = forward
    if (P.t === 'box') { const qx = abs(dx) - P.half[0], qy = abs(dy) - P.half[1], qz = abs(dz) - P.half[2]; return sqrt(Math.max(qx, 0) ** 2 + Math.max(qy, 0) ** 2 + Math.max(qz, 0) ** 2) + Math.min(Math.max(qx, qy, qz), 0); }
    // cylinder: axis = proxy x when a frame is given, else P.a
    const ax = P.fr ? dx : dx * P.a[0] + dy * P.a[1] + dz * P.a[2], rr = P.fr ? sqrt(dy * dy + dz * dz) : sqrt(Math.max(0, dx * dx + dy * dy + dz * dz - ax * ax)), q0 = rr - P.r, q1 = abs(ax) - P.h / 2;
    return Math.min(Math.max(q0, q1), 0) + sqrt(Math.max(q0, 0) ** 2 + Math.max(q1, 0) ** 2);
  }
  Hands.sdf = sdf;
  function capsuleGap(P, A, B, r) { let m = 1e9; for (let i = 0; i <= 6; i++) { const t = i / 6, p = [A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, A[2] + (B[2] - A[2]) * t]; const d = sdf(P, p) - r; if (d < m) m = d; } return m; }
  Hands.capsuleGap = capsuleGap;

  /* grip solver: every finger joint is closed (proximal joint first) until its capsule touches the proxy shape, so the fingers wrap the item
     and never go through it. A joint angle is bind*t (t = 1 is the file's own grip); the search runs over t in [tMin, t1]: if the finger already
     touches at the start pose the hand opens further (bigger item), otherwise it closes until contact (or to t1 for a small item).
     returns {th, contact[5], pen} (pen = deepest penetration left: ~0) */
  Rig.prototype.solveGrip = function (P, opt) {
    opt = opt || {}; const margin = opt.margin === undefined ? 0.004 : opt.margin, t0 = opt.t0 === undefined ? 0.35 : opt.t0, t1 = opt.t1 === undefined ? 1.15 : opt.t1, tMin = -0.12, steps = 26;
    const th = this.curlPose([t0, t0, t0, t0, t0], new Float32Array(this.n)), contact = [0, 0, 0, 0, 0]; let pen = 0;
    for (let f = 0; f < 5; f++) {
      if (opt.skip && opt.skip.indexOf(f) >= 0) continue;
      const bones = []; for (const i of this.flex) if (this.fing[i] === f) bones.push(i); bones.sort((a, b) => this.joint[a] - this.joint[b]);
      for (let jn = 0; jn < bones.length; jn++) {
        const bj = bones[jn], g = GAMMA * (this.bind[bj] < 0 ? -1 : 1) * 0.6, ang = (t) => g + t * (this.bind[bj] - g);
        const gap = (t) => { th[bj] = ang(t); this.skin(th, 0); let m = 1e9; for (let q = jn; q < bones.length; q++) { const k = bones[q], sg = this.seg(k); m = Math.min(m, capsuleGap(P, sg[0], sg[1], this.rad[k])); } return m; };
        let lo, hi;
        if (gap(t0) <= margin) { // touching already: open until it is free
          if (gap(tMin) <= margin) { th[bj] = ang(tMin); contact[f] = 1; continue; }
          lo = tMin; hi = t0; for (let it = 0; it < steps; it++) { const mid = (lo + hi) / 2; if (gap(mid) > margin) lo = mid; else hi = mid; }
          th[bj] = ang(lo); contact[f] = 1;
        } else if (gap(t1) > margin) { th[bj] = ang(t1); }   // closes completely without touching (small item)
        else { lo = t0; hi = t1; for (let it = 0; it < steps; it++) { const mid = (lo + hi) / 2; if (gap(mid) > margin) lo = mid; else hi = mid; } th[bj] = ang(lo); contact[f] = 1; }
      }
    }
    this.skin(th, 0);
    for (let k = 0; k < this.n; k++) if (this.fing[k] >= 0 && this.roles[k] !== 'thumb1') { const sg = this.seg(k), gp = capsuleGap(P, sg[0], sg[1], this.rad[k]); if (gp < pen) pen = gp; }
    return { th, contact, pen };
  };
  /* all posed finger capsules (for tests / debug): [{k, a, b, r}] */
  Rig.prototype.capsules = function (th, spread) { this.skin(th, spread || 0); const o = []; for (let k = 0; k < this.n; k++) if (this.fing[k] >= 0 && this.roles[k] !== 'thumb1') { const s = this.seg(k); o.push({ k, a: s[0], b: s[1], r: this.rad[k] }); } return o; };

  /* ------------------------------------------------------------------ item grip library */
  /* Each item has a proxy shape in the ITEM's own frame (origin = base centre, +Y up, metres; the sizes are the ones Stage3D.drawItemModel draws) and a
     grip kind. align 'up': the item's +Y axis runs along the wrist's X axis (the item is held upright, thumb up); 'long': the item's +X axis runs along it.
     The proxy is what the fingers are solved against (Rig.solveGrip), and the item is drawn with exactly that placement. */
  const ITEM_GRIPS = {
    can: { t: 'cyl', r: 0.034, h: 0.12, c: [0, 0.06, 0], align: 'up', grip: 'power' },
    medicine: { t: 'cyl', r: 0.04, h: 0.13, c: [0, 0.065, 0], align: 'up', grip: 'power' },
    battery: { t: 'cyl', r: 0.026, h: 0.12, c: [0, 0.06, 0], align: 'up', grip: 'power' },
    blank: { t: 'cyl', r: 0.026, h: 0.12, c: [0, 0.06, 0], align: 'up', grip: 'power' },
    spray: { t: 'cyl', r: 0.028, h: 0.15, c: [0, 0.075, 0], align: 'up', grip: 'power' },
    magnifier: { t: 'cyl', r: 0.013, h: 0.15, c: [0, 0.075, 0], align: 'up', grip: 'power' },
    knife: { t: 'box', half: [0.045, 0.011, 0.008], c: [-0.045, 0, 0], align: 'long', grip: 'power' },
    lighter: { t: 'box', half: [0.017, 0.03, 0.008], c: [0, 0.03, 0], align: 'up', grip: 'precision' },
    scrambler: { t: 'box', half: [0.05, 0.03, 0.035], c: [0, 0.03, 0], align: 'long', grip: 'power' },
    handcuffs: { t: 'box', half: [0.07, 0.012, 0.045], c: [0, 0.01, 0], align: 'long', grip: 'precision' },
    cigarette: { t: 'cyl', r: 0.0047, h: 0.093, c: [0.02, 0, 0], align: 'long', grip: 'pinch', axisLocal: 'x' },
    coin: { t: 'cyl', r: 0.032, h: 0.007, c: [0, 0.003, 0], align: 'up', grip: 'pinch' },
    rope: { t: 'sph', r: 0.055, c: [0, 0.03, 0], align: 'up', grip: 'power' }
  };
  Hands.ITEM_GRIPS = ITEM_GRIPS;
  /* palm frame of the file's pose: lateral l (index side -> pinky side axis, across the knuckles), forward f (wrist -> knuckles), palm normal n = f x l (towards
     the side the fingers curl), and the knuckle centre m. Everything an item grip needs is expressed in it. */
  Rig.prototype.palmFrame = function () {
    if (this._pf) return this._pf; const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], nrm = (a) => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; }, cr = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
    const mcp = FING.map((f) => this.head[this.idx[f + '1']]), m = [0, 1, 2].map((k) => (mcp[0][k] + mcp[1][k] + mcp[2][k] + mcp[3][k]) / 4);
    const f = nrm(m), l0 = nrm(sub(mcp[3], mcp[0])); let n = nrm(cr(f, l0)); if (n[1] < 0) n = [-n[0], -n[1], -n[2]];   // normal points to the palm side (+Y of the wrist frame)
    const l = nrm(cr(n, f)); let hi = 0; for (const q of mcp) hi = Math.max(hi, (q[0] - m[0]) * n[0] + (q[1] - m[1]) * n[1] + (q[2] - m[2]) * n[2]);   // the highest knuckle above the mean plane (a cupped hand)
    return (this._pf = { m, f, n, l, hi });
  };
  Rig.prototype.itemProxy = function (id, hs) {
    const g = ITEM_GRIPS[id] || ITEM_GRIPS.can, u = 1 / hs, up = g.align === 'up', pf = this.palmFrame(), sd = this.side;
    // item axes (columns) -> palm frame: 'up' puts the item's +Y towards the thumb (side * l), 'long' puts its +X along l
    const ux = up ? scl(pf.n, -sd) : pf.l, uy = up ? scl(pf.l, sd) : pf.n, uz = pf.f;
    let ext, P; const OFF = 0.075 + pf.hi, C = (e) => [pf.m[0] + pf.n[0] * (e + OFF) + pf.f[0] * 0.02, pf.m[1] + pf.n[1] * (e + OFF) + pf.f[1] * 0.02, pf.m[2] + pf.n[2] * (e + OFF) + pf.f[2] * 0.02];
    if (g.t === 'cyl') { ext = g.r * u; P = { t: 'cyl', c: C(ext), r: g.r * u, h: g.h * u, fr: [pf.l, pf.n, pf.f] }; }   // axis = frame x (lateral); 'long' cylinders (cigarette) lie along it too
    else if (g.t === 'sph') { ext = g.r * u; P = { t: 'sph', c: C(ext), r: g.r * u }; }
    else { const hx = g.half[0] * u, hy = g.half[1] * u, hz = g.half[2] * u; if (up) { P = { t: 'box', half: [hy, hx, hz], fr: [pf.l, pf.n, pf.f] }; ext = hx; } else { P = { t: 'box', half: [hx, hy, hz], fr: [pf.l, pf.n, pf.f] }; ext = hy; } P.c = C(ext); }
    // item origin in the wrist frame: proxy centre minus (item axes * item-frame centre offset)
    const c = g.c, o = [0, 1, 2].map((k) => P.c[k] - (ux[k] * c[0] + uy[k] * c[1] + uz[k] * c[2]) * u);
    return { proxy: P, ax: [ux, uy, uz], o, grip: g.grip };
  };
  const scl = (a, k) => [a[0] * k, a[1] * k, a[2] * k];
  Rig.prototype.palmSurface = 0.1;   // refined in Hands.init from the mesh (distance of the palm-side surface from the wrist axis)

  /* ------------------------------------------------------------------ per-hand controller + 8-state machine */
  const ST = Hands.STATES = ['idle', 'weapon', 'pickup', 'hold', 'release', 'interact', 'reload', 'transition'];
  function Ctl(rig, who, side) {
    this.rig = rig; this.who = who; this.side = side; this.state = 'idle'; this.prev = 'idle'; this.t = 0; this.attach = 0; this.attachT = 0;
    this.th = rig.curlPose([0.55, 0.55, 0.55, 0.55, 0.5]); this.tgt = new Float32Array(rig.n); this.tgt.set(this.th); this.spread = 0.1; this.item = null; this.grab = 0; this.grip = null;
    this.blend = 1; this.log = []; this.tau = new Float32Array(5).fill(0.07); this.vel = new Float32Array(rig.n); this.itemGrip = {};
  }
  Hands.Ctl = Ctl;
  const IDLE_C = [0.5, 0.55, 0.6, 0.62, 0.5];      // a relaxed, slightly curled hand
  /* input: {gun: this hand grips the gun, reload: 0..1 pump travel (support hand), curl: [5] the animation's own finger curl (0 relaxed-open .. 1 the file's grip),
             item: {id, th} | null (th = solved grip pose), grab: 0..1 closing amount, point: 1 pointing / tapping, near: 1 reaching for something} */
  Ctl.prototype.setState = function (s) { if (s === this.state) return; this.prev = this.state; this.state = s; this.t = 0; if (this.log.length < 400) this.log.push(this.prev + '>' + s); };
  Ctl.prototype.update = function (dt, inp) {
    const rig = this.rig; dt = clamp(dt, 0.001, 0.1); this.t += dt;
    const wantGun = inp.gun ? 1 : 0, holding = !!(inp.item && inp.item.id);
    // ---- attach weight: how strongly the wrist is locked to the gun (file-exact placement); eases in and out, so a pick-up or a release never pops
    this.attach += (wantGun - this.attach) * (1 - Math.exp(-dt * (wantGun ? 7 : 5.5)));
    if (abs(this.attach - wantGun) < 0.003) this.attach = wantGun;
    // ---- grab amount (0 = open hand, 1 = fingers wrapped around the item)
    const gT = holding ? sstep(inp.grab === undefined ? 1 : inp.grab) : 0; this.grab += (gT - this.grab) * (1 - Math.exp(-dt * (holding ? 10 : 7)));
    if (abs(this.grab - gT) < 0.004) this.grab = gT;
    // ---- state selection: exactly one of the 8 states at any time
    let s;
    if (wantGun) s = this.attach < 0.985 ? 'transition' : (inp.reload > 0.02 ? 'reload' : 'weapon');
    else if (this.attach > 0.015) s = 'release';                                     // the gun has been given up: fingers open while the wrist leaves the stock
    else if (holding) { if (this.grab > 0.9) this.gripped = true; s = !this.gripped ? 'pickup' : this.grab > 0.3 ? 'hold' : 'release'; }   // pickup until the fingers have closed once; hold while the item stays in the hand (a use animation may relax the fingers a little); release when they open around it
    else if (this.grab > 0.03) s = 'release';                                         // the item has been let go of
    else if (inp.point) s = 'interact';
    else if (inp.near) s = 'pickup';                                                  // reaching for the weapon / an item with an open hand
    else s = 'idle';
    if (!holding && this.grab <= 0.03) this.gripped = false;
    this.setState(s);
    // ---- target pose per state (joint angles)
    const T = this.tgt, c = inp.curl || IDLE_C;
    if (this.state === 'weapon' || this.state === 'reload') { rig.bindPose(T); }
    else if (this.state === 'transition') { const k = sstep(this.attach), base = rig.curlPose(c, this.tmp || (this.tmp = new Float32Array(rig.n))); rig.bindPose(T); for (let i = 0; i < rig.n; i++) T[i] = base[i] + (T[i] - base[i]) * k; }
    else if (holding && inp.item.th) { const base = rig.curlPose(c, this.tmp || (this.tmp = new Float32Array(rig.n))), gr = inp.item.th; for (let i = 0; i < rig.n; i++) T[i] = base[i] + (gr[i] - base[i]) * this.grab; }
    else if (this.state === 'interact') rig.curlPose([0.3, 1.0, 1.02, 1.05, 0.8], T);                // pointing: the index stays long, the others curl in
    else if (this.state === 'pickup') rig.curlPose([0.32, 0.32, 0.32, 0.32, 0.3], T);               // reaching: open, ready to close
    else rig.curlPose(c, T);                                                          // idle / release: the animation's own curl
    // ---- critically damped follow, a different time constant per finger: the fingers close one after the other, never snap and never jitter
    for (let i = 0; i < rig.n; i++) { const f = rig.fing[i]; if (f < 0) continue; this.th[i] += (T[i] - this.th[i]) * (1 - Math.exp(-dt / (this.tau[f] * (this.state === 'transition' ? 1.15 : 1)))); }
    const sp = (this.state === 'idle' || this.state === 'release' || this.state === 'pickup') ? 0.1 : this.state === 'interact' ? 0.04 : 0; this.spread += (sp - this.spread) * (1 - Math.exp(-dt * 6));
    return this;
  };
  /* skin palette for the shader (NJ*12 floats) */
  Ctl.prototype.palette = function (out) { const S = this.rig.skinFull(this.th, this.spread); if (out) { out.set(S); return out; } return new Float32Array(S); };

  /* ------------------------------------------------------------------ setup from the baked assets */
  Hands.init = function () {
    const BR = G.BR; if (!BR || !BR.hands) return false;
    Hands.rig = { R: new Rig(BR.hands.R, 'R'), L: new Rig(BR.hands.L, 'L') };
    for (const k of ['R', 'L']) { // palm thickness: distance of the palm-side surface from the metacarpal axis (mesh vertices bound to the rigid palm bones, on the +Y side)
      const d = BR.hands[k], r = Hands.rig[k]; let top = 0, cnt = 0; const p = d.p, j = d.j, w = d.w; const palm = new Set(); r.roles.forEach((rl, i) => { if (rl === 'wrist' || /0$/.test(rl)) palm.add(i); });
      for (let v = 0; v < p.length / 3; v++) { if (palm.has(j[v * 4]) && w[v * 4] > 0.8 && p[v * 3 + 1] > 0) { top = Math.max(top, p[v * 3 + 1]); cnt++; } }
      r.palmSurface = top > 0 ? top * 0.8 : 0.1;
    }
    Hands.ready = true; return true;
  };
  Hands.newCtl = function (key, who, side) { return new Ctl(Hands.rig[key], who, side); };
  /* the world meshes the stage uses: which baked mesh draws which hand */
  Hands.meshKey = (who, side) => (who === 'p' ? (side === 'l' ? 'L' : 'R') : (side === 'l' ? 'R' : 'L'));
  /* solved finger pose + placement for an item in a hand (cached per mesh / item / hand scale) */
  Hands.itemGrip = function (key, id, hs) { const rig = Hands.rig[key], cache = rig._ig || (rig._ig = {}), k = id + '@' + hs.toFixed(3); if (cache[k]) return cache[k]; const pl = rig.itemProxy(id, hs), r = rig.solveGrip(pl.proxy); return (cache[k] = { proxy: pl.proxy, ax: pl.ax, o: pl.o, th: r.th, contact: r.contact, pen: r.pen, grip: pl.grip }); };
  /* ------------------------------------------------------------------ GL side: meshes / materials / textures of the supplied gun and hands */
  Hands.buildGL = function (GL) {
    const BR = G.BR; if (!BR || !GL || !GL.ok || (!Hands.ready && !Hands.init())) return null;
    const X = { meta: BR.meta, parts: { body: {}, pump: {} }, hand: {}, mat: {} };
    const body = GL.mesh({ p: BR.body.p, n: BR.body.n, t: BR.body.t, i: BR.body.i }), pump = GL.mesh({ p: BR.pump.p, n: BR.pump.n, t: BR.pump.t, i: BR.pump.i });
    for (const g of BR.body.g) X.parts.body[g[0]] = GL.sub(body, g[1], g[2]);
    for (const g of BR.pump.g) X.parts.pump[g[0]] = GL.sub(pump, g[1], g[2]);
    for (const k of ['R', 'L']) {
      const d = BR.hands[k], nv = d.p.length / 3, j = new Uint8Array(d.j), w = new Uint8Array(nv * 4);
      for (let v = 0; v < nv; v++) { let sum = 0, mx = 0, mi = 0; for (let q = 0; q < 4; q++) { const b = Math.round(d.w[v * 4 + q] * 255); w[v * 4 + q] = b; sum += b; if (b > mx) { mx = b; mi = q; } } w[v * 4 + mi] = clamp(w[v * 4 + mi] + 255 - sum, 0, 255); }
      X.hand[k] = GL.mesh({ p: d.p, n: d.n, t: d.t, i: d.i, j, w });
    }
    // the game's lighting is dim by design (a few candles / one lamp): the same exposure factor the other props use is applied to the colour of every material;
    // the textures themselves are used exactly as they are in the file.
    const E = 1.5;
    X.mat.metal = GL.material({ c: [E, E, E], fb: [0.3, 0.3, 0.31], spec: 0.8, shin: 55 });
    X.mat.paint = GL.material({ c: [E, E, E], fb: [0.18, 0.2, 0.22], spec: 0.7, shin: 45 });
    X.mat.wood = GL.material({ c: [E, E, E], fb: [0.4, 0.24, 0.12], spec: 0.35, shin: 28 });
    const ES = E * 0.82;     // skin: the lamp is warm, the file's skin texture is already orange - a little less exposure keeps it from glowing
    X.mat.skin = GL.material({ c: [ES, ES, ES], fb: [0.62, 0.5, 0.42], kind: 4, spec: 0.3, shin: 22, rim: 0.2 });
    if (typeof Image !== 'undefined') for (const [k, key] of [['metal', 'metal'], ['paint', 'paint'], ['wood', 'wood'], ['skin', 'skin']]) {
      const im = new Image(); im.onload = () => { try { X.mat[k].map = GL.texture(im); X.loaded = (X.loaded || 0) + 1; } catch (e) { /* keep the fallback colour */ } }; im.src = BR.tex[key];
    }
    // key points of the weapon in the gun frame (bounds of the gun and of both hands): used by the camera clearance
    X.keys = Hands.keyPoints();
    return X;
  };
  /* corners of the gun's bounding box + of each hand mesh (bind pose) in the gun frame */
  Hands.keyPoints = function () {
    const BR = G.BR, o = [], box = (mn, mx) => { for (const x of [mn[0], mx[0]]) for (const y of [mn[1], mx[1]]) for (const z of [mn[2], mx[2]]) o.push([x, y, z]); };
    box(BR.meta.bounds[0], BR.meta.bounds[1]);
    for (const k of ['R', 'L']) { const d = BR.hands[k], F = Hands.rig[k].gunFromWrist, p = d.p, mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9];
      for (let v = 0; v < p.length; v += 3) { const x = p[v], y = p[v + 1], z = p[v + 2]; for (let a = 0; a < 3; a++) { const g = F[a] * x + F[4 + a] * y + F[8 + a] * z + F[12 + a]; if (g < mn[a]) mn[a] = g; if (g > mx[a]) mx[a] = g; } }
      box(mn, mx); }
    return o;
  };
  G.Hands = Hands;
  if (typeof module !== 'undefined' && module.exports) module.exports = Hands;
})(typeof window !== 'undefined' ? window : globalThis);
