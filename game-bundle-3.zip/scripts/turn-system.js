/* turn-system.js — session flow: new game / resume / rounds / turn ownership / player actions / Dealer turns /
   progression (achievements, endings, unlocks). Rules are applied through Engine.apply() ONLY; the Show narrates. */
(function (G) {
  'use strict';
  const U = G.U, D = G.GameData, E = G.Engine, AI = G.DealerAI, Show = G.Show, Save = G.Save, Au = G.AudioMgr, Anim = G.Anim, R = G.Renderer;
  const T = { st: null, busy: false, paused: false, aim: null, roundSnap: null, lastEnd: null, active: false, meta: null, settings: null, log: [] };
  const UI = () => G.UI;

  T.canAct = () => !!(T.active && T.st && T.st.phase === 'play' && T.st.turn === 'p' && !T.busy && !T.paused);
  T.state = () => T.st;

  /* run an async sequence; stale (cancelled) sequences never touch current state */
  T.run = async function (fn) {
    const tk = Show.token; T.busy = true; UI() && UI().updateActions();
    try { await fn(); } catch (e) { if (!Show.cancelled(e)) { console.error('[turns] sequence error', e); T.log.push(String(e && e.stack || e)); } }
    if (tk === Show.token) { T.busy = false; UI() && UI().updateActions(); }
  };
  const save = () => { if (T.st && T.st.phase !== 'lost' && T.st.phase !== 'won') Save.queueRun(T.st); };
  const saveMeta = () => { if (!Save.saveMeta(T.meta) && !T.warnedStorage) { T.warnedStorage = true; UI() && UI().toast(U.t('toast.storage'), 'info'); } };

  /* ------------------------------------------------------------ new / resume / restart */
  T.newGame = function (diff) {
    Show.reset(); T.aim = null; T.active = true; T.paused = false;
    const owned = []; for (const id of D.itemOrder) for (let i = 0; i < (T.meta.stock[id] || 0); i++) owned.push(id);
    const pick = []; while (owned.length && pick.length < 2) pick.push(owned.splice(Math.floor(Math.random() * owned.length), 1)[0]);
    for (const id of pick) { T.meta.stock[id]--; if (T.meta.stock[id] <= 0) delete T.meta.stock[id]; }
    const selW = (T.meta.selected && T.meta.selected.weapon) || 'caster', pool = (G.Economy && G.Economy.itemPool) ? G.Economy.itemPool(T.meta) : undefined;
    T.st = E.newGame(diff, undefined, pick, { weapon: selW, pool }); Show.st = T.st; Save.clearRun();
    T.meta.stats.games++; T.meta.lastDiff = diff; PG().newGame(); PG().check(T.meta); saveMeta();
    UI().showGame();
    T.run(async () => { Au.setMusicMode('game'); Show.say('greet'); await Show.sleep(1.2); await T.beginRound(); });
  };
  T.continueGame = function () {
    const st = Save.loadRun();
    if (Save.corruptFlag) { Save.corruptFlag = false; UI().toast(U.t('toast.corrupt'), 'info'); }
    if (!st) { UI().toast(U.t('toast.noSave'), 'info'); return false; }
    Show.reset(); T.aim = null; T.active = true; T.paused = false; T.st = st; Show.st = st; Au.setMusicMode('game');
    Show.restoreScene(st); UI().showGame();
    T.run(async () => {
      Show.say('greet');
      if (st.phase === 'between') { await Show.sleep(0.8); await T.beginRound(); }
      else { await Show.sleep(0.8); await settle(); }
    });
    return true;
  };
  T.beginRound = async function () {
    T.roundSnap = JSON.stringify(T.st);
    const evs = E.startRound(T.st);
    await process(evs);
  };
  T.nextRound = function () { T.run(async () => { await T.beginRound(); }); };
  T.retryRound = function () {
    if (!T.roundSnap) return T.newGame(T.st ? T.st.diff : 'normal');
    const snap = JSON.parse(T.roundSnap); snap.r = (snap.r ^ ((Math.random() * 0x7fffffff) | 0)) | 0; // fresh shuffle so a retry is not a memorised replay
    Show.reset(); T.aim = null; T.active = true; T.paused = false; Anim.setPaused(false); Au.setPaused(false);
    T.st = snap; Show.st = snap; Show.restoreScene(snap); UI().showGame();
    T.run(async () => { await T.beginRound(); });
  };
  T.restartGame = function () { const d = T.st ? T.st.diff : 'normal'; Anim.setPaused(false); Au.setPaused(false); T.newGame(d); };
  T.toMenu = function () {
    save(); Save.flushRun(); Show.reset(); T.active = false; T.paused = false; T.busy = false; T.aim = null;
    Anim.setPaused(false); Au.setPaused(false); Show.menuScene(); UI().showMenu();
  };

  /* ------------------------------------------------------------ narration + flow */
  async function process(evs) {
    const re = evs.find((e) => e.t === 'roundEnd'); if (re) T.lastEnd = re;
    for (const e of evs) if (e.t === 'item' && e.who === 'p') { if (!T.meta.discovered[e.id]) { T.meta.discovered[e.id] = 1; saveMeta(); } }
    PG().track(evs, T.st, T.meta);
    await Show.narrate(evs, T.st);
    save();
    await settle();
  }
  async function settle() {
    const st = T.st; Show.syncView(st);
    if (st.phase === 'play') {
      checkAch();
      if (st.turn === 'd') await dealerTurn();
      else { Show.waiting = true; Show.idleT = 12 + Math.random() * 8; UI().setPrompt(T.aim ? 'hud.promptAimed' : 'hud.promptTurn'); UI().updateActions(); }
      return;
    }
    Show.waiting = false;
    await endOfRound();
  }
  async function dealerTurn() {
    const st = T.st; Show.waiting = false; UI().setPrompt(null);
    while (st.phase === 'play' && st.turn === 'd') {
      const df = D.difficulties[st.diff];
      Anim.dealer.ambient.on = true; if (Math.random() < 0.5) Anim.dealer.play(Math.random() < 0.5 ? 'd_look_table' : 'd_tilt');
      await Show.sleep(Show.settings && Show.settings.reduced ? 0.6 : df.think[0] + Math.random() * (df.think[1] - df.think[0]));
      Anim.dealer.play('d_look_player');
      let act = AI.decide(st, 'd'), r = E.apply(st, 'd', act);
      if (!r.ok) { r = E.apply(st, 'd', { type: 'shoot', target: 'opp' }); } // never stall on an illegal AI choice
      if (!r.ok) { console.error('[turns] dealer could not act', r.reason); break; }
      const re = r.ev.find((e) => e.t === 'roundEnd'); if (re) T.lastEnd = re;
      PG().track(r.ev, st, T.meta);
      await Show.narrate(r.ev, st); save();
    }
    await settle();
  }

  /* ------------------------------------------------------------ round end, progression */
  const PG = () => G.Progress;
  const checkAch = () => { PG().check(T.meta); };   // achievements are derived from the saved statistics (progress.js)
  async function endOfRound() {
    const st = T.st, re = T.lastEnd || { winner: st.phase === 'lost' ? 'd' : 'p', hpLeft: st.p.hp, items: st.stats.roundItems };
    T.meta.stats.rounds += re.winner === 'p' ? 1 : 0;
    { const earn = re.winner === 'p' ? 12 + (st.phase === 'won' ? 40 : 0) : 3; PG().addWax(earn, T.meta); T.lastEarn = earn; saveMeta(); UI().toast(U.t('toast.coins', { n: earn }), 'good'); }
    PG().onRoundEnd(st, re, T.meta);
    if (st.phase === 'between') { save(); Save.flushRun(); saveMeta(); UI().showEnding('round', { round: st.round }); return; }
    if (st.phase === 'won') {
      T.meta.stats.wins++; T.meta.endings.survivor = 1;
      const untouched = st.stats.dmgTaken === 0; if (untouched) T.meta.endings.untouched = 1;
      PG().onWin(st, T.meta);
      const newly = !T.meta.unlocked.nightmare; T.meta.unlocked.nightmare = true;
      Save.clearRun(); saveMeta();
      await Show.victoryEnding();
      UI().showEnding('victory', { untouched, unlocked: newly });
      return;
    }
    T.meta.endings.defeat = 1; Save.clearRun(); saveMeta();
    UI().showEnding('defeat', {});
  }

  /* ------------------------------------------------------------ player actions */
  T.playerUse = function (idx) {
    if (!T.canAct()) { UI().toast(U.t(T.busy ? 'toast.busy' : 'toast.notTurn'), 'info'); return; }
    const st = T.st, c = E.canUse(st, 'p', idx);
    if (!c.ok) { UI().toast(U.t(c.reason), 'info'); Au.sfx('ui_back', { vol: 0.6 }); return; }
    Show.waiting = false; Show.st = st; R.scene.selected = null; UI().hideItemCard();
    T.run(async () => {
      if (T.aim) { await Show.lowerGun(); T.aim = null; UI().setAim(null); }
      const r = E.apply(st, 'p', { type: 'item', idx });
      if (!r.ok) { UI().toast(U.t(r.reason), 'info'); await settle(); return; }
      await process(r.ev);
    });
  };
  T.playerInspect = function (idx) {
    if (!T.canAct()) { UI().toast(U.t(T.busy ? 'toast.busy' : 'toast.notTurn'), 'info'); return; }
    if (!T.st.p.items[idx]) { UI().toast(U.t('toast.slotEmpty'), 'info'); return; }
    Show.waiting = false; R.scene.selected = null; UI().hideItemCard();
    T.run(async () => { if (T.aim) { await Show.lowerGun(); T.aim = null; UI().setAim(null); } await Show.inspectItem(idx); await settle(); });
  };
  T.playerInspectGun = function () {
    if (!T.canAct()) { UI().toast(U.t(T.busy ? 'toast.busy' : 'toast.notTurn'), 'info'); return; }
    Show.waiting = false;
    T.run(async () => { if (T.aim) { await Show.lowerGun(); T.aim = null; UI().setAim(null); } await Show.inspectGun(); await settle(); });
  };
  T.playerAim = function (target) {
    if (!T.canAct()) { UI().toast(U.t(T.busy ? 'toast.busy' : 'toast.notTurn'), 'info'); return; }
    if (T.aim === target) return;
    Show.waiting = false; R.scene.selected = null; UI().hideItemCard();
    T.run(async () => {
      await Show.takeGun('p'); await Show.aimGun('p', target); T.aim = target; UI().setAim(target); UI().setPrompt('hud.promptAimed');
    });
  };
  T.playerFire = function () {
    if (!T.canAct() || !T.aim) return;
    const st = T.st, target = T.aim === 'self' ? 'self' : 'opp';
    const r = E.apply(st, 'p', { type: 'shoot', target });
    if (!r.ok) { UI().toast(U.t(r.reason === 'empty' ? 'toast.busy' : r.reason), 'info'); return; }
    T.aim = null; UI().setAim(null); Show.waiting = false;
    T.run(async () => { await process(r.ev); });
  };
  T.playerLower = function () {
    if (!T.canAct() || !T.aim) return;
    T.run(async () => { await Show.lowerGun(); T.aim = null; UI().setAim(null); UI().setPrompt('hud.promptTurn'); });
  };

  /* ------------------------------------------------------------ pause */
  T.pause = function (auto) {
    if (T.paused || !T.active) return false;
    T.paused = true; Anim.setPaused(true); Au.setPaused(true); UI().updateActions();
    return true;
  };
  T.resume = function () { if (!T.paused) return; T.paused = false; Anim.setPaused(false); Au.setPaused(false); Au.applyVolumes(); UI().updateActions(); };

  G.Turns = T;
})(typeof window !== 'undefined' ? window : globalThis);
