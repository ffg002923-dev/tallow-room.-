/* emotes.js — ONE emote button + a translucent picker. Every gesture is a real clip on the player's skeletal hands (data/animations.js, em_*),
   never a GIF. Works in the single-player room (hands animate) and in online matches (the same menu; the gesture shows to every player as a speech bubble above the seat,
   because the online screen is 2D). Gestures are refused while a gun/item action is running so they can never fight with gameplay. */
(function (G) {
  'use strict';
  const U = G.U, D = G.GameData, UI = G.UI;
  const $ = (id) => document.getElementById(id);
  const E = { open: false, cd: 0 };
  const NEW = [['mock', 'Mock', 'استهزاء', '😏'], ['laugh', 'Laugh', 'ضحك', '😂'], ['point', 'Point', 'إشارة', '👉'], ['anger', 'Anger', 'غضب', '😡'], ['surrender', 'Surrender', 'استسلام', '🏳'], ['knock', 'Knock', 'طرق', '✊']];
  const ICON = { ok: '👌', clap: '👏', welcome: '🙌', thumbs_up: '👍', thumbs_down: '👎', refuse: '✋', challenge: '🤏', wave: '👋', wonder: '😮', victory: '✌' };
  for (const [id, en, ar, ic] of NEW) { if (!D.emotes.includes(id)) D.emotes.push(id); D.strings.en['emote.' + id] = en; D.strings.ar['emote.' + id] = ar; ICON[id] = ic; }
  Object.assign(D.strings.en, { 'emote.btn': 'Emotes', 'emote.busy': 'Not now' }); Object.assign(D.strings.ar, { 'emote.btn': 'الحركات', 'emote.busy': 'ليس الآن' });
  E.icon = (id) => ICON[id] || '✋';

  E.canPlay = function () {
    const T = G.Turns; if (!T || !T.st) return false; if (E.cd > Date.now()) return false;
    const p = G.Anim && G.Anim.player; if (p && p.busy && p.busy()) return false;
    return T.st.phase === 'play' && !!(T.canAct ? T.canAct() : true);
  };
  /* single player: plays the gesture on the hands; the Dealer answers in his own style */
  E.play = function (id) {
    if (!D.emotes.includes(id) || !E.canPlay()) { if (UI) UI.toast(U.t('emote.busy'), 'info'); return false; }
    E.cd = Date.now() + 700; const A = G.Anim;
    try { if (A && A.player && A.player.play) A.player.play('em_' + id, { force: true }); } catch (e) { /* missing clip must never break the game */ }
    if (G.Progress) G.Progress.emote(id);
    if (G.Gameplay && G.Gameplay.dealerReact) setTimeout(() => G.Gameplay.dealerReact(id), 600);
    return true;
  };
  E.build = function (onPick) {
    let m = $('emoteMenu'); if (!m) { m = document.createElement('div'); m.id = 'emoteMenu'; m.className = 'emenu hidden'; m.setAttribute('role', 'menu'); ($('app') || document.body).appendChild(m); document.addEventListener('pointerdown', (e) => { if (E.open && !m.contains(e.target) && !e.target.closest('.emotebtn')) E.close(); }); }
    m.innerHTML = D.emotes.map((id) => '<button role="menuitem" data-e="' + id + '"><span class="ei">' + E.icon(id) + '</span><span class="en">' + U.t('emote.' + id) + '</span></button>').join('');
    m.querySelectorAll('button').forEach((b) => (b.onclick = () => { E.close(); onPick(b.dataset.e); }));
    return m;
  };
  E.toggle = function (onPick) { const m = E.build(onPick); E.open = !E.open; m.classList.toggle('hidden', !E.open); };
  E.close = function () { E.open = false; const m = $('emoteMenu'); if (m) m.classList.add('hidden'); };
  E.init = function () {
    const act = $('actions'); if (!act || $('btnEmote')) return;
    const b = document.createElement('button'); b.id = 'btnEmote'; b.className = 'gbtn sm emotebtn'; b.setAttribute('aria-label', 'Emotes'); b.innerHTML = '<span class="ei" style="font-size:1.3rem">✋</span><span class="cap" id="emCap"></span>';
    act.insertBefore(b, act.firstChild); $('emCap').textContent = U.t('emote.btn');
    b.onclick = () => E.toggle(E.play);
    const al = UI.applyLang; UI.applyLang = function () { al.apply(this, arguments); const c = $('emCap'); if (c) c.textContent = U.t('emote.btn'); E.close(); };
  };
  G.Emotes = E;
})(window);
